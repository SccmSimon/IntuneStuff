#Requires -Version 5.1
# Remediation: stage the latest HP BIOS using HP CMSL.
# Installs HP CMSL if missing (optional), checks power, flashes with BitLocker suspended for one restart.
# Never restarts the device. The BIOS applies at the next restart.

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
$ScriptVersion        = '1.1'
$RunId                = ([guid]::NewGuid().ToString()).Substring(0, 8)
$TargetModels         = @('HP EliteBook 645 14 inch G11 Notebook PC')   # empty @() = all HP models
$InstallCmslIfMissing = $true    # $false if HP CMSL is deployed separately
$BiosPassword         = ''       # leave empty unless a model needs it
$MinBatteryPercent    = 50
$start                = Get-Date
$exitCode             = 0
$summary              = 'No action taken'

$DataRoot   = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir     = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile    = Join-Path $LogDir 'HPBIOS-Remediation.log'
$MarkerFile = Join-Path $LogDir 'HPBIOS-Staged.json'
New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 5MB) {
    Move-Item -Path $LogFile -Destination "$LogFile.old" -Force
}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $RunId, $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}
function Write-Section { param([string]$Name) Write-Log "---- $Name ----" }

function ConvertTo-BiosVersion {
    param([string]$Text)
    $m = [regex]::Match([string]$Text, '(\d+)\.(\d+)\.(\d+)')
    if (-not $m.Success) { return $null }
    [version]('{0}.{1}.{2}' -f [int]$m.Groups[1].Value, [int]$m.Groups[2].Value, [int]$m.Groups[3].Value)
}

function Test-PowerReady {
    $batt = @(Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue | Where-Object { $_ })
    if ($batt.Count -eq 0) { Write-Log '  No battery present, power check passed'; return $true }
    # BatteryStatus 2 = on AC, 6 to 9 = charging
    $onAC   = @($batt | Where-Object { $_.BatteryStatus -in 2,6,7,8,9 }).Count -gt 0
    $charge = [int](($batt | Measure-Object -Property EstimatedChargeRemaining -Average).Average)
    Write-Log "  Battery: on AC $onAC, charge $charge% (minimum $MinBatteryPercent%)"
    $onAC -and ($charge -ge $MinBatteryPercent)
}

function Install-HPCMSL {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

    $nuget = Get-PackageProvider -ListAvailable -Name NuGet -ErrorAction SilentlyContinue |
             Where-Object { $_.Version -ge [version]'2.8.5.201' }
    if (-not $nuget) {
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope AllUsers | Out-Null
        Write-Log '  NuGet provider installed'
    }

    $psg = Get-Module -ListAvailable -Name PowerShellGet | Sort-Object Version -Descending | Select-Object -First 1
    if ($psg.Version -lt [version]'2.2.5') {
        Install-Module -Name PowerShellGet -Force -AllowClobber -Scope AllUsers -Repository PSGallery
        Write-Log '  PowerShellGet updated'
    }

    # New PowerShellGet only loads in a new session, so install HP CMSL in a child process
    $cmd = "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; " +
           "Import-Module PowerShellGet -MinimumVersion 2.2.5; " +
           "Install-Module -Name HPCMSL -Force -AcceptLicense -Scope AllUsers -Repository PSGallery"
    $out = & "$PSHOME\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command $cmd 2>&1
    foreach ($l in $out) { Write-Log "  Install: $l" }

    if (-not (Get-Module -ListAvailable -Name HPCMSL)) { throw 'HP CMSL install did not complete' }
    Write-Log '  HP CMSL installed'
}

try {
    Write-Log '=================================================================='
    Write-Log "HP BIOS remediation v$ScriptVersion started on $env:COMPUTERNAME"

    # ---- Device ----
    Write-Section 'Device'
    $cs    = Get-CimInstance -ClassName Win32_ComputerSystem
    $board = Get-CimInstance -ClassName Win32_BaseBoard -ErrorAction SilentlyContinue
    $os    = Get-CimInstance -ClassName Win32_OperatingSystem
    $model = ([string]$cs.Model).Trim()
    $boot  = $os.LastBootUpTime.ToString('o')
    Write-Log "Manufacturer: $($cs.Manufacturer) | Model: $model | Platform ID: $($board.Product)"

    if ([string]$cs.Manufacturer -notmatch '^(HP|Hewlett)') { $summary = "Not applicable: $($cs.Manufacturer)"; Write-Log $summary; return }
    if ($TargetModels.Count -gt 0 -and @($TargetModels | Where-Object { $_ -eq $model }).Count -eq 0) {
        $summary = "Not applicable: $model"; Write-Log $summary; return
    }

    # ---- Already staged this boot? ----
    if (Test-Path $MarkerFile) {
        $marker = Get-Content -Path $MarkerFile -Raw | ConvertFrom-Json
        if ($marker.BootTime -eq $boot) {
            $summary = "BIOS $($marker.TargetVersion) already staged, waiting for restart"
            Write-Log $summary
            return
        }
        Write-Log "Previous staging ($($marker.TargetVersion) at $($marker.StagedAt)) did not apply after restart, retrying" 'WARN'
        Remove-Item -Path $MarkerFile -Force -ErrorAction SilentlyContinue
    }

    # ---- HP CMSL ----
    Write-Section 'HP CMSL'
    if (-not (Get-Module -ListAvailable -Name HPCMSL)) {
        if (-not $InstallCmslIfMissing) { throw 'HP CMSL is not installed and auto-install is off' }
        Write-Log 'HP CMSL missing, installing from PowerShell Gallery'
        Install-HPCMSL
    }
    Import-Module HPCMSL -ErrorAction Stop
    Write-Log "HP CMSL version: $((Get-Module HPCMSL).Version)"

    # ---- Versions ----
    Write-Section 'BIOS versions'
    $curText    = Get-HPBIOSVersion
    $cur        = ConvertTo-BiosVersion $curText
    $latestInfo = Get-HPBIOSUpdates -Latest
    $latest     = ConvertTo-BiosVersion $latestInfo.Ver
    Write-Log "Installed: $curText | Latest from HP: $($latestInfo.Ver), released $($latestInfo.Date)"
    Write-Log "BIOS setup password set: $(Get-HPBIOSSetupPasswordIsSet)"

    if (-not $cur -or -not $latest) { throw "Could not parse versions (installed '$curText', latest '$($latestInfo.Ver)')" }
    if ($cur -ge $latest) {
        $summary = "BIOS $curText is already the latest"
        Write-Log $summary
        return
    }

    # ---- Power ----
    Write-Section 'Power check'
    if (-not (Test-PowerReady)) {
        $summary  = 'Skipped: not on AC power or battery below threshold, will retry next run'
        $exitCode = 1
        Write-Log $summary 'WARN'
        return
    }

    # ---- BitLocker (state for the log; CMSL suspends it) ----
    try {
        $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
        Write-Log "BitLocker on $($env:SystemDrive): $($bl.ProtectionStatus)"
    } catch { Write-Log "Could not read BitLocker state: $($_.Exception.Message)" 'WARN' }

    # ---- Flash ----
    Write-Section 'Flash'
    $flashArgs = @{ Flash = $true; Version = $latestInfo.Ver; BitLocker = 'suspend'; Yes = $true }
    if ($BiosPassword) { $flashArgs.Password = $BiosPassword; Write-Log 'Using BIOS password' }
    Write-Log "Running: Get-HPBIOSUpdates -Flash -Version $($latestInfo.Ver) -BitLocker suspend -Yes$(if ($BiosPassword) { ' -Password ***' })"

    $sw = [Diagnostics.Stopwatch]::StartNew()
    $cmslOut = Get-HPBIOSUpdates @flashArgs *>&1
    $sw.Stop()
    foreach ($l in $cmslOut) { if ("$l".Trim()) { Write-Log "  CMSL: $l" } }
    Write-Log ("Flash command completed in {0:N0}s" -f $sw.Elapsed.TotalSeconds)

    # Record the staging so detection knows a restart is pending
    [pscustomobject]@{
        TargetVersion = $latestInfo.Ver
        FromVersion   = $curText
        StagedAt      = (Get-Date).ToString('o')
        BootTime      = $boot
    } | ConvertTo-Json | Set-Content -Path $MarkerFile -Force

    $summary = "BIOS $($latestInfo.Ver) staged (from $curText). Applies at next restart."
    Write-Log $summary
}
catch {
    $summary  = "Fatal error at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    $exitCode = 1
    Write-Log $summary 'ERROR'
    Write-Log "Stack: $($_.ScriptStackTrace)" 'ERROR'
}
finally {
    Write-Section 'Result'
    $d = (Get-Date) - $start
    Write-Log ("  Exit code {0} | {1} | Run time: {2}m {3}s" -f $exitCode, $summary, [int][Math]::Floor($d.TotalMinutes), $d.Seconds)
    Write-Output $summary
    # exit sits inside finally so the early 'return' paths above still pass the right exit code to Intune
    exit $exitCode
}
