#Requires -Version 5.1
<#
  Win32 app install: installs HP CMSL (bundled) for all users, then stages the latest HP BIOS for this platform.
  No model or version is hard coded. The target is the latest BIOS HP publishes for the device's platform.
  Exit codes: 0 = already current or platform not supported, 3010 = staged (soft reboot),
              1618 = power not ready (Intune retries), 1 = failed.
  Never restarts the device itself. Intune handles the restart from the 3010 return code.
#>
param(
    [string]$BiosPassword = ''   # leave empty unless a model needs it
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
$ScriptVersion     = '2.2'
$RunId             = ([guid]::NewGuid().ToString()).Substring(0, 8)
$MinBatteryPercent = 50
$start             = Get-Date
$exitCode          = 1
$summary           = 'Not started'

$DataRoot   = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir     = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile    = Join-Path $LogDir 'HPBIOS-Win32Install.log'
$CacheFile  = Join-Path $LogDir 'HPBIOS-Latest.html'
$MarkerFile = Join-Path $LogDir 'HPBIOS-Staged.html'
New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 5MB) {
    Move-Item -Path $LogFile -Destination "$LogFile.old" -Force
}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $RunId, $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}
function Write-Section { param([string]$Name) Write-Log "---- $Name ----" }

# State files: readable HTML table for people, embedded JSON block for the scripts
function Save-StateFile {
    param([string]$Path, [object]$Data, [string]$Title)
    $json = $Data | ConvertTo-Json -Compress
    $rows = ($Data.PSObject.Properties | ForEach-Object {
        "<tr><th>$([System.Net.WebUtility]::HtmlEncode($_.Name))</th><td>$([System.Net.WebUtility]::HtmlEncode([string]$_.Value))</td></tr>"
    }) -join ''
    $html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>$Title</title></head><body>" +
            "<h1>$Title</h1><table border='1' cellpadding='4'>$rows</table>" +
            "<script type='application/json' id='state'>$json</script></body></html>"
    Set-Content -Path $Path -Value $html -Encoding UTF8 -Force
}

# '01.09.01', '1.09.01' or 'W77 Ver. 01.09.01' -> [version] 1.9.1
function ConvertTo-BiosVersion {
    param([string]$Text)
    $m = [regex]::Match([string]$Text, '(\d+)\.(\d+)\.(\d+)')
    if (-not $m.Success) { return $null }
    [version]('{0}.{1}.{2}' -f [int]$m.Groups[1].Value, [int]$m.Groups[2].Value, [int]$m.Groups[3].Value)
}

function Test-PowerReady {
    $batt = @(Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue | Where-Object { $_ })
    if ($batt.Count -eq 0) { Write-Log '  No battery present, power check passed'; return $true }
    # BatteryStatus 2 = on AC, 6 to 9 = charging
    $onAC   = @($batt | Where-Object { $_.BatteryStatus -in 2,6,7,8,9 }).Count -gt 0
    $charge = [int](($batt | Measure-Object -Property EstimatedChargeRemaining -Average).Average)
    Write-Log "  Battery: on AC $onAC, charge $charge% (minimum $MinBatteryPercent%)"
    $onAC -and ($charge -ge $MinBatteryPercent)
}

# Copy each bundled module version into the all-users module path, if not already there
function Install-BundledModules {
    param([string]$Source)
    $dest = Join-Path $env:ProgramFiles 'WindowsPowerShell\Modules'
    foreach ($mod in @(Get-ChildItem -Path $Source -Directory)) {
        foreach ($ver in @(Get-ChildItem -Path $mod.FullName -Directory)) {
            $target = Join-Path $dest (Join-Path $mod.Name $ver.Name)
            if (Test-Path $target) { Write-Log "  $($mod.Name) $($ver.Name) already installed"; continue }
            New-Item -Path (Split-Path $target -Parent) -ItemType Directory -Force | Out-Null
            Copy-Item -Path $ver.FullName -Destination $target -Recurse -Force
            Write-Log "  Installed $($mod.Name) $($ver.Name)"
        }
    }
}

# Network problem, platform not supported, or something else
function Get-LookupFailureType {
    param($ErrorRecord)
    $e = $ErrorRecord.Exception
    $msgs = @()
    while ($e) {
        if ($e -is [System.Net.WebException] -or $e.GetType().Name -match 'Http') { return 'Network' }
        $msgs += $e.Message
        $e = $e.InnerException
    }
    $all = $msgs -join ' '
    if ($all -match 'remote name|unable to connect|timed out|proxy|connection') { return 'Network' }
    if ($all -match 'not supported|unsupported|could not find|not found') { return 'Unsupported' }
    'Unknown'
}

function Save-LatestCache {
    param([string]$Platform, [bool]$Supported, [string]$Version, [string]$Date)
    $data = [pscustomobject]@{
        Platform      = $Platform
        Supported     = $Supported
        LatestVersion = $Version
        LatestDate    = $Date
        CheckedAt     = (Get-Date).ToString('o')
    }
    Save-StateFile -Path $CacheFile -Data $data -Title 'HP BIOS: latest version from HP'
}

try {
    Write-Log '=================================================================='
    Write-Log "HP BIOS Win32 install v$ScriptVersion started on $env:COMPUTERNAME"

    # Remove state files from earlier versions
    foreach ($old in 'HPBIOS-Latest.json', 'HPBIOS-Staged.json') {
        $p = Join-Path $LogDir $old
        if (Test-Path $p) { Remove-Item -Path $p -Force -ErrorAction SilentlyContinue; Write-Log "Removed legacy file $old" }
    }

    # ---- Device ----
    Write-Section 'Device'
    $cs       = Get-CimInstance -ClassName Win32_ComputerSystem
    $os       = Get-CimInstance -ClassName Win32_OperatingSystem
    $platform = [string](Get-CimInstance -ClassName Win32_BaseBoard -ErrorAction SilentlyContinue).Product
    $boot     = $os.LastBootUpTime.ToString('o')
    Write-Log "Manufacturer: $($cs.Manufacturer) | Model: $($cs.Model) | Platform ID: $platform"
    Write-Log "Running as: $([Security.Principal.WindowsIdentity]::GetCurrent().Name), 64-bit: $([Environment]::Is64BitProcess)"

    if ([string]$cs.Manufacturer -notmatch '^(HP|Hewlett)') {
        $summary  = "Not an HP device ($($cs.Manufacturer)), nothing to do. Check the app requirement rule."
        $exitCode = 0
        Write-Log $summary 'WARN'
        return
    }

    # ---- HP CMSL ----
    Write-Section 'HP CMSL'
    $bundled = Join-Path $PSScriptRoot 'Modules'
    if (Test-Path $bundled) {
        Install-BundledModules -Source $bundled
    } else {
        Write-Log 'No bundled Modules folder in the package' 'WARN'
    }
    if (-not (Get-Module -ListAvailable -Name HPCMSL)) { throw 'HP CMSL is not available after install' }
    Import-Module HPCMSL -Force -ErrorAction Stop
    Write-Log "HP CMSL loaded: $((Get-Module HPCMSL).Version)"

    # ---- Versions ----
    Write-Section 'BIOS versions'
    $curText = Get-HPBIOSVersion
    $cur     = ConvertTo-BiosVersion $curText
    Write-Log "Installed: $curText"
    try { Write-Log "BIOS setup password set: $(Get-HPBIOSSetupPasswordIsSet)" } catch { }

    try {
        $latestInfo = Get-HPBIOSUpdates -Latest
    } catch {
        $type = Get-LookupFailureType -ErrorRecord $_
        Write-Log "HP lookup failed ($type): $($_.Exception.Message)" 'WARN'
        if ($type -eq 'Unsupported') {
            Save-LatestCache -Platform $platform -Supported $false -Version '' -Date ''
            $summary  = "Platform $platform is not supported for BIOS updates by HP CMSL. Recorded and skipped."
            $exitCode = 0
            Write-Log $summary 'WARN'
            return
        }
        throw "Could not get the latest BIOS from HP ($type): $($_.Exception.Message)"
    }

    Save-LatestCache -Platform $platform -Supported $true -Version ([string]$latestInfo.Ver) -Date ([string]$latestInfo.Date)
    $latest = ConvertTo-BiosVersion $latestInfo.Ver
    Write-Log "Latest from HP: $($latestInfo.Ver), released $($latestInfo.Date), file $($latestInfo.Bin)"

    if (-not $cur -or -not $latest) { throw "Could not parse versions (installed '$curText', latest '$($latestInfo.Ver)')" }
    if ($cur -ge $latest) {
        $summary  = "BIOS $curText is already the latest"
        $exitCode = 0
        Write-Log $summary
        return
    }

    # ---- Power ----
    Write-Section 'Power check'
    if (-not (Test-PowerReady)) {
        $summary  = 'Power not ready (needs AC and battery at minimum level). Returning 1618 so Intune retries.'
        $exitCode = 1618
        Write-Log $summary 'WARN'
        return
    }

    try {
        $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
        Write-Log "BitLocker on $($env:SystemDrive): $($bl.ProtectionStatus)"
    } catch { Write-Log "Could not read BitLocker state: $($_.Exception.Message)" 'WARN' }

    # ---- Flash ----
    Write-Section 'Flash'
    $flashArgs = @{ Flash = $true; Version = $latestInfo.Ver; BitLocker = 'suspend'; Yes = $true }
    if ($BiosPassword) { $flashArgs.Password = $BiosPassword }
    Write-Log "Running: Get-HPBIOSUpdates -Flash -Version $($latestInfo.Ver) -BitLocker suspend -Yes$(if ($BiosPassword) { ' -Password ***' })"

    $sw = [Diagnostics.Stopwatch]::StartNew()
    $cmslOut = Get-HPBIOSUpdates @flashArgs *>&1
    $sw.Stop()
    foreach ($l in $cmslOut) { if ("$l".Trim()) { Write-Log "  CMSL: $l" } }
    Write-Log ("Flash command completed in {0:N0}s" -f $sw.Elapsed.TotalSeconds)

    # Marker lets detection report 'installed' until the restart applies the flash
    $marker = [pscustomobject]@{
        TargetVersion = [string]$latestInfo.Ver
        FromVersion   = $curText
        StagedAt      = (Get-Date).ToString('o')
        BootTime      = $boot
    }
    Save-StateFile -Path $MarkerFile -Data $marker -Title 'HP BIOS: flash staged, restart pending'

    $summary  = "BIOS $($latestInfo.Ver) staged (from $curText). Applies at next restart."
    $exitCode = 3010
    Write-Log $summary
}
catch {
    $summary  = "Failed at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    $exitCode = 1
    Write-Log $summary 'ERROR'
    Write-Log "Stack: $($_.ScriptStackTrace)" 'ERROR'
}
finally {
    Write-Section 'Result'
    $d = (Get-Date) - $start
    Write-Log ("  Exit code {0} | {1} | Run time: {2}m {3}s" -f $exitCode, $summary, [int][Math]::Floor($d.TotalMinutes), $d.Seconds)
    # exit sits inside finally so the early 'return' paths above still pass the right exit code to Intune
    exit $exitCode
}
