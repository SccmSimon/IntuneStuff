# Win32 app requirement rule: HP devices only.
# Intune setting: output data type String, operator Equals, value Applicable, run as 64-bit.
if ([string](Get-CimInstance -ClassName Win32_ComputerSystem).Manufacturer -match '^(HP|Hewlett)') {
    Write-Output 'Applicable'
} else {
    Write-Output 'NotApplicable'
}
