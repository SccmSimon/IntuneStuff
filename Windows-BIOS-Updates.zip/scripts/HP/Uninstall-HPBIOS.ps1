#Requires -Version 5.1
<#
  Win32 app uninstall for "HP CMSL and BIOS Update".
  Removes what the install added: HP CMSL (all-users modules) and the app's state files.

  It does NOT roll back the BIOS. A flashed BIOS stays at its new version, because a BIOS
  downgrade is a separate, deliberate action (and HP often blocks it for security fixes).

  Uninstall command:
    %SystemRoot%\sysnative\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Uninstall-HPBIOS.ps1
  Keep HP CMSL (for example, if other remediations use it), remove only the state files:
    ... -File .\Uninstall-HPBIOS.ps1 -KeepCMSL

  Exit codes: 0 = removed (or nothing to remove), 1 = something could not be removed (see log).
#>
param(
    [switch]$KeepCMSL
)

$ErrorActionPreference = 'Stop'
$ScriptVersion = '1.0'
$RunId         = ([guid]::NewGuid().ToString()).Substring(0, 8)
$exitCode      = 0
$summary       = 'Not started'
$failures      = New-Object System.Collections.Generic.List[string]

$DataRoot   = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir     = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile    = Join-Path $LogDir 'HPBIOS-Win32Uninstall.log'
$ModuleRoot = Join-Path $env:ProgramFiles 'WindowsPowerShell\Modules'

# Every module HP CMSL installs. The list is extended at run time from HPCMSL's own manifest,
# so modules added in later CMSL versions are removed too.
$CmslModules = @('HPCMSL', 'HP.Private', 'HP.Utility', 'HP.ClientManagement', 'HP.Firmware', 'HP.Repo',
                 'HP.Sinks', 'HP.Softpaq', 'HP.Consent', 'HP.Retail', 'HP.Notifications', 'HP.SmartExperiences',
                 'HP.Displays', 'HP.Security', 'HP.Docks', 'HP.WorkforceExperience')

# State files written by the install, detection and remediation scripts (logs are kept)
$StateFiles = @('HPBIOS-Latest.html', 'HPBIOS-Staged.html', 'HPBIOS-Latest.json', 'HPBIOS-Staged.json')

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $RunId, $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}

# Names of the modules HPCMSL depends on, read from each installed HPCMSL manifest
function Get-CmslDependencies {
    $names = @()
    $cmslDir = Join-Path $ModuleRoot 'HPCMSL'
    if (-not (Test-Path $cmslDir)) { return $names }
    foreach ($psd1 in @(Get-ChildItem -Path $cmslDir -Filter 'HPCMSL.psd1' -File -Recurse -ErrorAction SilentlyContinue)) {
        try {
            $data = Import-PowerShellDataFile -Path $psd1.FullName
            foreach ($r in @($data.RequiredModules)) {
                if ($r -is [string]) { $names += $r }
                elseif ($r.ModuleName) { $names += $r.ModuleName }
            }
        } catch { Write-Log "Could not read $($psd1.FullName): $($_.Exception.Message)" 'WARN' }
    }
    $names | Where-Object { $_ -match '^HP' }
}

New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 5MB) { Move-Item -Path $LogFile -Destination "$LogFile.old" -Force }

try {
    Write-Log '=================================================================='
    Write-Log "HP BIOS Win32 uninstall v$ScriptVersion started on $env:COMPUTERNAME (KeepCMSL: $KeepCMSL)"
    try { Write-Log "Installed BIOS: $((Get-CimInstance -ClassName Win32_BIOS).SMBIOSBIOSVersion) (left as is, a BIOS is not rolled back)" } catch { }

    # ---- HP CMSL ----
    if ($KeepCMSL) {
        Write-Log 'HP CMSL kept on the device (-KeepCMSL)'
    } else {
        $names = @($CmslModules + (Get-CmslDependencies) | Select-Object -Unique)
        Write-Log "Modules to remove if present: $($names -join ', ')"
        Write-Log 'Any remediation that imports HPCMSL will fail on this device until HP CMSL is installed again' 'WARN'

        $removed = 0
        foreach ($n in $names) {
            $dir = Join-Path $ModuleRoot $n
            if (-not (Test-Path $dir)) { continue }
            $versions = @(Get-ChildItem -Path $dir -Directory -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) -join ', '
            try {
                Remove-Item -Path $dir -Recurse -Force
                $removed++
                Write-Log "  Removed $n ($versions)"
            } catch {
                # A file in use (a PowerShell session with the module loaded) blocks the delete
                $failures.Add($n)
                Write-Log "  Could not remove $n ($versions): $($_.Exception.Message)" 'ERROR'
            }
        }
        Write-Log "HP CMSL modules removed: $removed"
    }

    # ---- State files ----
    foreach ($f in $StateFiles) {
        $p = Join-Path $LogDir $f
        if (-not (Test-Path $p)) { continue }
        try { Remove-Item -Path $p -Force; Write-Log "Removed state file $f" }
        catch { $failures.Add($f); Write-Log "Could not remove $f`: $($_.Exception.Message)" 'ERROR' }
    }

    if ($failures.Count -gt 0) {
        $exitCode = 1
        $summary  = "Uninstall incomplete, could not remove: $($failures -join ', '). Close any PowerShell sessions using HP CMSL, or restart, then retry."
    } else {
        $summary  = if ($KeepCMSL) { 'State files removed, HP CMSL kept' } else { 'HP CMSL and state files removed' }
    }
}
catch {
    $exitCode = 1
    $summary  = "Failed at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    Write-Log $summary 'ERROR'
}
finally {
    Write-Log "Result: exit $exitCode | $summary"
    # exit sits inside finally so every path passes the right exit code to Intune
    exit $exitCode
}
