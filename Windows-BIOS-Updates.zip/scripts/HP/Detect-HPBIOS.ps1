# Win32 app detection: HP CMSL installed and HP BIOS at the latest version HP publishes for this platform.
# No model or version is hard coded. The target comes from HP at run time, cached for $CacheHours.
# Detected = exit 0 WITH output. Not detected = exit 0 with NO output.

$ProgressPreference = 'SilentlyContinue'
$CacheHours = 12
$StateDir   = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs'
$LogFile    = Join-Path $StateDir 'HPBIOS-Detection.log'
$CacheFile  = Join-Path $StateDir 'HPBIOS-Latest.html'
$MarkerFile = Join-Path $StateDir 'HPBIOS-Staged.html'

function Write-Log {
    param([string]$Message)
    try { Add-Content -Path $LogFile -Value ("{0:yyyy-MM-dd HH:mm:ss} {1}" -f (Get-Date), $Message) } catch { }
}
function Set-Detected    { param([string]$Reason) Write-Log "DETECTED: $Reason"; Write-Output "Detected: $Reason"; exit 0 }
function Set-NotDetected { param([string]$Reason) Write-Log "NOT DETECTED: $Reason"; exit 0 }

function Save-StateFile {
    param([string]$Path, [object]$Data, [string]$Title)
    $json = $Data | ConvertTo-Json -Compress
    $rows = ($Data.PSObject.Properties | ForEach-Object {
        "<tr><th>$([System.Net.WebUtility]::HtmlEncode($_.Name))</th><td>$([System.Net.WebUtility]::HtmlEncode([string]$_.Value))</td></tr>"
    }) -join ''
    $html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>$Title</title></head><body>" +
            "<h1>$Title</h1><table border='1' cellpadding='4'>$rows</table>" +
            "<script type='application/json' id='state'>$json</script></body></html>"
    Set-Content -Path $Path -Value $html -Encoding UTF8 -Force
}
function Read-StateFile {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return $null }
    try {
        $m = [regex]::Match((Get-Content -Path $Path -Raw), "<script type='application/json' id='state'>(.*?)</script>",
                            [System.Text.RegularExpressions.RegexOptions]::Singleline)
        if (-not $m.Success) { return $null }
        $m.Groups[1].Value | ConvertFrom-Json
    } catch { $null }
}

function ConvertTo-BiosVersion {
    param([string]$Text)
    $m = [regex]::Match([string]$Text, '(\d+)\.(\d+)\.(\d+)')
    if (-not $m.Success) { return $null }
    [version]('{0}.{1}.{2}' -f [int]$m.Groups[1].Value, [int]$m.Groups[2].Value, [int]$m.Groups[3].Value)
}

try {
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem
    if ([string]$cs.Manufacturer -notmatch '^(HP|Hewlett)') { Set-Detected "not an HP device ($($cs.Manufacturer))" }
    $platform = [string](Get-CimInstance -ClassName Win32_BaseBoard -ErrorAction SilentlyContinue).Product

    # 1. HP CMSL must be installed for all users
    if (-not (Get-Module -ListAvailable -Name HPCMSL)) { Set-NotDetected 'HP CMSL not installed' }
    Import-Module HPCMSL -ErrorAction Stop

    # 2. Installed BIOS
    $curText = Get-HPBIOSVersion
    $cur     = ConvertTo-BiosVersion $curText

    # 3. Latest BIOS from HP, cached
    $cache      = Read-StateFile -Path $CacheFile
    $cacheValid = $cache -and $cache.Platform -eq $platform
    $cacheFresh = $cacheValid -and ((Get-Date) - [datetime]$cache.CheckedAt).TotalHours -lt $CacheHours

    if (-not $cacheFresh) {
        try {
            $li = Get-HPBIOSUpdates -Latest
            $cache = [pscustomobject]@{
                Platform      = $platform
                Supported     = $true
                LatestVersion = [string]$li.Ver
                LatestDate    = [string]$li.Date
                CheckedAt     = (Get-Date).ToString('o')
            }
            Save-StateFile -Path $CacheFile -Data $cache -Title 'HP BIOS: latest version from HP'
        } catch {
            Write-Log "HP lookup failed: $($_.Exception.Message)"
            if (-not $cacheValid) { Set-NotDetected 'latest BIOS unknown (HP lookup failed and no cached result)' }
            Write-Log "Using cached result from $($cache.CheckedAt)"
        }
    }

    if ($cache.Supported -eq $false) { Set-Detected "platform $platform not supported for BIOS updates by HP CMSL" }

    $latest = ConvertTo-BiosVersion $cache.LatestVersion
    if (-not $cur -or -not $latest) { Set-NotDetected "could not parse versions (installed '$curText', latest '$($cache.LatestVersion)')" }

    # 4. Current?
    if ($cur -ge $latest) { Set-Detected "BIOS $curText is the latest ($($cache.LatestVersion))" }

    # 5. Latest staged in this boot session?
    $m = Read-StateFile -Path $MarkerFile
    if ($m) {
        $boot   = (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime.ToString('o')
        $staged = ConvertTo-BiosVersion $m.TargetVersion
        if ($m.BootTime -eq $boot -and $staged -and $staged -ge $latest) {
            Set-Detected "BIOS $($m.TargetVersion) staged, restart pending (installed $curText)"
        }
        if ($m.BootTime -ne $boot) { Write-Log "Staged $($m.TargetVersion) at $($m.StagedAt) did not apply after restart" }
    }

    Set-NotDetected "BIOS $curText is older than latest $($cache.LatestVersion)"
}
catch {
    Set-NotDetected "error: $($_.Exception.Message)"
}
