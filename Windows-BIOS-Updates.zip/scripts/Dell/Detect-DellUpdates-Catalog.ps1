#Requires -Version 5.1
<#
  Detection: missing Dell BIOS and driver updates, using Dell catalogue XML files (no Dell Command | Update needed).
  Finds this device's catalogue by System ID (Win32_ComputerSystem.SystemSKUNumber), then compares:
    BIOS    : installed BIOS version against the newest BIOS in the catalogue
    Drivers : each installed PCI / HD Audio driver against the newest catalogue driver for that hardware
  Read-only, changes nothing.
  Exit 0 = up to date or not applicable. Exit 1 = updates available, or the check could not run.
#>
param(
    [string]$CatalogRoot = 'C:\ProgramData\DellCatalogs'   # local folder or UNC path holding the extracted .xml catalogues
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
$ScriptVersion      = '1.0'
$RunId              = ([guid]::NewGuid().ToString()).Substring(0, 8)
$CheckDrivers       = $true    # $false = BIOS only
$MaxCatalogAgeDays  = 14       # warn when the catalogue is older than this
$DellNs             = 'openmanage/cm/dm'

$DataRoot   = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir     = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile    = Join-Path $LogDir 'DellCatalog-Detection.log'
$ReportFile = Join-Path $LogDir 'DellCatalog-Report.html'

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $RunId, $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}
function Write-Section { param([string]$Name) Write-Log "---- $Name ----" }

# Version text to [version], using the first four numeric parts ('1.49.0', '32.0.101.7088', '6.0.9954.2')
function ConvertTo-Ver {
    param([string]$Text)
    $nums = @([regex]::Matches([string]$Text, '\d+') | Select-Object -First 4 | ForEach-Object { [int64]$_.Value })
    if ($nums.Count -eq 0) { return $null }
    while ($nums.Count -lt 2) { $nums += 0 }
    try { [version]($nums -join '.') } catch { $null }
}

# Find the catalogue for this System ID: filename first (Model_0A69.xml), then file contents
function Find-Catalog {
    param([string]$Root, [string]$SystemId)
    $files = @(Get-ChildItem -Path $Root -Filter '*.xml' -File -Recurse -ErrorAction Stop)
    $byName = $files | Where-Object { $_.BaseName -match "(^|_)$([regex]::Escape($SystemId))$" } | Select-Object -First 1
    if ($byName) { return $byName }
    foreach ($f in $files) {
        if (Select-String -Path $f.FullName -Pattern "systemID=`"$([regex]::Escape($SystemId))`"" -SimpleMatch:$false -Quiet) { return $f }
    }
    $null
}

# Reads the catalogue: newest BIOS for the System ID, plus an index of driver hardware -> newest version
function Read-DellCatalog {
    param([string]$Path, [string]$SystemId, [string]$OsFamily)   # OsFamily: 'Windows 10' or 'Windows 11'
    [xml]$xml = Get-Content -Path $Path -Raw
    $nsm = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
    $nsm.AddNamespace('d', $DellNs)

    $manifest = $xml.DocumentElement
    $bios     = $null
    $drivers  = @{}   # key 'VEN_xxxx&DEV_yyyy' -> list of entries

    foreach ($c in $xml.SelectNodes('/d:Manifest/d:SoftwareComponent', $nsm)) {
        $type = $c.SelectSingleNode('d:ComponentType', $nsm).GetAttribute('value')
        if ($type -notin 'BIOS', 'DRVR') { continue }

        # Must apply to this System ID
        if (-not $c.SelectSingleNode("d:SupportedSystems/d:Brand/d:Model[@systemID='$SystemId']", $nsm)) { continue }

        $name = $c.SelectSingleNode('d:Name/d:Display', $nsm).InnerText
        $crit = $c.SelectSingleNode('d:Criticality/d:Display', $nsm)
        $info = [pscustomobject]@{
            Name        = $name
            Version     = $c.GetAttribute('vendorVersion')
            DellVersion = $c.GetAttribute('dellVersion')
            ReleaseDate = $c.GetAttribute('releaseDate')
            ReleaseId   = $c.GetAttribute('releaseID')
            Criticality = if ($crit) { $crit.InnerText } else { '' }
            Path        = $c.GetAttribute('path')
        }

        if ($type -eq 'BIOS') {
            $v = ConvertTo-Ver $info.Version
            if ($v -and (-not $bios -or $v -gt $bios.Ver)) { $bios = $info | Add-Member -NotePropertyName Ver -NotePropertyValue $v -PassThru }
            continue
        }

        # Drivers: must support this OS family on x64 (Dell lists 'Windows 11', 'Windows 10 64-Bit' and so on)
        $osOk = $false
        foreach ($os in $c.SelectNodes('d:SupportedOperatingSystems/d:OperatingSystem', $nsm)) {
            $osText = $os.SelectSingleNode('d:Display', $nsm).InnerText
            if ($os.GetAttribute('osArch') -eq 'x64' -and $osText -match "^$OsFamily(\s|$)" -and $osText -notmatch 'ARM|IOT|\bSE\b|Teams') { $osOk = $true; break }
        }
        if (-not $osOk) { continue }

        foreach ($dev in $c.SelectNodes('.//d:Device[d:PCIInfo]', $nsm)) {
            $dv = $dev.GetAttribute('version'); if (-not $dv) { $dv = $info.Version }
            $ver = ConvertTo-Ver $dv
            if (-not $ver) { continue }
            foreach ($pci in $dev.SelectNodes('d:PCIInfo', $nsm)) {
                $key = ('VEN_{0}&DEV_{1}' -f $pci.GetAttribute('vendorID'), $pci.GetAttribute('deviceID')).ToUpper()
                if (-not $drivers.ContainsKey($key)) { $drivers[$key] = New-Object System.Collections.Generic.List[object] }
                $drivers[$key].Add([pscustomobject]@{
                    SubVen = $pci.GetAttribute('subVendorID').ToUpper()
                    SubDev = $pci.GetAttribute('subDeviceID').ToUpper()
                    Ver    = $ver
                    VerText = $dv
                    Info   = $info
                })
            }
        }
    }

    [pscustomobject]@{
        CatalogVersion = $manifest.GetAttribute('version')
        CatalogDate    = $manifest.GetAttribute('dateTime')
        Bios           = $bios
        Drivers        = $drivers
    }
}

# Newest catalogue driver that matches an installed device's hardware ID, or $null
function Find-CatalogDriver {
    param([hashtable]$Index, [string]$DeviceId)
    $m = [regex]::Match($DeviceId, 'VEN_([0-9A-F]{4})&DEV_([0-9A-F]{4})', 'IgnoreCase')
    if (-not $m.Success) { return $null }
    $key = ('VEN_{0}&DEV_{1}' -f $m.Groups[1].Value, $m.Groups[2].Value).ToUpper()
    if (-not $Index.ContainsKey($key)) { return $null }

    $sub = [regex]::Match($DeviceId, 'SUBSYS_([0-9A-F]{8})', 'IgnoreCase')
    $subsys = if ($sub.Success) { $sub.Groups[1].Value.ToUpper() } else { '' }

    $best = $null
    foreach ($e in $Index[$key]) {
        $match = if ($e.SubVen -and $e.SubDev) {
            # PCI writes SUBSYS as device+vendor, HD Audio as vendor+device
            $subsys -and ($subsys -eq "$($e.SubDev)$($e.SubVen)" -or $subsys -eq "$($e.SubVen)$($e.SubDev)")
        } else { $true }
        if ($match -and (-not $best -or $e.Ver -gt $best.Ver)) { $best = $e }
    }
    $best
}

function Save-HtmlReport {
    param([object[]]$Rows, [string]$Title, [string]$Summary)
    $enc = { param($s) [System.Net.WebUtility]::HtmlEncode([string]$s) }
    $body = ($Rows | ForEach-Object {
        "<tr><td>$(& $enc $_.Type)</td><td>$(& $enc $_.Name)</td><td>$(& $enc $_.Installed)</td><td>$(& $enc $_.Latest)</td><td>$(& $enc $_.Released)</td><td>$(& $enc $_.Criticality)</td><td>$(& $enc $_.ReleaseId)</td></tr>"
    }) -join ''
    if (-not $body) { $body = "<tr><td colspan='7'>No updates available</td></tr>" }
    $html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>$Title</title></head><body>" +
            "<h1>$(& $enc $Title)</h1><p>$(& $enc $Summary)</p><p>Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm') on $env:COMPUTERNAME</p>" +
            "<table border='1' cellpadding='4'><tr><th>Type</th><th>Name</th><th>Installed</th><th>Latest</th><th>Released</th><th>Criticality</th><th>Release ID</th></tr>$body</table>" +
            "</body></html>"
    Set-Content -Path $ReportFile -Value $html -Encoding UTF8 -Force
}

# Stop here when dot-sourced for testing
if ($MyInvocation.InvocationName -eq '.') { return }

New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 5MB) {
    Move-Item -Path $LogFile -Destination "$LogFile.old" -Force
}

try {
    Write-Log '=================================================================='
    Write-Log "Dell catalogue detection v$ScriptVersion started on $env:COMPUTERNAME"

    # ---- Device ----
    Write-Section 'Device'
    $cs   = Get-CimInstance -ClassName Win32_ComputerSystem
    $bios = Get-CimInstance -ClassName Win32_BIOS
    $os   = Get-CimInstance -ClassName Win32_OperatingSystem
    $sku  = ([string]$cs.SystemSKUNumber).Trim().ToUpper()
    Write-Log "Manufacturer: $($cs.Manufacturer) | Model: $($cs.Model) | System ID: $sku"
    $osFamily = if ([int]$os.BuildNumber -ge 22000) { 'Windows 11' } else { 'Windows 10' }
    Write-Log "OS: $($os.Caption), build $($os.BuildNumber) ($osFamily) | BIOS: $($bios.SMBIOSBIOSVersion)"

    if ([string]$cs.Manufacturer -notmatch '^Dell') {
        Write-Log 'Result: Not applicable, not a Dell device'
        Write-Output "Not applicable: $($cs.Manufacturer)"
        exit 0
    }
    if (-not $sku) { throw 'System ID (SystemSKUNumber) is empty' }

    # ---- Catalogue ----
    Write-Section 'Catalogue'
    if (-not (Test-Path $CatalogRoot)) { throw "Catalogue folder not reachable: $CatalogRoot" }
    $file = Find-Catalog -Root $CatalogRoot -SystemId $sku
    if (-not $file) {
        Write-Log "No catalogue found for System ID $sku in $CatalogRoot" 'WARN'
        Write-Output "No Dell catalogue for System ID $sku ($($cs.Model)). Add it to $CatalogRoot"
        exit 1
    }
    Write-Log "Catalogue: $($file.FullName)"

    $sw  = [Diagnostics.Stopwatch]::StartNew()
    $cat = Read-DellCatalog -Path $file.FullName -SystemId $sku -OsFamily $osFamily
    $sw.Stop()
    Write-Log ("Read in {0:N1}s | Catalogue version {1}, dated {2} | Driver hardware IDs indexed: {3}" -f $sw.Elapsed.TotalSeconds, $cat.CatalogVersion, $cat.CatalogDate, $cat.Drivers.Count)

    $catAgeNote = ''
    try {
        $age = [int]((Get-Date) - [datetime]$cat.CatalogDate).TotalDays
        Write-Log "Catalogue age: $age days"
        if ($age -gt $MaxCatalogAgeDays) {
            $catAgeNote = " (catalogue is $age days old)"
            Write-Log "Catalogue is older than $MaxCatalogAgeDays days, newer Dell releases may be missing" 'WARN'
        }
    } catch { }

    $findings = New-Object System.Collections.Generic.List[object]

    # ---- BIOS ----
    Write-Section 'BIOS'
    $curBios = ConvertTo-Ver $bios.SMBIOSBIOSVersion
    if (-not $cat.Bios) {
        Write-Log "No BIOS listed for System ID $sku in this catalogue" 'WARN'
    } elseif (-not $curBios) {
        Write-Log "Could not parse installed BIOS version '$($bios.SMBIOSBIOSVersion)'" 'WARN'
    } else {
        Write-Log "Installed: $($bios.SMBIOSBIOSVersion) | Latest: $($cat.Bios.Version), released $($cat.Bios.ReleaseDate), criticality $($cat.Bios.Criticality)"
        if ($curBios -lt $cat.Bios.Ver) {
            $findings.Add([pscustomobject]@{
                Type = 'BIOS'; Name = $cat.Bios.Name; Installed = $bios.SMBIOSBIOSVersion; Latest = $cat.Bios.Version
                Released = $cat.Bios.ReleaseDate; Criticality = $cat.Bios.Criticality; ReleaseId = $cat.Bios.ReleaseId
            })
            Write-Log '  BIOS update available' 'WARN'
        } else {
            Write-Log '  BIOS is current'
        }
    }

    # ---- Drivers ----
    if ($CheckDrivers) {
        Write-Section 'Drivers'
        $installed = @(Get-CimInstance -ClassName Win32_PnPSignedDriver -ErrorAction Stop |
                       Where-Object { $_.DeviceID -match 'VEN_[0-9A-F]{4}&DEV_[0-9A-F]{4}' -and $_.DriverVersion })
        Write-Log "Installed PCI / HD Audio devices with drivers: $($installed.Count)"

        $matched = 0
        $seen = @{}
        foreach ($d in $installed) {
            $hit = Find-CatalogDriver -Index $cat.Drivers -DeviceId $d.DeviceID
            if (-not $hit) { continue }
            $matched++
            $iv = ConvertTo-Ver $d.DriverVersion
            $state = if (-not $iv) { 'unparsed' } elseif ($iv -lt $hit.Ver) { 'OUTDATED' } else { 'current' }
            Write-Log ("  {0,-8} | {1} | installed {2} | catalogue {3} ({4})" -f $state, $d.DeviceName, $d.DriverVersion, $hit.VerText, $hit.Info.Name) $(if ($state -eq 'OUTDATED') { 'WARN' } else { 'INFO' })

            # One finding per Dell package
            if ($state -eq 'OUTDATED' -and -not $seen.ContainsKey($hit.Info.ReleaseId)) {
                $seen[$hit.Info.ReleaseId] = $true
                $findings.Add([pscustomobject]@{
                    Type = 'Driver'; Name = $hit.Info.Name; Installed = $d.DriverVersion; Latest = $hit.VerText
                    Released = $hit.Info.ReleaseDate; Criticality = $hit.Info.Criticality; ReleaseId = $hit.Info.ReleaseId
                })
            }
        }
        Write-Log "Devices matched to the catalogue: $matched"
    }

    # ---- Summary ----
    Write-Section 'Summary'
    $nb = @($findings | Where-Object Type -eq 'BIOS').Count
    $nd = @($findings | Where-Object Type -eq 'Driver').Count
    $summary = if ($findings.Count) { "Dell updates available: BIOS $nb, drivers $nd$catAgeNote" } else { "No Dell BIOS or driver updates outstanding$catAgeNote" }
    try { Save-HtmlReport -Rows $findings -Title "Dell updates: $($cs.Model) ($sku)" -Summary $summary; Write-Log "Report: $ReportFile" }
    catch { Write-Log "Report write failed: $($_.Exception.Message)" 'WARN' }
    Write-Log "  $summary"

    if ($findings.Count -gt 0) {
        $list = ($findings | ForEach-Object { "[$($_.Type)] $($_.Name) $($_.Installed) -> $($_.Latest)" }) -join '; '
        if ($list.Length -gt 900) { $list = $list.Substring(0, 900) + '...' }
        Write-Log 'Result: UPDATES AVAILABLE' 'WARN'
        Write-Output "$summary`: $list"
        exit 1
    }

    Write-Log "Result: $summary"
    Write-Output "Compliant: $summary (BIOS $($bios.SMBIOSBIOSVersion))"
    exit 0
}
catch {
    $msg = "Fatal error at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    Write-Log $msg 'ERROR'
    Write-Log "Stack: $($_.ScriptStackTrace)" 'ERROR'
    Write-Output $msg
    exit 1
}
