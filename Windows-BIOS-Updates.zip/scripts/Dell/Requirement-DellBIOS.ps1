# Win32 app requirement rule: Dell devices only.
# Intune setting: output data type String, operator Equals, value Applicable, run as 64-bit.
if ([string](Get-CimInstance -ClassName Win32_ComputerSystem).Manufacturer -match '^Dell') {
    Write-Output 'Applicable'
} else {
    Write-Output 'NotApplicable'
}
