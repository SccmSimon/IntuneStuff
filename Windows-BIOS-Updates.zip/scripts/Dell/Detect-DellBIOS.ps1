# Win32 app detection: Dell Command | Update installed and the Dell BIOS at the latest version DCU offers.
# No model or version is hard coded. The latest comes from a DCU scan, cached for $CacheHours.
# Detected = exit 0 WITH output. Not detected = exit 0 with NO output.

$ProgressPreference = 'SilentlyContinue'
$CacheHours = 12
$StateDir   = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs'
$LogFile    = Join-Path $StateDir 'DellBIOS-Detection.log'
$CacheFile  = Join-Path $StateDir 'DellBIOS-Latest.html'
$MarkerFile = Join-Path $StateDir 'DellBIOS-Staged.html'

function Write-Log {
    param([string]$Message)
    try { Add-Content -Path $LogFile -Value ("{0:yyyy-MM-dd HH:mm:ss} {1}" -f (Get-Date), $Message) } catch { }
}
function Set-Detected    { param([string]$Reason) Write-Log "DETECTED: $Reason"; Write-Output "Detected: $Reason"; exit 0 }
function Set-NotDetected { param([string]$Reason) Write-Log "NOT DETECTED: $Reason"; exit 0 }

function Save-StateFile {
    param([string]$Path, [object]$Data, [string]$Title)
    $json = $Data | ConvertTo-Json -Compress
    $rows = ($Data.PSObject.Properties | ForEach-Object {
        "<tr><th>$([System.Net.WebUtility]::HtmlEncode($_.Name))</th><td>$([System.Net.WebUtility]::HtmlEncode([string]$_.Value))</td></tr>"
    }) -join ''
    $html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>$Title</title></head><body>" +
            "<h1>$Title</h1><table border='1' cellpadding='4'>$rows</table>" +
            "<script type='application/json' id='state'>$json</script></body></html>"
    Set-Content -Path $Path -Value $html -Encoding UTF8 -Force
}
function Read-StateFile {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return $null }
    try {
        $m = [regex]::Match((Get-Content -Path $Path -Raw), "<script type='application/json' id='state'>(.*?)</script>",
                            [System.Text.RegularExpressions.RegexOptions]::Singleline)
        if (-not $m.Success) { return $null }
        $m.Groups[1].Value | ConvertFrom-Json
    } catch { $null }
}

function ConvertTo-BiosVersion {
    param([string]$Text)
    $m = [regex]::Match([string]$Text, '(\d+)\.(\d+)(?:\.(\d+))?')
    if (-not $m.Success) { return $null }
    $p3 = if ($m.Groups[3].Success) { [int]$m.Groups[3].Value } else { 0 }
    [version]('{0}.{1}.{2}' -f [int]$m.Groups[1].Value, [int]$m.Groups[2].Value, $p3)
}

try {
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem
    if ([string]$cs.Manufacturer -notmatch '^Dell') { Set-Detected "not a Dell device ($($cs.Manufacturer))" }
    $sku = ([string]$cs.SystemSKUNumber).Trim().ToUpper()

    # 1. DCU must be installed
    $dcu = @("$env:ProgramFiles\Dell\CommandUpdate\dcu-cli.exe", "${env:ProgramFiles(x86)}\Dell\CommandUpdate\dcu-cli.exe") |
           Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
    if (-not $dcu) { Set-NotDetected 'Dell Command | Update not installed' }

    # 2. Installed BIOS
    $curText = [string](Get-CimInstance -ClassName Win32_BIOS).SMBIOSBIOSVersion
    $cur     = ConvertTo-BiosVersion $curText

    # 3. Latest BIOS from a DCU scan, cached
    $cache      = Read-StateFile -Path $CacheFile
    $cacheValid = $cache -and $cache.SystemId -eq $sku
    $cacheFresh = $cacheValid -and ((Get-Date) - [datetime]$cache.CheckedAt).TotalHours -lt $CacheHours

    if (-not $cacheFresh) {
        $dir = Join-Path $env:TEMP ('DellBIOSDetect_' + [guid]::NewGuid().ToString('N').Substring(0, 8))
        New-Item -Path $dir -ItemType Directory -Force | Out-Null
        try {
            $p = Start-Process -FilePath $dcu -ArgumentList "/scan -updateType=bios -report=`"$dir`" -silent" -PassThru -WindowStyle Hidden
            $null = $p.Handle
            if (-not $p.WaitForExit(20 * 60 * 1000)) { try { $p.Kill() } catch { }; $code = -1 } else { $code = $p.ExitCode }
            Write-Log "DCU scan exit code $code"

            if ($code -eq 7) {
                $cache = [pscustomobject]@{ SystemId = $sku; Supported = $false; UpdateAvailable = $false; LatestVersion = ''; InstalledBios = $curText; CheckedAt = (Get-Date).ToString('o') }
                Save-StateFile -Path $CacheFile -Data $cache -Title 'Dell BIOS: latest from Dell'
            } elseif ($code -in 0, 1, 5, 500) {
                $latestVer = $curText; $avail = $false
                $xmlFile = Get-ChildItem -Path $dir -Filter '*.xml' -File -ErrorAction SilentlyContinue | Select-Object -First 1
                if ($xmlFile) {
                    [xml]$xml = Get-Content -Path $xmlFile.FullName -Raw
                    foreach ($n in @($xml.SelectNodes('//update'))) {
                        $t = "$($n.SelectSingleNode('type').InnerText) $($n.SelectSingleNode('name').InnerText)"
                        if ($t -match 'BIOS') { $latestVer = $n.SelectSingleNode('version').InnerText.Trim(); $avail = $true; break }
                    }
                }
                $cache = [pscustomobject]@{ SystemId = $sku; Supported = $true; UpdateAvailable = $avail; LatestVersion = $latestVer; InstalledBios = $curText; CheckedAt = (Get-Date).ToString('o') }
                Save-StateFile -Path $CacheFile -Data $cache -Title 'Dell BIOS: latest from Dell'
            } else {
                Write-Log "DCU scan failed with exit code $code"
                if (-not $cacheValid) { Set-NotDetected "latest BIOS unknown (DCU scan exit code $code, no cached result)" }
                Write-Log "Using cached result from $($cache.CheckedAt)"
            }
        } finally {
            Remove-Item -Path $dir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    if ($cache.Supported -eq $false) { Set-Detected "model not supported by the DCU catalogue (System ID $sku)" }

    $latest = ConvertTo-BiosVersion $cache.LatestVersion
    if (-not $cur -or -not $latest) { Set-NotDetected "could not parse versions (installed '$curText', latest '$($cache.LatestVersion)')" }

    # 4. Current?
    if ($cur -ge $latest) { Set-Detected "BIOS $curText is the latest ($($cache.LatestVersion))" }

    # 5. Latest staged in this boot session?
    $m = Read-StateFile -Path $MarkerFile
    if ($m) {
        $boot   = (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime.ToString('o')
        $staged = ConvertTo-BiosVersion $m.TargetVersion
        if ($m.BootTime -eq $boot -and $staged -and $staged -ge $latest) {
            Set-Detected "BIOS $($m.TargetVersion) staged, restart pending (installed $curText)"
        }
        if ($m.BootTime -ne $boot) { Write-Log "Staged $($m.TargetVersion) at $($m.StagedAt) did not apply after restart" }
    }

    Set-NotDetected "BIOS $curText is older than latest $($cache.LatestVersion)"
}
catch {
    Set-NotDetected "error: $($_.Exception.Message)"
}
