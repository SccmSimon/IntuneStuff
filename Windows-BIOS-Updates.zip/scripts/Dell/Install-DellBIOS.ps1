#Requires -Version 5.1
<#
  Win32 app install: installs Dell Command | Update (DCU, bundled) if missing, then stages the latest Dell BIOS
  for this model using dcu-cli. No model or version is hard coded: DCU picks the latest BIOS from Dell's catalogue.

  BIOS password: if the device has a BIOS Admin password set, pass an encrypted password file and its key.
    Package:  BiosPassword.txt (created with dcu-cli /generateEncryptedPassword, see the guide)
    Command:  ... -File .\Install-DellBIOS.ps1 -EncryptionKey "YourKey1"
  The password is never in plain text in the package, the command line or the logs.

  Exit codes: 0 = already current or model not supported, 3010 = BIOS staged (soft reboot),
              1618 = power not ready or DCU busy (Intune retries), 1 = failed.
  Never restarts the device itself. Intune handles the restart from the 3010 return code.
#>
param(
    [string]$EncryptionKey = '',                  # key used when the encrypted password file was generated
    [string]$PasswordFile  = 'BiosPassword.txt'   # encrypted password file in the package folder
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
$ScriptVersion     = '1.0'
$RunId             = ([guid]::NewGuid().ToString()).Substring(0, 8)
$UpdateTypes       = 'bios'   # dcu-cli -updateType value
$MinBatteryPercent = 50
$TimeoutMinutes    = 45
$start             = Get-Date
$exitCode          = 1
$summary           = 'Not started'

$DataRoot   = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir     = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile    = Join-Path $LogDir 'DellBIOS-Win32Install.log'
$DcuLog     = Join-Path $LogDir 'DellBIOS-DCU.log'
$CacheFile  = Join-Path $LogDir 'DellBIOS-Latest.html'
$MarkerFile = Join-Path $LogDir 'DellBIOS-Staged.html'
$WorkDir    = Join-Path $env:TEMP "DellBIOS_$RunId"
New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 5MB) { Move-Item -Path $LogFile -Destination "$LogFile.old" -Force }

$DcuCodes = @{
    0 = 'Success'; 1 = 'Reboot required to complete'; 2 = 'Unknown application error'; 3 = 'Not a Dell system'
    4 = 'Not run as administrator'; 5 = 'Reboot pending from a previous operation'; 6 = 'Another DCU instance is running'
    7 = 'Model not supported by the catalogue'; 8 = 'No update filters configured'
    104 = 'Incorrect command syntax'; 105 = 'Incorrect option syntax'; 106 = 'Invalid options'; 107 = 'Invalid option value'
    109 = 'Invalid option combination'; 112 = 'Invalid catalogue'
    500 = 'No updates found'; 501 = 'Error determining available updates'; 502 = 'Scan cancelled'; 503 = 'Download error during scan'
    1000 = 'Error retrieving apply result'; 1001 = 'Apply cancelled'; 1002 = 'Download error during apply'
    2500 = 'Error encrypting password'; 2501 = 'Error with the encryption key'; 2502 = 'Encrypted password uses an older method, regenerate it'
    3000 = 'Dell Client Management Service not running'; 3001 = 'Service not installed'; 3002 = 'Service disabled'
}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $RunId, $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}
function Write-Section { param([string]$Name) Write-Log "---- $Name ----" }

# State files: readable HTML table for people, embedded JSON block for the scripts
function Save-StateFile {
    param([string]$Path, [object]$Data, [string]$Title)
    $json = $Data | ConvertTo-Json -Compress
    $rows = ($Data.PSObject.Properties | ForEach-Object {
        "<tr><th>$([System.Net.WebUtility]::HtmlEncode($_.Name))</th><td>$([System.Net.WebUtility]::HtmlEncode([string]$_.Value))</td></tr>"
    }) -join ''
    $html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>$Title</title></head><body>" +
            "<h1>$Title</h1><table border='1' cellpadding='4'>$rows</table>" +
            "<script type='application/json' id='state'>$json</script></body></html>"
    Set-Content -Path $Path -Value $html -Encoding UTF8 -Force
}

# '1.49.0', 'A16 1.12.0' -> [version]
function ConvertTo-BiosVersion {
    param([string]$Text)
    $m = [regex]::Match([string]$Text, '(\d+)\.(\d+)(?:\.(\d+))?')
    if (-not $m.Success) { return $null }
    $p3 = if ($m.Groups[3].Success) { [int]$m.Groups[3].Value } else { 0 }
    [version]('{0}.{1}.{2}' -f [int]$m.Groups[1].Value, [int]$m.Groups[2].Value, $p3)
}

function Get-DcuCli {
    @("$env:ProgramFiles\Dell\CommandUpdate\dcu-cli.exe", "${env:ProgramFiles(x86)}\Dell\CommandUpdate\dcu-cli.exe") |
        Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
}

# Runs dcu-cli, returns the exit code, or -1 on timeout. Arguments are logged with the key masked.
function Invoke-DcuCli {
    param([string]$Exe, [string]$Arguments)
    $shown = $Arguments -replace '(-encryptionKey=)"[^"]*"', '$1"***"'
    Write-Log "Running: dcu-cli.exe $shown"
    $p = Start-Process -FilePath $Exe -ArgumentList $Arguments -PassThru -WindowStyle Hidden
    $null = $p.Handle
    if (-not $p.WaitForExit($TimeoutMinutes * 60 * 1000)) { try { $p.Kill() } catch { }; return -1 }
    $p.ExitCode
}

function Get-DcuCodeText { param([int]$Code) if ($DcuCodes.ContainsKey($Code)) { $DcuCodes[$Code] } else { 'Unlisted code' } }

function Get-NodeValue {
    param($Node, [string[]]$Names)
    foreach ($n in $Names) { $c = $Node.SelectSingleNode($n); if ($c -and $c.InnerText) { return $c.InnerText.Trim() } }
    ''
}

function Test-PowerReady {
    $batt = @(Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue | Where-Object { $_ })
    if ($batt.Count -eq 0) { Write-Log '  No battery present, power check passed'; return $true }
    # BatteryStatus 2 = on AC, 6 to 9 = charging
    $onAC   = @($batt | Where-Object { $_.BatteryStatus -in 2,6,7,8,9 }).Count -gt 0
    $charge = [int](($batt | Measure-Object -Property EstimatedChargeRemaining -Average).Average)
    Write-Log "  Battery: on AC $onAC, charge $charge% (minimum $MinBatteryPercent%)"
    $onAC -and ($charge -ge $MinBatteryPercent)
}

# $true / $false from Dell's built-in BIOS WMI, or $null if the device cannot report it
function Get-DellAdminPasswordSet {
    try {
        $o = Get-CimInstance -Namespace 'root/dcim/sysman/wmisecurity' -ClassName PasswordObject -Filter "NameId='Admin'" -ErrorAction Stop
        if ($null -eq $o) { return $null }
        return ($o.IsPasswordSet -eq 1)
    } catch { return $null }
}

try {
    Write-Log '=================================================================='
    Write-Log "Dell BIOS Win32 install v$ScriptVersion started on $env:COMPUTERNAME"

    # ---- Device ----
    Write-Section 'Device'
    $cs   = Get-CimInstance -ClassName Win32_ComputerSystem
    $bios = Get-CimInstance -ClassName Win32_BIOS
    $os   = Get-CimInstance -ClassName Win32_OperatingSystem
    $sku  = ([string]$cs.SystemSKUNumber).Trim().ToUpper()
    $boot = $os.LastBootUpTime.ToString('o')
    Write-Log "Manufacturer: $($cs.Manufacturer) | Model: $($cs.Model) | System ID: $sku | BIOS: $($bios.SMBIOSBIOSVersion)"

    if ([string]$cs.Manufacturer -notmatch '^Dell') {
        $summary = "Not a Dell device ($($cs.Manufacturer)), nothing to do. Check the app requirement rule."
        $exitCode = 0; Write-Log $summary 'WARN'
        return
    }

    # ---- Dell Command | Update ----
    Write-Section 'Dell Command | Update'
    $dcu = Get-DcuCli
    if (-not $dcu) {
        $installer = Get-ChildItem -Path $PSScriptRoot -Filter 'Dell-Command-Update*.exe' -File | Select-Object -First 1
        if (-not $installer) { throw 'DCU is not installed and no Dell-Command-Update*.exe installer is in the package' }
        Write-Log "DCU not installed, running $($installer.Name)"
        $instLog = Join-Path $LogDir 'DellBIOS-DCUInstall.log'
        $p = Start-Process -FilePath $installer.FullName -ArgumentList "/s /l=`"$instLog`"" -Wait -PassThru
        Write-Log "  DCU installer exit code: $($p.ExitCode)"
        if ($p.ExitCode -notin 0, 2) { throw "DCU installer failed with exit code $($p.ExitCode), see $instLog" }
        $dcu = Get-DcuCli
        if (-not $dcu) { throw 'dcu-cli.exe not found after the DCU install' }
    }
    Write-Log "dcu-cli: $dcu, version $((Get-Item $dcu).VersionInfo.ProductVersion)"

    # ---- BIOS password ----
    Write-Section 'BIOS password'
    $pwdSet  = Get-DellAdminPasswordSet
    $pwdFile = Join-Path $PSScriptRoot $PasswordFile
    $pwdArgs = ''
    Write-Log "BIOS Admin password set: $(if ($null -eq $pwdSet) { 'unknown (BIOS WMI not available)' } else { $pwdSet })"
    if ($pwdSet -eq $true) {
        if (-not (Test-Path $pwdFile)) {
            throw "BIOS Admin password is set but $PasswordFile is not in the package. See the guide to create it."
        }
        if (-not $EncryptionKey) { throw 'BIOS Admin password is set but no -EncryptionKey was passed in the install command' }
        $pwdArgs = " -encryptedPasswordFile=`"$pwdFile`" -encryptionKey=`"$EncryptionKey`""
        Write-Log "Encrypted password file and key will be passed to DCU"
    } elseif ($null -eq $pwdSet -and (Test-Path $pwdFile) -and $EncryptionKey) {
        Write-Log 'Password state unknown, encrypted password available. Trying without it first.' 'WARN'
    }

    # ---- Scan ----
    Write-Section 'Scan'
    New-Item -Path $WorkDir -ItemType Directory -Force | Out-Null
    $code = Invoke-DcuCli -Exe $dcu -Arguments "/scan -updateType=$UpdateTypes -report=`"$WorkDir`" -silent -outputLog=`"$DcuLog`""
    if ($code -eq 6) {
        $summary = 'Another DCU instance is running. Returning 1618 so Intune retries.'
        $exitCode = 1618; Write-Log $summary 'WARN'
        return
    }
    Write-Log "Scan exit code $code ($(Get-DcuCodeText $code))"

    if ($code -eq 7) {
        Save-StateFile -Path $CacheFile -Title 'Dell BIOS: latest from Dell' -Data ([pscustomobject]@{
            SystemId = $sku; Supported = $false; UpdateAvailable = $false; LatestVersion = ''; InstalledBios = $bios.SMBIOSBIOSVersion; CheckedAt = (Get-Date).ToString('o') })
        $summary = "Model not supported by the DCU catalogue (System ID $sku). Recorded and skipped."
        $exitCode = 0; Write-Log $summary 'WARN'
        return
    }
    if ($code -notin 0, 1, 5, 500) { throw "DCU scan failed: $code ($(Get-DcuCodeText $code)). See $DcuLog" }

    $biosUpdate = $null
    $xmlFile = Get-ChildItem -Path $WorkDir -Filter '*.xml' -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($xmlFile) {
        [xml]$xml = Get-Content -Path $xmlFile.FullName -Raw
        foreach ($n in @($xml.SelectNodes('//update'))) {
            $t = Get-NodeValue $n @('type', 'category')
            $nm = Get-NodeValue $n @('name')
            if ("$t $nm" -match 'BIOS') {
                $biosUpdate = [pscustomobject]@{ Name = $nm; Version = (Get-NodeValue $n @('version')); Date = (Get-NodeValue $n @('date', 'releasedate'));
                                                 Urgency = (Get-NodeValue $n @('urgency', 'criticality')); Release = (Get-NodeValue $n @('release', 'releaseid')) }
                break
            }
        }
    }

    $latestVer = if ($biosUpdate) { $biosUpdate.Version } else { $bios.SMBIOSBIOSVersion }
    Save-StateFile -Path $CacheFile -Title 'Dell BIOS: latest from Dell' -Data ([pscustomobject]@{
        SystemId = $sku; Supported = $true; UpdateAvailable = [bool]$biosUpdate; LatestVersion = $latestVer
        InstalledBios = $bios.SMBIOSBIOSVersion; CheckedAt = (Get-Date).ToString('o') })

    if (-not $biosUpdate) {
        $summary = "BIOS $($bios.SMBIOSBIOSVersion) is already the latest"
        $exitCode = 0; Write-Log $summary
        return
    }
    Write-Log "Available: $($biosUpdate.Name) $($biosUpdate.Version), released $($biosUpdate.Date), urgency $($biosUpdate.Urgency), release $($biosUpdate.Release)"

    # ---- Power ----
    Write-Section 'Power check'
    if (-not (Test-PowerReady)) {
        $summary = 'Power not ready (needs AC and battery at minimum level). Returning 1618 so Intune retries.'
        $exitCode = 1618; Write-Log $summary 'WARN'
        return
    }
    try { Write-Log "BitLocker on $($env:SystemDrive): $((Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop).ProtectionStatus)" } catch { }

    # ---- Apply ----
    Write-Section 'Apply'
    $applyArgs = "/applyUpdates -updateType=$UpdateTypes -autoSuspendBitLocker=enable -reboot=disable -silent -outputLog=`"$DcuLog`""
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $code = Invoke-DcuCli -Exe $dcu -Arguments ($applyArgs + $pwdArgs)

    # Password state unknown and the plain attempt failed: retry once with the password, if we have one
    if ($code -notin 0, 1, 5 -and $null -eq $pwdSet -and (Test-Path $pwdFile) -and $EncryptionKey) {
        Write-Log "Apply returned $code ($(Get-DcuCodeText $code)), retrying with the encrypted password" 'WARN'
        $code = Invoke-DcuCli -Exe $dcu -Arguments ($applyArgs + " -encryptedPasswordFile=`"$pwdFile`" -encryptionKey=`"$EncryptionKey`"")
    }
    $sw.Stop()
    Write-Log ("Apply exit code {0} ({1}) after {2:N0}s" -f $code, (Get-DcuCodeText $code), $sw.Elapsed.TotalSeconds)

    switch ($code) {
        { $_ -in 0, 1, 5 } {
            Save-StateFile -Path $MarkerFile -Title 'Dell BIOS: flash staged, restart pending' -Data ([pscustomobject]@{
                TargetVersion = $biosUpdate.Version; FromVersion = $bios.SMBIOSBIOSVersion; StagedAt = (Get-Date).ToString('o'); BootTime = $boot })
            $summary = "BIOS $($biosUpdate.Version) staged (from $($bios.SMBIOSBIOSVersion)). Applies at next restart."
            $exitCode = 3010
        }
        6       { $summary = 'Another DCU instance is running. Returning 1618 so Intune retries.'; $exitCode = 1618 }
        -1      { $summary = "dcu-cli did not finish within $TimeoutMinutes minutes"; $exitCode = 1 }
        default { $summary = "DCU apply failed: $code ($(Get-DcuCodeText $code)). See $DcuLog"; $exitCode = 1 }
    }
    Write-Log $summary $(if ($exitCode -eq 1) { 'ERROR' } else { 'INFO' })
}
catch {
    $summary  = "Failed at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    $exitCode = 1
    Write-Log $summary 'ERROR'
}
finally {
    if (Test-Path $WorkDir) { Remove-Item -Path $WorkDir -Recurse -Force -ErrorAction SilentlyContinue }
    Write-Section 'Result'
    $d = (Get-Date) - $start
    Write-Log ("  Exit code {0} | {1} | Run time: {2}m {3}s" -f $exitCode, $summary, [int][Math]::Floor($d.TotalMinutes), $d.Seconds)
    # exit sits inside finally so the early 'return' paths above still pass the right exit code to Intune
    exit $exitCode
}
