#Requires -Version 5.1
<#
  Win32 app uninstall for "Dell BIOS Update".
  Removes the app's state files. Dell Command | Update is kept by default, because other tools and
  remediations may use it. Add -RemoveDCU to uninstall DCU as well.

  It does NOT roll back the BIOS. A flashed BIOS stays at its new version.

  Uninstall command:
    %SystemRoot%\sysnative\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Uninstall-DellBIOS.ps1
  Exit codes: 0 = removed (or nothing to remove), 3010 = DCU removed and a restart is needed, 1 = failed.
#>
param(
    [switch]$RemoveDCU
)

$ErrorActionPreference = 'Stop'
$ScriptVersion = '1.0'
$RunId         = ([guid]::NewGuid().ToString()).Substring(0, 8)
$exitCode      = 0
$summary       = 'Not started'

$DataRoot = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir   = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile  = Join-Path $LogDir 'DellBIOS-Win32Uninstall.log'
$StateFiles = @('DellBIOS-Latest.html', 'DellBIOS-Staged.html')

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $RunId, $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}

New-Item -Path $LogDir -ItemType Directory -Force | Out-Null

try {
    Write-Log '=================================================================='
    Write-Log "Dell BIOS Win32 uninstall v$ScriptVersion started on $env:COMPUTERNAME (RemoveDCU: $RemoveDCU)"
    try { Write-Log "Installed BIOS: $((Get-CimInstance -ClassName Win32_BIOS).SMBIOSBIOSVersion) (left as is, a BIOS is not rolled back)" } catch { }

    foreach ($f in $StateFiles) {
        $p = Join-Path $LogDir $f
        if (Test-Path $p) { Remove-Item -Path $p -Force; Write-Log "Removed state file $f" }
    }

    if ($RemoveDCU) {
        $keys = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                  'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
        $apps = @(Get-ItemProperty -Path $keys -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'Dell Command*Update*' })
        if (-not $apps) { Write-Log 'Dell Command | Update not found, nothing to remove' }
        foreach ($a in $apps) {
            Write-Log "Removing $($a.DisplayName) $($a.DisplayVersion)"
            if ($a.PSChildName -match '^\{[0-9A-Fa-f-]{36}\}$') {
                $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList "/x $($a.PSChildName) /qn /norestart" -Wait -PassThru
            } else {
                throw "No MSI product code for $($a.DisplayName). Uninstall string: $($a.UninstallString)"
            }
            Write-Log "  msiexec exit code $($p.ExitCode)"
            if ($p.ExitCode -eq 3010) { $exitCode = 3010 }
            elseif ($p.ExitCode -notin 0, 1605) { throw "DCU uninstall failed with exit code $($p.ExitCode)" }
        }
    } else {
        Write-Log 'Dell Command | Update kept on the device'
    }

    $summary = if ($RemoveDCU) { 'State files and Dell Command | Update removed' } else { 'State files removed, Dell Command | Update kept' }
}
catch {
    $exitCode = 1
    $summary  = "Failed at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    Write-Log $summary 'ERROR'
}
finally {
    Write-Log "Result: exit $exitCode | $summary"
    exit $exitCode
}
