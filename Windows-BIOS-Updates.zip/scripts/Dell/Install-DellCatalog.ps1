#Requires -Version 5.1
<#
  Win32 app: installs the Dell catalogue XML for this device's model into C:\ProgramData\DellCatalogs,
  where the Dell catalogue detection script looks for it.

  Package layout (the .intunewin source folder):
    Install-DellCatalog.ps1
    Catalogs\<any subfolders>\<Model>_<SystemID>.xml   (for example Catalogs\Precision 7560\Precision_0A69.xml)

  Only the catalogue for this device's System ID is copied (about 10 MB), not the whole set.
  Records what was installed in HKLM\SOFTWARE\DellCatalogs for the app detection rule.

  Install:   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-DellCatalog.ps1
  Uninstall: powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-DellCatalog.ps1 -Uninstall
  Exit codes: 0 = success (or nothing to do), 1 = failed.
#>
param(
    [switch]$Uninstall,
    [string]$Destination = 'C:\ProgramData\DellCatalogs'
)

$ErrorActionPreference = 'Stop'
$PackageVersion = '2026.10.08'   # bump on every package rebuild, and set the same value in the detection script
$ScriptVersion = '1.0'
$RunId         = ([guid]::NewGuid().ToString()).Substring(0, 8)
$RegPath       = 'HKLM:\SOFTWARE\DellCatalogs'
$DellNs        = 'openmanage/cm/dm'
$exitCode      = 1
$summary       = 'Not started'

$DataRoot = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir   = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile  = Join-Path $LogDir 'DellCatalog-Install.log'

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $RunId, $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}

# Catalogue for this System ID: filename first (Model_0A69.xml), then file contents
function Find-Catalog {
    param([string]$Root, [string]$SystemId)
    $files = @(Get-ChildItem -Path $Root -Filter '*.xml' -File -Recurse)
    $byName = $files | Where-Object { $_.BaseName -match "(^|_)$([regex]::Escape($SystemId))$" } | Select-Object -First 1
    if ($byName) { return $byName }
    foreach ($f in $files) {
        if (Select-String -Path $f.FullName -Pattern "systemID=`"$([regex]::Escape($SystemId))`"" -Quiet) { return $f }
    }
    $null
}

function Set-State {
    param([hashtable]$Values)
    if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
    foreach ($k in $Values.Keys) { Set-ItemProperty -Path $RegPath -Name $k -Value ([string]$Values[$k]) -Force }
}

New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 5MB) { Move-Item -Path $LogFile -Destination "$LogFile.old" -Force }

try {
    Write-Log '=================================================================='
    Write-Log "Dell catalogue $(if ($Uninstall) { 'uninstall' } else { 'install' }) v$ScriptVersion, package $PackageVersion, started on $env:COMPUTERNAME"

    # ---- Uninstall ----
    if ($Uninstall) {
        if (Test-Path $Destination) { Remove-Item -Path $Destination -Recurse -Force; Write-Log "Removed $Destination" }
        if (Test-Path $RegPath)     { Remove-Item -Path $RegPath -Recurse -Force;     Write-Log "Removed $RegPath" }
        $summary = 'Dell catalogues removed'; $exitCode = 0
        return
    }

    # ---- Device ----
    $cs  = Get-CimInstance -ClassName Win32_ComputerSystem
    $sku = ([string]$cs.SystemSKUNumber).Trim().ToUpper()
    Write-Log "Manufacturer: $($cs.Manufacturer) | Model: $($cs.Model) | System ID: $sku"

    if ([string]$cs.Manufacturer -notmatch '^Dell') {
        $summary = "Not a Dell device ($($cs.Manufacturer)), nothing to install. Check the app requirement rule."
        Write-Log $summary 'WARN'; $exitCode = 0
        return
    }
    if (-not $sku) { throw 'System ID (SystemSKUNumber) is empty' }

    # ---- Find the catalogue in the package ----
    $source = Join-Path $PSScriptRoot 'Catalogs'
    if (-not (Test-Path $source)) { throw "Catalogs folder missing from the package: $source" }
    $pkgFiles = @(Get-ChildItem -Path $source -Filter '*.xml' -File -Recurse)
    Write-Log "Catalogues in package: $($pkgFiles.Count) ($(($pkgFiles.Name) -join ', '))"

    $cat = Find-Catalog -Root $source -SystemId $sku
    if (-not $cat) {
        # Record the result so the app shows as installed and Intune does not retry forever
        Set-State @{ SystemID = $sku; Model = $cs.Model; CatalogFile = ''; CatalogVersion = 'NoCatalogueForModel'
                     InstalledAt = (Get-Date).ToString('s'); ScriptVersion = $ScriptVersion; PackageVersion = $PackageVersion }
        $summary = "No catalogue in this package for System ID $sku ($($cs.Model)). Add it to the package to cover this model."
        Write-Log $summary 'WARN'; $exitCode = 0
        return
    }

    # Check it is a readable Dell catalogue and get its version
    [xml]$xml = Get-Content -Path $cat.FullName -Raw
    if ($xml.DocumentElement.NamespaceURI -ne $DellNs) { throw "$($cat.Name) is not a Dell catalogue" }
    $catVersion = $xml.DocumentElement.GetAttribute('version')
    $catDate    = $xml.DocumentElement.GetAttribute('dateTime')
    $xml = $null
    Write-Log "Selected: $($cat.Name), catalogue version $catVersion, dated $catDate"

    # ---- Copy ----
    New-Item -Path $Destination -ItemType Directory -Force | Out-Null
    # Remove older catalogues so only the current one is present
    Get-ChildItem -Path $Destination -Filter '*.xml' -File -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ne $cat.Name } |
        ForEach-Object { Remove-Item -Path $_.FullName -Force; Write-Log "Removed old catalogue $($_.Name)" }

    $target = Join-Path $Destination $cat.Name
    Copy-Item -Path $cat.FullName -Destination $target -Force
    if ((Get-FileHash $target).Hash -ne (Get-FileHash $cat.FullName).Hash) { throw 'Copied file does not match the source' }
    Write-Log "Copied to $target ($([math]::Round((Get-Item $target).Length / 1MB, 1)) MB)"

    Set-State @{ SystemID = $sku; Model = $cs.Model; CatalogFile = $cat.Name; CatalogVersion = $catVersion
                 CatalogDate = $catDate; InstalledAt = (Get-Date).ToString('s'); ScriptVersion = $ScriptVersion; PackageVersion = $PackageVersion }
    Write-Log "Recorded in $RegPath"

    $summary = "Installed $($cat.Name) (catalogue $catVersion) to $Destination"
    $exitCode = 0
}
catch {
    $summary  = "Failed at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    $exitCode = 1
    Write-Log $summary 'ERROR'
}
finally {
    Write-Log "Result: exit $exitCode | $summary"
    # exit sits inside finally so the early 'return' paths above still pass the right exit code to Intune
    exit $exitCode
}
