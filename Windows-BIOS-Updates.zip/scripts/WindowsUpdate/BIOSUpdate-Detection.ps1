#Requires -Version 5.1
# Detection: Dell and HP system BIOS updates from Microsoft Update only.
# Non-compliant if:
#   - Microsoft Update offers a system firmware update that matches this device's UEFI system firmware
#     resource (ESRT Type 1)
#   - A BIOS package is installed but was not applied at restart (BIOS still on the old version)
#   - The last UEFI capsule update attempt failed
# Exit 0 = compliant or not applicable, Exit 1 = run remediation.
#
# 1.2: Detects BIOS packages installed but not applied (Windows Update reports them as installed, so the
#      scan alone misses them). Scans the default source when Microsoft Update is not registered yet.
#      ESRT values read without the signed / unsigned cast error. Failed capsule attempts are non-compliant.

$ErrorActionPreference = 'Stop'
$ScriptVersion = '1.2'
$RunId         = ([guid]::NewGuid().ToString()).Substring(0, 8)
$MUServiceId   = '7971f918-a847-4430-9279-4a52d1efe18d'   # Microsoft Update
$Criteria      = "IsInstalled=0 and Type='Driver'"

$DataRoot = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir   = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile  = Join-Path $LogDir 'BIOSUpdate-Detection.log'
New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 5MB) {
    Move-Item -Path $LogFile -Destination "$LogFile.old" -Force
}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $RunId, $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}
function Write-Section { param([string]$Name) Write-Log "---- $Name ----" }
function Complete {
    param([int]$Code, [string]$Message)
    if ($Code -eq 0) { Write-Log "Result: $Message" } else { Write-Log "Result: NON-COMPLIANT. $Message" 'WARN' }
    Write-Output $Message
    exit $Code
}

$EsrtStatus = @{ 0='Success'; 1='Unsuccessful'; 2='Insufficient resources'; 3='Incorrect version';
                 4='Invalid image format'; 5='Authentication error'; 6='AC power not connected'; 7='Insufficient battery' }

# Registry DWORDs come back as signed Int32. Convert without the cast error a plain [uint32] gives on large values.
function ConvertTo-UInt32 {
    param($Value)
    if ($null -eq $Value) { return [uint32]0 }
    [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$Value), 0)
}
# ESRT version as four bytes, the same format Windows uses for the firmware package version
function Format-FwVersion {
    param([uint32]$Value)
    '{0}.{1}.{2}.{3}' -f (($Value -shr 24) -band 255), (($Value -shr 16) -band 255), (($Value -shr 8) -band 255), ($Value -band 255)
}

# System firmware entry from the UEFI ESRT table
function Get-SystemFirmware {
    $root = 'HKLM:\HARDWARE\UEFI\ESRT'
    if (-not (Test-Path $root)) { return $null }
    foreach ($k in @(Get-ChildItem -Path $root -ErrorAction SilentlyContinue)) {
        if (-not $k -or -not $k.PSPath) { continue }
        try {
            $props = Get-ItemProperty -Path $k.PSPath -ErrorAction Stop
            if ($props.Type -eq 1) {
                return [pscustomobject]@{
                    Guid               = $k.PSChildName.Trim('{', '}')
                    Version            = ConvertTo-UInt32 $props.Version
                    LowestSupported    = ConvertTo-UInt32 $props.LowestSupportedVersion
                    LastAttemptVersion = ConvertTo-UInt32 $props.LastAttemptVersion
                    LastAttemptStatus  = ConvertTo-UInt32 $props.LastAttemptStatus
                }
            }
        } catch {
            Write-Log "Could not read ESRT key $($k.PSChildName): $($_.Exception.Message)" 'WARN'
        }
    }
    $null
}

# Returns matching BIOS updates, newest first, and logs every driver update seen
function Get-BiosCandidates {
    param($Updates, $Firmware, [string]$VendorPattern)
    $list = New-Object System.Collections.Generic.List[object]
    foreach ($u in $Updates) {
        $hwid   = [string]$u.DriverHardwareID
        $isFw   = $u.DriverClass -eq 'Firmware'
        $hwOk   = $hwid -like "*$($Firmware.Guid)*"
        $vendOk = ("$($u.DriverManufacturer) $($u.DriverProvider) $($u.Title)") -match $VendorPattern
        $match  = $isFw -and $hwOk -and $vendOk
        $tag    = if ($match) { 'MATCH  ' } else { 'IGNORED' }
        Write-Log ("  {0} | {1} | Class: {2} | HWID: {3} | Driver date: {4:yyyy-MM-dd}" -f $tag, $u.Title, $u.DriverClass, $hwid, $u.DriverVerDate)
        if ($match) { $list.Add($u) }
    }
    , @($list | Sort-Object -Property { $_.DriverVerDate } -Descending)
}

$WUPolicy = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
$WUAU     = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'

$MdmPaths = @('HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Update') + @(
    Get-ChildItem -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\providers' -ErrorAction SilentlyContinue |
        ForEach-Object { "HKLM:\SOFTWARE\Microsoft\PolicyManager\providers\$($_.PSChildName)\default\Device\Update" } |
        Where-Object { $_ -and (Test-Path $_) }
)

$isOne    = { param($v) $v -eq 1 }
$isZero   = { param($v) $v -eq 0 }
$isFive   = { param($v) $v -eq 5 }
$nonEmpty = { param($v) -not [string]::IsNullOrWhiteSpace([string]$v) }

$Blockers = @(
    foreach ($n in 'WUServer','WUStatusServer','UpdateServiceUrlAlternate') { @{Path=$WUPolicy;Name=$n;Test=$nonEmpty} }
    foreach ($n in 'DisableWindowsUpdateAccess','DoNotConnectToWindowsUpdateInternetLocations',
                   'ExcludeWUDriversInQualityUpdate','SetPolicyDrivenUpdateSourceForDriverUpdates') { @{Path=$WUPolicy;Name=$n;Test=$isOne} }
    foreach ($n in 'NoAutoUpdate','UseWUServer') { @{Path=$WUAU;Name=$n;Test=$isOne} }
    foreach ($mp in $MdmPaths) {
        foreach ($n in 'ExcludeWUDriversInQualityUpdate','SetPolicyDrivenUpdateSourceForDriverUpdates',
                       'DoNotConnectToWindowsUpdateInternetLocations') { @{Path=$mp;Name=$n;Test=$isOne} }
        @{Path=$mp;Name='UpdateServiceUrl';Test=$nonEmpty}
        @{Path=$mp;Name='AllowUpdateService';Test=$isZero}
        @{Path=$mp;Name='AllowAutoUpdate';Test=$isFive}
    }
)
# Drop anything without a usable path
$Blockers = @($Blockers | Where-Object { $_ -and -not [string]::IsNullOrEmpty($_.Path) })

try {
    Write-Log '=================================================================='
    Write-Log "BIOS detection v$ScriptVersion started on $env:COMPUTERNAME"

    # ---- Device ----
    Write-Section 'Device'
    $cs   = Get-CimInstance -ClassName Win32_ComputerSystem
    $bios = Get-CimInstance -ClassName Win32_BIOS
    Write-Log "Manufacturer: $($cs.Manufacturer) | Model: $($cs.Model)"
    Write-Log ("Current BIOS: {0}, released {1:yyyy-MM-dd}" -f $bios.SMBIOSBIOSVersion, $bios.ReleaseDate)
    Write-Log "Intune policy paths checked: $($MdmPaths.Count)"

    $vendorPattern = switch -Regex ([string]$cs.Manufacturer) {
        '^Dell'          { 'Dell' }
        '^(HP|Hewlett)'  { 'HP|Hewlett' }
        default          { $null }
    }
    if (-not $vendorPattern) { Complete 0 "Not applicable: $($cs.Manufacturer)" }

    # ---- Firmware ----
    Write-Section 'System firmware (ESRT)'
    $fw = Get-SystemFirmware
    if (-not $fw) {
        Write-Log 'No ESRT system firmware entry. Device is legacy BIOS or does not support capsule updates.' 'WARN'
        Complete 0 'Not applicable: no UEFI system firmware resource'
    }
    $running     = Format-FwVersion $fw.Version
    $lastAttempt = Format-FwVersion $fw.LastAttemptVersion
    $statusText  = $EsrtStatus[[int]$fw.LastAttemptStatus]
    if (-not $statusText) { $statusText = "status $($fw.LastAttemptStatus)" }
    Write-Log ("Firmware GUID: {0}" -f $fw.Guid)
    Write-Log ("Version: {0} (0x{1:X8}) | Lowest supported: {2} | Last attempt: {3}, {4}" -f $running, $fw.Version, (Format-FwVersion $fw.LowestSupported), $lastAttempt, $statusText)

    # ---- Staged but not applied ----
    # Windows Update installs the firmware package first and the BIOS flashes at the next restart.
    # Once the package is installed the scan no longer returns it, so check it here.
    Write-Section 'Staged firmware'
    $fwDev = Get-PnpDevice -Class Firmware -PresentOnly -ErrorAction SilentlyContinue |
             Where-Object { $_.InstanceId -like "*$($fw.Guid)*" } | Select-Object -First 1
    if ($fwDev) {
        $pkgText = [string](Get-PnpDeviceProperty -InstanceId $fwDev.InstanceId -KeyName DEVPKEY_Device_DriverVersion -ErrorAction SilentlyContinue).Data
        $infName = [string](Get-PnpDeviceProperty -InstanceId $fwDev.InstanceId -KeyName DEVPKEY_Device_DriverInfPath -ErrorAction SilentlyContinue).Data
        $problem = (Get-PnpDeviceProperty -InstanceId $fwDev.InstanceId -KeyName DEVPKEY_Device_ProblemCode -ErrorAction SilentlyContinue).Data
        Write-Log "Firmware device: $($fwDev.InstanceId) | package $pkgText ($infName) | running $running | status $($fwDev.Status) | problem code $problem"
        $pkg = $null; try { $pkg = [version]$pkgText } catch { }
        if ($pkg -and $pkg -gt [version]$running) {
            if ($problem -eq 14) {   # 14 = restart required
                Complete 0 "Compliant, restart pending: BIOS package $pkgText staged, running $running"
            }
            Complete 1 "BIOS package $pkgText installed but not applied (running $running, problem code $problem, last capsule attempt $lastAttempt $statusText). Capsule not processed at restart"
        }
    } else {
        Write-Log 'No firmware device found for the ESRT GUID' 'WARN'
    }

    # ---- Failed capsule attempt ----
    if ($fw.LastAttemptStatus -ne 0) {
        Complete 1 "Last BIOS capsule update failed: $lastAttempt, $statusText (running $running)"
    }

    # ---- Blockers (logged only) ----
    Write-Section 'Blocker check'
    $blockers = 0
    foreach ($b in $Blockers) {
        if ([string]::IsNullOrEmpty($b.Path) -or -not (Test-Path $b.Path)) { continue }
        $item = Get-ItemProperty -Path $b.Path -Name $b.Name -ErrorAction SilentlyContinue
        if ($null -eq $item) { continue }
        $val = $item.($b.Name)
        if (& $b.Test $val) { $blockers++; Write-Log "  Blocker: $($b.Path)\$($b.Name)=$val" 'WARN' }
    }
    Write-Log "Checked $($Blockers.Count) rules, blockers found: $blockers"

    # ---- Scan ----
    Write-Section 'Update scan'
    try {
        $session  = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $svcMgr   = New-Object -ComObject Microsoft.Update.ServiceManager
        if (@($svcMgr.Services | Where-Object { $_.ServiceID -eq $MUServiceId }).Count) {
            $searcher.ServerSelection = 3
            $searcher.ServiceID = $MUServiceId
            Write-Log "Source: Microsoft Update (ServerSelection 3), criteria: $Criteria"
        } else {
            Write-Log "Microsoft Update not registered. Scanning the default source (remediation registers it), criteria: $Criteria" 'WARN'
        }
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $result = $searcher.Search($Criteria)
        $sw.Stop()
        Write-Log ("Scan completed in {0:N1}s, driver updates returned: {1}" -f $sw.Elapsed.TotalSeconds, $result.Updates.Count)
    } catch {
        Write-Log ("Update search failed: {0} (HRESULT 0x{1:X8})" -f $_.Exception.Message, $_.Exception.HResult) 'ERROR'
        Complete 1 "BIOS update search failed: $($_.Exception.Message)"
    }

    $candidates    = Get-BiosCandidates -Updates $result.Updates -Firmware $fw -VendorPattern $vendorPattern
    $rebootPending = (New-Object -ComObject Microsoft.Update.SystemInfo).RebootRequired

    # ---- Summary ----
    Write-Section 'Summary'
    Write-Log "Matching BIOS updates: $($candidates.Count) | Reboot pending: $rebootPending"

    if ($candidates.Count -gt 0) {
        $latest = $candidates[0]
        Write-Log ("Latest: {0}, driver date {1:yyyy-MM-dd}" -f $latest.Title, $latest.DriverVerDate) 'WARN'
        Complete 1 "BIOS update available: $($latest.Title) (current $($bios.SMBIOSBIOSVersion))"
    }

    if ($rebootPending) {
        Complete 0 "Compliant: no newer BIOS offered (current $($bios.SMBIOSBIOSVersion)), Windows restart pending"
    }
    Complete 0 "Compliant: no newer BIOS offered (current $($bios.SMBIOSBIOSVersion))"
}
catch {
    $msg = "Fatal error at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    Write-Log $msg 'ERROR'
    Write-Log "Position: $($_.InvocationInfo.PositionMessage)" 'ERROR'
    Write-Log "Stack: $($_.ScriptStackTrace)" 'ERROR'
    Write-Output $msg
    exit 1
}
