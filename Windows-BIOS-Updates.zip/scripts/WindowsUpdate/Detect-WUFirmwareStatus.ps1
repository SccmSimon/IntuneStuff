<#
.SYNOPSIS
    Intune Remediations detection script. Reports whether Windows Update has delivered system firmware
    (BIOS) to this device, and why not if it has failed or is stuck.

.DESCRIPTION
    Read-only. Works for any vendor (HP, Dell, Lenovo) because it only looks at what Windows sees:
      1. UEFI ESRT (HKLM\HARDWARE\UEFI\ESRT): is there a system firmware resource, its version, and the
         result of the last capsule update attempt.
      2. System Firmware device in Device Manager: present, and its version (same format as the Intune
         driver list, so Dell 0.1.34.0 = BIOS 1.34.0).
      3. Windows Update history: the last firmware update offered, and whether it succeeded or failed.
      4. Windows Update scan: firmware updates offered but not yet installed.
      5. Whether a restart is pending.

    Exit 1 (issue) when:
      - No system firmware resource (UEFI capsule updates disabled or not supported)
      - The last capsule update attempt failed
      - Firmware installed by Windows Update but not applied (BIOS still on the old version)
      - The last Windows Update firmware install failed (within $FailLookbackDays days) with no later success
      - A firmware update is offered but not installed
      - The Windows Update scan failed
    Exit 0 (no issue) otherwise.

    Output is one line for the Intune report (pre-remediation detection output column), e.g.
      ISSUE: Firmware offered, not installed | Model=Dell Inc. Precision 7560; BIOS=1.34.0; ...

.NOTES
    Version : 1.1
    Author  : Simon Diaz
    1.1     : Flags firmware installed by Windows Update but not applied (System Firmware device version
              newer than the ESRT version). Adds device problem code and last boot time to the output.
    Intune  : Devices > Scripts and remediations > Remediations. Detection script only (no remediation).
              Run this script using the logged-on credentials: No (runs as SYSTEM).
              Run script in 64-bit PowerShell: Yes.
              Schedule: daily.
    Log     : %ProgramData%\Microsoft\IntuneManagementExtension\Logs\WUFirmware-Detection.log
#>

$ProgressPreference = 'SilentlyContinue'
$FailLookbackDays   = 30
$LogFile = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs\WUFirmware-Detection.log'

function Write-Log {
    param([string]$Message)
    try { Add-Content -Path $LogFile -Value ("{0:yyyy-MM-dd HH:mm:ss} {1}" -f (Get-Date), $Message) } catch { }
}

# Writes one line for Intune, logs it, and exits. Intune keeps up to 2048 characters of output.
function Complete-Detection {
    param([bool]$Issue, [string]$Status, [System.Collections.Specialized.OrderedDictionary]$Info)
    $details = ($Info.GetEnumerator() | Where-Object { "$($_.Value)" } | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join '; '
    $line = "{0}: {1} | {2}" -f $(if ($Issue) { 'ISSUE' } else { 'OK' }), $Status, $details
    if ($line.Length -gt 2000) { $line = $line.Substring(0, 2000) }
    Write-Log $line
    Write-Output $line
    if ($Issue) { exit 1 } else { exit 0 }
}

# ESRT versions are a DWORD. Show them as four bytes, the same way Windows shows firmware driver versions.
function Format-FwVersion {
    param($Value)
    if ($null -eq $Value) { return '' }
    $v = [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$Value), 0)
    '{0}.{1}.{2}.{3}' -f (($v -shr 24) -band 255), (($v -shr 16) -band 255), (($v -shr 8) -band 255), ($v -band 255)
}

# UEFI capsule LastAttemptStatus values
$capsuleStatus = @{
    0 = 'Success'; 1 = 'Unsuccessful'; 2 = 'Insufficient resources'; 3 = 'Incorrect version'
    4 = 'Invalid image format'; 5 = 'Authentication error'; 6 = 'Power event: AC not connected'
    7 = 'Power event: battery too low'
}
# Windows Update history ResultCode values
$resultName = @{ 0 = 'Not started'; 1 = 'In progress'; 2 = 'Succeeded'; 3 = 'Succeeded with errors'; 4 = 'Failed'; 5 = 'Aborted' }

$info = [ordered]@{}

try {
    # ---- Device ----
    $cs   = Get-CimInstance -ClassName Win32_ComputerSystem
    $bios = Get-CimInstance -ClassName Win32_BIOS
    $info.Model = "$($cs.Manufacturer) $($cs.Model)".Trim()
    $info.BIOS  = [string]$bios.SMBIOSBIOSVersion

    # ---- 1. ESRT system firmware resource (Type 1 = system firmware) ----
    $sysFw = $null
    foreach ($k in @(Get-ChildItem -Path 'HKLM:\HARDWARE\UEFI\ESRT' -ErrorAction SilentlyContinue)) {
        $p = Get-ItemProperty -Path $k.PSPath -ErrorAction SilentlyContinue
        if ($p.Type -eq 1) { $sysFw = $p; break }
    }
    if ($sysFw) {
        $info.EsrtVersion = Format-FwVersion $sysFw.Version
        $lastStatus = [int]$sysFw.LastAttemptStatus
        $info.LastCapsule = "{0} ({1})" -f $(if ($capsuleStatus.ContainsKey($lastStatus)) { $capsuleStatus[$lastStatus] } else { "status $lastStatus" }),
                                           (Format-FwVersion $sysFw.LastAttemptVersion)
    }

    # ---- 2. System Firmware device ----
    $fwDev = Get-PnpDevice -Class Firmware -PresentOnly -ErrorAction SilentlyContinue |
             Where-Object FriendlyName -like '*System Firmware*' | Select-Object -First 1
    if ($fwDev) {
        $info.FwDevice = (Get-PnpDeviceProperty -InstanceId $fwDev.InstanceId -KeyName DEVPKEY_Device_DriverVersion -ErrorAction SilentlyContinue).Data
        if ($fwDev.Status -ne 'OK') {
            $code = (Get-PnpDeviceProperty -InstanceId $fwDev.InstanceId -KeyName DEVPKEY_Device_ProblemCode -ErrorAction SilentlyContinue).Data
            $info.FwDeviceStatus = "$($fwDev.Status) (code $code)"
        }
    }

    $lastBoot = (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime
    $info.LastBoot = '{0:yyyy-MM-dd HH:mm}' -f $lastBoot

    if (-not $sysFw -and -not $fwDev) {
        Complete-Detection -Issue $true -Status 'No system firmware resource. UEFI capsule updates are disabled in the BIOS or not supported, so Windows Update cannot deliver a BIOS' -Info $info
    }

    # ---- 3. Windows Update history ----
    $session  = New-Object -ComObject Microsoft.Update.Session
    $searcher = $session.CreateUpdateSearcher()
    $count    = $searcher.GetTotalHistoryCount()
    $fwHist   = @()
    if ($count -gt 0) {
        $fwHist = @(foreach ($h in $searcher.QueryHistory(0, $count)) {
            if ($h.Title -match 'Firmware') {
                [pscustomobject]@{ Date = $h.Date; Title = $h.Title; ResultCode = [int]$h.ResultCode; HResult = $h.HResult }
            }
        }) | Sort-Object Date -Descending
    }
    $lastFw = $fwHist | Select-Object -First 1
    $lastOk = $fwHist | Where-Object { $_.ResultCode -in 2, 3 } | Select-Object -First 1
    if ($lastFw) {
        $info.LastWUFirmware = "{0} ({1:yyyy-MM-dd}, {2})" -f $lastFw.Title, $lastFw.Date, $resultName[$lastFw.ResultCode]
    } else {
        $info.LastWUFirmware = 'None in history'
    }

    # ---- 4. Firmware offered but not installed ----
    $pending = @()
    try {
        $result = $searcher.Search("IsInstalled=0 and Type='Driver'")
        foreach ($u in $result.Updates) {
            if ($u.DriverClass -eq 'Firmware' -or $u.Title -match 'Firmware') {
                $pending += "{0}{1}" -f $u.Title, $(if ($u.IsDownloaded) { ' [downloaded]' } else { '' })
            }
        }
    } catch {
        $info.ScanError = $_.Exception.Message
        Complete-Detection -Issue $true -Status 'Windows Update scan failed' -Info $info
    }
    if ($pending.Count) { $info.Pending = $pending -join ', ' }

    # ---- 5. Restart pending ----
    $rebootRequired = $false
    try { $rebootRequired = [bool](New-Object -ComObject Microsoft.Update.SystemInfo).RebootRequired } catch { }
    if ($rebootRequired) { $info.RestartPending = 'Yes' }

    # ---- Decide ----
    if ($sysFw -and [int]$sysFw.LastAttemptStatus -ne 0) {
        Complete-Detection -Issue $true -Status "Last BIOS capsule update failed: $($info.LastCapsule)" -Info $info
    }

    # Firmware package installed by Windows Update but the BIOS itself not updated.
    # The package version (System Firmware device) is newer than the running firmware (ESRT).
    $staged  = $null; $running = $null
    try { $staged  = [version]$info.FwDevice }    catch { }
    try { $running = [version]$info.EsrtVersion } catch { }
    if ($staged -and $running -and $staged -gt $running) {
        $installedAt = if ($lastOk -and $info.FwDevice -and $lastOk.Title -like "*$($info.FwDevice)*") { $lastOk.Date.ToLocalTime() } else { $null }
        if ($installedAt -and $lastBoot -lt $installedAt) {
            Complete-Detection -Issue $true -Status "Firmware $($info.FwDevice) staged, restart needed to apply" -Info $info
        }
        Complete-Detection -Issue $true -Status "Firmware $($info.FwDevice) installed by Windows Update but not applied (BIOS still $($info.EsrtVersion)). Capsule not processed at restart" -Info $info
    }

    $cutoff = (Get-Date).ToUniversalTime().AddDays(-$FailLookbackDays)
    if ($lastFw -and $lastFw.ResultCode -in 4, 5 -and $lastFw.Date -ge $cutoff -and
        (-not $lastOk -or $lastOk.Date -lt $lastFw.Date)) {
        $info.HResult = '0x{0:X8}' -f $lastFw.HResult
        Complete-Detection -Issue $true -Status 'Windows Update firmware install failed' -Info $info
    }

    if ($pending.Count) {
        $why = if ($rebootRequired) { 'Firmware offered, not installed (restart pending)' } else { 'Firmware offered, not installed' }
        Complete-Detection -Issue $true -Status $why -Info $info
    }

    $okStatus = if ($lastOk) { 'No firmware pending. Last firmware from Windows Update installed' } else { 'No firmware offered by Windows Update' }
    Complete-Detection -Issue $false -Status $okStatus -Info $info
}
catch {
    $info.Error = $_.Exception.Message
    Complete-Detection -Issue $true -Status 'Detection error' -Info $info
}
