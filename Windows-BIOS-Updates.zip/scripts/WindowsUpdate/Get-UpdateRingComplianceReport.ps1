#Requires -Version 5.1
<#
.SYNOPSIS
    Update ring compliance report: one Excel sheet per Windows Update ring, with the ring's settings and every
    device in the ring, showing when each monthly Windows update was offered and installed, and whether that
    matched the ring's deferral and deadline (green) or not (red).

.DESCRIPTION
    Sources (all read-only):
      Intune update rings      deviceConfigurations of type windowsUpdateForBusinessConfiguration, with assignments
      Devices in each ring     the ring's include / exclude groups, expanded (nested) to devices. User groups are
                               mapped to devices through each device's primary user.
      Offered / installed      the Detect-WUInstallHistory.ps1 Intune remediation (detection only, daily), which
                               reports each device's Windows Update history. Run states are read from Intune.

    For each of the last -Months Patch Tuesdays (second Tuesday of the month) and each device:
      Release        second Tuesday of the month in the update title (for example 2026-10 = 14 Oct 2026)
      Deferral ends  Release + ring quality update deferral (days)
      Deadline       Deferral ends + ring quality deadline (days) + grace period (days)
      Green          installed on or after Deferral ends, and on or before Deadline. Also green when that month
                     was not installed but a later cumulative update was installed before this month's deadline
                     (cumulative updates include earlier months).
      Red            installed before the deferral ended, installed after the deadline, failed, or not installed
                     and the deadline has passed. Also red when ConfigMgr manages updates on a co-managed device
                     (the ring is not in effect) or the device is in more than one ring.
      Grey           not yet due (deadline still ahead), or no data from the device yet.

    Output: UpdateRingCompliance_<date>.xlsx in -OutputFolder. Sheet 1 Summary, then one sheet per ring, then
    "No update ring" for live devices in no ring and "Multiple rings" for devices targeted by more than one ring. Each ring sheet has the ring settings at the top and the device
    table below. Requires the ImportExcel module (offers to install it for the current user).

.PARAMETER Months
    How many monthly updates to check, counting back from the latest Patch Tuesday. Default 3.
.PARAMETER RemediationName
    Intune name of the Detect-WUInstallHistory.ps1 remediation. Wildcards allowed. Default *InstallHistory*.
.PARAMETER StaleDays
    Only devices that checked in to Intune within this many days. Default 30.
.PARAMETER NamePrefixes
    Only devices whose name starts with one of these. Default: the standard naming convention,
    WL4, WL5, WL6, WD4, WD5, WD6.
.PARAMETER AllNames
    Include every live Windows device, whatever its name (ignores -NamePrefixes).
.PARAMETER DeviceName
    Optional. Only these devices (exact names).
.PARAMETER DeviceListPath
    Optional. A CSV or text file of device names to report on (adds to -DeviceName). A CSV needs a column called
    DeviceName, Device name, Device, Name, ComputerName or Hostname (an Intune device export works as it is).
    A text file is one name per line. Devices in the list are reported whatever their last check-in date, and
    names not found in Intune are listed on the Summary sheet.

.EXAMPLE
    .\Get-UpdateRingComplianceReport.ps1
    .\Get-UpdateRingComplianceReport.ps1 -Months 6
    .\Get-UpdateRingComplianceReport.ps1 -AllNames
    .\Get-UpdateRingComplianceReport.ps1 -NamePrefixes WL5, WL6
    .\Get-UpdateRingComplianceReport.ps1 -DeviceListPath C:\Temp\Devices.csv

.NOTES
    Version : 1.6
    1.6     : 'Last reboot' and 'Days since reboot' columns (from the device). When an update is waiting for a restart,
              the Reason says when the device last restarted.
    1.5     : Summary percentages use only the latest monthly cumulative update (one result per device), not every
              row. 'Device script' column and a Summary count of devices on a detection script older than 1.2, which
              cannot report error codes.
    1.4     : -DeviceListPath imports a CSV or text list of devices. Error codes from Detect-WUInstallHistory.ps1 1.2
              (E:) shown with Microsoft's message, description and mitigation from MS Learn, plus an 'Errors' sheet.
              'Entra device ID' column and a 'Column guide' sheet mapping each column to the Windows Update for
              Business reports schema (UCClientUpdateStatus).
    1.3     : Defaults to the standard device naming convention (WL4, WL5, WL6, WD4, WD5, WD6). -AllNames for every device.
    1.2     : Reads the Detect-WUInstallHistory.ps1 1.1 flags: WMI=Broken (noted in Reason) and P:1 (update started but
              not finished, usually waiting for a restart).
    1.1     : 'Multiple rings' sheet (each device, its rings and the groups that put it there) and an
              'In more than one ring' count per ring on the Summary sheet.
    Author  : Simon Diaz
    Permissions (delegated, read-only): DeviceManagementConfiguration.Read.All,
    DeviceManagementManagedDevices.Read.All, Group.Read.All, Device.Read.All
#>
[CmdletBinding()]
param(
    [string]$OutputFolder = 'C:\Temp\UpdateRingReport',
    [ValidateRange(1, 6)][int]$Months = 3,
    [string]$RemediationName = '*InstallHistory*',
    [int]$StaleDays = 30,
    [string[]]$NamePrefixes = @('WL4', 'WL5', 'WL6', 'WD4', 'WD5', 'WD6'),   # standard device naming convention
    [switch]$AllNames,          # include every Windows device, whatever its name
    [string[]]$DeviceName,
    [string]$DeviceListPath,   # CSV or text file of device names (adds to -DeviceName)
    [string]$TestDataPath      # offline test only: JSON with Rings, Devices, Members, RunStates
)

$ErrorActionPreference = 'Stop'
$ScriptVersion = '1.6'
$beta = 'https://graph.microsoft.com/beta'
$v1   = 'https://graph.microsoft.com/v1.0'
$Today = (Get-Date).Date

#region Helpers
function Invoke-GraphGet {
    param([string]$Uri)
    for ($attempt = 1; ; $attempt++) {
        try { return Invoke-MgGraphRequest -Method GET -Uri $Uri -OutputType PSObject }
        catch {
            $code = $null
            try { $code = [int]$_.Exception.Response.StatusCode } catch { }
            if ($code -in 429, 503, 504 -and $attempt -le 5) {
                $wait = [math]::Pow(2, $attempt)
                Write-Warning "Graph returned $code. Retrying in $wait seconds."
                Start-Sleep -Seconds $wait
            } else { throw }
        }
    }
}
function Get-AllPages {
    param([string]$Uri)
    while ($Uri) {
        $r = Invoke-GraphGet -Uri $Uri
        if ($r.value) { $r.value }
        $Uri = $r.'@odata.nextLink'
    }
}
function Get-PatchTuesday {
    param([int]$Year, [int]$Month)
    $d = Get-Date -Year $Year -Month $Month -Day 1 -Hour 0 -Minute 0 -Second 0 -Millisecond 0
    while ($d.DayOfWeek -ne 'Tuesday') { $d = $d.AddDays(1) }
    $d.AddDays(7).Date
}
function Format-Day  { param($Date) if ($Date) { ([datetime]$Date).ToString('yyyy-MM-dd') } else { '' } }
function Format-Time { param($Date) if ($Date) { ([datetime]$Date).ToString('yyyy-MM-dd HH:mm') } else { '' } }
function ConvertFrom-Utc {
    param([string]$Text)
    if (-not $Text) { return $null }
    try { [datetime]::Parse($Text, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AdjustToUniversal -bor [Globalization.DateTimeStyles]::AssumeUniversal).ToLocalTime() }
    catch { $null }
}

# Reads device names from a CSV (DeviceName / Device name / Device / Name / ComputerName / Hostname column) or a
# text file (one name per line). Returns unique names.
function Import-DeviceList {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { throw "Device list not found: $Path" }
    $lines = @(Get-Content -LiteralPath $Path | Where-Object { $_.Trim() })
    if (-not $lines.Count) { return @() }
    $headers = @('DeviceName', 'Device name', 'Device', 'Name', 'ComputerName', 'Computer name', 'Hostname')
    $delim = if ($lines[0] -match ';' -and $lines[0] -notmatch ',') { ';' } elseif ($lines[0] -match "`t") { "`t" } else { ',' }
    $first = @($lines[0] -split [regex]::Escape($delim) | ForEach-Object { $_.Trim().Trim('"') })
    $col = $first | Where-Object { $headers -contains $_ } | Select-Object -First 1
    $names = if ($col) {
        @($lines | ConvertFrom-Csv -Delimiter $delim | ForEach-Object { [string]$_.$col })
    } else {
        @($lines | ForEach-Object { ($_ -split '[,;\t]')[0] })   # plain list, first field of each line
    }
    @($names | ForEach-Object { $_.Trim().Trim('"').Trim() } | Where-Object { $_ } | Sort-Object -Unique)
}

#region Windows Update error codes (MS Learn)
# Built on 2026-10-27 from three Microsoft Learn pages. Text is Microsoft's own, unchanged apart from formatting.
#   C = Windows Update common errors and mitigation (has the mitigation steps)
#   R = Windows Update error codes by component
#   W = Windows Update Agent success and error codes
# To refresh, rebuild this table from the same pages. Codes not listed fall back to the Windows system message.
$WUErrorSource = @{
    C = 'https://learn.microsoft.com/troubleshoot/windows-client/installing-updates-features-roles/common-windows-update-errors'
    R = 'https://learn.microsoft.com/windows/deployment/update/windows-update-error-reference'
    W = 'https://learn.microsoft.com/windows/win32/wua_sdk/wua-success-and-error-codes-'
}
$WUErrorTable = @{}
@'
Code,Message,Description,Mitigation,Source
0x00240001,WU_S_SERVICE_STOP,Windows Update Agent was stopped successfully.,,R
0x00240002,WU_S_SELFUPDATE,Windows Update Agent updated itself.,,R
0x00240003,WU_S_UPDATE_ERROR,Operation completed successfully but there were errors applying the updates.,,R
0x00240004,WU_S_MARKED_FOR_DISCONNECT,A callback was marked to be disconnected later because the request to disconnect the operation came while a callback was executing.,,R
0x00240005,WU_S_REBOOT_REQUIRED,The system must be restarted to complete installation of the update.,,R
0x00240006,WU_S_ALREADY_INSTALLED,The update to be installed is already installed on the system.,,R
0x00240007,WU_S_ALREADY_UNINSTALLED,The update to be removed isn't installed on the system.,,R
0x00240008,WU_S_ALREADY_DOWNLOADED,The update to be downloaded has already been downloaded.,,R
0x00242015,WU_S_UH_INSTALLSTILLPENDING,The installation operation for the update is still in progress.,,W
0x80070003,ERROR_PATH_NOT_FOUND,The system can't find the path specified. The servicing stack can't access a specific path.,"Indicates an invalid path to an executable. Go to %Windir%\logs\CBS, open the last CBS.log, and search for ', error'. Then, match the results to the timestamp.",C
0x80070005,E_ACCESSDENIED,General access denied error. File system or registry key permissions have been changed and the servicing stack doesn't have the required level of access.,"This error generally means that access was denied. Go to %Windir%\logs\CBS, open the last CBS.log, search for ', error', and match with the timestamp. After you find the error, scroll up, and try to determine what caused the access denial. It could be access denied to a file, registry key. Determine which object needs the right permissions, and change the permissions as appropriate. For more information, see Troubleshoot Windows Update error 0x80070005.",C
0x8007000D,ERROR_INVALID_DATA,Indicates data that isn't valid was downloaded or corruption occurred.,"Try to redownload the update, and then start the installation.",C
0x80070020,ERROR_SHARING_VIOLATION,Numerous causes. CBS log analysis required.,"This error is caused by non-Microsoft filter drivers, such as antivirus. 1. Perform a clean restart, and retry the installation 2. Download the sysinternal tool Process Monitor. 3. Run Procmon.exe. The tool starts data capture automatically. 4. Install the update package again. 5. Keep the Process Monitor main window in focus, and press CTRL+E or select the magnifying glass to stop data capture. 6. Select File > Save > All Events > PML, and choose a path to save the.PML file. 7. Go to %windir%\logs\cbs, open the last Cbs.log file, and search for the error entry. After you locate the error line, you should see which file is accessed during the installation and is causing the sharing violation error. 8. In Process Monitor, filter for path, and insert the file name (it should resemble ""path"" ""contains"" ""filename from CBS""). 9. Try to stop or uninstall the process that's causing the error.",C
0x80070422,ERROR_SERVICE_DISABLED,This issue occurs when the Windows Update service stops working or isn't running.,Check whether the Windows Update service is running.,C
0x80070490,ERROR_NOT_FOUND,This error occurs during driver installation as part of the update.,"This issue occurs because details such as the architecture for a driver that's being updated are missing in the registry. Manually add the missing inf file Arch value in the Driver operations registry by following these steps: 1. Open regedit, and navigate to HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\ComponentBasedServicing\DriverOperations\0\2(SequenceID) 2. Review the Identity value to determine the value that's missing. 3. Manually add the missing value by referring to the information in the Identity value. For example, Name: Arch; Type: REG_SZ (String Value); Data: amd64. 4. Proceed with installing the failing update.",C
0x80070570,ERROR_FILE_CORRUPT,The file or directory is corrupted and unreadable. Component Store corruption,"Repair the component store by running Dism RestoreHealth, or manually repair by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device. For more information, see Troubleshoot Windows Update error 0x80070570.",C
0x800706BE,Failed to install cumulative updates,"Windows Server 2016 Std failed to install cumulative packages by using the.msu package. No error is returned. When installing the packages with dism.exe, it returned the error 0x800706be.","The last cumulative update didn't install, and it was corrupted. To resolve this issue, navigate to the registry key for the corrupted update package. Change the ""current state"" value to 000020 hex (32 dec) - resolved, or 000040 hex (64 dec) - staged, or 000070 hex (112 dec) - installed.",C
0x80070BC9,ERROR_FAIL_REBOOT_REQUIRED,The requested operation failed. Restart the system to roll back changes made.,"Make sure that you don't have any policies that control the start behavior of the Windows Installer service. This service should be managed by the operating system. The default Startup type of the Windows Installer service is Manual. Also: The TrustedInstaller service changes the startup type from Manual to Automatic if it encounters an update that has to process a transaction after a restart. If the value is reverted to Manual before the restart, the transaction can't be applied. This transaction will be pending and block all other update installations. To fix this issue, change the TrustedInstaller policy to Automatic, and restart the computer. If this change doesn't fix the issue, start the computer to WinRE to revert the pending actions. For example, dism /Image:C:\ /Cleanup-Image /RevertPendingActions. If this action also has no effect, start the computer to WinRE, rename \WinSxS\Pending.xml, and then remove the PendingXMLIdentifier from COMPONENTS Hive.",C
0x80072EE2,WININET_E_TIMEOUT,"The operation timed out. Unable to scan for updates due to a connectivity issue to Windows Update, Configuration Manager, or WSUS.","This error generally means that the Windows Update Agent was unable to connect to the update servers or your own source, such as WSUS, Configuration Manager, or Microsoft Intune. Check with your network team to ensure that the device can reach the update sources. For more info, see Troubleshoot software update scan failures in Configuration Manager. If you're using the public Microsoft update servers, check that your device can access the following Windows Update endpoints: http://windowsupdate.microsoft.com https://*.windowsupdate.microsoft.com https://update.microsoft.com https://*.update.microsoft.com https://windowsupdate.com https://*.windowsupdate.com https://download.windowsupdate.com https://*.download.windowsupdate.com https://download.microsoft.com https://*.download.windowsupdate.com https://wustat.windows.com https://*.wustat.windows.com https://ntservicepack.microsoft.com",C
0x80072EFD,TIME_OUT_ERRORS,The operation timed out,Make sure that no firewall rules or proxies block Microsoft download URLs. Take a network monitor trace to understand the situation better. <Refer to Firewall Troubleshooting scenario>,C
0x80072EFE,TIME_OUT_ERRORS,The operation timed out,"Make sure that no firewall rules or proxies block Microsoft download URLs. Take a network monitor trace to understand the situation better. <Refer to Firewall Troubleshooting scenario> Also: Encountered if BITS is broken or if the file that's being transferred can't be written to the destination folder on the client. This error is caused by connection errors while checking or downloading updates. At a command prompt, run: BITSADMIN /LIST /ALLUSERS /VERBOSE Search for the 0x80072EFE error code. You should see a reference to an HTTP code and a specific file. Using a browser, try to download the file manually. Make sure that you use your organization's proxy settings. If the download fails, work with your proxy manager to achieve successful communication. Also, check with your network team for this specific URL access.",C
0x80072F8F,WININET_E_DECODING_FAILED,Content decoding has failed. TLS 1.2 isn't configured correctly on the client.,This error generally means that the Windows Update Agent can't decode the received content. Install and configure TLS 1.2 by installing the update that's provided in KB3140245.,C
0x80073701,ERROR_SXS_ASSEMBLY_MISSING,"The referenced assembly couldn't be found. Typically, a component store corruption caused when a component is in a partially installed state.","Repair the component store by running Dism RestoreHealth command, or manually repair it by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x8007371B,ERROR_SXS_TRANSACTION_CLOSURE_INCOMPLETE,One or more required members of the transaction aren't present. Component Store corruption.,"Repair the component store by running the Dism RestoreHealth command, or manually repair it by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x800F081F,CBS_E_SOURCE_MISSING,"source for package or file not found, ResolveSource() unsuccessful. Component Store corruption","Repair the component store by running the Dism RestoreHealth command, or manually repair by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x800F0821,CBS_E_ABORT,"client abort, IDABORT returned by ICbsUIHandler method except Error(). CBS transaction timeout exceeded.","A servicing operation is taking a long time to finish. The servicing stack watchdog timer expires. Extending the timeout mitigates the issue. Increase the resources on the device. If it's a virtual machine, increase virtual CPU and memory to speed up operations. Make sure that the device has installed the update in KB4493473 or later.",C
0x800F0825,CBS_E_CANNOT_UNINSTALL,Package can't be uninstalled. Typically this error occurs because of component store corruption that was caused by a component in a partially installed state.,"Repair the component store by using the Dism RestoreHealth command, or manually repair by using a payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x800F0831,CBS_E_STORE_CORRUPTION,CBS store is corrupted. Corruption in the Windows Component Store.,"Repair the component store by runnning Dism RestoreHealth or manually repair by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x800F0920,CBS_E_HANG_DETECTED,A failure to respond was detected while processing the operation. Subsequent error logged after getting 0x800f0821,"A servicing operation is taking a long time to finish. The servicing stack watchdog timer expires and assumes that the system stopped responding. Extending the timeout value mitigates the issue. Increase the resources on the device. If it's a virtual machine, increase virtual CPU and memory to speed up operations. Make sure that the device has update KB4493473 or later installed.",C
0x800F0922,CBS_E_INSTALLERS_FAILED,The July cumulative update failed to be installed on Windows Server 2016,"In the CBS.log, you might find that updates sometimes roll back when License and Product key tokens fail to be updated. This issue can be resolved by adding write permissions for the ""User"" and ""Network Service"" accounts to the C:\Windows\System32\spp\ folder.",C
0x80200053,BG_E_VALIDATION_FAILED,,Make sure that there are no firewalls that might filter downloads. Such filtering could cause incorrect responses to be received by the Windows Update client.,C
0x80240001,WU_E_NO_SERVICE,Windows Update Agent was unable to provide the service.,,R
0x80240002,WU_E_MAX_CAPACITY_REACHED,The maximum capacity of the service was exceeded.,,R
0x80240003,WU_E_UNKNOWN_ID,An ID can't be found.,,R
0x80240004,WU_E_NOT_INITIALIZED,The object couldn't be initialized.,,R
0x80240005,WU_E_RANGEOVERLAP,The update handler requested a byte range overlapping a previously requested range.,,R
0x80240006,WU_E_TOOMANYRANGES,The requested number of byte ranges exceeds the maximum number (2^31 - 1).,,R
0x80240007,WU_E_INVALIDINDEX,The index to a collection was invalid.,,R
0x80240008,WU_E_ITEMNOTFOUND,The key for the item queried couldn't be found.,,R
0x80240009,WU_E_OPERATIONINPROGRESS,Another conflicting operation was in progress. Some operations such as installation can't be performed twice simultaneously.,,R
0x8024000A,WU_E_COULDNOTCANCEL,Cancellation of the operation wasn't allowed.,,R
0x8024000B,WU_E_CALL_CANCELLED,Operation was canceled.,The operation was canceled by the user or service. You might also receive this error message if we can't filter the results.,C
0x8024000C,WU_E_NOOP,No operation was required.,,R
0x8024000D,WU_E_XML_MISSINGDATA,Windows Update Agent couldn't find required information in the update's XML data.,,R
0x8024000E,WU_E_XML_INVALID,Windows Update Agent found information in the update's XML data that isn't valid.,Certain drivers contain more metadata information in Update.xml. Orchestrator might interpret that condition as data that isn't valid. Make sure that you have the latest Windows Update Agent installed on the device.,C
0x8024000F,WU_E_CYCLE_DETECTED,Circular update relationships were detected in the metadata.,,R
0x80240010,WU_E_TOO_DEEP_RELATION,Update relationships too deep to evaluate were evaluated.,,R
0x80240011,WU_E_INVALID_RELATIONSHIP,An invalid update relationship was detected.,,R
0x80240012,WU_E_REG_VALUE_INVALID,An invalid registry value was read.,,R
0x80240013,WU_E_DUPLICATE_ITEM,Operation tried to add a duplicate item to a list.,,R
0x80240014,WU_E_INVALID_INSTALL_REQUESTED,Updates that are requested for install are not installable by the caller.,,W
0x80240016,WU_E_INSTALL_NOT_ALLOWED,Operation tried to install while another installation was in progress or the system was pending a mandatory restart.,,R
0x80240017,WU_E_NOT_APPLICABLE,Operation wasn't performed because there are no applicable updates.,,R
0x80240018,WU_E_NO_USERTOKEN,Operation failed because a required user token is missing.,,R
0x80240019,WU_E_EXCLUSIVE_INSTALL_CONFLICT,An exclusive update can't be installed with other updates at the same time.,,R
0x8024001A,WU_E_POLICY_NOT_SET,A policy value wasn't set.,,R
0x8024001B,WU_E_SELFUPDATE_IN_PROGRESS,The operation couldn't be performed because the Windows Update Agent is self-updating.,,R
0x8024001D,WU_E_INVALID_UPDATE,An update contains invalid metadata.,,R
0x8024001E,WU_E_SERVICE_STOP,Operation didn't complete because the service or system was being shut down.,,R
0x8024001F,WU_E_NO_CONNECTION,Operation didn't complete because the network connection was unavailable.,,R
0x80240020,WU_E_NO_INTERACTIVE_USER,The operation didn't finish because no interactive user is signed in.,"Sign in to the device to start the installation, and allow the device to restart.",C
0x80240021,WU_E_TIME_OUT,Operation didn't complete because it timed out.,,R
0x80240022,WU_E_ALL_UPDATES_FAILED,Operation failed for all the updates. Multiple root causes for this error.,The most common issue is that antivirus software is blocking access to certain folders (like SoftwareDistribution). CBS.log analysis has to determine the file or folder that's being protected.,C
0x80240023,WU_E_EULAS_DECLINED,The license terms for all updates were declined.,,R
0x80240024,WU_E_NO_UPDATE,There are no updates.,,R
0x80240025,WU_E_USER_ACCESS_DISABLED,Group Policy settings prevented access to Windows Update.,,R
0x80240026,WU_E_INVALID_UPDATE_TYPE,The type of update is invalid.,,R
0x80240027,WU_E_URL_TOO_LONG,The URL exceeded the maximum length.,,R
0x80240028,WU_E_UNINSTALL_NOT_ALLOWED,The update couldn't be uninstalled because the request didn't originate from a WSUS server.,,R
0x80240029,WU_E_INVALID_PRODUCT_LICENSE,Search may have missed some updates before there's an unlicensed application on the system.,,R
0x8024002A,WU_E_MISSING_HANDLER,A component required to detect applicable updates was missing.,,R
0x8024002B,WU_E_LEGACYSERVER,An operation didn't complete because it requires a newer version of server.,,R
0x8024002C,WU_E_BIN_SOURCE_ABSENT,A delta-compressed update couldn't be installed because it required the source.,,R
0x8024002D,WU_E_SOURCE_ABSENT,A full-file update couldn't be installed because it required the source.,,R
0x8024002E,WU_E_WU_DISABLED,Access to an unmanaged server isn't allowed.,,R
0x8024002F,WU_E_CALL_CANCELLED_BY_POLICY,Operation didn't complete because the DisableWindowsUpdateAccess policy was set.,,R
0x80240030,WU_E_INVALID_PROXY_SERVER,The format of the proxy list was invalid.,,R
0x80240031,WU_E_INVALID_FILE,The file is in the wrong format.,,R
0x80240032,WU_E_INVALID_CRITERIA,The search criteria string was invalid.,,R
0x80240033,WU_E_EULA_UNAVAILABLE,License terms couldn't be downloaded.,,R
0x80240034,WU_E_DOWNLOAD_FAILED,Update failed to download.,,R
0x80240035,WU_E_UPDATE_NOT_PROCESSED,The update wasn't processed.,,R
0x80240036,WU_E_INVALID_OPERATION,The object's current state didn't allow the operation.,,R
0x80240037,WU_E_NOT_SUPPORTED,The functionality for the operation isn't supported.,,R
0x80240038,WU_E_WINHTTP_INVALID_FILE,The downloaded file has an unexpected content type.,,R
0x80240039,WU_E_TOO_MANY_RESYNC,Agent is asked by server to resync too many times.,,R
0x80240040,WU_E_NO_SERVER_CORE_SUPPORT,WUA API method doesn't run on Server Core installation.,,R
0x80240041,WU_E_SYSPREP_IN_PROGRESS,Service isn't available while sysprep is running.,,R
0x80240042,WU_E_UNKNOWN_SERVICE,The update service is no longer registered with AU.,,R
0x80240043,WU_E_NO_UI_SUPPORT,There's no support for WUA UI.,,R
0x80240044,WU_E_PER_MACHINE_UPDATE_ACCESS_DENIED,Only administrators can perform this operation on per-computer updates.,,W
0x80240045,WU_E_UNSUPPORTED_SEARCHSCOPE,A search was attempted with a scope that is not currently supported for this type of search.,,W
0x80240046,WU_E_BAD_FILE_URL,The URL does not point to a file.,,W
0x80240047,WU_E_NOTSUPPORTED,The operation requested is not supported.,,W
0x80240048,WU_E_INVALID_NOTIFICATION_INFO,The featured update notification info returned by the server is invalid.,,W
0x80240049,WU_E_OUTOFRANGE,The data is out of range.,,W
0x8024004A,WU_E_SETUP_IN_PROGRESS,WUA operations are not available while operating system setup is running.,,W
0x8024043D,WU_E_SERVICEPROP_NOTAVAIL,The requested service property isn't available.,,R
0x80240FFF,WU_E_UNEXPECTED,An operation failed due to reasons not covered by another error code.,,R
0x80241001,WU_E_MSI_WRONG_VERSION,Search may have missed some updates because the Windows Installer is less than version 3.1.,,R
0x80241002,WU_E_MSI_NOT_CONFIGURED,Search may have missed some updates because the Windows Installer isn't configured.,,R
0x80241003,WU_E_MSP_DISABLED,Search may have missed some updates because policy has disabled Windows Installer patching.,,R
0x80241004,WU_E_MSI_WRONG_APP_CONTEXT,An update couldn't be applied because the application is installed per-user.,,R
0x80241FFF,WU_E_MSP_UNEXPECTED,Search may have missed some updates because there was a failure of the Windows Installer.,,R
0x80242000,WU_E_UH_REMOTEUNAVAILABLE,A request for a remote update handler couldn't be completed because no remote process is available.,,R
0x80242001,WU_E_UH_LOCALONLY,A request for a remote update handler couldn't be completed because the handler is local only.,,R
0x80242002,WU_E_UH_UNKNOWNHANDLER,A request for an update handler couldn't be completed because the handler couldn't be recognized.,,R
0x80242003,WU_E_UH_REMOTEALREADYACTIVE,A remote update handler couldn't be created because one already exists.,,R
0x80242004,WU_E_UH_DOESNOTSUPPORTACTION,A request for the handler to install (uninstall) an update couldn't be completed because the update doesn't support install (uninstall).,,R
0x80242005,WU_E_UH_WRONGHANDLER,An operation didn't complete because the wrong handler was specified.,,R
0x80242006,WU_E_UH_INVALIDMETADATA,A handler operation couldn't be completed because the update contains invalid metadata.,"Rename the software redistribution folder, and try to download the updates again: Rename the following folders to *.BAK: - %systemroot%\system32\catroot2 Type the following commands at a command prompt. Press ENTER after you type each command. Ren %systemroot%\SoftwareDistribution\DataStore DataStore.bak Ren %systemroot%\SoftwareDistribution\Download Download.bak Ren %systemroot%\system32\catroot2 catroot2.bak",C
0x80242007,WU_E_UH_INSTALLERHUNG,An operation couldn't be completed because the installer exceeded the time limit.,,R
0x80242008,WU_E_UH_OPERATIONCANCELLED,An operation being done by the update handler was canceled.,,R
0x80242009,WU_E_UH_BADHANDLERXML,An operation couldn't be completed because the handler-specific metadata is invalid.,,R
0x8024200A,WU_E_UH_CANREQUIREINPUT,A request to the handler to install an update couldn't be completed because the update requires user input.,,R
0x8024200B,WU_E_UH_INSTALLERFAILURE,The installer failed to install (uninstall) one or more updates.,,R
0x8024200C,WU_E_UH_FALLBACKTOSELFCONTAINED,The update handler should download self-contained content rather than delta-compressed content for the update.,,R
0x8024200D,WU_E_UH_NEEDANOTHERDOWNLOAD,The update handler didn't install the update because it needs to be downloaded again.,,R
0x8024200E,WU_E_UH_NOTIFYFAILURE,The update handler failed to send notification of the status of the install (uninstall) operation.,,R
0x8024200F,WU_E_UH_INCONSISTENT_FILE_NAMES,The file names contained in the update metadata and in the update package are inconsistent.,,R
0x80242010,WU_E_UH_FALLBACKERROR,The update handler failed to fall back to the self-contained content.,,R
0x80242011,WU_E_UH_TOOMANYDOWNLOADREQUESTS,The update handler has exceeded the maximum number of download requests.,,R
0x80242012,WU_E_UH_UNEXPECTEDCBSRESPONSE,The update handler has received an unexpected response from CBS.,,R
0x80242013,WU_E_UH_BADCBSPACKAGEID,The update metadata contains an invalid CBS package identifier.,,R
0x80242014,WU_E_UH_POSTREBOOTSTILLPENDING,The post-restart operation for the update is still in progress.,Some Windows updates require the device to be restarted. Restart the device to complete update the installation.,C
0x80242015,WU_E_UH_POSTREBOOTRESULTUNKNOWN,The result of the post-reboot operation for the update couldn't be determined.,,R
0x80242016,WU_E_UH_POSTREBOOTUNEXPECTEDSTATE,The state of the update after its post-reboot operation has completed is unexpected.,,R
0x80242017,WU_E_UH_NEW_SERVICING_STACK_REQUIRED,The OS servicing stack must be updated before this update is downloaded or installed.,,R
0x80242FFF,WU_E_UH_UNEXPECTED,An update handler error not covered by another WU_E_UH_* code.,,R
0x80243001,WU_E_INSTALLATION_RESULTS_UNKNOWN_VERSION,The results of download and installation couldn't be read from the registry due to an unrecognized data format version.,,R
0x80243002,WU_E_INSTALLATION_RESULTS_INVALID_DATA,The results of download and installation couldn't be read from the registry due to an invalid data format.,,R
0x80243003,WU_E_INSTALLATION_RESULTS_NOT_FOUND,The results of download and installation aren't available; the operation may have failed to start.,,R
0x80243004,WU_E_TRAYICON_FAILURE,A failure occurred when trying to create an icon in the taskbar notification area.,,R
0x80243FFD,WU_E_NON_UI_MODE,Unable to show UI when in non-UI mode; Windows Update client UI modules may not be installed.,,R
0x80243FFE,WU_E_WUCLTUI_UNSUPPORTED_VERSION,Unsupported version of Windows Update client UI exported functions.,,R
0x80243FFF,WU_E_AUCLIENT_UNEXPECTED,There was a user interface error not covered by another WU_E_AUCLIENT_* error code.,,R
0x80244000,WU_E_PT_SOAPCLIENT_BASE,WU_E_PT_SOAPCLIENT_* error codes map to the SOAPCLIENT_ERROR enum of the ATL Server Library.,,R
0x80244001,WU_E_PT_SOAPCLIENT_INITIALIZE,Same as SOAPCLIENT_INITIALIZE_ERROR - initialization of the SOAP client failed possibly because of an MSXML installation failure.,,R
0x80244002,WU_E_PT_SOAPCLIENT_OUTOFMEMORY,Same as SOAPCLIENT_OUTOFMEMORY - SOAP client failed because it ran out of memory.,,R
0x80244003,WU_E_PT_SOAPCLIENT_GENERATE,Same as SOAPCLIENT_GENERATE_ERROR - SOAP client failed to generate the request.,,R
0x80244004,WU_E_PT_SOAPCLIENT_CONNECT,Same as SOAPCLIENT_CONNECT_ERROR - SOAP client failed to connect to the server.,,R
0x80244005,WU_E_PT_SOAPCLIENT_SEND,Same as SOAPCLIENT_SEND_ERROR - SOAP client failed to send a message for reasons of WU_E_WINHTTP_* error codes.,,R
0x80244006,WU_E_PT_SOAPCLIENT_SERVER,Same as SOAPCLIENT_SERVER_ERROR - SOAP client failed because there was a server error.,,R
0x80244007,WU_E_PT_SOAPCLIENT_SOAPFAULT,SOAP client failed because there was a SOAP fault for reasons of WU_E_PT_SOAP_* error codes.,"This issue occurs because Windows can't renew the cookies for Windows Update. For more information to resolve the issue, see 0x80244007 error when Windows tries to scan for updates on a WSUS server.",C
0x80244008,WU_E_PT_SOAPCLIENT_PARSEFAULT,Same as SOAPCLIENT_PARSEFAULT_ERROR - SOAP client failed to parse a SOAP fault.,,R
0x80244009,WU_E_PT_SOAPCLIENT_READ,Same as SOAPCLIENT_READ_ERROR - SOAP client failed while reading the response from the server.,,R
0x8024400A,WU_E_PT_SOAPCLIENT_PARSE,Same as SOAPCLIENT_PARSE_ERROR - SOAP client failed to parse the response from the server.,,R
0x8024400B,WU_E_PT_SOAP_VERSION,Same as SOAP_E_VERSION_MISMATCH - SOAP client found an unrecognizable namespace for the SOAP envelope.,,R
0x8024400C,WU_E_PT_SOAP_MUST_UNDERSTAND,Same as SOAP_E_MUST_UNDERSTAND - SOAP client was unable to understand a header.,,R
0x8024400D,WU_E_PT_SOAP_CLIENT,Same as SOAP_E_CLIENT - SOAP client found the message was malformed; fix before resending.,,R
0x8024400E,WU_E_PT_SOAP_SERVER,Same as SOAP_E_SERVER - The SOAP message couldn't be processed due to a server error; resend later.,,R
0x8024400F,WU_E_PT_WMI_ERROR,There was an unspecified Windows Management Instrumentation (WMI) error.,,R
0x80244010,WU_E_PT_EXCEEDED_MAX_SERVER_TRIPS,The number of round trips to the server exceeded the maximum limit.,,R
0x80244011,WU_E_PT_SUS_SERVER_NOT_SET,WUServer policy value is missing in the registry.,,R
0x80244012,WU_E_PT_DOUBLE_INITIALIZATION,Initialization failed because the object was already initialized.,,R
0x80244013,WU_E_PT_INVALID_COMPUTER_NAME,The computer name couldn't be determined.,,R
0x80244015,WU_E_PT_REFRESH_CACHE_REQUIRED,The reply from the server indicates that the server was changed or the cookie was invalid; refresh the state of the internal cache and retry.,,R
0x80244016,WU_E_PT_HTTP_STATUS_BAD_REQUEST,Same as HTTP status 400 - the server couldn't process the request due to invalid syntax.,,R
0x80244017,WU_E_PT_HTTP_STATUS_DENIED,Same as HTTP status 401 - the requested resource requires user authentication.,,R
0x80244018,WU_E_PT_HTTP_STATUS_FORBIDDEN,Same as HTTP status 403 - server understood the request but declined to fulfill it.,,R
0x80244019,WU_E_PT_HTTP_STATUS_NOT_FOUND,Same as HTTP status 404 - the server can't find the requested URI (Uniform Resource Identifier).,,R
0x8024401A,WU_E_PT_HTTP_STATUS_BAD_METHOD,Same as HTTP status 405 - the HTTP method isn't allowed.,,R
0x8024401B,WU_E_PT_HTTP_STATUS_PROXY_AUTH_REQ,Same as HTTP status 407 - proxy authentication is required. Unable to authenticate through a proxy server.,"Either the Winhttp proxy or WinInet proxy settings aren't configured correctly. This error generally means that the Windows Update Agent can't connect to the update servers or your own update source, such as WSUS, Configuration Manager, or Microsoft Intune, due to a proxy error. Verify the proxy settings on the client. The Windows Update Agent uses WinHTTP to scan for available updates. When there's a proxy server between the client and the update source, the proxy settings must be configured correctly on the clients to enable them to communicate by using the source's FQDN. Check with your network and proxy teams to verify that the device can access the update source without the proxy requiring user authentication.",C
0x8024401C,WU_E_PT_HTTP_STATUS_REQUEST_TIMEOUT,Same as HTTP status 408 - the server timed out waiting for the request.,,R
0x8024401D,WU_E_PT_HTTP_STATUS_CONFLICT,Same as HTTP status 409 - the request wasn't completed due to a conflict with the current state of the resource.,,R
0x8024401E,WU_E_PT_HTTP_STATUS_GONE,Same as HTTP status 410 - requested resource is no longer available at the server.,,R
0x8024401F,WU_E_PT_HTTP_STATUS_SERVER_ERROR,Same as HTTP status 500 - an error internal to the server prevented fulfilling the request.,,R
0x80244020,WU_E_PT_HTTP_STATUS_NOT_SUPPORTED,Same as HTTP status 500 - server doesn't support the functionality required to fulfill the request.,,R
0x80244021,WU_E_PT_HTTP_STATUS_BAD_GATEWAY,Same as HTTP status 502 - the server while acting as a gateway or a proxy received an invalid response from the upstream server it accessed in attempting to fulfill the request.,,R
0x80244022,WU_E_PT_HTTP_STATUS_SERVICE_UNAVAILABLE,Same as HTTP status 503 - the service is temporarily overloaded. Unable to connect to the configured update source.,Network troubleshooting is needed to resolve the connectivity issue. Check with your network and proxy teams to verify that the device can access the update source without the proxy requiring user authentication.,C
0x80244023,WU_E_PT_HTTP_STATUS_GATEWAY_TIMEOUT,Same as HTTP status 503 - the request was timed out waiting for a gateway.,,R
0x80244024,WU_E_PT_HTTP_STATUS_VERSION_NOT_SUP,Same as HTTP status 505 - the server doesn't support the HTTP protocol version used for the request.,,R
0x80244025,WU_E_PT_FILE_LOCATIONS_CHANGED,Operation failed due to a changed file location; refresh internal state and resend.,,R
0x80244026,WU_E_PT_REGISTRATION_NOT_SUPPORTED,Operation failed because Windows Update Agent doesn't support registration with a non-WSUS server.,,R
0x80244027,WU_E_PT_NO_AUTH_PLUGINS_REQUESTED,The server returned an empty authentication information list.,,R
0x80244028,WU_E_PT_NO_AUTH_COOKIES_CREATED,Windows Update Agent was unable to create any valid authentication cookies.,,R
0x80244029,WU_E_PT_INVALID_CONFIG_PROP,A configuration property value was wrong.,,R
0x8024402A,WU_E_PT_CONFIG_PROP_MISSING,A configuration property value was missing.,,R
0x8024402B,WU_E_PT_HTTP_STATUS_NOT_MAPPED,The HTTP request couldn't be completed and the reason didn't correspond to any of the WU_E_PT_HTTP_* error codes.,,R
0x8024402C,WU_E_PT_WINHTTP_NAME_NOT_RESOLVED,Same as ERROR_WINHTTP_NAME_NOT_RESOLVED - the proxy server or target server name can't be resolved.,,R
0x8024402F,WU_E_PT_ECP_SUCCEEDED_WITH_ERRORS,External.cab file processing completed with some errors,This error might be caused by the Lightspeed Rocket for web filtering software. Add the IP addresses of the devices that you want to receive updates to the exceptions list of Lightspeed Rocket.,C
0x80244030,WU_E_PT_ECP_INIT_FAILED,The external cab processor initialization didn't complete.,,R
0x80244031,WU_E_PT_ECP_INVALID_FILE_FORMAT,The format of a metadata file was invalid.,,R
0x80244032,WU_E_PT_ECP_INVALID_METADATA,External cab processor found invalid metadata.,,R
0x80244033,WU_E_PT_ECP_FAILURE_TO_EXTRACT_DIGEST,The file digest couldn't be extracted from an external cab file.,,R
0x80244034,WU_E_PT_ECP_FAILURE_TO_DECOMPRESS_CAB_FILE,An external cab file couldn't be decompressed.,,R
0x80244035,WU_E_PT_ECP_FILE_LOCATION_ERROR,External cab processor was unable to get file locations.,,R
0x80244FFF,WU_E_PT_UNEXPECTED,A communication error not covered by another WU_E_PT_* error code.,,R
0x80245001,WU_E_REDIRECTOR_LOAD_XML,The redirector XML document couldn't be loaded into the DOM class.,,R
0x80245002,WU_E_REDIRECTOR_S_FALSE,The redirector XML document is missing some required information.,,R
0x80245003,WU_E_REDIRECTOR_ID_SMALLER,The redirectorId in the downloaded redirector cab is less than in the cached cab.,,R
0x8024502D,WU_E_PT_SAME_REDIR_ID,Windows Update Agent failed to download a redirector cabinet file with a new redirectorId value from the server during the recovery.,,R
0x8024502E,WU_E_PT_NO_MANAGED_RECOVER,A redirector recovery action didn't complete because the server is managed.,,R
0x80245FFF,WU_E_REDIRECTOR_UNEXPECTED,The redirector failed for reasons not covered by another WU_E_REDIRECTOR_* error code.,,R
0x80246001,WU_E_DM_URLNOTAVAILABLE,A download manager operation couldn't be completed because the requested file doesn't have a URL.,,R
0x80246002,WU_E_DM_INCORRECTFILEHASH,A download manager operation couldn't be completed because the file digest wasn't recognized.,,R
0x80246003,WU_E_DM_UNKNOWNALGORITHM,A download manager operation couldn't be completed because the file metadata requested an unrecognized hash algorithm.,,R
0x80246004,WU_E_DM_NEEDDOWNLOADREQUEST,An operation couldn't be completed because a download request is required from the download handler.,,R
0x80246005,WU_E_DM_NONETWORK,A download manager operation couldn't be completed because the network connection was unavailable.,,R
0x80246006,WU_E_DM_WRONGBITSVERSION,A download manager operation couldn't be completed because the version of Background Intelligent Transfer Service (BITS) is incompatible.,,R
0x80246007,WU_E_DM_NOTDOWNLOADED,The update hasn't been downloaded.,,R
0x80246008,WU_E_DM_FAILTOCONNECTTOBITS,A download manager operation failed because the download manager was unable to connect the Background Intelligent Transfer Service (BITS).,,R
0x80246009,WU_E_DM_BITSTRANSFERERROR,A download manager operation failed because there was an unspecified Background Intelligent Transfer Service (BITS) transfer error.,,R
0x8024600A,WU_E_DM_DOWNLOADLOCATIONCHANGED,A download must be restarted because the location of the source of the download has changed.,,R
0x8024600B,WU_E_DM_CONTENTCHANGED,A download must be restarted because the update content changed in a new revision.,,R
0x80246017,WU_E_DM_UNAUTHORIZED_LOCAL_USER,The download failed because the local user was denied authorization to download the content.,Ensure that the user attempting to download and install updates has been provided with sufficient privileges to install updates (Local Administrator).,C
0x80246FFF,WU_E_DM_UNEXPECTED,There was a download manager error not covered by another WU_E_DM_* error code.,,R
0x80247001,WU_E_OL_INVALID_SCANFILE,An operation couldn't be completed because the scan package was invalid.,,R
0x80247002,WU_E_OL_NEWCLIENT_REQUIRED,An operation couldn't be completed because the scan package requires a greater version of the Windows Update Agent.,,R
0x80247FFF,WU_E_OL_UNEXPECTED,Search using the scan package failed.,,R
0x80248000,WU_E_DS_SHUTDOWN,An operation failed because Windows Update Agent is shutting down.,,R
0x80248001,WU_E_DS_INUSE,An operation failed because the data store was in use.,,R
0x80248002,WU_E_DS_INVALID,The current and expected states of the data store don't match.,,R
0x80248003,WU_E_DS_TABLEMISSING,The data store is missing a table.,,R
0x80248004,WU_E_DS_TABLEINCORRECT,The data store contains a table with unexpected columns.,,R
0x80248005,WU_E_DS_INVALIDTABLENAME,A table couldn't be opened because the table isn't in the data store.,,R
0x80248006,WU_E_DS_BADVERSION,The current and expected versions of the data store don't match.,,R
0x80248007,WU_E_DS_NODATA,The information requested isn't in the data store.,,R
0x80248008,WU_E_DS_MISSINGDATA,The data store is missing required information or has a NULL in a table column that requires a non-null value.,,R
0x80248009,WU_E_DS_MISSINGREF,The data store is missing required information or has a reference to missing license terms file localized property or linked row.,,R
0x8024800A,WU_E_DS_UNKNOWNHANDLER,The update wasn't processed because its update handler couldn't be recognized.,,R
0x8024800B,WU_E_DS_CANTDELETE,The update wasn't deleted because it's still referenced by one or more services.,,R
0x8024800C,WU_E_DS_LOCKTIMEOUTEXPIRED,The data store section couldn't be locked within the allotted time.,,R
0x8024800D,WU_E_DS_NOCATEGORIES,The category wasn't added because it contains no parent categories and isn't a top-level category itself.,,R
0x8024800E,WU_E_DS_ROWEXISTS,The row wasn't added because an existing row has the same primary key.,,R
0x8024800F,WU_E_DS_STOREFILELOCKED,The data store couldn't be initialized because it was locked by another process.,,R
0x80248010,WU_E_DS_CANNOTREGISTER,The data store isn't allowed to be registered with COM in the current process.,,R
0x80248011,WU_E_DS_UNABLETOSTART,Couldn't create a data store object in another process.,,R
0x80248013,WU_E_DS_DUPLICATEUPDATEID,The server sent the same update to the client with two different revision IDs.,,R
0x80248014,WU_E_DS_UNKNOWNSERVICE,An operation didn't complete because the service isn't in the data store.,,R
0x80248015,WU_E_DS_SERVICEEXPIRED,An operation didn't complete because the registration of the service has expired.,,R
0x80248016,WU_E_DS_DECLINENOTALLOWED,A request to hide an update was declined because it's a mandatory update or because it was deployed with a deadline.,,R
0x80248017,WU_E_DS_TABLESESSIONMISMATCH,A table wasn't closed because it isn't associated with the session.,,R
0x80248018,WU_E_DS_SESSIONLOCKMISMATCH,A table wasn't closed because it isn't associated with the session.,,R
0x80248019,WU_E_DS_NEEDWINDOWSSERVICE,A request to remove the Windows Update service or to unregister it with Automatic Updates was declined because it's a built-in service and/or Automatic Updates can't fall back to another service.,,R
0x8024801A,WU_E_DS_INVALIDOPERATION,A request was declined because the operation isn't allowed.,,R
0x8024801B,WU_E_DS_SCHEMAMISMATCH,The schema of the current data store and the schema of a table in a backup XML document don't match.,,R
0x8024801C,WU_E_DS_RESETREQUIRED,The data store requires a session reset; release the session and retry with a new session.,,R
0x8024801D,WU_E_DS_IMPERSONATED,A data store operation didn't complete because it was requested with an impersonated identity.,,R
0x80248FFF,WU_E_DS_UNEXPECTED,A data store error not covered by another WU_E_DS_* code.,,R
0x80249001,WU_E_INVENTORY_PARSEFAILED,Parsing of the rule file failed.,,R
0x80249002,WU_E_INVENTORY_GET_INVENTORY_TYPE_FAILED,Failed to get the requested inventory type from the server.,,R
0x80249003,WU_E_INVENTORY_RESULT_UPLOAD_FAILED,Failed to upload inventory result to the server.,,R
0x80249004,WU_E_INVENTORY_UNEXPECTED,There was an inventory error not covered by another error code.,,R
0x80249005,WU_E_INVENTORY_WMI_ERROR,A WMI error occurred when enumerating the instances for a particular class.,,R
0x8024A000,WU_E_AU_NOSERVICE,Automatic Updates was unable to service incoming requests.,,R
0x8024A002,WU_E_AU_NONLEGACYSERVER,The old version of the Automatic Updates client has stopped because the WSUS server has been upgraded.,,R
0x8024A003,WU_E_AU_LEGACYCLIENTDISABLED,The old version of the Automatic Updates client was disabled.,,R
0x8024A004,WU_E_AU_PAUSED,Automatic Updates was unable to process incoming requests because it was paused.,,R
0x8024A005,WU_E_AU_NO_REGISTERED_SERVICE,No unmanaged service is registered with AU.,,R
0x8024A10A,USO_E_SERVICE_SHUTTING_DOWN,Indicates that the Windows Update Service is shutting down.,"This error can occur after a long time of inactivity. The system doesn't respond, causing the service to be idle and, eventually, shut down. Make sure that the system remains active, and the connections remain established to complete the installation.",C
0x8024AFFF,WU_E_AU_UNEXPECTED,An Automatic Updates error not covered by another WU_E_AU* code.,,R
0x8024C001,WU_E_DRV_PRUNED,A driver was skipped.,,R
0x8024C002,WU_E_DRV_NOPROP_OR_LEGACY,A property for the driver couldn't be found. It may not conform with required specifications.,,R
0x8024C003,WU_E_DRV_REG_MISMATCH,The registry type read for the driver doesn't match the expected type.,,R
0x8024C004,WU_E_DRV_NO_METADATA,The driver update is missing metadata.,,R
0x8024C005,WU_E_DRV_MISSING_ATTRIBUTE,The driver update is missing a required attribute.,,R
0x8024C006,WU_E_DRV_SYNC_FAILED,Driver synchronization failed.,,R
0x8024C007,WU_E_DRV_NO_PRINTER_CONTENT,Information required for the synchronization of applicable printers is missing.,,R
0x8024CFFF,WU_E_DRV_UNEXPECTED,A driver error not covered by another WU_E_DRV_* code.,,R
0x8024D001,WU_E_SETUP_INVALID_INFDATA,Windows Update Agent couldn't be updated because an INF file contains invalid information.,,R
0x8024D002,WU_E_SETUP_INVALID_IDENTDATA,Windows Update Agent couldn't be updated because the wuident.cab file contains invalid information.,,R
0x8024D003,WU_E_SETUP_ALREADY_INITIALIZED,Windows Update Agent couldn't be updated because of an internal error that caused setup initialization to be performed twice.,,R
0x8024D004,WU_E_SETUP_NOT_INITIALIZED,Windows Update Agent couldn't be updated because setup initialization never completed successfully.,,R
0x8024D005,WU_E_SETUP_SOURCE_VERSION_MISMATCH,Windows Update Agent couldn't be updated because the versions specified in the INF don't match the actual source file versions.,,R
0x8024D006,WU_E_SETUP_TARGET_VERSION_GREATER,Windows Update Agent couldn't be updated because a WUA file on the target system is newer than the corresponding source file.,,R
0x8024D007,WU_E_SETUP_REGISTRATION_FAILED,Windows Update Agent couldn't be updated because regsvr32.exe returned an error.,,R
0x8024D009,WU_E_SETUP_SKIP_UPDATE,An update to the Windows Update Agent was skipped due to a directive in the Wuident.cab file.,"You might encounter this error if WSUS isn't sending the self-update to the clients. For more information to resolve the issue, see KB920659.",C
0x8024D00A,WU_E_SETUP_UNSUPPORTED_CONFIGURATION,Windows Update Agent couldn't be updated because the current system configuration isn't supported.,,R
0x8024D00B,WU_E_SETUP_BLOCKED_CONFIGURATION,Windows Update Agent couldn't be updated because the system is configured to block the update.,,R
0x8024D00C,WU_E_SETUP_REBOOT_TO_FIX,Windows Update Agent couldn't be updated because a restart of the system is required.,,R
0x8024D00D,WU_E_SETUP_ALREADYRUNNING,Windows Update Agent setup is already running.,,R
0x8024D00E,WU_E_SETUP_REBOOTREQUIRED,Windows Update Agent setup package requires a reboot to complete installation.,,R
0x8024D00F,WU_E_SETUP_HANDLER_EXEC_FAILURE,Windows Update Agent couldn't be updated because the setup handler failed during execution.,,R
0x8024D010,WU_E_SETUP_INVALID_REGISTRY_DATA,Windows Update Agent couldn't be updated because the registry contains invalid information.,,R
0x8024D013,WU_E_SETUP_WRONG_SERVER_VERSION,Windows Update Agent couldn't be updated because the server doesn't contain update information for this version.,,R
0x8024DFFF,WU_E_SETUP_UNEXPECTED,Windows Update Agent couldn't be updated because of an error not covered by another WU_E_SETUP_* error code.,,R
0x8024E001,WU_E_EE_UNKNOWN_EXPRESSION,An expression evaluator operation couldn't be completed because an expression was unrecognized.,,R
0x8024E002,WU_E_EE_INVALID_EXPRESSION,An expression evaluator operation couldn't be completed because an expression was invalid.,,R
0x8024E003,WU_E_EE_MISSING_METADATA,An expression evaluator operation couldn't be completed because an expression contains an incorrect number of metadata nodes.,,R
0x8024E004,WU_E_EE_INVALID_VERSION,An expression evaluator operation couldn't be completed because the version of the serialized expression data is invalid.,,R
0x8024E005,WU_E_EE_NOT_INITIALIZED,The expression evaluator couldn't be initialized.,,R
0x8024E006,WU_E_EE_INVALID_ATTRIBUTEDATA,An expression evaluator operation couldn't be completed because there was an invalid attribute.,,R
0x8024E007,WU_E_EE_CLUSTER_ERROR,An expression evaluator operation couldn't be completed because the cluster state of the computer couldn't be determined.,,R
0x8024EFFF,WU_E_EE_UNEXPECTED,There was an expression evaluator error not covered by another WU_E_EE_* error code.,,R
0x8024F001,WU_E_REPORTER_EVENTCACHECORRUPT,The event cache file was defective.,,R
0x8024F002,WU_E_REPORTER_EVENTNAMESPACEPARSEFAILED,The XML in the event namespace descriptor couldn't be parsed.,,R
0x8024F003,WU_E_INVALID_EVENT,The XML in the event namespace descriptor couldn't be parsed.,,R
0x8024F004,WU_E_SERVER_BUSY,The server rejected an event because the server was too busy.,,R
0x8024FFFF,WU_E_REPORTER_UNEXPECTED,There was a reporter error not covered by another error code.,,R
0x80D02002,TIME_OUT_ERRORS,The operation timed out,Make sure that no firewall rules or proxies block Microsoft download URLs. Take a network monitor trace to understand the situation better. <Refer to Firewall Troubleshooting scenario>,C
'@ | ConvertFrom-Csv | ForEach-Object { $WUErrorTable[$_.Code] = $_ }

# Returns the MS Learn details for an error code (0x80240022, 80240022 or a signed number such as -2145124318)
function Get-WUErrorInfo {
    param([string]$Code)
    if (-not $Code) { return $null }
    $c = $Code.Trim()
    if ($c -match '^-?\d+$') { $c = '0x{0:X8}' -f [int64]$c -replace '^0xFFFFFFFF', '0x' }
    elseif ($c -match '(?:0x)?([0-9A-Fa-f]{8})') { $c = '0x' + $Matches[1].ToUpper() }
    else { return $null }
    $e = $WUErrorTable[$c]
    if ($e) {
        $link = $WUErrorSource[$e.Source]
        if ($e.Source -eq 'C') { $link += '#' + $c.ToLower() }
        return [pscustomobject]@{
            Code = $c; Message = $e.Message; Description = $e.Description
            Mitigation = if ($e.Mitigation) { $e.Mitigation } else { 'No mitigation listed on MS Learn for this code. See the link.' }
            Link = $link; Found = $true
        }
    }
    # Not on the MS Learn Windows Update pages. 0x8007xxxx is a Windows (Win32) error: use the system message.
    $sys = ''
    if ($c -match '^0x8007([0-9A-F]{4})$') {
        try { $sys = ([ComponentModel.Win32Exception][Convert]::ToInt32($Matches[1], 16)).Message } catch { }
        if ($sys -match '^Unknown error') { $sys = '' }
    }
    [pscustomobject]@{
        Code = $c; Message = ''
        Description = if ($sys) { "Not on the MS Learn Windows Update error pages. Windows system message: $sys" } else { 'Not on the MS Learn Windows Update error pages.' }
        Mitigation = 'Search MS Learn for the code (see the link).'
        Link = "https://learn.microsoft.com/search/?terms=$c"; Found = $false
    }
}
#endregion

# Parses the Detect-WUInstallHistory.ps1 output line
# "WUHIST v1.0 | OS=26100.6899 | Scan=... | Boot=... | 2026-10=KB5066835,I:2026-10-21T12:04Z,D:...,F:0 | ..."
function ConvertFrom-WUHistory {
    param([string]$Text)
    $o = [pscustomobject]@{ Valid = $false; Version = ''; OS = ''; Scan = $null; Boot = $null; Error = ''; Wmi = ''; Months = @{} }
    if ($Text -notmatch '^WUHIST') { return $o }
    $o.Valid = $true
    if ($Text -match '^WUHIST v([\d.]+)') { $o.Version = $Matches[1] }
    foreach ($part in ($Text -split '\s\|\s')) {
        $part = $part.Trim()
        if     ($part -match '^OS=(.*)$')    { $o.OS = $Matches[1] }
        elseif ($part -match '^Scan=(.*)$')  { $o.Scan = ConvertFrom-Utc $Matches[1] }
        elseif ($part -match '^Boot=(.*)$')  { $o.Boot = ConvertFrom-Utc $Matches[1] }
        elseif ($part -match '^ERROR=(.*)$') { $o.Error = $Matches[1] }
        elseif ($part -match '^WMI=(.*)$')   { $o.Wmi = $Matches[1] }
        elseif ($part -match '^(\d{4}-\d{2})=(KB[\d?]+)(.*)$') {
            $m = [pscustomobject]@{ KB = $Matches[2]; Installed = $null; Download = $null; Failed = 0; FirstFail = $null; Error = ''; Pending = $false }
            foreach ($kv in ($Matches[3] -split ',')) {
                if     ($kv -match '^I:(.+)$')  { $m.Installed = ConvertFrom-Utc $Matches[1] }
                elseif ($kv -match '^D:(.+)$')  { $m.Download  = ConvertFrom-Utc $Matches[1] }
                elseif ($kv -match '^F:(\d+)$') { $m.Failed    = [int]$Matches[1] }
                elseif ($kv -match '^FD:(.+)$') { $m.FirstFail = ConvertFrom-Utc $Matches[1] }
                elseif ($kv -match '^P:1$')     { $m.Pending   = $true }
                elseif ($kv -match '^E:(0x[0-9A-Fa-f]{8})$') { $m.Error = $Matches[1].ToUpper() -replace '^0X', '0x' }
            }
            $o.Months[$part.Substring(0, 7)] = $m
        }
    }
    $o
}

# Judges one device against one month for one ring. Returns Compliance (Green/Red/Grey) and Reason.
function Test-RingCompliance {
    param($Ring, $History, [string]$MonthKey, [datetime]$Release, [string[]]$LaterMonths)
    $deferEnd = $Release.AddDays([int]$Ring.QualityDeferral)
    $deadline = if ($null -ne $Ring.QualityDeadline) { $deferEnd.AddDays([int]$Ring.QualityDeadline + [int]$Ring.GraceDays) } else { $null }
    $r = [ordered]@{ DeferralEnds = $deferEnd; Deadline = $deadline; Compliance = 'Grey'; Reason = ''; Entry = $null; Covered = $null }

    if (-not $History -or -not $History.Valid) { $r.Reason = 'No data from the device (remediation not run yet)'; return [pscustomobject]$r }
    if ($History.Error) { $r.Reason = "Device script error: $($History.Error)"; return [pscustomobject]$r }

    $e = $History.Months[$MonthKey]
    $r.Entry = $e
    if ($e -and $e.Installed) {
        $day = $e.Installed.Date
        if ($day -lt $deferEnd) {
            $r.Compliance = 'Red'; $r.Reason = "Installed $([int]($deferEnd - $day).TotalDays) day(s) before the deferral ended"
        } elseif ($deadline -and $day -gt $deadline) {
            $r.Compliance = 'Red'; $r.Reason = "Installed $([int]($day - $deadline).TotalDays) day(s) after the deadline"
        } else {
            $r.Compliance = 'Green'; $r.Reason = 'Installed within the ring window'
        }
        if ($e.Failed) { $r.Reason += " ($($e.Failed) failed attempt(s) first)" }
        return [pscustomobject]$r
    }

    # Not installed: did a later cumulative update cover it in time?
    foreach ($lm in $LaterMonths) {
        $later = $History.Months[$lm]
        if ($later -and $later.Installed) {
            $r.Covered = $later
            if (-not $deadline -or $later.Installed.Date -le $deadline) {
                $r.Compliance = 'Green'; $r.Reason = "Not installed, covered by $($later.KB) ($lm) installed $(Format-Day $later.Installed), within this month's window"
            } else {
                $r.Compliance = 'Red'; $r.Reason = "Not installed. Covered later by $($later.KB) ($lm) on $(Format-Day $later.Installed), after this month's deadline"
            }
            return [pscustomobject]$r
        }
    }

    $failNote = if ($e -and $e.Failed) { "Failed $($e.Failed) time(s), first $(Format-Day $e.FirstFail)$(if ($e.Error) { ", last error $($e.Error)$(if ($x = Get-WUErrorInfo $e.Error) { if ($x.Message) { " ($($x.Message))" } })" }). " } else { '' }
    if ($e -and $e.Pending) {
        $failNote += 'Started but not finished (usually waiting for a restart'
        $failNote += if ($History.Boot) { ", last restart $(Format-Day $History.Boot), $([int]($Today - $History.Boot.Date).TotalDays) day(s) ago). " } else { '). ' }
    }
    if ($deadline -and $Today -gt $deadline) {
        $r.Compliance = 'Red'; $r.Reason = "${failNote}Not installed, deadline $(Format-Day $deadline) has passed"
    } elseif ($e -and $e.Failed) {
        $r.Compliance = 'Red'; $r.Reason = "${failNote}Not installed yet"
    } else {
        $r.Compliance = 'Grey'; $r.Reason = if ($Today -lt $deferEnd) { "${failNote}Not due yet (deferral not ended)" } else { "${failNote}Not installed yet, deadline $(Format-Day $deadline)" }
    }
    [pscustomobject]$r
}

function Get-SafeSheetName {
    param([string]$Name, [hashtable]$Used)
    $n = ($Name -replace '[\[\]\:\*\?\/\\]', '-').Trim()
    if ($n.Length -gt 31) { $n = $n.Substring(0, 31) }
    $base = $n; $i = 2
    while ($Used.ContainsKey($n.ToLower())) { $suffix = " ($i)"; $n = $base.Substring(0, [math]::Min($base.Length, 31 - $suffix.Length)) + $suffix; $i++ }
    $Used[$n.ToLower()] = $true
    $n
}
#endregion

#region Modules and sign-in
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    $ans = Read-Host 'The ImportExcel module is needed to write the spreadsheet. Install it for the current user now? (Y/N)'
    if ($ans -notmatch '^[Yy]') { throw 'ImportExcel is required. Install-Module ImportExcel -Scope CurrentUser' }
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    Install-Module ImportExcel -Scope CurrentUser -Force
}
Import-Module ImportExcel

$scopes = 'DeviceManagementConfiguration.Read.All', 'DeviceManagementManagedDevices.Read.All', 'Group.Read.All', 'Device.Read.All'
$test = $null
if ($TestDataPath) {
    $test = Get-Content -Path $TestDataPath -Raw | ConvertFrom-Json
    if ($test.Today) { $Today = ([datetime]$test.Today).Date }
    Write-Host "TEST MODE: data from $TestDataPath, today = $(Format-Day $Today)"
} else {
    Import-Module Microsoft.Graph.Authentication
    $ctx = Get-MgContext
    if (-not $ctx -or @($scopes | Where-Object { $ctx.Scopes -notcontains $_ }).Count) { Connect-MgGraph -Scopes $scopes -NoWelcome }
}
New-Item -Path $OutputFolder -ItemType Directory -Force | Out-Null
#endregion

#region 1. Update rings
Write-Host 'Reading update rings...'
$ringRaw = if ($test) { @($test.Rings) } else {
    try { @(Get-AllPages -Uri "$beta/deviceManagement/deviceConfigurations?`$filter=isof('microsoft.graph.windowsUpdateForBusinessConfiguration')") }
    catch {
        Write-Warning "  Filtered read failed ($($_.Exception.Message)). Reading all configuration profiles instead."
        @(Get-AllPages -Uri "$beta/deviceManagement/deviceConfigurations" | Where-Object { $_.'@odata.type' -like '*windowsUpdateForBusinessConfiguration' })
    }
}
$groupName = @{}
function Get-GroupName {
    param([string]$Id)
    if ($test) { $g = $test.GroupNames.$Id; if ($g) { return $g } else { return $Id } }
    if (-not $groupName.ContainsKey($Id)) {
        try { $groupName[$Id] = (Invoke-GraphGet -Uri "$v1/groups/$Id`?`$select=displayName").displayName } catch { $groupName[$Id] = "$Id (not found)" }
    }
    $groupName[$Id]
}

$rings = foreach ($r in $ringRaw) {
    $assign = if ($test) { @($r.assignments) } else { @(Get-AllPages -Uri "$beta/deviceManagement/deviceConfigurations/$($r.id)/assignments") }
    $inc = @(); $exc = @(); $all = $false; $allUsers = $false
    foreach ($a in $assign) {
        switch -Wildcard ([string]$a.target.'@odata.type') {
            '*exclusionGroupAssignmentTarget'   { $exc += ([string]$a.target.groupId).ToLower() }
            '*allDevicesAssignmentTarget'       { $all = $true }
            '*allLicensedUsersAssignmentTarget' { $allUsers = $true }
            '*.groupAssignmentTarget'           { $inc += ([string]$a.target.groupId).ToLower() }
        }
    }
    $sched = $r.installationSchedule
    $schedText = switch -Wildcard ([string]$sched.'@odata.type') {
        '*ActiveHoursInstall'  { "Active hours $($sched.activeHoursStart) to $($sched.activeHoursEnd)" }
        '*ScheduledInstall'    { "Scheduled: $($sched.scheduledInstallDay) at $($sched.scheduledInstallTime)" }
        default                { '' }
    }
    [pscustomobject]@{
        Id = [string]$r.id; Name = [string]$r.displayName; Raw = $r
        QualityDeferral = [int]$r.qualityUpdatesDeferralPeriodInDays
        QualityDeadline = $r.deadlineForQualityUpdatesInDays
        GraceDays       = [int]$r.deadlineGracePeriodInDays
        Include = $inc; Exclude = $exc; AllDevices = $all; AllUsers = $allUsers
        Schedule = $schedText
        QualityPaused = [bool]$r.qualityUpdatesPaused
    }
}
Write-Host "  Update rings: $(@($rings).Count)"
foreach ($r in $rings) {
    Write-Host ("  {0} | quality deferral {1} d | deadline {2} | grace {3} d{4}" -f $r.Name, $r.QualityDeferral,
        $(if ($null -ne $r.QualityDeadline) { "$($r.QualityDeadline) d" } else { 'not set' }), $r.GraceDays, $(if ($r.QualityPaused) { ' | QUALITY UPDATES PAUSED' }))
}
#endregion

#region 2. Live Intune devices
if ($DeviceListPath) {
    $listed = @(Import-DeviceList -Path $DeviceListPath)
    Write-Host "Device list $DeviceListPath : $($listed.Count) device name(s)"
    if (-not $listed.Count) { Write-Warning 'The device list is empty.'; return }
    $DeviceName = @(@($DeviceName) + $listed | Where-Object { $_ } | Sort-Object -Unique)
}
$nameScope = if ($DeviceListPath) { "$($DeviceName.Count) devices from $(Split-Path $DeviceListPath -Leaf)" } elseif ($DeviceName) { "names: $($DeviceName -join ', ')" } elseif ($AllNames -or -not $NamePrefixes) { 'all names' } else { "names starting $($NamePrefixes -join ', ')" }
Write-Host "Reading Intune Windows devices (checked in within $StaleDays days, $nameScope)..."
$cutoff = (Get-Date).ToUniversalTime().AddDays(-$StaleDays)
$devRaw = if ($test) { @($test.Devices) } else {
    $sel = '$select=id,deviceName,azureADDeviceId,userId,userPrincipalName,manufacturer,model,osVersion,lastSyncDateTime,managementAgent,configurationManagerClientEnabledFeatures'
    try { @(Get-AllPages -Uri "$beta/deviceManagement/managedDevices?`$filter=operatingSystem eq 'Windows'&$sel&`$top=999") }
    catch {
        Write-Warning "  Co-management details not available ($($_.Exception.Message)). Reading without them."
        @(Get-AllPages -Uri "$beta/deviceManagement/managedDevices?`$filter=operatingSystem eq 'Windows'&`$select=id,deviceName,azureADDeviceId,userId,userPrincipalName,manufacturer,model,osVersion,lastSyncDateTime,managementAgent&`$top=999")
    }
}
$prefixRx = if ($NamePrefixes -and -not $AllNames) { '^(' + (($NamePrefixes | ForEach-Object { [regex]::Escape($_) }) -join '|') + ')' } else { '.' }
$devices = @{}          # Entra device ID -> device
$devByUser = @{}        # user ID -> list of Entra device IDs
foreach ($d in $devRaw) {
    $name = [string]$d.deviceName
    if ($DeviceName -and $DeviceName -notcontains $name) { continue }
    if (-not $DeviceName -and $name -notmatch $prefixRx) { continue }
    $sync = if ($d.lastSyncDateTime) { ([datetime]$d.lastSyncDateTime).ToUniversalTime() } else { [datetime]::MinValue }
    if (-not $DeviceName -and $sync -lt $cutoff) { continue }
    $aad = ([string]$d.azureADDeviceId).ToLower()
    if (-not $aad -or $aad -eq '00000000-0000-0000-0000-000000000000') { continue }
    if ($devices.ContainsKey($aad) -and $devices[$aad].LastSync -ge $sync) { continue }
    $cmWufb = $d.configurationManagerClientEnabledFeatures.windowsUpdateForBusiness
    $coMgd  = [string]$d.managementAgent -match 'configurationManager'
    $devices[$aad] = [pscustomobject]@{
        IntuneId = [string]$d.id; Name = $name; User = [string]$d.userPrincipalName; UserId = ([string]$d.userId).ToLower()
        Manufacturer = [string]$d.manufacturer; Model = [string]$d.model; OSVersion = [string]$d.osVersion; LastSync = $sync
        UpdatesBy = if ($coMgd -and $cmWufb -eq $false) { 'ConfigMgr' } elseif ($coMgd -and $null -eq $cmWufb) { 'Co-managed (workload unknown)' } else { 'Intune' }
    }
    if ($devices[$aad].UserId) {
        if (-not $devByUser.ContainsKey($devices[$aad].UserId)) { $devByUser[$devices[$aad].UserId] = New-Object System.Collections.Generic.List[string] }
        $devByUser[$devices[$aad].UserId].Add($aad)
    }
}
Write-Host "  Live devices in scope: $($devices.Count)"
$notFound = @()
if ($DeviceName) {
    $foundNames = @($devices.Values | ForEach-Object Name)
    $notFound = @($DeviceName | Where-Object { $foundNames -notcontains $_ })
    if ($notFound.Count) { Write-Warning "  $($notFound.Count) listed device(s) not found in Intune (or no Entra device ID): $(($notFound | Select-Object -First 20) -join ', ')$(if ($notFound.Count -gt 20) { ' ...' })" }
}
if ($devices.Count -eq 0) { Write-Warning 'No devices in scope.'; return }
#endregion

#region 3. Devices in each ring (groups expanded, user groups through primary user)
$groupDevices = @{}   # group ID -> HashSet of Entra device IDs
function Get-GroupDeviceSet {
    param([string]$GroupId)
    if ($groupDevices.ContainsKey($GroupId)) { return $groupDevices[$GroupId] }
    $set = New-Object System.Collections.Generic.HashSet[string]
    if ($test) {
        foreach ($m in @($test.Members.$GroupId)) {
            if ($m.type -eq 'device' -and $devices.ContainsKey($m.id)) { [void]$set.Add($m.id) }
            if ($m.type -eq 'user' -and $devByUser.ContainsKey($m.id)) { foreach ($x in $devByUser[$m.id]) { [void]$set.Add($x) } }
        }
    } else {
        try {
            foreach ($m in Get-AllPages -Uri "$v1/groups/$GroupId/transitiveMembers/microsoft.graph.device?`$select=deviceId&`$top=999") {
                $did = ([string]$m.deviceId).ToLower(); if ($devices.ContainsKey($did)) { [void]$set.Add($did) }
            }
            foreach ($m in Get-AllPages -Uri "$v1/groups/$GroupId/transitiveMembers/microsoft.graph.user?`$select=id&`$top=999") {
                $uid = ([string]$m.id).ToLower(); if ($devByUser.ContainsKey($uid)) { foreach ($x in $devByUser[$uid]) { [void]$set.Add($x) } }
            }
        } catch { Write-Warning "  Could not expand group $(Get-GroupName $GroupId): $($_.Exception.Message)" }
    }
    $groupDevices[$GroupId] = $set
    $set
}

Write-Host 'Working out which devices are in each ring...'
$ringsOfDevice = @{}   # Entra device ID -> list of ring names
$ringDevices   = @{}   # ring ID -> list of Entra device IDs
$ringVia       = @{}   # "deviceId|ring name" -> include groups (or All devices / All users) that put it in the ring
foreach ($r in $rings) {
    $members = New-Object System.Collections.Generic.HashSet[string]
    if ($r.AllDevices -or $r.AllUsers) {
        foreach ($k in $devices.Keys) { [void]$members.Add($k); $ringVia["$k|$($r.Name)"] = @($(if ($r.AllDevices) { 'All devices' } else { 'All users' })) }
    }
    foreach ($g in $r.Include) {
        foreach ($x in (Get-GroupDeviceSet $g)) {
            [void]$members.Add($x)
            $ringVia["$x|$($r.Name)"] = @($ringVia["$x|$($r.Name)"]) + (Get-GroupName $g) | Where-Object { $_ } | Select-Object -Unique
        }
    }
    foreach ($g in $r.Exclude) { foreach ($x in (Get-GroupDeviceSet $g)) { [void]$members.Remove($x) } }
    $ringDevices[$r.Id] = @($members)
    foreach ($x in $members) {
        if (-not $ringsOfDevice.ContainsKey($x)) { $ringsOfDevice[$x] = New-Object System.Collections.Generic.List[string] }
        $ringsOfDevice[$x].Add($r.Name)
    }
    Write-Host "  $($r.Name): $($members.Count) devices"
}
$multiRing = @($ringsOfDevice.Keys | Where-Object { $ringsOfDevice[$_].Count -gt 1 })
if ($multiRing.Count) { Write-Warning "  $($multiRing.Count) device(s) are in more than one update ring. See the 'Multiple rings' sheet." }
else { Write-Host '  No device is in more than one ring.' }
#endregion

#region 4. Device-reported Windows Update history
Write-Host "Reading device results from remediation matching '$RemediationName'..."
$history = @{}   # Intune device ID -> parsed history (+ ReportedOn)
$runStates = @()
$remName = ''
if ($test) { $runStates = @($test.RunStates); $remName = 'test data' }
else {
    $rem = @(Get-AllPages -Uri "$beta/deviceManagement/deviceHealthScripts?`$select=id,displayName" | Where-Object { $_.displayName -like $RemediationName }) | Select-Object -First 1
    if (-not $rem) { Write-Warning "  No remediation matches '$RemediationName'. Deploy Detect-WUInstallHistory.ps1 or set -RemediationName. Every device will show 'No data'." }
    else {
        $remName = $rem.displayName
        Write-Host "  Using remediation: $remName"
        $runStates = @(Get-AllPages -Uri "$beta/deviceManagement/deviceHealthScripts/$($rem.id)/deviceRunStates?`$select=id,lastStateUpdateDateTime,preRemediationDetectionScriptOutput&`$top=999")
    }
}
foreach ($st in $runStates) {
    $mid = ([string]$st.id -split ':')[-1]
    $h = ConvertFrom-WUHistory ([string]$st.preRemediationDetectionScriptOutput)
    $h | Add-Member -NotePropertyName ReportedOn -NotePropertyValue $(if ($st.lastStateUpdateDateTime) { ([datetime]$st.lastStateUpdateDateTime).ToLocalTime() } else { $null })
    $history[$mid.ToLower()] = $h
}
Write-Host "  Device results read: $($history.Count)"
#endregion

#region 5. Months to check
$monthList = @()
$cursor = Get-Date -Year $Today.Year -Month $Today.Month -Day 1
while ($monthList.Count -lt $Months) {
    $pt = Get-PatchTuesday $cursor.Year $cursor.Month
    if ($pt -le $Today) { $monthList += [pscustomobject]@{ Key = $pt.ToString('yyyy-MM'); Release = $pt } }
    $cursor = $cursor.AddMonths(-1)
}
Write-Host "Checking updates: $(($monthList | ForEach-Object { "$($_.Key) (released $(Format-Day $_.Release))" }) -join ', ')"
# Every month from the oldest checked up to this month, used to find a later cumulative update that covered a missed one
$allKeys = @(0..($Months + 1) | ForEach-Object { $Today.AddMonths(-$_).ToString('yyyy-MM') }) | Select-Object -Unique | Sort-Object
#endregion

#region 6. Rows
function New-DeviceRows {
    param($Ring, [string]$AadId)
    $dev  = $devices[$AadId]
    $h    = $history[$dev.IntuneId.ToLower()]
    $also = @($ringsOfDevice[$AadId] | Where-Object { $Ring -and $_ -ne $Ring.Name })
    foreach ($m in $monthList) {
        $later = @($allKeys | Where-Object { $_ -gt $m.Key })
        if ($Ring) { $t = Test-RingCompliance -Ring $Ring -History $h -MonthKey $m.Key -Release $m.Release -LaterMonths $later }
        else       { $t = [pscustomobject]@{ DeferralEnds = $null; Deadline = $null; Compliance = 'Red'; Reason = 'Not in any update ring'; Entry = $(if ($h) { $h.Months[$m.Key] }); Covered = $null } }
        $comp = $t.Compliance; $reason = $t.Reason
        if ($Ring -and $dev.UpdatesBy -eq 'ConfigMgr') { $comp = 'Red'; $reason = "ConfigMgr manages Windows Update on this co-managed device, so the ring is not in effect. $reason" }
        if ($also.Count) { $comp = 'Red'; $reason = "Also in ring(s): $($also -join ', ') (conflict). $reason" }
        if ($Ring -and $Ring.QualityPaused) { $reason = "Quality updates are PAUSED in this ring. $reason" }
        if ($h -and $h.Wmi) { $reason = "WMI repository broken on the device, which also stops Windows Update ($($h.Wmi)). $reason" }
        $e = $t.Entry
        $err = if ($e -and $e.Error) { Get-WUErrorInfo $e.Error } else { $null }
        [pscustomobject][ordered]@{
            'Device'              = $dev.Name
            'Primary user'        = $dev.User
            'Model'               = $dev.Model
            'OS build (device)'   = if ($h -and $h.OS) { $h.OS } else { $dev.OSVersion }
            'Updates managed by'  = $dev.UpdatesBy
            'Last check-in'       = Format-Day $dev.LastSync
            'Update month'        = $m.Key
            'KB'                  = if ($e) { $e.KB } elseif ($t.Covered) { "(none, covered by $($t.Covered.KB))" } else { '' }
            'Release date'        = Format-Day $m.Release
            'Deferral ends'       = Format-Day $t.DeferralEnds
            'Deadline (incl. grace)' = if ($Ring) { if ($t.Deadline) { Format-Day $t.Deadline } else { 'No deadline' } } else { '' }
            'Offered (download started)' = if ($e) { Format-Time $e.Download } else { '' }
            'Installed'           = if ($e) { Format-Time $e.Installed } else { '' }
            'Days after release'  = if ($e -and $e.Installed) { [math]::Round(($e.Installed - $m.Release).TotalDays, 1) } else { '' }
            'Failed attempts'     = if ($e) { $e.Failed } else { '' }
            'Error code'          = if ($err) { $err.Code } else { '' }
            'Error (MS Learn)'    = if ($err) { $err.Message } else { '' }
            'What it means (MS Learn)' = if ($err) { $err.Description } else { '' }
            'Mitigation (MS Learn)'    = if ($err) { $err.Mitigation } else { '' }
            'MS Learn link'       = if ($err) { $err.Link } else { '' }
            'Compliance'          = $comp
            'Reason'              = $reason
            'Device data date'    = if ($h) { Format-Time $h.ReportedOn } else { '' }
            'Last WU scan'        = if ($h) { Format-Time $h.Scan } else { '' }
            'Last reboot'         = if ($h -and $h.Boot) { Format-Time $h.Boot } else { '' }
            'Days since reboot'   = if ($h -and $h.Boot) { [int]($Today - $h.Boot.Date).TotalDays } else { '' }
            'Device script'       = if ($h -and $h.Version) { "v$($h.Version)" } else { '' }
            'Entra device ID'     = $AadId
        }
    }
}

$ringRows = [ordered]@{}
foreach ($r in $rings) {
    $list = New-Object System.Collections.Generic.List[object]
    foreach ($id in ($ringDevices[$r.Id] | Sort-Object { $devices[$_].Name })) { foreach ($row in New-DeviceRows -Ring $r -AadId $id) { $list.Add($row) } }
    $ringRows[$r.Id] = $list.ToArray()   # plain arrays: @(List).Count fails inside [ordered] literals in some PowerShell versions
}
$noRing = New-Object System.Collections.Generic.List[object]
foreach ($id in ($devices.Keys | Where-Object { -not $ringsOfDevice.ContainsKey($_) } | Sort-Object { $devices[$_].Name })) {
    foreach ($row in New-DeviceRows -Ring $null -AadId $id) { $noRing.Add($row) }
}
$noRing = $noRing.ToArray()
#endregion

#region 7. Workbook
# Latest monthly cumulative update only: one row per device, so each device counts once
$latestKey = $monthList[0].Key
function Get-LatestStats {
    param($Rows)
    $lr = @($Rows | Where-Object { $_.'Update month' -eq $latestKey })
    $data = @($lr | Where-Object { $_.'Device script' })   # valid output from the device script
    $inst = @($data | Where-Object { $_.Installed })
    $win  = @($inst | Where-Object { $_.Compliance -eq 'Green' })
    $pct  = { param($n, $d) if ($d) { [math]::Round(100 * $n / $d, 1) } else { '' } }
    [pscustomobject]@{
        Month = $latestKey; Devices = $lr.Count; WithData = $data.Count; Installed = $inst.Count; InWindow = $win.Count
        InstalledRed = $inst.Count - $win.Count; NotInstalled = $data.Count - $inst.Count; NoData = $lr.Count - $data.Count
        PctInstalled = (& $pct $inst.Count $data.Count); PctInWindow = (& $pct $win.Count $data.Count)
    }
}
$file = Join-Path $OutputFolder ("UpdateRingCompliance_{0:yyyyMMdd_HHmm}.xlsx" -f (Get-Date))
if (Test-Path $file) { Remove-Item $file -Force }
$used = @{ 'summary' = $true }

function Get-RingSettings {
    param($Ring)
    $raw = $Ring.Raw
    $yesNo = { param($v) if ($null -eq $v) { '' } elseif ($v) { 'Yes' } else { 'No' } }
    $inc = @($Ring.Include | ForEach-Object { Get-GroupName $_ })
    if ($Ring.AllDevices) { $inc += 'All devices' }
    if ($Ring.AllUsers)   { $inc += 'All users' }
    @(
        [pscustomobject]@{ Setting = 'Update ring';                         Value = $Ring.Name }
        [pscustomobject]@{ Setting = 'Description';                         Value = [string]$raw.description }
        [pscustomobject]@{ Setting = 'Quality update deferral (days)';      Value = $Ring.QualityDeferral }
        [pscustomobject]@{ Setting = 'Quality update deadline (days)';      Value = $(if ($null -ne $Ring.QualityDeadline) { $Ring.QualityDeadline } else { 'Not set' }) }
        [pscustomobject]@{ Setting = 'Grace period (days)';                 Value = $Ring.GraceDays }
        [pscustomobject]@{ Setting = 'Feature update deferral (days)';      Value = $raw.featureUpdatesDeferralPeriodInDays }
        [pscustomobject]@{ Setting = 'Feature update deadline (days)';      Value = $raw.deadlineForFeatureUpdatesInDays }
        [pscustomobject]@{ Setting = 'Auto reboot before deadline';         Value = (& $yesNo (-not $raw.postponeRebootUntilAfterDeadline)) }
        [pscustomobject]@{ Setting = 'Automatic update behaviour';          Value = [string]$raw.automaticUpdateMode }
        [pscustomobject]@{ Setting = 'Install schedule / active hours';     Value = $Ring.Schedule }
        [pscustomobject]@{ Setting = 'Quality updates paused';              Value = "$(& $yesNo $raw.qualityUpdatesPaused)$(if ($raw.qualityUpdatesPaused -and $raw.qualityUpdatesPauseExpiryDateTime) { " until $(Format-Day $raw.qualityUpdatesPauseExpiryDateTime)" })" }
        [pscustomobject]@{ Setting = 'Feature updates paused';              Value = (& $yesNo $raw.featureUpdatesPaused) }
        [pscustomobject]@{ Setting = 'Servicing channel / pre-release';     Value = [string]$raw.prereleaseFeatures }
        [pscustomobject]@{ Setting = 'Microsoft product updates';           Value = (& $yesNo $raw.microsoftUpdateServiceAllowed) }
        [pscustomobject]@{ Setting = 'Windows drivers excluded';            Value = (& $yesNo $raw.driversExcluded) }
        [pscustomobject]@{ Setting = 'Assigned groups';                     Value = ($inc -join '; ') }
        [pscustomobject]@{ Setting = 'Excluded groups';                     Value = (@($Ring.Exclude | ForEach-Object { Get-GroupName $_ }) -join '; ') }
        [pscustomobject]@{ Setting = 'Last modified';                       Value = (Format-Time $raw.lastModifiedDateTime) }
    )
}

function Write-RingSheet {
    param([string]$Sheet, [string]$Title, $Settings, $Rows)
    $settingsStart = 3
    $tableStart = $settingsStart + @($Settings).Count + 3
    $xl = $Settings | Export-Excel -Path $file -WorksheetName $Sheet -StartRow $settingsStart -AutoSize -PassThru
    $ws = $xl.Workbook.Worksheets[$Sheet]
    $ws.Cells['A1'].Value = $Title
    $ws.Cells['A1'].Style.Font.Size = 14; $ws.Cells['A1'].Style.Font.Bold = $true
    $ws.Cells["A$($settingsStart):A$($settingsStart + @($Settings).Count)"].Style.Font.Bold = $true
    Close-ExcelPackage $xl

    if (-not @($Rows).Count) {
        $xl = Open-ExcelPackage -Path $file; $ws = $xl.Workbook.Worksheets[$Sheet]
        $ws.Cells["A$tableStart"].Value = 'No devices.'
        Close-ExcelPackage $xl; return
    }
    $tableName = 'T' + ($Sheet -replace '[^A-Za-z0-9]', '')
    $xl = $Rows | Export-Excel -Path $file -WorksheetName $Sheet -StartRow $tableStart -TableName $tableName -TableStyle Light1 -AutoSize -PassThru
    $ws = $xl.Workbook.Worksheets[$Sheet]
    $lt = Get-LatestStats $Rows
    $ws.Cells["A$($tableStart - 1)"].Value = "Latest cumulative update $($lt.Month): devices $($lt.Devices), with device data $($lt.WithData), installed $($lt.Installed) ($($lt.PctInstalled)%), installed within the ring window $($lt.InWindow) ($($lt.PctInWindow)%), not installed $($lt.NotInstalled), no data $($lt.NoData). Earlier months are shown for history only."
    $ws.Cells["A$($tableStart - 1)"].Style.Font.Bold = $true

    # Row colour from the Compliance column (conditional formatting: fast on large sheets)
    $cols = @($Rows[0].PSObject.Properties.Name)
    $compCol = [OfficeOpenXml.ExcelCellAddress]::new(1, [array]::IndexOf($cols, 'Compliance') + 1).Address -replace '\d', ''
    $lastCol = [OfficeOpenXml.ExcelCellAddress]::new(1, $cols.Count).Address -replace '\d', ''
    $first = $tableStart + 1; $last = $tableStart + @($Rows).Count
    $range = $ws.Cells["A$($first):$lastCol$last"]
    foreach ($rule in @(@('Green', 198, 239, 206), @('Red', 255, 199, 206), @('Grey', 237, 237, 237))) {
        $cf = $ws.ConditionalFormatting.AddExpression($range)
        $cf.Formula = "`$$compCol$first=""$($rule[0])"""
        $cf.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $cf.Style.Fill.BackgroundColor.Color = [System.Drawing.Color]::FromArgb(255, $rule[1], $rule[2], $rule[3])
    }
    $ws.Column([array]::IndexOf($cols, 'Reason') + 1).Width = 70
    foreach ($wide in @('What it means (MS Learn)', 'Mitigation (MS Learn)')) {
        $i = [array]::IndexOf($cols, $wide); if ($i -ge 0) { $ws.Column($i + 1).Width = 60 }
    }
    $i = [array]::IndexOf($cols, 'MS Learn link'); if ($i -ge 0 -and $ws.Column($i + 1).Width -gt 40) { $ws.Column($i + 1).Width = 40 }
    if ($ws.Column(2).Width -gt 45) { $ws.Column(2).Width = 45 }   # long setting values
    if ($ws.Column(1).Width -lt 32) { $ws.Column(1).Width = 32 }   # setting names
    for ($c = 2; $c -le $cols.Count; $c++) { if ($ws.Column($c).Width -lt 13) { $ws.Column($c).Width = 13 } }
    $ws.View.FreezePanes($first, 2)
    Close-ExcelPackage $xl
}

Write-Host "Writing $file ..."
# Summary first
$summary = foreach ($r in $rings) {
    $lt = Get-LatestStats $ringRows[$r.Id]
    [pscustomobject][ordered]@{
        'Update ring'           = $r.Name
        'Devices'               = @($ringDevices[$r.Id]).Count
        'Quality deferral (d)'  = $r.QualityDeferral
        'Deadline (d)'          = $(if ($null -ne $r.QualityDeadline) { $r.QualityDeadline } else { 'Not set' })
        'Grace (d)'             = $r.GraceDays
        'Paused'                = $(if ($r.QualityPaused) { 'Yes' } else { 'No' })
        'With device data'      = $lt.WithData
        "Installed $latestKey"  = $lt.Installed
        'Installed in window'   = $lt.InWindow
        'Installed late / early' = $lt.InstalledRed
        'Not installed'         = $lt.NotInstalled
        'No device data'        = $lt.NoData
        'Installed %'           = $lt.PctInstalled
        'In window %'           = $lt.PctInWindow
        'In more than one ring' = @($ringDevices[$r.Id] | Where-Object { $ringsOfDevice[$_].Count -gt 1 }).Count
    }
}
$lt = Get-LatestStats $noRing
$summary += [pscustomobject][ordered]@{
    'Update ring' = 'No update ring'; 'Devices' = $lt.Devices; 'Quality deferral (d)' = ''; 'Deadline (d)' = ''; 'Grace (d)' = ''; 'Paused' = ''
    'With device data' = $lt.WithData; "Installed $latestKey" = $lt.Installed; 'Installed in window' = ''; 'Installed late / early' = ''
    'Not installed' = $lt.NotInstalled; 'No device data' = $lt.NoData; 'Installed %' = $lt.PctInstalled; 'In window %' = ''; 'In more than one ring' = ''
}
$allLatest = Get-LatestStats (@($ringRows.Values | ForEach-Object { $_ }) + @($noRing))
$oldScript = @($history.Values | Where-Object { $_.Valid -and $_.Version -and [version]$_.Version -lt [version]'1.2' }).Count
$xl = $summary | Export-Excel -Path $file -WorksheetName 'Summary' -StartRow 9 -TableName 'Summary' -TableStyle Medium2 -AutoSize -PassThru
$ws = $xl.Workbook.Worksheets['Summary']
$ws.Cells['A1'].Value = 'Update ring compliance report'
$ws.Cells['A1'].Style.Font.Size = 16; $ws.Cells['A1'].Style.Font.Bold = $true
$ws.Cells['A2'].Value = "Generated $(Format-Time (Get-Date)) by Get-UpdateRingComplianceReport.ps1 v$ScriptVersion. Live devices (checked in within $StaleDays days, $nameScope): $($devices.Count)."
$ws.Cells['A3'].Value = "Updates checked: $(($monthList | ForEach-Object { "$($_.Key) (released $(Format-Day $_.Release))" }) -join ', '). Device data from remediation: $remName."
$ws.Cells['A4'].Value = "Percentages use the latest monthly cumulative update only ($latestKey, released $(Format-Day $monthList[0].Release)), one result per device. Installed % = devices that installed it / devices with device data. In window % = installed between the end of the ring deferral and the deadline / devices with device data. Earlier months are on the ring sheets for history."
$ws.Cells['A6'].Value = "All devices, $($latestKey): $($allLatest.Installed) of $($allLatest.WithData) devices with data installed it ($($allLatest.PctInstalled)%). $($allLatest.NoData) device(s) have no data from the device yet."
$ws.Cells['A6'].Style.Font.Bold = $true
$ws.Cells['A7'].Value = 'Row colours on ring sheets: green = installed between the end of the ring deferral and the deadline (incl. grace). Red = early, late, failed, not installed by the deadline, ConfigMgr-managed, or in more than one ring. Grey = not due yet or no device data.'
$ws.Cells['A5'].Value = "Devices in more than one update ring: $($multiRing.Count)$(if ($multiRing.Count) { ' (see the Multiple rings sheet)' })"
$ws.Cells['A5'].Style.Font.Bold = $true
if ($oldScript) {
    $ws.Cells['A8'].Value = "$oldScript device(s) are on Detect-WUInstallHistory.ps1 older than 1.2, so they cannot report error codes. Upload the latest version (1.3) to the remediation (see the Device script column)."
    $ws.Cells['A8'].Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(255, 192, 0, 0))
}
if ($multiRing.Count) { $ws.Cells['A5'].Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(255, 192, 0, 0)) }
if ($notFound.Count) {
    $nfRow = 9 + @($summary).Count + 3
    $ws.Cells["A$nfRow"].Value = "Listed devices not found in Intune ($($notFound.Count)):"
    $ws.Cells["A$nfRow"].Style.Font.Bold = $true
    for ($i = 0; $i -lt $notFound.Count; $i++) { $ws.Cells["A$($nfRow + 1 + $i)"].Value = $notFound[$i] }
}
Close-ExcelPackage $xl

foreach ($r in $rings) {
    $sheet = Get-SafeSheetName -Name $r.Name -Used $used
    Write-Host "  Sheet: $sheet ($(@($ringRows[$r.Id]).Count) rows)"
    Write-RingSheet -Sheet $sheet -Title "Update ring: $($r.Name)" -Settings (Get-RingSettings $r) -Rows $ringRows[$r.Id]
}
$noRingSettings = @([pscustomobject]@{ Setting = 'Note'; Value = 'Live devices that are not in any update ring. Without a ring, Windows Update uses its defaults or other policy.' })
Write-RingSheet -Sheet (Get-SafeSheetName -Name 'No update ring' -Used $used) -Title 'Devices in no update ring' -Settings $noRingSettings -Rows $noRing

# Devices in more than one ring: one row per device, every ring it is in, and the groups that put it there
$multiRows = @(foreach ($id in ($multiRing | Sort-Object { $devices[$_].Name })) {
    $dev = $devices[$id]
    $names = @($ringsOfDevice[$id])
    [pscustomobject][ordered]@{
        'Device'             = $dev.Name
        'Primary user'       = $dev.User
        'Model'              = $dev.Model
        'Updates managed by' = $dev.UpdatesBy
        'Last check-in'      = Format-Day $dev.LastSync
        'Number of rings'    = $names.Count
        'Update rings'       = $names -join '; '
        'Assigned through'   = (@($names | ForEach-Object { "$($_): $((@($ringVia["$id|$_"]) -join ', '))" }) -join ' | ')
        'Compliance'         = 'Red'
        'Reason'             = 'In more than one update ring. Where the rings disagree, Intune reports the settings as a conflict and may not apply either value, so deferrals and deadlines are unpredictable. Fix the include / exclude groups so the device is in one ring.'
    }
})
$multiSettings = @(
    [pscustomobject]@{ Setting = 'Note'; Value = 'Devices targeted by more than one update ring after include and exclude groups are applied.' }
    [pscustomobject]@{ Setting = 'Fix';  Value = 'Add the device''s ring group to the exclude groups of the other rings, or remove it from the extra include group.' }
)
Write-RingSheet -Sheet (Get-SafeSheetName -Name 'Multiple rings' -Used $used) -Title 'Devices in more than one update ring' -Settings $multiSettings -Rows $multiRows

# Errors: every error code reported, how many devices, and Microsoft's text from MS Learn
$allRows = @($ringRows.Values | ForEach-Object { $_ }) + @($noRing)
$errRows = @($allRows | Where-Object { $_.'Error code' } | Group-Object 'Error code' | Sort-Object Count -Descending | ForEach-Object {
    $x = Get-WUErrorInfo $_.Name
    [pscustomobject][ordered]@{
        'Error code'               = $x.Code
        'Devices'                  = @($_.Group | Select-Object -ExpandProperty Device -Unique).Count
        'Device list'              = (@($_.Group | Select-Object -ExpandProperty Device -Unique | Select-Object -First 30) -join ', ')
        'Error (MS Learn)'         = $x.Message
        'What it means (MS Learn)' = $x.Description
        'Mitigation (MS Learn)'    = $x.Mitigation
        'MS Learn link'            = $x.Link
    }
})
$errSheet = Get-SafeSheetName -Name 'Errors' -Used $used
if ($errRows.Count) {
    $xl = $errRows | Export-Excel -Path $file -WorksheetName $errSheet -StartRow 3 -TableName 'Errors' -TableStyle Light9 -AutoSize -PassThru
    $ws = $xl.Workbook.Worksheets[$errSheet]
    $ws.Cells['A1'].Value = 'Windows Update error codes reported by devices (last failed attempt per month), with Microsoft''s text from MS Learn'
    $ws.Cells['A1'].Style.Font.Size = 14; $ws.Cells['A1'].Style.Font.Bold = $true
    foreach ($c in 3, 5, 6) { $ws.Column($c).Width = 60; $ws.Column($c).Style.WrapText = $true }
    $ws.Column(7).Width = 45
    Close-ExcelPackage $xl
} else {
    $xl = [pscustomobject]@{ Note = 'No error codes reported. Devices need Detect-WUInstallHistory.ps1 1.2 or later to report them.' } |
        Export-Excel -Path $file -WorksheetName $errSheet -AutoSize -PassThru
    Close-ExcelPackage $xl
}

# Column guide: what each column means, and the matching Windows Update for Business reports field
$wufb = 'https://learn.microsoft.com/windows/deployment/update/wufb-reports-schema-ucclientupdatestatus'
$guide = @(
    @('Device',                     'DeviceName',                  'Device name in Intune.')
    @('Primary user',               '',                            'Intune primary user. Used to map user groups in ring assignments to devices.')
    @('Model',                      '',                            'Device model from Intune.')
    @('OS build (device)',          'TargetBuild (current build)', 'Build and revision the device reports now (for example 26100.6899). From the device script, or Intune if no device data.')
    @('Updates managed by',         '',                            'Intune, or ConfigMgr when co-management has the Windows Update workload in ConfigMgr (the ring is then not in effect).')
    @('Last check-in',              '',                            'Last Intune check-in.')
    @('Update month',               '',                            'Month of the monthly Windows update (from the update title, for example 2026-10).')
    @('KB',                         'TargetKBNumber',              'KB article of the update the device installed for that month.')
    @('Release date',               'UpdateReleaseTime',           'Release date of the update. Worked out as Patch Tuesday (second Tuesday of the month).')
    @('Deferral ends',              '',                            'Release date + the ring''s quality update deferral. The update should not install before this.')
    @('Deadline (incl. grace)',     '',                            'Deferral ends + the ring''s quality update deadline + grace period. The update should be installed by this.')
    @('Offered (download started)', 'ClientSubstate = DownloadStart', 'When Windows Update started downloading the update (WindowsUpdateClient event 44). The nearest device-side equivalent of the offer. Empty when the event log no longer holds it.')
    @('Installed',                  'UpdateInstalledTime',         'When the update installed successfully (Windows Update history).')
    @('Days after release',         '',                            'Installed - Release date, in days.')
    @('Failed attempts',            '',                            'Failed or aborted install attempts for that month in Windows Update history.')
    @('Error code',                 '',                            'Error code (HResult) of the most recent failed attempt that month. Needs Detect-WUInstallHistory.ps1 1.2 or later.')
    @('Error (MS Learn)',           '',                            'Microsoft''s name for the error code, from MS Learn.')
    @('What it means (MS Learn)',   '',                            'Microsoft''s description of the error, from MS Learn.')
    @('Mitigation (MS Learn)',      '',                            'Microsoft''s mitigation, from the MS Learn common Windows Update errors page where listed.')
    @('MS Learn link',              '',                            'The MS Learn page the error text came from.')
    @('Compliance',                 '',                            'Green = installed between Deferral ends and Deadline (or covered in time by a later cumulative update). Red = early, late, failed, missed deadline, ConfigMgr-managed or in more than one ring. Grey = not due yet or no device data.')
    @('Reason',                     '',                            'Why the row has its colour, in plain English.')
    @('Device data date',           '',                            'When the device last ran the detection script.')
    @('Last WU scan',               '',                            'Last successful Windows Update scan on the device.')
    @('Last reboot',                '',                            'When the device last started (Win32_OperatingSystem, or the System event log 6005 when WMI is broken). The nearest WUfB field is RestartRequiredTime, which is when the update asked for a restart, not when it happened.')
    @('Days since reboot',          '',                            'Days from the last reboot to today. A device that has not restarted since the update installed has not finished it.')
    @('Entra device ID',            'AzureADDeviceId',             'Microsoft Entra device ID. Use it to match rows with Windows Update for Business reports.')
) | ForEach-Object { [pscustomobject][ordered]@{ 'Column' = $_[0]; 'WUfB reports field (UCClientUpdateStatus)' = $_[1]; 'Meaning' = $_[2] } }
$guideSheet = Get-SafeSheetName -Name 'Column guide' -Used $used
$xl = $guide | Export-Excel -Path $file -WorksheetName $guideSheet -StartRow 3 -TableName 'ColumnGuide' -TableStyle Light1 -AutoSize -PassThru
$ws = $xl.Workbook.Worksheets[$guideSheet]
$ws.Cells['A1'].Value = 'Column guide'
$ws.Cells['A1'].Style.Font.Size = 14; $ws.Cells['A1'].Style.Font.Bold = $true
$ws.Cells['A2'].Value = "Field names from the Windows Update for Business reports schema: $wufb"
$ws.Column(3).Width = 100; $ws.Column(3).Style.WrapText = $true
Close-ExcelPackage $xl

Write-Host "`nDone: $file"
$summary | Format-Table -AutoSize | Out-String -Width 250 | Write-Host
#endregion
