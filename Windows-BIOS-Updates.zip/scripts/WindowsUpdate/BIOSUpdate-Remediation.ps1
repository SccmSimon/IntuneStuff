#Requires -Version 5.1
# Remediation: Dell and HP system BIOS updates from Microsoft Update only.
# Installs the newest system firmware update offered for this device's UEFI system firmware resource.
# If a BIOS package is already installed but was not applied at restart (System Firmware device in
# problem code 10, BIOS still on the old version), restages it so it flashes at the next restart.
# Checks power, suspends BitLocker for one restart, never reboots the device.
#
# 1.3: Restages a BIOS package that was installed but not applied (remove and rescan the System Firmware
#      device, confirm problem code 14, suspend BitLocker). Stops after $MaxRestageAttempts attempts for the
#      same package and reports it. ESRT values read without the signed / unsigned cast error.

$ErrorActionPreference = 'Stop'
$ScriptVersion      = '1.3'
$RunId              = ([guid]::NewGuid().ToString()).Substring(0, 8)
$MUServiceId        = '7971f918-a847-4430-9279-4a52d1efe18d'   # Microsoft Update
$Criteria           = "IsInstalled=0 and Type='Driver'"
$MinBatteryPercent  = 50
$MaxRestageAttempts = 3
$StateKey           = 'HKLM:\SOFTWARE\BIOSUpdate'
$start              = Get-Date
$exitCode           = 0
$cmStopped          = $false
$summary            = 'No action taken'

$DataRoot = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir   = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile  = Join-Path $LogDir 'BIOSUpdate-Remediation.log'
New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 5MB) {
    Move-Item -Path $LogFile -Destination "$LogFile.old" -Force
}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] [{2}] {3}" -f (Get-Date), $RunId, $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}
function Write-Section { param([string]$Name) Write-Log "---- $Name ----" }
function Format-HResult { param($HResult) '0x{0:X8}' -f [int]$HResult }

$ResultCodes = @{ 0='Not started'; 1='In progress'; 2='Succeeded'; 3='Succeeded with errors'; 4='Failed'; 5='Aborted' }
$EsrtStatus  = @{ 0='Success'; 1='Unsuccessful'; 2='Insufficient resources'; 3='Incorrect version';
                  4='Invalid image format'; 5='Authentication error'; 6='AC power not connected'; 7='Insufficient battery' }

# Registry DWORDs come back as signed Int32. Convert without the cast error a plain [uint32] gives on large values.
function ConvertTo-UInt32 {
    param($Value)
    if ($null -eq $Value) { return [uint32]0 }
    [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$Value), 0)
}
# ESRT version as four bytes, the same format Windows uses for the firmware package version
function Format-FwVersion {
    param([uint32]$Value)
    '{0}.{1}.{2}.{3}' -f (($Value -shr 24) -band 255), (($Value -shr 16) -band 255), (($Value -shr 8) -band 255), ($Value -band 255)
}

function Get-SystemFirmware {
    $root = 'HKLM:\HARDWARE\UEFI\ESRT'
    if (-not (Test-Path $root)) { return $null }
    foreach ($k in @(Get-ChildItem -Path $root -ErrorAction SilentlyContinue)) {
        if (-not $k -or -not $k.PSPath) { continue }
        try {
            $props = Get-ItemProperty -Path $k.PSPath -ErrorAction Stop
            if ($props.Type -eq 1) {
                return [pscustomobject]@{
                    Guid               = $k.PSChildName.Trim('{', '}')
                    Version            = ConvertTo-UInt32 $props.Version
                    LowestSupported    = ConvertTo-UInt32 $props.LowestSupportedVersion
                    LastAttemptVersion = ConvertTo-UInt32 $props.LastAttemptVersion
                    LastAttemptStatus  = ConvertTo-UInt32 $props.LastAttemptStatus
                }
            }
        } catch {
            Write-Log "Could not read ESRT key $($k.PSChildName): $($_.Exception.Message)" 'WARN'
        }
    }
    $null
}

function Get-BiosCandidates {
    param($Updates, $Firmware, [string]$VendorPattern)
    $list = New-Object System.Collections.Generic.List[object]
    foreach ($u in $Updates) {
        $hwid   = [string]$u.DriverHardwareID
        $isFw   = $u.DriverClass -eq 'Firmware'
        $hwOk   = $hwid -like "*$($Firmware.Guid)*"
        $vendOk = ("$($u.DriverManufacturer) $($u.DriverProvider) $($u.Title)") -match $VendorPattern
        $match  = $isFw -and $hwOk -and $vendOk
        $tag    = if ($match) { 'MATCH  ' } else { 'IGNORED' }
        Write-Log ("  {0} | {1} | Class: {2} | HWID: {3} | Driver date: {4:yyyy-MM-dd}" -f $tag, $u.Title, $u.DriverClass, $hwid, $u.DriverVerDate)
        if ($match) { $list.Add($u) }
    }
    , @($list | Sort-Object -Property { $_.DriverVerDate } -Descending)
}

function Test-PowerReady {
    $batt = @(Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue | Where-Object { $_ })
    if ($batt.Count -eq 0) { Write-Log '  No battery present, power check passed'; return $true }
    # BatteryStatus 2 = on AC, 6 to 9 = charging
    $onAC   = @($batt | Where-Object { $_.BatteryStatus -in 2,6,7,8,9 }).Count -gt 0
    $charge = [int](($batt | Measure-Object -Property EstimatedChargeRemaining -Average).Average)
    Write-Log "  Battery: on AC $onAC, charge $charge% (minimum $MinBatteryPercent%)"
    $onAC -and ($charge -ge $MinBatteryPercent)
}

# ---- Restage helpers ----
function Get-FwDeviceState {
    param([string]$InstanceId)
    [pscustomobject]@{
        Package = [string](Get-PnpDeviceProperty -InstanceId $InstanceId -KeyName DEVPKEY_Device_DriverVersion -ErrorAction SilentlyContinue).Data
        Inf     = [string](Get-PnpDeviceProperty -InstanceId $InstanceId -KeyName DEVPKEY_Device_DriverInfPath -ErrorAction SilentlyContinue).Data
        Problem = (Get-PnpDeviceProperty -InstanceId $InstanceId -KeyName DEVPKEY_Device_ProblemCode -ErrorAction SilentlyContinue).Data
    }
}
function Invoke-PnpUtil {
    param([string[]]$Arguments)
    # Continue, so pnputil output on stderr does not become a terminating error in PowerShell 5.1
    $ErrorActionPreference = 'Continue'
    $out  = & pnputil.exe @Arguments 2>&1
    $code = $LASTEXITCODE
    foreach ($l in $out) { if ("$l".Trim()) { Write-Log "    $l" } }
    Write-Log "  pnputil $($Arguments -join ' ') exit code $code"
    $code
}
# Remove the System Firmware device and rescan. Windows reinstalls the package from the driver store,
# which stages the capsule again. Returns the device state once it is back (waits up to 60 seconds).
function Invoke-FirmwareRestage {
    param([string]$InstanceId)
    $null = Invoke-PnpUtil @('/remove-device', $InstanceId)
    $null = Invoke-PnpUtil @('/scan-devices')
    $state = $null
    for ($i = 0; $i -lt 12; $i++) {
        Start-Sleep -Seconds 5
        if (Get-PnpDevice -InstanceId $InstanceId -ErrorAction SilentlyContinue) {
            $state = Get-FwDeviceState -InstanceId $InstanceId
            if ($state.Problem -eq 14) { break }
        }
    }
    if (-not $state) { $state = [pscustomobject]@{ Package = ''; Inf = ''; Problem = 'device not back after rescan' } }
    $state
}
function Suspend-BitLockerOnce {
    try {
        $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
        if ($bl.ProtectionStatus -eq 'On') {
            Suspend-BitLocker -MountPoint $env:SystemDrive -RebootCount 1 | Out-Null
            Write-Log '  BitLocker suspended for 1 restart'
            'suspended for 1 restart'
        } else { "protection $($bl.ProtectionStatus)" }
    } catch {
        Write-Log "  Could not suspend BitLocker: $($_.Exception.Message)" 'WARN'
        'not suspended'
    }
}
# Restage attempts are counted per package version, so a BIOS that refuses the capsule is not restaged forever
function Get-RestageCount {
    param([string]$Package)
    $s = Get-ItemProperty -Path $StateKey -ErrorAction SilentlyContinue
    if ($s -and $s.RestagePackage -eq $Package) { [int]$s.RestageCount } else { 0 }
}
function Set-RestageCount {
    param([string]$Package, [int]$Count)
    try {
        New-Item -Path $StateKey -Force -ErrorAction SilentlyContinue | Out-Null
        Set-ItemProperty -Path $StateKey -Name RestagePackage -Value $Package
        Set-ItemProperty -Path $StateKey -Name RestageCount   -Value $Count -Type DWord
        Set-ItemProperty -Path $StateKey -Name RestageLast    -Value (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    } catch { Write-Log "  Could not save restage count: $($_.Exception.Message)" 'WARN' }
}
function Clear-RestageCount {
    if (Test-Path $StateKey) {
        Remove-ItemProperty -Path $StateKey -Name RestagePackage, RestageCount, RestageLast -ErrorAction SilentlyContinue
    }
}

$WUPolicy = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
$WUAU     = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'

$MdmPaths = @('HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Update') + @(
    Get-ChildItem -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\providers' -ErrorAction SilentlyContinue |
        ForEach-Object { "HKLM:\SOFTWARE\Microsoft\PolicyManager\providers\$($_.PSChildName)\default\Device\Update" } |
        Where-Object { $_ -and (Test-Path $_) }
)

$isOne    = { param($v) $v -eq 1 }
$isZero   = { param($v) $v -eq 0 }
$isFive   = { param($v) $v -eq 5 }
$nonEmpty = { param($v) -not [string]::IsNullOrWhiteSpace([string]$v) }

$Blockers = @(
    foreach ($n in 'WUServer','WUStatusServer','UpdateServiceUrlAlternate') { @{Path=$WUPolicy;Name=$n;Test=$nonEmpty} }
    foreach ($n in 'DisableWindowsUpdateAccess','DoNotConnectToWindowsUpdateInternetLocations',
                   'ExcludeWUDriversInQualityUpdate','SetPolicyDrivenUpdateSourceForDriverUpdates') { @{Path=$WUPolicy;Name=$n;Test=$isOne} }
    foreach ($n in 'NoAutoUpdate','UseWUServer') { @{Path=$WUAU;Name=$n;Test=$isOne} }
    foreach ($mp in $MdmPaths) {
        foreach ($n in 'ExcludeWUDriversInQualityUpdate','SetPolicyDrivenUpdateSourceForDriverUpdates',
                       'DoNotConnectToWindowsUpdateInternetLocations') { @{Path=$mp;Name=$n;Test=$isOne} }
        @{Path=$mp;Name='UpdateServiceUrl';Test=$nonEmpty}
        @{Path=$mp;Name='AllowUpdateService';Test=$isZero}
        @{Path=$mp;Name='AllowAutoUpdate';Test=$isFive}
    }
)
# Drop anything without a usable path
$Blockers = @($Blockers | Where-Object { $_ -and -not [string]::IsNullOrEmpty($_.Path) })

$IsCM = [bool](Get-Service -Name CcmExec -ErrorAction SilentlyContinue)

try {
    Write-Log '=================================================================='
    Write-Log "BIOS remediation v$ScriptVersion started on $env:COMPUTERNAME (ConfigMgr client: $IsCM)"

    # ---- Device ----
    Write-Section 'Device'
    $cs   = Get-CimInstance -ClassName Win32_ComputerSystem
    $bios = Get-CimInstance -ClassName Win32_BIOS
    Write-Log "Manufacturer: $($cs.Manufacturer) | Model: $($cs.Model)"
    Write-Log ("Current BIOS: {0}, released {1:yyyy-MM-dd}" -f $bios.SMBIOSBIOSVersion, $bios.ReleaseDate)
    Write-Log "Intune policy paths checked: $($MdmPaths.Count)"

    $vendorPattern = switch -Regex ([string]$cs.Manufacturer) {
        '^Dell'          { 'Dell' }
        '^(HP|Hewlett)'  { 'HP|Hewlett' }
        default          { $null }
    }
    if (-not $vendorPattern) {
        $summary = "Not applicable: $($cs.Manufacturer)"
        Write-Log $summary
        return
    }

    # ---- Firmware ----
    Write-Section 'System firmware (ESRT)'
    $fw = Get-SystemFirmware
    if (-not $fw) {
        $summary = 'Not applicable: no UEFI system firmware resource'
        Write-Log $summary 'WARN'
        return
    }
    $running = Format-FwVersion $fw.Version
    Write-Log ("Firmware GUID: {0}" -f $fw.Guid)
    Write-Log ("Version: {0} (0x{1:X8}) | Last attempt: {2}, status {3} ({4})" -f $running, $fw.Version, (Format-FwVersion $fw.LastAttemptVersion), $fw.LastAttemptStatus, $EsrtStatus[[int]$fw.LastAttemptStatus])

    # ---- Staged but not applied: restage ----
    # A BIOS package Windows Update installed but the firmware never applied stays "installed", so the scan
    # below never offers it again. Restaging puts it back to problem code 14 (restart required).
    Write-Section 'Staged firmware'
    $fwDev = Get-PnpDevice -Class Firmware -PresentOnly -ErrorAction SilentlyContinue |
             Where-Object { $_.InstanceId -like "*$($fw.Guid)*" } | Select-Object -First 1
    if ($fwDev) {
        $state = Get-FwDeviceState -InstanceId $fwDev.InstanceId
        Write-Log "Firmware device: $($fwDev.InstanceId) | package $($state.Package) ($($state.Inf)) | running $running | problem code $($state.Problem)"
        $pkg = $null; try { $pkg = [version]$state.Package } catch { }

        if ($pkg -and $pkg -gt [version]$running) {
            if ($state.Problem -eq 14) {
                $bl = Suspend-BitLockerOnce
                $summary = "BIOS package $($state.Package) staged, flashes on next restart (running $running, BitLocker $bl)"
                Write-Log $summary
                return
            }

            $count = Get-RestageCount -Package $state.Package
            if ($count -ge $MaxRestageAttempts) {
                $summary  = "BIOS package $($state.Package) restaged $count times and never applied (running $running, problem code $($state.Problem)). Check the BIOS event log or use the vendor tool"
                $exitCode = 1
                Write-Log $summary 'ERROR'
                return
            }

            Write-Log "Restaging BIOS package $($state.Package), attempt $($count + 1) of $MaxRestageAttempts"
            $after = Invoke-FirmwareRestage -InstanceId $fwDev.InstanceId
            Set-RestageCount -Package $state.Package -Count ($count + 1)
            Write-Log "After restage: package $($after.Package) | problem code $($after.Problem)"

            if ($after.Problem -eq 14) {
                $bl = Suspend-BitLockerOnce
                $summary = "BIOS package $($state.Package) restaged (attempt $($count + 1) of $MaxRestageAttempts), flashes on next restart (running $running, BitLocker $bl)"
                Write-Log $summary
            } else {
                $summary  = "BIOS package $($state.Package) restage did not reach restart required (problem code $($after.Problem))"
                $exitCode = 1
                Write-Log $summary 'ERROR'
            }
            return
        }

        # Package applied (or nothing staged): forget any earlier restage attempts
        Clear-RestageCount
    } else {
        Write-Log 'No firmware device found for the ESRT GUID' 'WARN'
    }

    # ---- Stop ConfigMgr ----
    if ($IsCM) {
        Write-Section 'ConfigMgr client'
        try {
            Stop-Service -Name CcmExec -Force
            $cmStopped = $true
            Write-Log 'Stopped ConfigMgr client (CcmExec) for the duration of the run'
        } catch { Write-Log "Could not stop ConfigMgr client, continuing: $($_.Exception.Message)" 'WARN' }
    }

    # ---- Backup and remove blockers ----
    Write-Section 'Blocker removal'
    $backupDir = Join-Path $LogDir ("BIOSUpdate_RegBackup_{0:yyyyMMdd_HHmmss}" -f $start)
    New-Item -Path $backupDir -ItemType Directory -Force | Out-Null
    $i = 0
    $uniquePaths = @($Blockers | ForEach-Object { $_.Path } | Where-Object { $_ } | Select-Object -Unique)
    foreach ($path in $uniquePaths) {
        if ($path -and (Test-Path $path)) {
            $i++
            & reg.exe export ($path -replace '^HKLM:', 'HKLM') (Join-Path $backupDir "backup$i.reg") /y | Out-Null
        }
    }
    Write-Log "Backup folder: $backupDir ($i keys)"
    Get-ChildItem -Path $LogDir -Directory -Filter 'BIOSUpdate_RegBackup_*' -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending | Select-Object -Skip 5 |
        ForEach-Object { if ($_.FullName) { Remove-Item -Path $_.FullName -Recurse -Force -ErrorAction SilentlyContinue } }

    $removed = 0
    foreach ($b in $Blockers) {
        if ([string]::IsNullOrEmpty($b.Path) -or -not (Test-Path $b.Path)) { continue }
        $item = Get-ItemProperty -Path $b.Path -Name $b.Name -ErrorAction SilentlyContinue
        if ($null -eq $item) { continue }
        $val = $item.($b.Name)
        if (& $b.Test $val) {
            try {
                Remove-ItemProperty -Path $b.Path -Name $b.Name -Force
                $removed++
                Write-Log "  Removed $($b.Path)\$($b.Name) (was $val)"
            } catch { Write-Log "  Could not remove $($b.Path)\$($b.Name): $($_.Exception.Message)" 'ERROR' }
        }
    }
    Write-Log "Checked $($Blockers.Count) rules, removed $removed values"

    # ---- Services ----
    Write-Section 'Services'
    $svcConfig = @{ wuauserv = 'Manual'; bits = 'Manual'; UsoSvc = 'Manual'; cryptsvc = 'Automatic' }
    foreach ($name in $svcConfig.Keys) {
        try {
            $s = Get-Service -Name $name -ErrorAction Stop
            if ($s.StartType -eq 'Disabled') { Set-Service -Name $name -StartupType $svcConfig[$name]; Write-Log "  Set $name to $($svcConfig[$name])" }
            if ($s.Status -ne 'Running') { Start-Service -Name $name; Write-Log "  Started $name" }
        } catch { Write-Log "  Service $name issue: $($_.Exception.Message)" 'ERROR' }
    }

    $probe = New-Object -ComObject Microsoft.Update.Installer
    $waitUntil = (Get-Date).AddMinutes(5)
    if ($probe.IsBusy) { Write-Log '  Installer busy, waiting up to 5 minutes' 'WARN' }
    while ($probe.IsBusy -and (Get-Date) -lt $waitUntil) { Start-Sleep -Seconds 15 }

    Restart-Service -Name wuauserv -Force
    Restart-Service -Name bits -Force -ErrorAction SilentlyContinue

    try {
        $null = (New-Object -ComObject Microsoft.Update.ServiceManager).AddService2($MUServiceId, 7, '')
        Write-Log '  Microsoft Update registered'
    } catch { Write-Log "  Microsoft Update registration failed: $($_.Exception.Message)" 'WARN' }

    # ---- Scan ----
    Write-Section 'Update scan'
    Write-Log "Source: Microsoft Update (ServerSelection 3), criteria: $Criteria"
    $session = New-Object -ComObject Microsoft.Update.Session
    $session.ClientApplicationID = 'BIOSUpdate'
    $searcher = $session.CreateUpdateSearcher()
    $searcher.ServerSelection = 3
    $searcher.ServiceID = $MUServiceId
    $result = $searcher.Search($Criteria)
    Write-Log "Driver updates returned: $($result.Updates.Count)"

    $candidates = Get-BiosCandidates -Updates $result.Updates -Firmware $fw -VendorPattern $vendorPattern
    if ($candidates.Count -eq 0) {
        $summary = "No BIOS update offered (current $($bios.SMBIOSBIOSVersion))"
        Write-Log $summary
        return
    }

    $u = $candidates[0]
    Write-Log ("Selected latest: {0}, driver date {1:yyyy-MM-dd}" -f $u.Title, $u.DriverVerDate)
    foreach ($older in @($candidates | Select-Object -Skip 1)) {
        Write-Log ("  Skipped older: {0}, driver date {1:yyyy-MM-dd}" -f $older.Title, $older.DriverVerDate)
    }

    # ---- Power ----
    Write-Section 'Power check'
    if (-not (Test-PowerReady)) {
        $summary  = 'Skipped: not on AC power or battery below threshold, will retry next run'
        $exitCode = 1
        Write-Log $summary 'WARN'
        return
    }

    # ---- Download ----
    Write-Section 'Download'
    if ($u.IsHidden) { $u.IsHidden = $false; Write-Log '  Unhidden' }
    if (-not $u.EulaAccepted) { $u.AcceptEula() }
    $coll = New-Object -ComObject Microsoft.Update.UpdateColl
    $null = $coll.Add($u)
    if (-not $u.IsDownloaded) {
        $dl = $session.CreateUpdateDownloader()
        $dl.Updates = $coll
        $dr = $dl.Download()
        Write-Log ("  Download: {0} ({1}), HRESULT {2}" -f $dr.ResultCode, $ResultCodes[[int]$dr.ResultCode], (Format-HResult $dr.GetUpdateResult(0).HResult))
        if ($dr.ResultCode -ne 2) { throw 'Download did not succeed' }
    } else { Write-Log '  Already downloaded' }

    # ---- BitLocker ----
    Write-Section 'BitLocker'
    $blSuspended = $false
    try {
        $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
        Write-Log "  $env:SystemDrive protection: $($bl.ProtectionStatus)"
        if ($bl.ProtectionStatus -eq 'On') {
            Suspend-BitLocker -MountPoint $env:SystemDrive -RebootCount 1 | Out-Null
            $blSuspended = $true
            Write-Log '  BitLocker suspended for 1 restart'
        }
    } catch {
        $summary  = "Install cancelled: could not read or suspend BitLocker ($($_.Exception.Message))"
        $exitCode = 1
        Write-Log $summary 'ERROR'
        return
    }

    # ---- Install ----
    Write-Section 'Install'
    $inst = $session.CreateUpdateInstaller()
    $inst.Updates = $coll
    $inst.ForceQuiet = $true
    $inst.AllowSourcePrompts = $false
    $ir   = $inst.Install()
    $uRes = $ir.GetUpdateResult(0)
    $msg  = "  Install: {0} ({1}), HRESULT {2}, reboot required: {3}" -f $ir.ResultCode, $ResultCodes[[int]$ir.ResultCode], (Format-HResult $uRes.HResult), $uRes.RebootRequired

    if ($ir.ResultCode -in 2,3) {
        Write-Log $msg
        $summary = "BIOS update staged: $($u.Title). Flashes on next restart."
    } else {
        Write-Log $msg 'ERROR'
        $summary  = "BIOS install failed: $($u.Title), HRESULT $(Format-HResult $uRes.HResult)"
        $exitCode = 1
        if ($blSuspended) {
            try { Resume-BitLocker -MountPoint $env:SystemDrive | Out-Null; Write-Log '  BitLocker resumed after failed install' }
            catch { Write-Log "  Could not resume BitLocker, it resumes after the next restart: $($_.Exception.Message)" 'WARN' }
        }
    }
}
catch {
    $summary  = "Fatal error at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    $exitCode = 1
    Write-Log ("{0} (HRESULT {1})" -f $summary, (Format-HResult $_.Exception.HResult)) 'ERROR'
    Write-Log "Position: $($_.InvocationInfo.PositionMessage)" 'ERROR'
    Write-Log "Stack: $($_.ScriptStackTrace)" 'ERROR'
}
finally {
    if ($cmStopped) {
        try {
            Start-Service -Name CcmExec
            Write-Log 'Started ConfigMgr client (CcmExec)'
        } catch { Write-Log "Could not restart ConfigMgr client: $($_.Exception.Message)" 'ERROR' }
    }
    Write-Section 'Summary'
    $d = (Get-Date) - $start
    Write-Log ("  Exit code {0} | {1} | Run time: {2}m {3}s" -f $exitCode, $summary, [int][Math]::Floor($d.TotalMinutes), $d.Seconds)
    Write-Log 'BIOS remediation finished'
    Write-Output $summary
    # exit sits inside finally so the early 'return' paths above still pass the right exit code to Intune
    exit $exitCode
}
