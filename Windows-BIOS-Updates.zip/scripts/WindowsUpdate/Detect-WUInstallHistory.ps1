<#
.SYNOPSIS
    Intune Remediations detection script (report only). Reports when this device installed each monthly
    Windows cumulative / security update, so the update ring report can compare it with the ring's
    deferral and deadline settings.

.DESCRIPTION
    Read-only. Collects, for the last $MonthsBack months:
      - Windows Update history (Operation = Installation) for monthly Windows updates, titles like
        "2026-10 Cumulative Update for Windows 11 ... (KB5066835)" or "2026-10 Security Update (KB...)".
        Preview, Out-of-band, .NET and Defender updates are skipped.
      - First successful install date, number of failed attempts, and the first failure date.
      - When Windows Update started downloading it (WindowsUpdateClient event 44), used as the
        "offered" date. Empty when the event log no longer holds it.
    Also reports the OS build (with UBR), last successful Windows Update scan and last boot time.

    Output is one line for the Intune report (pre-remediation detection output column), for example:
      WUHIST v1.3 | OS=26100.6899 | Scan=2026-10-27T08:01Z | Boot=2026-10-26T07:55Z |
      2026-10=KB5066835,I:2026-10-21T12:04Z,D:2026-10-21T09:12Z,F:0 | 2026-09=KB5065426,I:...
      I = installed (UTC), D = download started (UTC), F = failed attempts, FD = first failure (UTC),
      E = error code of the most recent failure (HResult, look it up on MS Learn),
      P:1 = started but not finished (usually waiting for a restart). WMI=Broken when Win32_OperatingSystem
      cannot be read (broken WMI repository, which also breaks Windows Update).
    A month with failures but no success has no I: value.

    Always exits 0 (reports "Without issues"). It collects data only.

.NOTES
    Version : 1.3
    Author  : Simon Diaz
    1.3     : Error code falls back to UnmappedResultCode when HResult is 0.
    1.2     : Adds the error code of the most recent failed attempt each month (E:0x8024xxxx), so the report can
              show Microsoft's description and mitigation from MS Learn.
    1.1     : Flags a broken WMI repository (WMI=Broken) instead of writing an error, boot time falls back to the
              System log. Marks an update that started but did not finish (P:1, usually waiting for a restart).
    Intune  : Devices > Scripts and remediations > Remediations. Detection script only, no remediation.
              Run this script using the logged-on credentials: No (runs as SYSTEM).
              Run script in 64-bit PowerShell: Yes.  Schedule: daily.
    Log     : %ProgramData%\Microsoft\IntuneManagementExtension\Logs\WUInstallHistory-Detection.log
#>

$ProgressPreference = 'SilentlyContinue'
$ScriptVersion = '1.3'
$MonthsBack    = 6
$LogFile = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs\WUInstallHistory-Detection.log'

function Write-Log {
    param([string]$Message)
    try { Add-Content -Path $LogFile -Value ("{0:yyyy-MM-dd HH:mm:ss} {1}" -f (Get-Date), $Message) } catch { }
}
function Format-Utc { param($Date) if ($Date) { ([datetime]$Date).ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm'Z'") } else { '' } }

# Monthly Windows update titles. Group 1 = YYYY-MM, KB found separately.
$TitlePattern   = '^(\d{4}-\d{2}) (Cumulative Update|Security Update)\b'
$ExcludePattern = 'Preview|Out-of-band|\.NET|Defender|Malicious|Servicing Stack'

$parts = New-Object System.Collections.Generic.List[string]
$parts.Add("WUHIST v$ScriptVersion")

try {
    # ---- Device ----
    $cv  = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction SilentlyContinue
    $parts.Add("OS=$($cv.CurrentBuildNumber).$($cv.UBR)")
    try {
        $scan = (New-Object -ComObject Microsoft.Update.AutoUpdate).Results.LastSearchSuccessDate
        if ($scan -and $scan.Year -gt 2000) { $parts.Add("Scan=$(Format-Utc $scan)") }
    } catch { }
    # Boot time. A broken WMI repository (0x80041010 "Invalid class") also breaks Windows Update, so flag it
    # and fall back to the last "Event log service started" event (System 6005)
    $boot = $null
    try { $boot = (Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime }
    catch {
        $parts.Add("WMI=Broken ($(($_.Exception.Message -replace '[|\r\n]', ' ').Trim()))")
        try { $boot = (Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 6005 } -MaxEvents 1 -ErrorAction Stop).TimeCreated } catch { }
    }
    $parts.Add("Boot=$(Format-Utc $boot)")

    $since = (Get-Date).AddMonths(-$MonthsBack)

    # ---- Download start dates from the WindowsUpdateClient log (event 44), by KB ----
    $downloadByKb = @{}
    try {
        $events = Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-WindowsUpdateClient/Operational'; Id = 44; StartTime = $since } -ErrorAction Stop
        foreach ($ev in $events) {
            $title = ([xml]$ev.ToXml()).Event.EventData.Data | Where-Object { $_.Name -eq 'updateTitle' } | ForEach-Object { $_.'#text' }
            if ($title -match '\(KB(\d{6,8})\)') {
                $kb = "KB$($Matches[1])"
                if (-not $downloadByKb.ContainsKey($kb) -or $ev.TimeCreated -lt $downloadByKb[$kb]) { $downloadByKb[$kb] = $ev.TimeCreated }
            }
        }
    } catch { }   # no events in range, or log disabled

    # ---- Windows Update history ----
    $searcher = (New-Object -ComObject Microsoft.Update.Session).CreateUpdateSearcher()
    $count    = $searcher.GetTotalHistoryCount()
    $months   = @{}   # YYYY-MM -> info
    if ($count -gt 0) {
        foreach ($h in $searcher.QueryHistory(0, $count)) {
            if ($h.Operation -ne 1) { continue }                         # 1 = installation
            $title = [string]$h.Title
            if ($title -notmatch $TitlePattern -or $title -match $ExcludePattern) { continue }
            $month = $Matches[1]
            if ($h.Date -lt $since) { continue }
            $kb = if ($title -match '\(KB(\d{6,8})\)') { "KB$($Matches[1])" } else { 'KB?' }
            if (-not $months.ContainsKey($month)) {
                $months[$month] = [pscustomobject]@{ KB = $kb; Installed = $null; Failed = 0; FirstFail = $null; LastFail = $null; LastError = ''; Pending = $false }
            }
            $m = $months[$month]
            if ([int]$h.ResultCode -in 2, 3) {                            # succeeded / succeeded with errors
                if (-not $m.Installed -or $h.Date -lt $m.Installed) { $m.Installed = $h.Date; $m.KB = $kb }
            } elseif ([int]$h.ResultCode -in 0, 1) {                      # not started / in progress (usually waiting for a restart)
                $m.Pending = $true
            } elseif ([int]$h.ResultCode -in 4, 5) {                      # failed / aborted
                $m.Failed++
                if (-not $m.FirstFail -or $h.Date -lt $m.FirstFail) { $m.FirstFail = $h.Date }
                if (-not $m.LastFail -or $h.Date -gt $m.LastFail) {
                    $m.LastFail = $h.Date
                    $code = 0
                    try { $code = [int64]$h.HResult } catch { }
                    if ($code -eq 0) { try { $code = [int64]$h.UnmappedResultCode } catch { } }   # some failures only set this
                    $m.LastError = if ($code -ne 0) { '0x{0:X8}' -f ($code -band 0xFFFFFFFFL) } else { '' }
                }
            }
        }
    }

    foreach ($month in ($months.Keys | Sort-Object -Descending)) {
        $m = $months[$month]
        $e = "$month=$($m.KB)"
        if ($m.Installed) { $e += ",I:$(Format-Utc $m.Installed)" }
        if ($downloadByKb.ContainsKey($m.KB)) { $e += ",D:$(Format-Utc $downloadByKb[$m.KB])" }
        $e += ",F:$($m.Failed)"
        if ($m.FirstFail) { $e += ",FD:$(Format-Utc $m.FirstFail)" }
        if ($m.LastError) { $e += ",E:$($m.LastError)" }
        if ($m.Pending -and -not $m.Installed) { $e += ',P:1' }
        $parts.Add($e)
    }
    if ($months.Count -eq 0) { $parts.Add('NONE') }
}
catch {
    $parts.Add("ERROR=$($_.Exception.Message -replace '[|\r\n]', ' ')")
}

$line = $parts -join ' | '
if ($line.Length -gt 2000) { $line = $line.Substring(0, 2000) }
Write-Log $line
Write-Output $line
exit 0
