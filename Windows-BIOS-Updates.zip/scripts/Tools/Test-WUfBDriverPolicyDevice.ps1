#Requires -Version 5.1
<#
  Diagnoses why a device assigned to an Intune driver update policy does not show as a member of that policy
  in the Windows Update for Business deployment service (and so shows "Not in any driver update policy").

  Checks, in order:
    1. Intune record: Entra device ID, last check-in, join type
    2. Entra device object and its group memberships (direct and nested)
    3. Intune driver update policy: exists, its assignments, and whether the device is in an assigned group
    4. Deployment service: the policy with the same ID exists, its audience, and whether the device is a member
    5. Deployment service: the device's registration (updatable asset), driver enrolment and any errors

  Read-only. Same permissions as Get-WUfBFirmwareOffers.ps1.
  Example: .\Test-WUfBDriverPolicyDevice.ps1 -DeviceName WL5ABC123 -PolicyId 00000000-0000-0000-0000-000000000000
#>
param(
    [Parameter(Mandatory)] [string]$DeviceName,
    [Parameter(Mandatory)] [string]$PolicyId
)

$ErrorActionPreference = 'Stop'
$beta = 'https://graph.microsoft.com/beta'
$wu   = "$beta/admin/windows/updates"

function Get-AllPages {
    param([string]$Uri)
    while ($Uri) {
        $r = Invoke-MgGraphRequest -Method GET -Uri $Uri -OutputType PSObject
        if ($r.value) { $r.value }
        $Uri = $r.'@odata.nextLink'
    }
}
function Get-One {
    param([string]$Uri)
    try { Invoke-MgGraphRequest -Method GET -Uri $Uri -OutputType PSObject }
    catch {
        $code = $null
        try { $code = [int]$_.Exception.Response.StatusCode } catch { }
        [pscustomobject]@{ __error = $true; Status = $code; Message = $_.Exception.Message }
    }
}
function Show { param([string]$Label, $Value, [string]$Colour = 'Gray') Write-Host ("  {0,-34} {1}" -f $Label, $Value) -ForegroundColor $Colour }
function Ok   { param([string]$Text) Write-Host "  OK    $Text" -ForegroundColor Green }
function Bad  { param([string]$Text) Write-Host "  ISSUE $Text" -ForegroundColor Red }
function Warn { param([string]$Text) Write-Host "  CHECK $Text" -ForegroundColor Yellow }

Import-Module Microsoft.Graph.Authentication
Connect-MgGraph -Scopes 'WindowsUpdates.ReadWrite.All', 'DeviceManagementManagedDevices.Read.All', 'DeviceManagementConfiguration.Read.All', 'Group.Read.All' -NoWelcome

# ---- 1. Intune record ----
Write-Host "`n[1] Intune record for $DeviceName" -ForegroundColor Cyan
$md = @(Get-AllPages -Uri "$beta/deviceManagement/managedDevices?`$filter=deviceName eq '$($DeviceName -replace "'", "''")'&`$select=id,deviceName,azureADDeviceId,lastSyncDateTime,joinType,managementAgent,operatingSystem,osVersion,model")
if (-not $md) { Bad "$DeviceName not found in Intune"; return }
if ($md.Count -gt 1) { Warn "$($md.Count) Intune records with this name. Using the one that checked in last." }
$md = $md | Sort-Object { [datetime]$_.lastSyncDateTime } -Descending | Select-Object -First 1
$entraId = [string]$md.azureADDeviceId
Show 'Entra device ID' $entraId
Show 'Last check-in' $md.lastSyncDateTime
Show 'Join type / management' "$($md.joinType) / $($md.managementAgent)"
Show 'OS' "$($md.operatingSystem) $($md.osVersion)"
if (-not $entraId -or $entraId -eq '00000000-0000-0000-0000-000000000000') { Bad 'No Entra device ID. The device cannot join a deployment service audience.'; return }

# ---- 2. Entra device and groups ----
Write-Host "`n[2] Entra device and group membership" -ForegroundColor Cyan
$ed = Get-One -Uri "https://graph.microsoft.com/v1.0/devices(deviceId='$entraId')?`$select=id,displayName,accountEnabled,trustType"
if ($ed.__error) { Bad "Entra device object not found ($($ed.Status)). The Intune record points at a deleted Entra object."; return }
Show 'Entra object ID' $ed.id
Show 'Enabled / trust type' "$($ed.accountEnabled) / $($ed.trustType)"
if (-not $ed.accountEnabled) { Bad 'Entra device is disabled.' }
$deviceGroups = @{}
foreach ($g in Get-AllPages -Uri "https://graph.microsoft.com/v1.0/devices/$($ed.id)/transitiveMemberOf?`$select=id,displayName") { $deviceGroups[[string]$g.id] = $g.displayName }
Show 'Groups the device is in' $deviceGroups.Count

# ---- 3. Intune driver update policy and assignment ----
Write-Host "`n[3] Intune driver update policy $PolicyId" -ForegroundColor Cyan
$prof = Get-One -Uri "$beta/deviceManagement/windowsDriverUpdateProfiles/$PolicyId`?`$expand=assignments"
if ($prof.__error) {
    Bad "Not found as an Intune driver update policy ($($prof.Status)). Check the ID is the driver update policy, not a ring or feature update policy."
} else {
    Show 'Name' $prof.displayName
    Show 'Approval type' $prof.approvalType
    Show 'Devices reporting' $prof.deviceReporting
    $inGroup = $false; $excluded = $false
    foreach ($as in @($prof.assignments)) {
        $t = $as.target; $gid = [string]$t.groupId
        $gname = if ($gid) { $n = (Get-One -Uri "https://graph.microsoft.com/v1.0/groups/$gid`?`$select=displayName,groupTypes"); if ($n.__error) { $gid } else { $n.displayName } } else { '' }
        $member = $gid -and $deviceGroups.ContainsKey($gid)
        switch -Wildcard ($t.'@odata.type') {
            '*exclusionGroupAssignmentTarget' { Show "Exclude: $gname" $(if ($member) { 'DEVICE IS IN THIS GROUP' } else { 'device not in group' }) $(if ($member) { 'Red' } else { 'Gray' }); if ($member) { $excluded = $true } }
            '*allDevicesAssignmentTarget'     { Show 'Include: All devices' 'device included'; $inGroup = $true }
            '*allLicensedUsersAssignmentTarget' { Show 'Include: All users' 'user targeting'; Warn 'Assigned to All users. Driver update policies apply to devices; use device groups.' }
            default                           { Show "Include: $gname" $(if ($member) { 'device is in this group' } else { 'device not in group' }) $(if ($member) { 'Green' } else { 'Gray' }); if ($member) { $inGroup = $true } }
        }
    }
    if ($excluded)      { Bad 'Device is in an excluded group.' }
    elseif ($inGroup)   { Ok  'Device is in an assigned device group.' }
    else                { Bad 'Device is not a member of any assigned group as a DEVICE. If the policy targets a user group, the device is not added. Assign a device group.' }
}

# ---- 4. Deployment service policy and audience membership ----
Write-Host "`n[4] Deployment service policy and audience" -ForegroundColor Cyan
$pol = Get-One -Uri "$wu/updatePolicies/$PolicyId`?`$expand=audience"
$audIds = @()
if ($pol.__error) {
    Warn "No deployment service policy with ID $PolicyId ($($pol.Status)). The Intune and service IDs differ, or Intune policies are not visible through this API."
    Write-Host '  Searching every audience for the device instead...'
    $audIds = @(Get-AllPages -Uri "$wu/deploymentAudiences" | ForEach-Object { [string]$_.id })
    Show 'Audiences visible' $audIds.Count
} else {
    Ok "Deployment service policy found. Audience: $($pol.audience.id)"
    $audIds = @([string]$pol.audience.id)
}
$foundIn = @()
foreach ($aid in $audIds) {
    $members = @(Get-AllPages -Uri "$wu/deploymentAudiences/$aid/members")
    $excl    = @(try { Get-AllPages -Uri "$wu/deploymentAudiences/$aid/exclusions" } catch { })
    if ($audIds.Count -eq 1) { Show 'Audience members / exclusions' "$($members.Count) / $($excl.Count)" }
    if ($members | Where-Object { [string]$_.id -eq $entraId }) { $foundIn += $aid }
    if ($excl    | Where-Object { [string]$_.id -eq $entraId }) { Bad "Device is EXCLUDED in audience $aid" }
}
if ($foundIn) { Ok "Device is a member of audience(s): $($foundIn -join ', ')" }
else          { Bad 'Device is not a member of the audience. This is why the report says "Not in any driver update policy".' }

# ---- 5. Deployment service registration ----
Write-Host "`n[5] Deployment service registration (updatable asset)" -ForegroundColor Cyan
$asset = Get-One -Uri "$wu/updatableAssets/$entraId"
if ($asset.__error) {
    Bad "Device is not registered with the deployment service ($($asset.Status)). Intune has not enrolled it yet."
} else {
    $drv = $asset.enrollment.driver
    Show 'Registered' 'Yes'
    Show 'Driver management enrolled' $(if ($drv) { 'Yes' } else { 'No' }) $(if ($drv) { 'Green' } else { 'Red' })
    Show 'Feature / quality enrolled' "$([bool]$asset.enrollment.feature) / $([bool]$asset.enrollment.quality)"
    if (@($asset.errors).Count) {
        foreach ($er in @($asset.errors)) { Bad "Registration error: $($er.reason) $($er.'@odata.type')" }
    } else { Ok 'No registration errors' }
}

# ---- Summary ----
Write-Host "`nLikely causes when the device is assigned but not in the audience:" -ForegroundColor Cyan
Write-Host '  - Policy assigned to a user group, or the device is not a direct or nested member of the device group'
Write-Host '  - Device recently added: Intune can take 24 hours or more to add it to the audience'
Write-Host '  - Device not registered or not driver-enrolled (step 5), or has registration errors'
Write-Host '  - Windows diagnostic data off, or "Enable features that require Windows diagnostic data" not set in Intune tenant admin'
Write-Host '  - Device not Entra joined or hybrid joined, or Entra object disabled or duplicated'
