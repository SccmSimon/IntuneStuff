#Requires -Version 5.1
<#
.SYNOPSIS
    Collects the device-side facts that decide whether a UEFI capsule (BIOS) update applies, so failing
    and working devices can be compared.

.DESCRIPTION
    Read-only. Runs as an Intune Remediations detection script (always exits 0) or by hand as admin.
      - One summary line for the Intune report: model, BIOS, passwords, capsule setting, every ESRT
        firmware resource with its last attempt, firmware devices with a problem code, Secure Boot,
        BitLocker, Fast Startup, battery and AC state.
      - Full dump of every Dell BIOS setting to the IME Logs folder, for a side by side diff:
          %ProgramData%\Microsoft\IntuneManagementExtension\Logs\FirmwareDiag_<device>.csv
        (Collect diagnostics in Intune picks this folder up.)

.NOTES
    Version : 1.0
    Author  : Simon Diaz
    Intune  : Remediations, detection script only, run as SYSTEM, 64-bit PowerShell. Assign to a group
              holding the failing devices plus a few working ones of the same model.
#>

$ProgressPreference = 'SilentlyContinue'
$LogDir = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs'
$info   = [ordered]@{}

function ConvertTo-UInt32 { param($v) if ($null -eq $v) { return [uint32]0 }; [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$v), 0) }
function Format-FwVersion {
    param([uint32]$v)
    '{0}.{1}.{2}.{3}' -f (($v -shr 24) -band 255), (($v -shr 16) -band 255), (($v -shr 8) -band 255), ($v -band 255)
}
function Try-Get { param([scriptblock]$Block, $Default = 'n/a') try { $r = & $Block; if ($null -eq $r -or "$r" -eq '') { $Default } else { $r } } catch { $Default } }

# ---- Device ----
$cs   = Get-CimInstance Win32_ComputerSystem
$bios = Get-CimInstance Win32_BIOS
$info.Model = "$($cs.Model)"
$info.SKU   = "$($cs.SystemSKUNumber)"
$info.BIOS  = "$($bios.SMBIOSBIOSVersion) ($('{0:yyyy-MM-dd}' -f $bios.ReleaseDate))"

# ---- Dell BIOS: passwords and update-related settings ----
$isDell = "$($cs.Manufacturer)" -match '^Dell'
if ($isDell) {
    $pw = Try-Get { Get-CimInstance -Namespace root\dcim\sysman\wmisecurity -ClassName PasswordObject -ErrorAction Stop } $null
    if ($pw) { $info.Passwords = ($pw | ForEach-Object { "$($_.NameId)=$(if ($_.IsPasswordSet) { 'Set' } else { 'None' })" }) -join ',' }
    else     { $info.Passwords = 'Dell WMI not available' }

    $attrs = @()
    foreach ($cls in 'EnumerationAttribute', 'IntegerAttribute', 'StringAttribute') {
        $attrs += @(Try-Get { Get-CimInstance -Namespace root\dcim\sysman\biosattributes -ClassName $cls -ErrorAction Stop } @())
    }
    if ($attrs.Count) {
        $key = $attrs | Where-Object { $_.AttributeName -match 'Capsule|BiosUpdate|Flash|Downgrade|AutoOsRecovery|BiosRecovery|SecureBoot|TpmSecurity|PowerWarn|AdminSetupLockout' }
        $info.BiosSettings = ($key | Sort-Object AttributeName | ForEach-Object { "$($_.AttributeName)=$($_.CurrentValue)" }) -join ','
        try {
            $attrs | Sort-Object AttributeName |
                Select-Object @{n='Setting';e={$_.AttributeName}}, @{n='Value';e={"$($_.CurrentValue)"}} |
                Export-Csv -Path (Join-Path $LogDir "FirmwareDiag_$env:COMPUTERNAME.csv") -NoTypeInformation -Encoding UTF8
        } catch { }
    }
}

# ---- ESRT: every firmware resource ----
$capsuleStatus = @{ 0='OK'; 1='Unsuccessful'; 2='NoResources'; 3='BadVersion'; 4='BadImage'; 5='AuthError'; 6='NoAC'; 7='LowBattery' }
$esrt = foreach ($k in @(Get-ChildItem 'HKLM:\HARDWARE\UEFI\ESRT' -ErrorAction SilentlyContinue)) {
    $p = Get-ItemProperty $k.PSPath
    $st = [int](ConvertTo-UInt32 $p.LastAttemptStatus)
    '{0}:{1}:v{2}:last {3} {4}' -f $k.PSChildName.Trim('{','}').Substring(0, 8),
        $(if ($p.Type -eq 1) { 'System' } else { 'Device' }),
        (Format-FwVersion (ConvertTo-UInt32 $p.Version)),
        (Format-FwVersion (ConvertTo-UInt32 $p.LastAttemptVersion)),
        $(if ($capsuleStatus.ContainsKey($st)) { $capsuleStatus[$st] } else { "status$st" })
}
$info.ESRT = if ($esrt) { $esrt -join ' | ' } else { 'None' }

# ---- Firmware devices: package version and problem codes ----
$fwDevs = foreach ($d in @(Get-PnpDevice -Class Firmware -PresentOnly -ErrorAction SilentlyContinue)) {
    $ver  = (Get-PnpDeviceProperty -InstanceId $d.InstanceId -KeyName DEVPKEY_Device_DriverVersion -ErrorAction SilentlyContinue).Data
    $code = (Get-PnpDeviceProperty -InstanceId $d.InstanceId -KeyName DEVPKEY_Device_ProblemCode -ErrorAction SilentlyContinue).Data
    $guid = if ($d.InstanceId -match '\{([0-9a-fA-F]{8})') { $Matches[1] } else { $d.InstanceId }
    '{0}:pkg {1}:code {2}' -f $guid, $ver, $(if ($code) { $code } else { 0 })
}
$info.FwDevices = if ($fwDevs) { $fwDevs -join ' | ' } else { 'None' }

# ---- Platform ----
$info.SecureBoot  = Try-Get { if (Confirm-SecureBootUEFI) { 'On' } else { 'Off' } }
$info.BitLocker   = Try-Get { (Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop).ProtectionStatus }
$info.FastStartup = Try-Get { if ((Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -ErrorAction Stop).HiberbootEnabled -eq 1) { 'On' } else { 'Off' } }
$batt = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
if ($batt.Count) {
    $onAC = @($batt | Where-Object { $_.BatteryStatus -in 2, 6, 7, 8, 9 }).Count -gt 0
    $info.Power = 'AC {0}, battery {1}%' -f $(if ($onAC) { 'Yes' } else { 'No' }), [int](($batt | Measure-Object EstimatedChargeRemaining -Average).Average)
} else { $info.Power = 'No battery' }
$info.LastBoot = '{0:yyyy-MM-dd HH:mm}' -f (Get-CimInstance Win32_OperatingSystem).LastBootUpTime

$line = ($info.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join '; '
if ($line.Length -gt 2000) { $line = $line.Substring(0, 2000) }
Write-Output $line
exit 0
