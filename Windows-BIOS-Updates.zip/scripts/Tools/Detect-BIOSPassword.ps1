#Requires -Version 5.1
<#
  Detection (report only): is a BIOS password set on this Dell or HP device?
  Uses the BIOS management interface built into the firmware. No Dell Command | Update, Dell Command | Monitor
  or HP CMSL needed. Read-only, changes nothing.

  Use as the detection script of an Intune Remediation with no remediation script.
  Exit 1 = BIOS password set, or state unknown (shows under "With issues"). Exit 0 = no BIOS password.
  Output (one line, visible in the Intune report): Vendor | Admin/Setup password | System/Power-on password | Source
#>

$ErrorActionPreference = 'Stop'
$ScriptVersion = '1.0'

$DataRoot = if ($env:ProgramData) { $env:ProgramData } else { 'C:\ProgramData' }
$LogDir   = Join-Path $DataRoot 'Microsoft\IntuneManagementExtension\Logs'
$LogFile  = Join-Path $LogDir 'BIOSPassword-Detection.log'

function Write-Log {
    param([string]$Message)
    try { Add-Content -Path $LogFile -Value ("{0:yyyy-MM-dd HH:mm:ss} {1}" -f (Get-Date), $Message) } catch { }
}
function ConvertTo-State { param($Value) if ($null -eq $Value) { 'Unknown' } elseif ([int]$Value -eq 1) { 'Set' } else { 'Not set' } }

$vendor = ''; $admin = $null; $system = $null; $source = ''
try {
    New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem
    $mfr = [string]$cs.Manufacturer

    if ($mfr -match '^Dell') {
        $vendor = 'Dell'
        # 1. Dell BIOS WMI, built into the firmware on most Dell business models from about 2018
        try {
            $objs = @(Get-CimInstance -Namespace 'root/dcim/sysman/wmisecurity' -ClassName PasswordObject -ErrorAction Stop)
            $admin  = ($objs | Where-Object NameId -eq 'Admin'  | Select-Object -First 1).IsPasswordSet
            $system = ($objs | Where-Object NameId -eq 'System' | Select-Object -First 1).IsPasswordSet
            $source = 'Dell BIOS WMI'
        } catch {
            # 2. Older models: Dell Command | Monitor, only if it happens to be installed
            try {
                $objs = @(Get-CimInstance -Namespace 'root/dcim/sysman' -ClassName DCIM_BiosPassword -ErrorAction Stop)
                $a = $objs | Where-Object AttributeName -eq 'AdminPwd'  | Select-Object -First 1
                $s = $objs | Where-Object AttributeName -eq 'SystemPwd' | Select-Object -First 1
                if ($a) { $admin  = [int][bool]$a.IsSet }
                if ($s) { $system = [int][bool]$s.IsSet }
                $source = 'Dell Command | Monitor'
            } catch { $source = 'No Dell BIOS management interface on this model' }
        }
    }
    elseif ($mfr -match '^(HP|Hewlett)') {
        $vendor = 'HP'
        # HP BIOS WMI, built into HP business models
        try {
            $objs = @(Get-CimInstance -Namespace 'root/HP/InstrumentedBIOS' -ClassName HP_BIOSPassword -ErrorAction Stop)
            $admin  = ($objs | Where-Object Name -eq 'Setup Password'    | Select-Object -First 1).IsSet
            $system = ($objs | Where-Object Name -eq 'Power-On Password' | Select-Object -First 1).IsSet
            $source = 'HP BIOS WMI'
        } catch { $source = 'No HP BIOS management interface on this model' }
    }
    else {
        $out = "Not applicable: $mfr"
        Write-Log "v$ScriptVersion | $out"
        Write-Output $out
        exit 0
    }

    $adminState  = ConvertTo-State $admin
    $systemState = ConvertTo-State $system
    $label = if ($vendor -eq 'HP') { @('Setup', 'Power-on') } else { @('Admin', 'System') }
    $out = "$vendor $($cs.Model) | $($label[0]) password: $adminState | $($label[1]) password: $systemState | $source"
    Write-Log "v$ScriptVersion | $out"
    Write-Output $out

    if ($adminState -eq 'Not set' -and $systemState -ne 'Set') { exit 0 }
    exit 1
}
catch {
    $out = "Error at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
    Write-Log "v$ScriptVersion | $out"
    Write-Output $out
    exit 1
}
