#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Clears a BIOS package that Windows Update installed but the firmware never applied, so the update can be
    tried again.

.DESCRIPTION
    Windows Update decides "IsInstalled" from the driver installed on the System Firmware device, not from the
    running BIOS. When the capsule is not processed at restart the package stays installed, the scan no longer
    offers it, and the device shows problem code 10. There is no flag to clear; this script changes the
    driver state instead.

    -Mode Restage (default)
        Removes the System Firmware device and rescans. Windows reinstalls the same package from the driver
        store, which stages the capsule again for the next restart. No download, no Windows Update scan.

    -Mode Reoffer
        Deletes the firmware package from the driver store and rescans. The device falls back to no driver,
        Windows Update sees the BIOS as not installed (IsInstalled=0) and offers it again, so
        BIOSUpdate-Detection / BIOSUpdate-Remediation pick it up on the next run.

    Fix the reason it did not apply first (BIOS admin password, capsule updates disabled, BIOS event log).
    Otherwise it stages again and fails again.

    Does nothing if the running BIOS is already at or above the package version, unless -Force.
    Never restarts the device.

.PARAMETER Mode
    Restage (default) or Reoffer.

.PARAMETER Force
    Run even if the package is not newer than the running BIOS.

.EXAMPLE
    .\Reset-StagedBIOS.ps1
.EXAMPLE
    .\Reset-StagedBIOS.ps1 -Mode Reoffer

.NOTES
    Version : 1.0
    Author  : Simon Diaz
    Log     : %ProgramData%\Microsoft\IntuneManagementExtension\Logs\BIOSUpdate-Reset.log
#>
param(
    [ValidateSet('Restage', 'Reoffer')]
    [string]$Mode = 'Restage',
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$LogFile = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs\BIOSUpdate-Reset.log'

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0:yyyy-MM-dd HH:mm:ss} [{1}] {2}" -f (Get-Date), $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
    $colour = switch ($Level) { 'WARN' { 'Yellow' } 'ERROR' { 'Red' } default { 'Gray' } }
    Write-Host $line -ForegroundColor $colour
}
function ConvertTo-UInt32 { param($Value) if ($null -eq $Value) { return [uint32]0 }; [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$Value), 0) }
function Format-FwVersion {
    param([uint32]$Value)
    '{0}.{1}.{2}.{3}' -f (($Value -shr 24) -band 255), (($Value -shr 16) -band 255), (($Value -shr 8) -band 255), ($Value -band 255)
}
function Get-FwState {
    param([string]$InstanceId)
    [pscustomobject]@{
        Package = [string](Get-PnpDeviceProperty -InstanceId $InstanceId -KeyName DEVPKEY_Device_DriverVersion -ErrorAction SilentlyContinue).Data
        Inf     = [string](Get-PnpDeviceProperty -InstanceId $InstanceId -KeyName DEVPKEY_Device_DriverInfPath -ErrorAction SilentlyContinue).Data
        Problem = (Get-PnpDeviceProperty -InstanceId $InstanceId -KeyName DEVPKEY_Device_ProblemCode -ErrorAction SilentlyContinue).Data
    }
}

try {
    Write-Log "==== Reset staged BIOS on $env:COMPUTERNAME, mode $Mode ===="

    # ---- ESRT system firmware ----
    $esrt = $null
    foreach ($k in @(Get-ChildItem -Path 'HKLM:\HARDWARE\UEFI\ESRT' -ErrorAction SilentlyContinue)) {
        $p = Get-ItemProperty -Path $k.PSPath
        if ($p.Type -eq 1) { $esrt = [pscustomobject]@{ Guid = $k.PSChildName.Trim('{', '}'); Version = ConvertTo-UInt32 $p.Version }; break }
    }
    if (-not $esrt) { Write-Log 'No ESRT system firmware entry. Nothing to do.' 'WARN'; exit 1 }
    $running = Format-FwVersion $esrt.Version

    $dev = Get-PnpDevice -Class Firmware -PresentOnly -ErrorAction SilentlyContinue |
           Where-Object { $_.InstanceId -like "*$($esrt.Guid)*" } | Select-Object -First 1
    if (-not $dev) { Write-Log "No firmware device for ESRT GUID $($esrt.Guid). Nothing to do." 'WARN'; exit 1 }
    $id    = $dev.InstanceId
    $state = Get-FwState -InstanceId $id
    Write-Log "Device: $id | running $running | package $($state.Package) ($($state.Inf)) | status $($dev.Status) | problem code $($state.Problem)"

    $pkg = $null; try { $pkg = [version]$state.Package } catch { }
    if (-not $Force -and (-not $pkg -or $pkg -le [version]$running)) {
        Write-Log "Package is not newer than the running BIOS. Nothing to reset. Use -Force to run anyway."
        exit 0
    }
    if ($state.Inf -notlike 'oem*.inf') {
        Write-Log "Driver is $($state.Inf), not a third-party package. Nothing to remove." 'WARN'
        exit 1
    }

    switch ($Mode) {
        'Restage' {
            Write-Log "Removing device $id"
            & pnputil.exe /remove-device "$id" | ForEach-Object { Write-Log "  $_" }
            Write-Log 'Rescanning devices'
            & pnputil.exe /scan-devices | ForEach-Object { Write-Log "  $_" }
            Start-Sleep -Seconds 10

            # The capsule flashes before Windows starts, so suspend BitLocker for that one restart
            try {
                $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive
                if ($bl.ProtectionStatus -eq 'On') {
                    Suspend-BitLocker -MountPoint $env:SystemDrive -RebootCount 1 | Out-Null
                    Write-Log 'BitLocker suspended for 1 restart'
                }
            } catch { Write-Log "Could not check or suspend BitLocker: $($_.Exception.Message)" 'WARN' }

            $dev2 = Get-PnpDevice -InstanceId $id -ErrorAction SilentlyContinue
            if ($dev2) {
                $after = Get-FwState -InstanceId $id
                Write-Log "After: package $($after.Package) | status $($dev2.Status) | problem code $($after.Problem)"
                if ($after.Problem -eq 14) { Write-Log 'Staged. Restart the device to apply the BIOS.' }
                else { Write-Log 'Device reinstalled but not showing restart required (code 14). Check Device Manager.' 'WARN' }
            } else {
                Write-Log 'Device not back after the rescan. Run pnputil /scan-devices again or restart.' 'WARN'
            }
        }
        'Reoffer' {
            Write-Log "Deleting driver package $($state.Inf) and uninstalling it from the device"
            & pnputil.exe /delete-driver $state.Inf /uninstall /force | ForEach-Object { Write-Log "  $_" }
            & pnputil.exe /scan-devices | ForEach-Object { Write-Log "  $_" }
            Write-Log 'Done. The next Windows Update scan should offer the BIOS again (IsInstalled=0).'
            Write-Log 'Run the BIOSUpdate remediation, or wait for its next scheduled run.'
        }
    }
    exit 0
}
catch {
    Write-Log "Error: $($_.Exception.Message)" 'ERROR'
    exit 1
}
