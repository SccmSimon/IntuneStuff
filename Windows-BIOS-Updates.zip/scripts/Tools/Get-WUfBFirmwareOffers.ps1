#Requires -Version 5.1
<#
  Version 2.9
  Reports, for live Intune devices, which Intune driver update policy applies to each device and whether that
  policy has BIOS / firmware updates approved, waiting for review, declined or paused (policy level), and
  what firmware Windows Update is actually offering each device (device level).

  Why Intune data only (v2.0):
    In this tenant the Intune driver update policies do not appear in the Windows Update for Business
    deployment service API (policy IDs return 404 and devices are not in any visible audience), and the
    Intune list API returns 0 for "devices reporting". So this version takes everything from Intune:
      Device -> policy   : the policy's include / exclude groups, expanded to their device members
      Firmware approvals : the policy's driver inventory (approvalStatus, applicableDeviceCount, release date)
  Driver inventory is per policy and does not say which model an update is for, so it is only used for the
  policy-level CSVs. Each device's row is device specific: its policy (from groups) and what the device itself
  reported from Windows Update (Detect-WUFirmwareStatus.ps1 remediation, see 2.4).

  Device scope: live Intune devices only (names start with $NamePrefixes, checked in within $StaleDays days).
  Single device check: -DeviceName WL5ABC123 (one or more names). Ignores -NamePrefixes and -StaleDays and
  prints the result for each device to the console.

  Run from an admin workstation. Requires Microsoft.Graph.Authentication.
  Permissions: DeviceManagementManagedDevices.Read.All, DeviceManagementConfiguration.Read.All, Group.Read.All,
  Device.Read.All. Read-only: GET requests only.

  Output (in $OutputFolder):
    DriverPolicy-Devices_<date>.csv          one row per live device: its policy, device-reported result, status
    DriverPolicy-Firmware_<date>.csv         one row per firmware update per policy, with approval status
    DriverPolicy-PolicySummary_<date>.csv    one row per policy: groups, live devices, firmware counts

  2.2: Graph calls retry on 429 / 503 / 504. A policy whose driver inventory cannot be read is flagged and its
       devices show "Driver inventory could not be read" instead of "no firmware". Inventory entry count per
       policy. Installed BIOS version (always in single device mode, -IncludeBiosVersion on a full run).
  2.3: Reuses an existing Graph sign-in that already has the required scopes (used by the GUI,
       Show-DriverPolicyChecker.ps1). File names include seconds so back-to-back runs do not overwrite.
  2.4: Confirmed offer details. Reads each device's latest result from the Detect-WUFirmwareStatus.ps1
       Intune remediation (detection only, run daily as SYSTEM). That script asks Windows Update on the device
       what firmware it is offered, so these columns are what the device itself reported:
         DeviceCheck          OK / ISSUE / not run, and when it last ran
         DeviceResult         the detection result, for example "Firmware offered, not installed"
         OfferedNow           firmware Windows Update is offering the device now (not yet installed)
         LastWUFirmware       last firmware in the device's Windows Update history and its result
         FirmwarePackage      System Firmware device version (what Windows Update installed)
         RunningFirmware      UEFI ESRT version (what the BIOS is actually running)
         LastCapsule          result of the last UEFI capsule (BIOS) update attempt
         RestartPending       Yes when a restart is waiting
       -OfferScriptName picks the remediation by its Intune name (wildcards allowed). -SkipDeviceCheck turns it off.
  2.5: [CmdletBinding()], so an unknown parameter is an error instead of being silently ignored.
       Tables are written through Write-Host, so they also show in the GUI log.
  2.6: LatestVendorFirmware column removed. Intune driver inventory does not say which model a firmware
       update is for, so the newest vendor firmware in a policy was often another model's BIOS. Use
       OfferedNow (reported by the device) for what this device is actually offered.
  2.7: Devices CSV is device specific only. Vendor-wide columns removed (FirmwareApproved, FirmwareNeedsReview,
       FirmwareDeclinedOrPaused, WaitingForApproval). Status now comes from policy membership plus what the
       device reported: Not in any driver update policy | In more than one driver update policy (conflict) |
       In policy, device check not run | In policy, device result out of date | Firmware offered, not installed |
       Device issue: <result> | Up to date (no firmware offered). Policy-level firmware counts stay in the
       PolicySummary and Firmware CSVs.
  2.9: Error codes reported by the device (HResult of a failed Windows Update firmware install, or an error code
       in a scan or script error) shown with Microsoft's message, description and mitigation from MS Learn:
       ErrorCode, ErrorMessage, ErrorMeaning, ErrorMitigation, ErrorLink.
  2.8: Model comparison. Compares each device's running firmware (UEFI ESRT, reported by the device) with the
       newest firmware Windows Update has delivered to any device of the same model in this run.
         BiosOnDevice        BIOS version the device reports (Win32_BIOS). Intune's BiosVersion can be stale.
         NewestSeenForModel  newest firmware package seen on any device of the same model, and on which device
         Status "Behind other devices of this model" when the device runs older firmware than that and is not
         being offered it. Larger runs (a full model, or a full report) give a better comparison.
#>
[CmdletBinding()]
param(
    [string]$OutputFolder = 'C:\Temp\BIOSReport',
    [switch]$IncludeDrivers,      # also report non-firmware drivers
    [string[]]$NamePrefixes = @('WL4', 'WL5', 'WL6', 'WD4', 'WD5', 'WD6'),  # only devices whose name starts with one of these
    [int]$StaleDays = 30,         # only devices that have checked in to Intune within this many days
    [string[]]$DeviceName,        # check these devices only (exact names); ignores -NamePrefixes and -StaleDays
    [switch]$IncludeBiosVersion,  # full run: also read each device's BIOS version (one extra call per device)
    [string]$OfferScriptName = '*Firmware*',  # Intune remediation running Detect-WUFirmwareStatus.ps1 (name, wildcards allowed)
    [int]$DeviceCheckMaxAgeDays = 7,          # device results older than this are flagged as stale
    [switch]$SkipDeviceCheck                  # do not read the device-reported Windows Update results
)

$ErrorActionPreference = 'Stop'
$beta = 'https://graph.microsoft.com/beta'
$v1   = 'https://graph.microsoft.com/v1.0'

# Single GET with retry on throttling or transient errors
function Invoke-GraphGet {
    param([string]$Uri)
    for ($attempt = 1; ; $attempt++) {
        try { return Invoke-MgGraphRequest -Method GET -Uri $Uri -OutputType PSObject }
        catch {
            $code = $null
            try { $code = [int]$_.Exception.Response.StatusCode } catch { }
            if ($code -in 429, 503, 504 -and $attempt -le 5) {
                $wait = [math]::Pow(2, $attempt)
                Write-Warning "Graph returned $code. Retrying in $wait seconds."
                Start-Sleep -Seconds $wait
            }
            else { throw }
        }
    }
}
function Get-AllPages {
    param([string]$Uri)
    while ($Uri) {
        $r = Invoke-GraphGet -Uri $Uri
        if ($r.value) { $r.value }
        $Uri = $r.'@odata.nextLink'
    }
}
function Format-Date { param($Value) if ($Value) { ([datetime]$Value).ToString('yyyy-MM-dd') } else { '' } }
# First word of a manufacturer name, letters and digits only, so 'HP Inc.' -> HP, 'Dell, Inc.' -> DELL
function Get-Vendor {
    param([string]$Name)
    $w = (([string]$Name).Trim() -split '[\s,.\-]+' | Where-Object { $_ } | Select-Object -First 1)
    $w = ([string]$w -replace '[^A-Za-z0-9]', '').ToUpper()
    if ($w -like 'HEWLETT*') { 'HP' } else { $w }
}

Import-Module Microsoft.Graph.Authentication
$scopes = 'DeviceManagementManagedDevices.Read.All', 'DeviceManagementConfiguration.Read.All', 'Group.Read.All', 'Device.Read.All'
# Reuse an existing sign-in when it already has every scope (the GUI signs in first); otherwise sign in now
$ctx = Get-MgContext
if (-not $ctx -or @($scopes | Where-Object { $ctx.Scopes -notcontains $_ }).Count) {
    Connect-MgGraph -Scopes $scopes -NoWelcome
} else {
    Write-Host "Using existing Graph sign-in: $($ctx.Account)"
}
New-Item -Path $OutputFolder -ItemType Directory -Force | Out-Null
$stamp  = Get-Date -Format 'yyyyMMdd_HHmmss'
$single = [bool]$DeviceName

# ---- 1. Live Intune devices ----
if ($single) {
    Write-Host "Single device check: $($DeviceName -join ', ')"
    $NamePrefixes = $DeviceName; $StaleDays = 36500
} else {
    Write-Host "Reading Intune Windows devices (last check-in within $StaleDays days, names $($NamePrefixes -join ', '))..."
}
$cutoff   = (Get-Date).ToUniversalTime().AddDays(-$StaleDays)
$prefixRx = '^(' + (($NamePrefixes | ForEach-Object { [regex]::Escape($_) }) -join '|') + ')' + $(if ($single) { '$' } else { '' })
$emptyId  = '00000000-0000-0000-0000-000000000000'
$devices  = @{}   # Entra device ID -> device
$stats    = @{ Total = 0; WrongName = 0; Stale = 0; NoEntraId = 0; Duplicate = 0 }

$sel  = '$select=id,deviceName,manufacturer,model,azureADDeviceId,lastSyncDateTime,serialNumber,userPrincipalName'
$uris = if ($single) {
    foreach ($n in $DeviceName) { "$beta/deviceManagement/managedDevices?`$filter=deviceName eq '$($n -replace "'", "''")'&$sel" }
} else {
    "$beta/deviceManagement/managedDevices?`$filter=operatingSystem eq 'Windows'&$sel&`$top=999"
}
foreach ($d in ($uris | ForEach-Object { Get-AllPages -Uri $_ })) {
    $stats.Total++
    if ([string]$d.deviceName -notmatch $prefixRx) { $stats.WrongName++; continue }
    $sync = if ($d.lastSyncDateTime) { ([datetime]$d.lastSyncDateTime).ToUniversalTime() } else { [datetime]::MinValue }
    if ($sync -lt $cutoff) { $stats.Stale++; continue }
    $aad = ([string]$d.azureADDeviceId).ToLower()
    if (-not $aad -or $aad -eq $emptyId) { $stats.NoEntraId++; continue }
    $obj = [pscustomobject]@{
        intuneId = $d.id
        displayName = $d.deviceName; manufacturer = $d.manufacturer; model = $d.model
        serialNumber = $d.serialNumber; primaryUser = $d.userPrincipalName; lastSync = $sync
        vendor = Get-Vendor $d.manufacturer
        biosVersion = ''
    }
    if ($devices.ContainsKey($aad)) { $stats.Duplicate++; if ($devices[$aad].lastSync -ge $sync) { continue } }
    $devices[$aad] = $obj
}
Write-Host ("  Windows devices in Intune: {0} | wrong name: {1} | not checked in for {2}+ days: {3} | no Entra ID: {4} | duplicates: {5}" -f `
    $stats.Total, $stats.WrongName, $StaleDays, $stats.Stale, $stats.NoEntraId, $stats.Duplicate)
Write-Host "  Live devices in scope: $($devices.Count)"
if ($single) {
    foreach ($n in $DeviceName) {
        if (-not ($devices.Values | Where-Object { $_.displayName -eq $n })) { Write-Warning "  $n not found in Intune, or it has no Entra device ID" }
    }
}
if ($devices.Count -eq 0) { Write-Warning 'No live devices in scope.'; return }

# BIOS version: hardwareInformation is only returned on a single device GET with $select
if ($single -or $IncludeBiosVersion) {
    Write-Host 'Reading installed BIOS versions...'
    $n = 0
    foreach ($dev in $devices.Values) {
        $n++
        if (-not $single -and $n % 200 -eq 0) { Write-Host "  $n of $($devices.Count)" }
        try {
            $hw = Invoke-GraphGet -Uri "$beta/deviceManagement/managedDevices/$($dev.intuneId)?`$select=hardwareInformation"
            $dev.biosVersion = [string]$hw.hardwareInformation.systemManagementBIOSVersion
        } catch { $dev.biosVersion = 'Not read' }
    }
}

# ---- 2. Driver update policies, assignments and firmware inventory ----
Write-Host 'Reading Intune driver update policies...'
$profiles = @(Get-AllPages -Uri "$beta/deviceManagement/windowsDriverUpdateProfiles?`$expand=assignments")
Write-Host "  Driver update policies: $($profiles.Count)"
if (-not $profiles) { Write-Warning 'No Intune driver update policies found.'; return }

$groupName = @{}
function Get-GroupName {
    param([string]$Id)
    if (-not $groupName.ContainsKey($Id)) {
        try { $groupName[$Id] = (Invoke-GraphGet -Uri "$v1/groups/$Id`?`$select=displayName").displayName }
        catch { $groupName[$Id] = "$Id (not found)" }
    }
    $groupName[$Id]
}

$policies = @{}       # policy ID -> info
$firmware = New-Object System.Collections.Generic.List[object]
foreach ($pr in $profiles) {
    $inc = @(); $exc = @(); $allDevices = $false; $userTargets = @()
    foreach ($as in @($pr.assignments)) {
        $t = $as.target
        switch -Wildcard ($t.'@odata.type') {
            '*exclusionGroupAssignmentTarget'   { $exc += ([string]$t.groupId).ToLower() }
            '*allDevicesAssignmentTarget'       { $allDevices = $true }
            '*allLicensedUsersAssignmentTarget' { $userTargets += 'All users' }
            '*.groupAssignmentTarget'           { $inc += ([string]$t.groupId).ToLower() }
        }
    }

    # A failed read is recorded, never treated as an empty inventory
    $inv = @(); $invError = $null
    try { $inv = @(Get-AllPages -Uri "$beta/deviceManagement/windowsDriverUpdateProfiles/$($pr.id)/driverInventories") }
    catch {
        $invError = $_.Exception.Message
        Write-Warning "  Could not read driver inventory for '$($pr.displayName)': $invError"
    }
    $fw = @($inv | Where-Object { $IncludeDrivers -or $_.driverClass -eq 'Firmware' })

    foreach ($i in $fw) {
        $firmware.Add([pscustomobject]@{
            PolicyName            = $pr.displayName
            ApprovalType          = $pr.approvalType
            DriverClass           = $i.driverClass
            Manufacturer          = $i.manufacturer
            Name                  = $i.name
            Version               = $i.version
            Released              = Format-Date $i.releaseDateTime
            ApprovalStatus        = $i.approvalStatus
            Category              = $i.category
            DeployDate            = Format-Date $i.deployDateTime
            ApplicableDeviceCount = $i.applicableDeviceCount
            PolicyId              = $pr.id
            DriverId              = $i.id
        })
    }
    $policies[[string]$pr.id] = [pscustomobject]@{
        Id = [string]$pr.id; Name = $pr.displayName; ApprovalType = $pr.approvalType
        Include = $inc; Exclude = $exc; AllDevices = $allDevices; UserTargets = $userTargets
        Firmware = $fw; InventoryCount = $inv.Count; InventoryError = $invError
    }
    if ($invError) {
        Write-Host ("  {0} | {1} | INVENTORY NOT READ" -f $pr.displayName, $pr.approvalType) -ForegroundColor Red
    } else {
        $c = @{}; foreach ($s in 'approved', 'needsReview', 'declined', 'suspended') { $c[$s] = @($fw | Where-Object approvalStatus -eq $s).Count }
        Write-Host ("  {0} | {1} | inventory entries {2} | firmware approved {3}, needs review {4}, declined {5}, paused {6}" -f `
            $pr.displayName, $pr.approvalType, $inv.Count, $c.approved, $c.needsReview, $c.declined, $c.suspended)
    }
}

# ---- 3. Device -> policy, through group membership ----
# Single device: read the device's own groups (fast). Full run: expand each assigned group once.
$deviceGroups = @{}   # Entra device ID -> HashSet of group IDs
$usedGroups   = @($policies.Values | ForEach-Object { $_.Include; $_.Exclude } | Where-Object { $_ } | Select-Object -Unique)

if ($single) {
    foreach ($id in @($devices.Keys)) {
        $set = New-Object System.Collections.Generic.HashSet[string]
        try {
            $ed = Invoke-GraphGet -Uri "$v1/devices(deviceId='$id')?`$select=id"
            foreach ($g in Get-AllPages -Uri "$v1/devices/$($ed.id)/transitiveMemberOf?`$select=id") { [void]$set.Add(([string]$g.id).ToLower()) }
        } catch { Write-Warning "  Could not read groups for $($devices[$id].displayName): $($_.Exception.Message)" }
        $deviceGroups[$id] = $set
    }
} else {
    Write-Host "Expanding $($usedGroups.Count) assigned groups to their device members..."
    foreach ($gid in $usedGroups) {
        $n = 0
        try {
            # OData cast: device members only, nested groups included
            foreach ($m in Get-AllPages -Uri "$v1/groups/$gid/transitiveMembers/microsoft.graph.device?`$select=deviceId&`$top=999") {
                $did = ([string]$m.deviceId).ToLower()
                if ($devices.ContainsKey($did)) {
                    if (-not $deviceGroups.ContainsKey($did)) { $deviceGroups[$did] = New-Object System.Collections.Generic.HashSet[string] }
                    [void]$deviceGroups[$did].Add($gid); $n++
                }
            }
        } catch { Write-Warning "  Could not expand group $(Get-GroupName $gid): $($_.Exception.Message)" }
        Write-Host ("  {0}: {1} live devices in scope" -f (Get-GroupName $gid), $n)
    }
}

function Get-DevicePolicies {
    param([string]$Id)
    $set = if ($deviceGroups.ContainsKey($Id)) { $deviceGroups[$Id] } else { $null }
    foreach ($p in $policies.Values) {
        $included = $p.AllDevices -or ($null -ne $set -and @($p.Include | Where-Object { $set.Contains($_) }).Count -gt 0)
        $excluded = $null -ne $set -and @($p.Exclude | Where-Object { $set.Contains($_) }).Count -gt 0
        if ($included -and -not $excluded) { $p }
    }
}

#region Windows Update error codes (MS Learn)
# Built on 2026-10-27 from three Microsoft Learn pages. Text is Microsoft's own, unchanged apart from formatting.
#   C = Windows Update common errors and mitigation (has the mitigation steps)
#   R = Windows Update error codes by component
#   W = Windows Update Agent success and error codes
# To refresh, rebuild this table from the same pages. Codes not listed fall back to the Windows system message.
$WUErrorSource = @{
    C = 'https://learn.microsoft.com/troubleshoot/windows-client/installing-updates-features-roles/common-windows-update-errors'
    R = 'https://learn.microsoft.com/windows/deployment/update/windows-update-error-reference'
    W = 'https://learn.microsoft.com/windows/win32/wua_sdk/wua-success-and-error-codes-'
}
$WUErrorTable = @{}
@'
Code,Message,Description,Mitigation,Source
0x00240001,WU_S_SERVICE_STOP,Windows Update Agent was stopped successfully.,,R
0x00240002,WU_S_SELFUPDATE,Windows Update Agent updated itself.,,R
0x00240003,WU_S_UPDATE_ERROR,Operation completed successfully but there were errors applying the updates.,,R
0x00240004,WU_S_MARKED_FOR_DISCONNECT,A callback was marked to be disconnected later because the request to disconnect the operation came while a callback was executing.,,R
0x00240005,WU_S_REBOOT_REQUIRED,The system must be restarted to complete installation of the update.,,R
0x00240006,WU_S_ALREADY_INSTALLED,The update to be installed is already installed on the system.,,R
0x00240007,WU_S_ALREADY_UNINSTALLED,The update to be removed isn't installed on the system.,,R
0x00240008,WU_S_ALREADY_DOWNLOADED,The update to be downloaded has already been downloaded.,,R
0x00242015,WU_S_UH_INSTALLSTILLPENDING,The installation operation for the update is still in progress.,,W
0x80070003,ERROR_PATH_NOT_FOUND,The system can't find the path specified. The servicing stack can't access a specific path.,"Indicates an invalid path to an executable. Go to %Windir%\logs\CBS, open the last CBS.log, and search for ', error'. Then, match the results to the timestamp.",C
0x80070005,E_ACCESSDENIED,General access denied error. File system or registry key permissions have been changed and the servicing stack doesn't have the required level of access.,"This error generally means that access was denied. Go to %Windir%\logs\CBS, open the last CBS.log, search for ', error', and match with the timestamp. After you find the error, scroll up, and try to determine what caused the access denial. It could be access denied to a file, registry key. Determine which object needs the right permissions, and change the permissions as appropriate. For more information, see Troubleshoot Windows Update error 0x80070005.",C
0x8007000D,ERROR_INVALID_DATA,Indicates data that isn't valid was downloaded or corruption occurred.,"Try to redownload the update, and then start the installation.",C
0x80070020,ERROR_SHARING_VIOLATION,Numerous causes. CBS log analysis required.,"This error is caused by non-Microsoft filter drivers, such as antivirus. 1. Perform a clean restart, and retry the installation 2. Download the sysinternal tool Process Monitor. 3. Run Procmon.exe. The tool starts data capture automatically. 4. Install the update package again. 5. Keep the Process Monitor main window in focus, and press CTRL+E or select the magnifying glass to stop data capture. 6. Select File > Save > All Events > PML, and choose a path to save the.PML file. 7. Go to %windir%\logs\cbs, open the last Cbs.log file, and search for the error entry. After you locate the error line, you should see which file is accessed during the installation and is causing the sharing violation error. 8. In Process Monitor, filter for path, and insert the file name (it should resemble ""path"" ""contains"" ""filename from CBS""). 9. Try to stop or uninstall the process that's causing the error.",C
0x80070422,ERROR_SERVICE_DISABLED,This issue occurs when the Windows Update service stops working or isn't running.,Check whether the Windows Update service is running.,C
0x80070490,ERROR_NOT_FOUND,This error occurs during driver installation as part of the update.,"This issue occurs because details such as the architecture for a driver that's being updated are missing in the registry. Manually add the missing inf file Arch value in the Driver operations registry by following these steps: 1. Open regedit, and navigate to HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\ComponentBasedServicing\DriverOperations\0\2(SequenceID) 2. Review the Identity value to determine the value that's missing. 3. Manually add the missing value by referring to the information in the Identity value. For example, Name: Arch; Type: REG_SZ (String Value); Data: amd64. 4. Proceed with installing the failing update.",C
0x80070570,ERROR_FILE_CORRUPT,The file or directory is corrupted and unreadable. Component Store corruption,"Repair the component store by running Dism RestoreHealth, or manually repair by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device. For more information, see Troubleshoot Windows Update error 0x80070570.",C
0x800706BE,Failed to install cumulative updates,"Windows Server 2016 Std failed to install cumulative packages by using the.msu package. No error is returned. When installing the packages with dism.exe, it returned the error 0x800706be.","The last cumulative update didn't install, and it was corrupted. To resolve this issue, navigate to the registry key for the corrupted update package. Change the ""current state"" value to 000020 hex (32 dec) - resolved, or 000040 hex (64 dec) - staged, or 000070 hex (112 dec) - installed.",C
0x80070BC9,ERROR_FAIL_REBOOT_REQUIRED,The requested operation failed. Restart the system to roll back changes made.,"Make sure that you don't have any policies that control the start behavior of the Windows Installer service. This service should be managed by the operating system. The default Startup type of the Windows Installer service is Manual. Also: The TrustedInstaller service changes the startup type from Manual to Automatic if it encounters an update that has to process a transaction after a restart. If the value is reverted to Manual before the restart, the transaction can't be applied. This transaction will be pending and block all other update installations. To fix this issue, change the TrustedInstaller policy to Automatic, and restart the computer. If this change doesn't fix the issue, start the computer to WinRE to revert the pending actions. For example, dism /Image:C:\ /Cleanup-Image /RevertPendingActions. If this action also has no effect, start the computer to WinRE, rename \WinSxS\Pending.xml, and then remove the PendingXMLIdentifier from COMPONENTS Hive.",C
0x80072EE2,WININET_E_TIMEOUT,"The operation timed out. Unable to scan for updates due to a connectivity issue to Windows Update, Configuration Manager, or WSUS.","This error generally means that the Windows Update Agent was unable to connect to the update servers or your own source, such as WSUS, Configuration Manager, or Microsoft Intune. Check with your network team to ensure that the device can reach the update sources. For more info, see Troubleshoot software update scan failures in Configuration Manager. If you're using the public Microsoft update servers, check that your device can access the following Windows Update endpoints: http://windowsupdate.microsoft.com https://*.windowsupdate.microsoft.com https://update.microsoft.com https://*.update.microsoft.com https://windowsupdate.com https://*.windowsupdate.com https://download.windowsupdate.com https://*.download.windowsupdate.com https://download.microsoft.com https://*.download.windowsupdate.com https://wustat.windows.com https://*.wustat.windows.com https://ntservicepack.microsoft.com",C
0x80072EFD,TIME_OUT_ERRORS,The operation timed out,Make sure that no firewall rules or proxies block Microsoft download URLs. Take a network monitor trace to understand the situation better. <Refer to Firewall Troubleshooting scenario>,C
0x80072EFE,TIME_OUT_ERRORS,The operation timed out,"Make sure that no firewall rules or proxies block Microsoft download URLs. Take a network monitor trace to understand the situation better. <Refer to Firewall Troubleshooting scenario> Also: Encountered if BITS is broken or if the file that's being transferred can't be written to the destination folder on the client. This error is caused by connection errors while checking or downloading updates. At a command prompt, run: BITSADMIN /LIST /ALLUSERS /VERBOSE Search for the 0x80072EFE error code. You should see a reference to an HTTP code and a specific file. Using a browser, try to download the file manually. Make sure that you use your organization's proxy settings. If the download fails, work with your proxy manager to achieve successful communication. Also, check with your network team for this specific URL access.",C
0x80072F8F,WININET_E_DECODING_FAILED,Content decoding has failed. TLS 1.2 isn't configured correctly on the client.,This error generally means that the Windows Update Agent can't decode the received content. Install and configure TLS 1.2 by installing the update that's provided in KB3140245.,C
0x80073701,ERROR_SXS_ASSEMBLY_MISSING,"The referenced assembly couldn't be found. Typically, a component store corruption caused when a component is in a partially installed state.","Repair the component store by running Dism RestoreHealth command, or manually repair it by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x8007371B,ERROR_SXS_TRANSACTION_CLOSURE_INCOMPLETE,One or more required members of the transaction aren't present. Component Store corruption.,"Repair the component store by running the Dism RestoreHealth command, or manually repair it by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x800F081F,CBS_E_SOURCE_MISSING,"source for package or file not found, ResolveSource() unsuccessful. Component Store corruption","Repair the component store by running the Dism RestoreHealth command, or manually repair by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x800F0821,CBS_E_ABORT,"client abort, IDABORT returned by ICbsUIHandler method except Error(). CBS transaction timeout exceeded.","A servicing operation is taking a long time to finish. The servicing stack watchdog timer expires. Extending the timeout mitigates the issue. Increase the resources on the device. If it's a virtual machine, increase virtual CPU and memory to speed up operations. Make sure that the device has installed the update in KB4493473 or later.",C
0x800F0825,CBS_E_CANNOT_UNINSTALL,Package can't be uninstalled. Typically this error occurs because of component store corruption that was caused by a component in a partially installed state.,"Repair the component store by using the Dism RestoreHealth command, or manually repair by using a payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x800F0831,CBS_E_STORE_CORRUPTION,CBS store is corrupted. Corruption in the Windows Component Store.,"Repair the component store by runnning Dism RestoreHealth or manually repair by using the payload from the partially installed component. In an elevated Command Prompt window, run these commands: Dism.exe /Online /Cleanup-Image /Restorehealth Sfc.exe /Scannow Restart the device.",C
0x800F0920,CBS_E_HANG_DETECTED,A failure to respond was detected while processing the operation. Subsequent error logged after getting 0x800f0821,"A servicing operation is taking a long time to finish. The servicing stack watchdog timer expires and assumes that the system stopped responding. Extending the timeout value mitigates the issue. Increase the resources on the device. If it's a virtual machine, increase virtual CPU and memory to speed up operations. Make sure that the device has update KB4493473 or later installed.",C
0x800F0922,CBS_E_INSTALLERS_FAILED,The July cumulative update failed to be installed on Windows Server 2016,"In the CBS.log, you might find that updates sometimes roll back when License and Product key tokens fail to be updated. This issue can be resolved by adding write permissions for the ""User"" and ""Network Service"" accounts to the C:\Windows\System32\spp\ folder.",C
0x80200053,BG_E_VALIDATION_FAILED,,Make sure that there are no firewalls that might filter downloads. Such filtering could cause incorrect responses to be received by the Windows Update client.,C
0x80240001,WU_E_NO_SERVICE,Windows Update Agent was unable to provide the service.,,R
0x80240002,WU_E_MAX_CAPACITY_REACHED,The maximum capacity of the service was exceeded.,,R
0x80240003,WU_E_UNKNOWN_ID,An ID can't be found.,,R
0x80240004,WU_E_NOT_INITIALIZED,The object couldn't be initialized.,,R
0x80240005,WU_E_RANGEOVERLAP,The update handler requested a byte range overlapping a previously requested range.,,R
0x80240006,WU_E_TOOMANYRANGES,The requested number of byte ranges exceeds the maximum number (2^31 - 1).,,R
0x80240007,WU_E_INVALIDINDEX,The index to a collection was invalid.,,R
0x80240008,WU_E_ITEMNOTFOUND,The key for the item queried couldn't be found.,,R
0x80240009,WU_E_OPERATIONINPROGRESS,Another conflicting operation was in progress. Some operations such as installation can't be performed twice simultaneously.,,R
0x8024000A,WU_E_COULDNOTCANCEL,Cancellation of the operation wasn't allowed.,,R
0x8024000B,WU_E_CALL_CANCELLED,Operation was canceled.,The operation was canceled by the user or service. You might also receive this error message if we can't filter the results.,C
0x8024000C,WU_E_NOOP,No operation was required.,,R
0x8024000D,WU_E_XML_MISSINGDATA,Windows Update Agent couldn't find required information in the update's XML data.,,R
0x8024000E,WU_E_XML_INVALID,Windows Update Agent found information in the update's XML data that isn't valid.,Certain drivers contain more metadata information in Update.xml. Orchestrator might interpret that condition as data that isn't valid. Make sure that you have the latest Windows Update Agent installed on the device.,C
0x8024000F,WU_E_CYCLE_DETECTED,Circular update relationships were detected in the metadata.,,R
0x80240010,WU_E_TOO_DEEP_RELATION,Update relationships too deep to evaluate were evaluated.,,R
0x80240011,WU_E_INVALID_RELATIONSHIP,An invalid update relationship was detected.,,R
0x80240012,WU_E_REG_VALUE_INVALID,An invalid registry value was read.,,R
0x80240013,WU_E_DUPLICATE_ITEM,Operation tried to add a duplicate item to a list.,,R
0x80240014,WU_E_INVALID_INSTALL_REQUESTED,Updates that are requested for install are not installable by the caller.,,W
0x80240016,WU_E_INSTALL_NOT_ALLOWED,Operation tried to install while another installation was in progress or the system was pending a mandatory restart.,,R
0x80240017,WU_E_NOT_APPLICABLE,Operation wasn't performed because there are no applicable updates.,,R
0x80240018,WU_E_NO_USERTOKEN,Operation failed because a required user token is missing.,,R
0x80240019,WU_E_EXCLUSIVE_INSTALL_CONFLICT,An exclusive update can't be installed with other updates at the same time.,,R
0x8024001A,WU_E_POLICY_NOT_SET,A policy value wasn't set.,,R
0x8024001B,WU_E_SELFUPDATE_IN_PROGRESS,The operation couldn't be performed because the Windows Update Agent is self-updating.,,R
0x8024001D,WU_E_INVALID_UPDATE,An update contains invalid metadata.,,R
0x8024001E,WU_E_SERVICE_STOP,Operation didn't complete because the service or system was being shut down.,,R
0x8024001F,WU_E_NO_CONNECTION,Operation didn't complete because the network connection was unavailable.,,R
0x80240020,WU_E_NO_INTERACTIVE_USER,The operation didn't finish because no interactive user is signed in.,"Sign in to the device to start the installation, and allow the device to restart.",C
0x80240021,WU_E_TIME_OUT,Operation didn't complete because it timed out.,,R
0x80240022,WU_E_ALL_UPDATES_FAILED,Operation failed for all the updates. Multiple root causes for this error.,The most common issue is that antivirus software is blocking access to certain folders (like SoftwareDistribution). CBS.log analysis has to determine the file or folder that's being protected.,C
0x80240023,WU_E_EULAS_DECLINED,The license terms for all updates were declined.,,R
0x80240024,WU_E_NO_UPDATE,There are no updates.,,R
0x80240025,WU_E_USER_ACCESS_DISABLED,Group Policy settings prevented access to Windows Update.,,R
0x80240026,WU_E_INVALID_UPDATE_TYPE,The type of update is invalid.,,R
0x80240027,WU_E_URL_TOO_LONG,The URL exceeded the maximum length.,,R
0x80240028,WU_E_UNINSTALL_NOT_ALLOWED,The update couldn't be uninstalled because the request didn't originate from a WSUS server.,,R
0x80240029,WU_E_INVALID_PRODUCT_LICENSE,Search may have missed some updates before there's an unlicensed application on the system.,,R
0x8024002A,WU_E_MISSING_HANDLER,A component required to detect applicable updates was missing.,,R
0x8024002B,WU_E_LEGACYSERVER,An operation didn't complete because it requires a newer version of server.,,R
0x8024002C,WU_E_BIN_SOURCE_ABSENT,A delta-compressed update couldn't be installed because it required the source.,,R
0x8024002D,WU_E_SOURCE_ABSENT,A full-file update couldn't be installed because it required the source.,,R
0x8024002E,WU_E_WU_DISABLED,Access to an unmanaged server isn't allowed.,,R
0x8024002F,WU_E_CALL_CANCELLED_BY_POLICY,Operation didn't complete because the DisableWindowsUpdateAccess policy was set.,,R
0x80240030,WU_E_INVALID_PROXY_SERVER,The format of the proxy list was invalid.,,R
0x80240031,WU_E_INVALID_FILE,The file is in the wrong format.,,R
0x80240032,WU_E_INVALID_CRITERIA,The search criteria string was invalid.,,R
0x80240033,WU_E_EULA_UNAVAILABLE,License terms couldn't be downloaded.,,R
0x80240034,WU_E_DOWNLOAD_FAILED,Update failed to download.,,R
0x80240035,WU_E_UPDATE_NOT_PROCESSED,The update wasn't processed.,,R
0x80240036,WU_E_INVALID_OPERATION,The object's current state didn't allow the operation.,,R
0x80240037,WU_E_NOT_SUPPORTED,The functionality for the operation isn't supported.,,R
0x80240038,WU_E_WINHTTP_INVALID_FILE,The downloaded file has an unexpected content type.,,R
0x80240039,WU_E_TOO_MANY_RESYNC,Agent is asked by server to resync too many times.,,R
0x80240040,WU_E_NO_SERVER_CORE_SUPPORT,WUA API method doesn't run on Server Core installation.,,R
0x80240041,WU_E_SYSPREP_IN_PROGRESS,Service isn't available while sysprep is running.,,R
0x80240042,WU_E_UNKNOWN_SERVICE,The update service is no longer registered with AU.,,R
0x80240043,WU_E_NO_UI_SUPPORT,There's no support for WUA UI.,,R
0x80240044,WU_E_PER_MACHINE_UPDATE_ACCESS_DENIED,Only administrators can perform this operation on per-computer updates.,,W
0x80240045,WU_E_UNSUPPORTED_SEARCHSCOPE,A search was attempted with a scope that is not currently supported for this type of search.,,W
0x80240046,WU_E_BAD_FILE_URL,The URL does not point to a file.,,W
0x80240047,WU_E_NOTSUPPORTED,The operation requested is not supported.,,W
0x80240048,WU_E_INVALID_NOTIFICATION_INFO,The featured update notification info returned by the server is invalid.,,W
0x80240049,WU_E_OUTOFRANGE,The data is out of range.,,W
0x8024004A,WU_E_SETUP_IN_PROGRESS,WUA operations are not available while operating system setup is running.,,W
0x8024043D,WU_E_SERVICEPROP_NOTAVAIL,The requested service property isn't available.,,R
0x80240FFF,WU_E_UNEXPECTED,An operation failed due to reasons not covered by another error code.,,R
0x80241001,WU_E_MSI_WRONG_VERSION,Search may have missed some updates because the Windows Installer is less than version 3.1.,,R
0x80241002,WU_E_MSI_NOT_CONFIGURED,Search may have missed some updates because the Windows Installer isn't configured.,,R
0x80241003,WU_E_MSP_DISABLED,Search may have missed some updates because policy has disabled Windows Installer patching.,,R
0x80241004,WU_E_MSI_WRONG_APP_CONTEXT,An update couldn't be applied because the application is installed per-user.,,R
0x80241FFF,WU_E_MSP_UNEXPECTED,Search may have missed some updates because there was a failure of the Windows Installer.,,R
0x80242000,WU_E_UH_REMOTEUNAVAILABLE,A request for a remote update handler couldn't be completed because no remote process is available.,,R
0x80242001,WU_E_UH_LOCALONLY,A request for a remote update handler couldn't be completed because the handler is local only.,,R
0x80242002,WU_E_UH_UNKNOWNHANDLER,A request for an update handler couldn't be completed because the handler couldn't be recognized.,,R
0x80242003,WU_E_UH_REMOTEALREADYACTIVE,A remote update handler couldn't be created because one already exists.,,R
0x80242004,WU_E_UH_DOESNOTSUPPORTACTION,A request for the handler to install (uninstall) an update couldn't be completed because the update doesn't support install (uninstall).,,R
0x80242005,WU_E_UH_WRONGHANDLER,An operation didn't complete because the wrong handler was specified.,,R
0x80242006,WU_E_UH_INVALIDMETADATA,A handler operation couldn't be completed because the update contains invalid metadata.,"Rename the software redistribution folder, and try to download the updates again: Rename the following folders to *.BAK: - %systemroot%\system32\catroot2 Type the following commands at a command prompt. Press ENTER after you type each command. Ren %systemroot%\SoftwareDistribution\DataStore DataStore.bak Ren %systemroot%\SoftwareDistribution\Download Download.bak Ren %systemroot%\system32\catroot2 catroot2.bak",C
0x80242007,WU_E_UH_INSTALLERHUNG,An operation couldn't be completed because the installer exceeded the time limit.,,R
0x80242008,WU_E_UH_OPERATIONCANCELLED,An operation being done by the update handler was canceled.,,R
0x80242009,WU_E_UH_BADHANDLERXML,An operation couldn't be completed because the handler-specific metadata is invalid.,,R
0x8024200A,WU_E_UH_CANREQUIREINPUT,A request to the handler to install an update couldn't be completed because the update requires user input.,,R
0x8024200B,WU_E_UH_INSTALLERFAILURE,The installer failed to install (uninstall) one or more updates.,,R
0x8024200C,WU_E_UH_FALLBACKTOSELFCONTAINED,The update handler should download self-contained content rather than delta-compressed content for the update.,,R
0x8024200D,WU_E_UH_NEEDANOTHERDOWNLOAD,The update handler didn't install the update because it needs to be downloaded again.,,R
0x8024200E,WU_E_UH_NOTIFYFAILURE,The update handler failed to send notification of the status of the install (uninstall) operation.,,R
0x8024200F,WU_E_UH_INCONSISTENT_FILE_NAMES,The file names contained in the update metadata and in the update package are inconsistent.,,R
0x80242010,WU_E_UH_FALLBACKERROR,The update handler failed to fall back to the self-contained content.,,R
0x80242011,WU_E_UH_TOOMANYDOWNLOADREQUESTS,The update handler has exceeded the maximum number of download requests.,,R
0x80242012,WU_E_UH_UNEXPECTEDCBSRESPONSE,The update handler has received an unexpected response from CBS.,,R
0x80242013,WU_E_UH_BADCBSPACKAGEID,The update metadata contains an invalid CBS package identifier.,,R
0x80242014,WU_E_UH_POSTREBOOTSTILLPENDING,The post-restart operation for the update is still in progress.,Some Windows updates require the device to be restarted. Restart the device to complete update the installation.,C
0x80242015,WU_E_UH_POSTREBOOTRESULTUNKNOWN,The result of the post-reboot operation for the update couldn't be determined.,,R
0x80242016,WU_E_UH_POSTREBOOTUNEXPECTEDSTATE,The state of the update after its post-reboot operation has completed is unexpected.,,R
0x80242017,WU_E_UH_NEW_SERVICING_STACK_REQUIRED,The OS servicing stack must be updated before this update is downloaded or installed.,,R
0x80242FFF,WU_E_UH_UNEXPECTED,An update handler error not covered by another WU_E_UH_* code.,,R
0x80243001,WU_E_INSTALLATION_RESULTS_UNKNOWN_VERSION,The results of download and installation couldn't be read from the registry due to an unrecognized data format version.,,R
0x80243002,WU_E_INSTALLATION_RESULTS_INVALID_DATA,The results of download and installation couldn't be read from the registry due to an invalid data format.,,R
0x80243003,WU_E_INSTALLATION_RESULTS_NOT_FOUND,The results of download and installation aren't available; the operation may have failed to start.,,R
0x80243004,WU_E_TRAYICON_FAILURE,A failure occurred when trying to create an icon in the taskbar notification area.,,R
0x80243FFD,WU_E_NON_UI_MODE,Unable to show UI when in non-UI mode; Windows Update client UI modules may not be installed.,,R
0x80243FFE,WU_E_WUCLTUI_UNSUPPORTED_VERSION,Unsupported version of Windows Update client UI exported functions.,,R
0x80243FFF,WU_E_AUCLIENT_UNEXPECTED,There was a user interface error not covered by another WU_E_AUCLIENT_* error code.,,R
0x80244000,WU_E_PT_SOAPCLIENT_BASE,WU_E_PT_SOAPCLIENT_* error codes map to the SOAPCLIENT_ERROR enum of the ATL Server Library.,,R
0x80244001,WU_E_PT_SOAPCLIENT_INITIALIZE,Same as SOAPCLIENT_INITIALIZE_ERROR - initialization of the SOAP client failed possibly because of an MSXML installation failure.,,R
0x80244002,WU_E_PT_SOAPCLIENT_OUTOFMEMORY,Same as SOAPCLIENT_OUTOFMEMORY - SOAP client failed because it ran out of memory.,,R
0x80244003,WU_E_PT_SOAPCLIENT_GENERATE,Same as SOAPCLIENT_GENERATE_ERROR - SOAP client failed to generate the request.,,R
0x80244004,WU_E_PT_SOAPCLIENT_CONNECT,Same as SOAPCLIENT_CONNECT_ERROR - SOAP client failed to connect to the server.,,R
0x80244005,WU_E_PT_SOAPCLIENT_SEND,Same as SOAPCLIENT_SEND_ERROR - SOAP client failed to send a message for reasons of WU_E_WINHTTP_* error codes.,,R
0x80244006,WU_E_PT_SOAPCLIENT_SERVER,Same as SOAPCLIENT_SERVER_ERROR - SOAP client failed because there was a server error.,,R
0x80244007,WU_E_PT_SOAPCLIENT_SOAPFAULT,SOAP client failed because there was a SOAP fault for reasons of WU_E_PT_SOAP_* error codes.,"This issue occurs because Windows can't renew the cookies for Windows Update. For more information to resolve the issue, see 0x80244007 error when Windows tries to scan for updates on a WSUS server.",C
0x80244008,WU_E_PT_SOAPCLIENT_PARSEFAULT,Same as SOAPCLIENT_PARSEFAULT_ERROR - SOAP client failed to parse a SOAP fault.,,R
0x80244009,WU_E_PT_SOAPCLIENT_READ,Same as SOAPCLIENT_READ_ERROR - SOAP client failed while reading the response from the server.,,R
0x8024400A,WU_E_PT_SOAPCLIENT_PARSE,Same as SOAPCLIENT_PARSE_ERROR - SOAP client failed to parse the response from the server.,,R
0x8024400B,WU_E_PT_SOAP_VERSION,Same as SOAP_E_VERSION_MISMATCH - SOAP client found an unrecognizable namespace for the SOAP envelope.,,R
0x8024400C,WU_E_PT_SOAP_MUST_UNDERSTAND,Same as SOAP_E_MUST_UNDERSTAND - SOAP client was unable to understand a header.,,R
0x8024400D,WU_E_PT_SOAP_CLIENT,Same as SOAP_E_CLIENT - SOAP client found the message was malformed; fix before resending.,,R
0x8024400E,WU_E_PT_SOAP_SERVER,Same as SOAP_E_SERVER - The SOAP message couldn't be processed due to a server error; resend later.,,R
0x8024400F,WU_E_PT_WMI_ERROR,There was an unspecified Windows Management Instrumentation (WMI) error.,,R
0x80244010,WU_E_PT_EXCEEDED_MAX_SERVER_TRIPS,The number of round trips to the server exceeded the maximum limit.,,R
0x80244011,WU_E_PT_SUS_SERVER_NOT_SET,WUServer policy value is missing in the registry.,,R
0x80244012,WU_E_PT_DOUBLE_INITIALIZATION,Initialization failed because the object was already initialized.,,R
0x80244013,WU_E_PT_INVALID_COMPUTER_NAME,The computer name couldn't be determined.,,R
0x80244015,WU_E_PT_REFRESH_CACHE_REQUIRED,The reply from the server indicates that the server was changed or the cookie was invalid; refresh the state of the internal cache and retry.,,R
0x80244016,WU_E_PT_HTTP_STATUS_BAD_REQUEST,Same as HTTP status 400 - the server couldn't process the request due to invalid syntax.,,R
0x80244017,WU_E_PT_HTTP_STATUS_DENIED,Same as HTTP status 401 - the requested resource requires user authentication.,,R
0x80244018,WU_E_PT_HTTP_STATUS_FORBIDDEN,Same as HTTP status 403 - server understood the request but declined to fulfill it.,,R
0x80244019,WU_E_PT_HTTP_STATUS_NOT_FOUND,Same as HTTP status 404 - the server can't find the requested URI (Uniform Resource Identifier).,,R
0x8024401A,WU_E_PT_HTTP_STATUS_BAD_METHOD,Same as HTTP status 405 - the HTTP method isn't allowed.,,R
0x8024401B,WU_E_PT_HTTP_STATUS_PROXY_AUTH_REQ,Same as HTTP status 407 - proxy authentication is required. Unable to authenticate through a proxy server.,"Either the Winhttp proxy or WinInet proxy settings aren't configured correctly. This error generally means that the Windows Update Agent can't connect to the update servers or your own update source, such as WSUS, Configuration Manager, or Microsoft Intune, due to a proxy error. Verify the proxy settings on the client. The Windows Update Agent uses WinHTTP to scan for available updates. When there's a proxy server between the client and the update source, the proxy settings must be configured correctly on the clients to enable them to communicate by using the source's FQDN. Check with your network and proxy teams to verify that the device can access the update source without the proxy requiring user authentication.",C
0x8024401C,WU_E_PT_HTTP_STATUS_REQUEST_TIMEOUT,Same as HTTP status 408 - the server timed out waiting for the request.,,R
0x8024401D,WU_E_PT_HTTP_STATUS_CONFLICT,Same as HTTP status 409 - the request wasn't completed due to a conflict with the current state of the resource.,,R
0x8024401E,WU_E_PT_HTTP_STATUS_GONE,Same as HTTP status 410 - requested resource is no longer available at the server.,,R
0x8024401F,WU_E_PT_HTTP_STATUS_SERVER_ERROR,Same as HTTP status 500 - an error internal to the server prevented fulfilling the request.,,R
0x80244020,WU_E_PT_HTTP_STATUS_NOT_SUPPORTED,Same as HTTP status 500 - server doesn't support the functionality required to fulfill the request.,,R
0x80244021,WU_E_PT_HTTP_STATUS_BAD_GATEWAY,Same as HTTP status 502 - the server while acting as a gateway or a proxy received an invalid response from the upstream server it accessed in attempting to fulfill the request.,,R
0x80244022,WU_E_PT_HTTP_STATUS_SERVICE_UNAVAILABLE,Same as HTTP status 503 - the service is temporarily overloaded. Unable to connect to the configured update source.,Network troubleshooting is needed to resolve the connectivity issue. Check with your network and proxy teams to verify that the device can access the update source without the proxy requiring user authentication.,C
0x80244023,WU_E_PT_HTTP_STATUS_GATEWAY_TIMEOUT,Same as HTTP status 503 - the request was timed out waiting for a gateway.,,R
0x80244024,WU_E_PT_HTTP_STATUS_VERSION_NOT_SUP,Same as HTTP status 505 - the server doesn't support the HTTP protocol version used for the request.,,R
0x80244025,WU_E_PT_FILE_LOCATIONS_CHANGED,Operation failed due to a changed file location; refresh internal state and resend.,,R
0x80244026,WU_E_PT_REGISTRATION_NOT_SUPPORTED,Operation failed because Windows Update Agent doesn't support registration with a non-WSUS server.,,R
0x80244027,WU_E_PT_NO_AUTH_PLUGINS_REQUESTED,The server returned an empty authentication information list.,,R
0x80244028,WU_E_PT_NO_AUTH_COOKIES_CREATED,Windows Update Agent was unable to create any valid authentication cookies.,,R
0x80244029,WU_E_PT_INVALID_CONFIG_PROP,A configuration property value was wrong.,,R
0x8024402A,WU_E_PT_CONFIG_PROP_MISSING,A configuration property value was missing.,,R
0x8024402B,WU_E_PT_HTTP_STATUS_NOT_MAPPED,The HTTP request couldn't be completed and the reason didn't correspond to any of the WU_E_PT_HTTP_* error codes.,,R
0x8024402C,WU_E_PT_WINHTTP_NAME_NOT_RESOLVED,Same as ERROR_WINHTTP_NAME_NOT_RESOLVED - the proxy server or target server name can't be resolved.,,R
0x8024402F,WU_E_PT_ECP_SUCCEEDED_WITH_ERRORS,External.cab file processing completed with some errors,This error might be caused by the Lightspeed Rocket for web filtering software. Add the IP addresses of the devices that you want to receive updates to the exceptions list of Lightspeed Rocket.,C
0x80244030,WU_E_PT_ECP_INIT_FAILED,The external cab processor initialization didn't complete.,,R
0x80244031,WU_E_PT_ECP_INVALID_FILE_FORMAT,The format of a metadata file was invalid.,,R
0x80244032,WU_E_PT_ECP_INVALID_METADATA,External cab processor found invalid metadata.,,R
0x80244033,WU_E_PT_ECP_FAILURE_TO_EXTRACT_DIGEST,The file digest couldn't be extracted from an external cab file.,,R
0x80244034,WU_E_PT_ECP_FAILURE_TO_DECOMPRESS_CAB_FILE,An external cab file couldn't be decompressed.,,R
0x80244035,WU_E_PT_ECP_FILE_LOCATION_ERROR,External cab processor was unable to get file locations.,,R
0x80244FFF,WU_E_PT_UNEXPECTED,A communication error not covered by another WU_E_PT_* error code.,,R
0x80245001,WU_E_REDIRECTOR_LOAD_XML,The redirector XML document couldn't be loaded into the DOM class.,,R
0x80245002,WU_E_REDIRECTOR_S_FALSE,The redirector XML document is missing some required information.,,R
0x80245003,WU_E_REDIRECTOR_ID_SMALLER,The redirectorId in the downloaded redirector cab is less than in the cached cab.,,R
0x8024502D,WU_E_PT_SAME_REDIR_ID,Windows Update Agent failed to download a redirector cabinet file with a new redirectorId value from the server during the recovery.,,R
0x8024502E,WU_E_PT_NO_MANAGED_RECOVER,A redirector recovery action didn't complete because the server is managed.,,R
0x80245FFF,WU_E_REDIRECTOR_UNEXPECTED,The redirector failed for reasons not covered by another WU_E_REDIRECTOR_* error code.,,R
0x80246001,WU_E_DM_URLNOTAVAILABLE,A download manager operation couldn't be completed because the requested file doesn't have a URL.,,R
0x80246002,WU_E_DM_INCORRECTFILEHASH,A download manager operation couldn't be completed because the file digest wasn't recognized.,,R
0x80246003,WU_E_DM_UNKNOWNALGORITHM,A download manager operation couldn't be completed because the file metadata requested an unrecognized hash algorithm.,,R
0x80246004,WU_E_DM_NEEDDOWNLOADREQUEST,An operation couldn't be completed because a download request is required from the download handler.,,R
0x80246005,WU_E_DM_NONETWORK,A download manager operation couldn't be completed because the network connection was unavailable.,,R
0x80246006,WU_E_DM_WRONGBITSVERSION,A download manager operation couldn't be completed because the version of Background Intelligent Transfer Service (BITS) is incompatible.,,R
0x80246007,WU_E_DM_NOTDOWNLOADED,The update hasn't been downloaded.,,R
0x80246008,WU_E_DM_FAILTOCONNECTTOBITS,A download manager operation failed because the download manager was unable to connect the Background Intelligent Transfer Service (BITS).,,R
0x80246009,WU_E_DM_BITSTRANSFERERROR,A download manager operation failed because there was an unspecified Background Intelligent Transfer Service (BITS) transfer error.,,R
0x8024600A,WU_E_DM_DOWNLOADLOCATIONCHANGED,A download must be restarted because the location of the source of the download has changed.,,R
0x8024600B,WU_E_DM_CONTENTCHANGED,A download must be restarted because the update content changed in a new revision.,,R
0x80246017,WU_E_DM_UNAUTHORIZED_LOCAL_USER,The download failed because the local user was denied authorization to download the content.,Ensure that the user attempting to download and install updates has been provided with sufficient privileges to install updates (Local Administrator).,C
0x80246FFF,WU_E_DM_UNEXPECTED,There was a download manager error not covered by another WU_E_DM_* error code.,,R
0x80247001,WU_E_OL_INVALID_SCANFILE,An operation couldn't be completed because the scan package was invalid.,,R
0x80247002,WU_E_OL_NEWCLIENT_REQUIRED,An operation couldn't be completed because the scan package requires a greater version of the Windows Update Agent.,,R
0x80247FFF,WU_E_OL_UNEXPECTED,Search using the scan package failed.,,R
0x80248000,WU_E_DS_SHUTDOWN,An operation failed because Windows Update Agent is shutting down.,,R
0x80248001,WU_E_DS_INUSE,An operation failed because the data store was in use.,,R
0x80248002,WU_E_DS_INVALID,The current and expected states of the data store don't match.,,R
0x80248003,WU_E_DS_TABLEMISSING,The data store is missing a table.,,R
0x80248004,WU_E_DS_TABLEINCORRECT,The data store contains a table with unexpected columns.,,R
0x80248005,WU_E_DS_INVALIDTABLENAME,A table couldn't be opened because the table isn't in the data store.,,R
0x80248006,WU_E_DS_BADVERSION,The current and expected versions of the data store don't match.,,R
0x80248007,WU_E_DS_NODATA,The information requested isn't in the data store.,,R
0x80248008,WU_E_DS_MISSINGDATA,The data store is missing required information or has a NULL in a table column that requires a non-null value.,,R
0x80248009,WU_E_DS_MISSINGREF,The data store is missing required information or has a reference to missing license terms file localized property or linked row.,,R
0x8024800A,WU_E_DS_UNKNOWNHANDLER,The update wasn't processed because its update handler couldn't be recognized.,,R
0x8024800B,WU_E_DS_CANTDELETE,The update wasn't deleted because it's still referenced by one or more services.,,R
0x8024800C,WU_E_DS_LOCKTIMEOUTEXPIRED,The data store section couldn't be locked within the allotted time.,,R
0x8024800D,WU_E_DS_NOCATEGORIES,The category wasn't added because it contains no parent categories and isn't a top-level category itself.,,R
0x8024800E,WU_E_DS_ROWEXISTS,The row wasn't added because an existing row has the same primary key.,,R
0x8024800F,WU_E_DS_STOREFILELOCKED,The data store couldn't be initialized because it was locked by another process.,,R
0x80248010,WU_E_DS_CANNOTREGISTER,The data store isn't allowed to be registered with COM in the current process.,,R
0x80248011,WU_E_DS_UNABLETOSTART,Couldn't create a data store object in another process.,,R
0x80248013,WU_E_DS_DUPLICATEUPDATEID,The server sent the same update to the client with two different revision IDs.,,R
0x80248014,WU_E_DS_UNKNOWNSERVICE,An operation didn't complete because the service isn't in the data store.,,R
0x80248015,WU_E_DS_SERVICEEXPIRED,An operation didn't complete because the registration of the service has expired.,,R
0x80248016,WU_E_DS_DECLINENOTALLOWED,A request to hide an update was declined because it's a mandatory update or because it was deployed with a deadline.,,R
0x80248017,WU_E_DS_TABLESESSIONMISMATCH,A table wasn't closed because it isn't associated with the session.,,R
0x80248018,WU_E_DS_SESSIONLOCKMISMATCH,A table wasn't closed because it isn't associated with the session.,,R
0x80248019,WU_E_DS_NEEDWINDOWSSERVICE,A request to remove the Windows Update service or to unregister it with Automatic Updates was declined because it's a built-in service and/or Automatic Updates can't fall back to another service.,,R
0x8024801A,WU_E_DS_INVALIDOPERATION,A request was declined because the operation isn't allowed.,,R
0x8024801B,WU_E_DS_SCHEMAMISMATCH,The schema of the current data store and the schema of a table in a backup XML document don't match.,,R
0x8024801C,WU_E_DS_RESETREQUIRED,The data store requires a session reset; release the session and retry with a new session.,,R
0x8024801D,WU_E_DS_IMPERSONATED,A data store operation didn't complete because it was requested with an impersonated identity.,,R
0x80248FFF,WU_E_DS_UNEXPECTED,A data store error not covered by another WU_E_DS_* code.,,R
0x80249001,WU_E_INVENTORY_PARSEFAILED,Parsing of the rule file failed.,,R
0x80249002,WU_E_INVENTORY_GET_INVENTORY_TYPE_FAILED,Failed to get the requested inventory type from the server.,,R
0x80249003,WU_E_INVENTORY_RESULT_UPLOAD_FAILED,Failed to upload inventory result to the server.,,R
0x80249004,WU_E_INVENTORY_UNEXPECTED,There was an inventory error not covered by another error code.,,R
0x80249005,WU_E_INVENTORY_WMI_ERROR,A WMI error occurred when enumerating the instances for a particular class.,,R
0x8024A000,WU_E_AU_NOSERVICE,Automatic Updates was unable to service incoming requests.,,R
0x8024A002,WU_E_AU_NONLEGACYSERVER,The old version of the Automatic Updates client has stopped because the WSUS server has been upgraded.,,R
0x8024A003,WU_E_AU_LEGACYCLIENTDISABLED,The old version of the Automatic Updates client was disabled.,,R
0x8024A004,WU_E_AU_PAUSED,Automatic Updates was unable to process incoming requests because it was paused.,,R
0x8024A005,WU_E_AU_NO_REGISTERED_SERVICE,No unmanaged service is registered with AU.,,R
0x8024A10A,USO_E_SERVICE_SHUTTING_DOWN,Indicates that the Windows Update Service is shutting down.,"This error can occur after a long time of inactivity. The system doesn't respond, causing the service to be idle and, eventually, shut down. Make sure that the system remains active, and the connections remain established to complete the installation.",C
0x8024AFFF,WU_E_AU_UNEXPECTED,An Automatic Updates error not covered by another WU_E_AU* code.,,R
0x8024C001,WU_E_DRV_PRUNED,A driver was skipped.,,R
0x8024C002,WU_E_DRV_NOPROP_OR_LEGACY,A property for the driver couldn't be found. It may not conform with required specifications.,,R
0x8024C003,WU_E_DRV_REG_MISMATCH,The registry type read for the driver doesn't match the expected type.,,R
0x8024C004,WU_E_DRV_NO_METADATA,The driver update is missing metadata.,,R
0x8024C005,WU_E_DRV_MISSING_ATTRIBUTE,The driver update is missing a required attribute.,,R
0x8024C006,WU_E_DRV_SYNC_FAILED,Driver synchronization failed.,,R
0x8024C007,WU_E_DRV_NO_PRINTER_CONTENT,Information required for the synchronization of applicable printers is missing.,,R
0x8024CFFF,WU_E_DRV_UNEXPECTED,A driver error not covered by another WU_E_DRV_* code.,,R
0x8024D001,WU_E_SETUP_INVALID_INFDATA,Windows Update Agent couldn't be updated because an INF file contains invalid information.,,R
0x8024D002,WU_E_SETUP_INVALID_IDENTDATA,Windows Update Agent couldn't be updated because the wuident.cab file contains invalid information.,,R
0x8024D003,WU_E_SETUP_ALREADY_INITIALIZED,Windows Update Agent couldn't be updated because of an internal error that caused setup initialization to be performed twice.,,R
0x8024D004,WU_E_SETUP_NOT_INITIALIZED,Windows Update Agent couldn't be updated because setup initialization never completed successfully.,,R
0x8024D005,WU_E_SETUP_SOURCE_VERSION_MISMATCH,Windows Update Agent couldn't be updated because the versions specified in the INF don't match the actual source file versions.,,R
0x8024D006,WU_E_SETUP_TARGET_VERSION_GREATER,Windows Update Agent couldn't be updated because a WUA file on the target system is newer than the corresponding source file.,,R
0x8024D007,WU_E_SETUP_REGISTRATION_FAILED,Windows Update Agent couldn't be updated because regsvr32.exe returned an error.,,R
0x8024D009,WU_E_SETUP_SKIP_UPDATE,An update to the Windows Update Agent was skipped due to a directive in the Wuident.cab file.,"You might encounter this error if WSUS isn't sending the self-update to the clients. For more information to resolve the issue, see KB920659.",C
0x8024D00A,WU_E_SETUP_UNSUPPORTED_CONFIGURATION,Windows Update Agent couldn't be updated because the current system configuration isn't supported.,,R
0x8024D00B,WU_E_SETUP_BLOCKED_CONFIGURATION,Windows Update Agent couldn't be updated because the system is configured to block the update.,,R
0x8024D00C,WU_E_SETUP_REBOOT_TO_FIX,Windows Update Agent couldn't be updated because a restart of the system is required.,,R
0x8024D00D,WU_E_SETUP_ALREADYRUNNING,Windows Update Agent setup is already running.,,R
0x8024D00E,WU_E_SETUP_REBOOTREQUIRED,Windows Update Agent setup package requires a reboot to complete installation.,,R
0x8024D00F,WU_E_SETUP_HANDLER_EXEC_FAILURE,Windows Update Agent couldn't be updated because the setup handler failed during execution.,,R
0x8024D010,WU_E_SETUP_INVALID_REGISTRY_DATA,Windows Update Agent couldn't be updated because the registry contains invalid information.,,R
0x8024D013,WU_E_SETUP_WRONG_SERVER_VERSION,Windows Update Agent couldn't be updated because the server doesn't contain update information for this version.,,R
0x8024DFFF,WU_E_SETUP_UNEXPECTED,Windows Update Agent couldn't be updated because of an error not covered by another WU_E_SETUP_* error code.,,R
0x8024E001,WU_E_EE_UNKNOWN_EXPRESSION,An expression evaluator operation couldn't be completed because an expression was unrecognized.,,R
0x8024E002,WU_E_EE_INVALID_EXPRESSION,An expression evaluator operation couldn't be completed because an expression was invalid.,,R
0x8024E003,WU_E_EE_MISSING_METADATA,An expression evaluator operation couldn't be completed because an expression contains an incorrect number of metadata nodes.,,R
0x8024E004,WU_E_EE_INVALID_VERSION,An expression evaluator operation couldn't be completed because the version of the serialized expression data is invalid.,,R
0x8024E005,WU_E_EE_NOT_INITIALIZED,The expression evaluator couldn't be initialized.,,R
0x8024E006,WU_E_EE_INVALID_ATTRIBUTEDATA,An expression evaluator operation couldn't be completed because there was an invalid attribute.,,R
0x8024E007,WU_E_EE_CLUSTER_ERROR,An expression evaluator operation couldn't be completed because the cluster state of the computer couldn't be determined.,,R
0x8024EFFF,WU_E_EE_UNEXPECTED,There was an expression evaluator error not covered by another WU_E_EE_* error code.,,R
0x8024F001,WU_E_REPORTER_EVENTCACHECORRUPT,The event cache file was defective.,,R
0x8024F002,WU_E_REPORTER_EVENTNAMESPACEPARSEFAILED,The XML in the event namespace descriptor couldn't be parsed.,,R
0x8024F003,WU_E_INVALID_EVENT,The XML in the event namespace descriptor couldn't be parsed.,,R
0x8024F004,WU_E_SERVER_BUSY,The server rejected an event because the server was too busy.,,R
0x8024FFFF,WU_E_REPORTER_UNEXPECTED,There was a reporter error not covered by another error code.,,R
0x80D02002,TIME_OUT_ERRORS,The operation timed out,Make sure that no firewall rules or proxies block Microsoft download URLs. Take a network monitor trace to understand the situation better. <Refer to Firewall Troubleshooting scenario>,C
'@ | ConvertFrom-Csv | ForEach-Object { $WUErrorTable[$_.Code] = $_ }

# Returns the MS Learn details for an error code (0x80240022, 80240022 or a signed number such as -2145124318)
function Get-WUErrorInfo {
    param([string]$Code)
    if (-not $Code) { return $null }
    $c = $Code.Trim()
    if ($c -match '^-?\d+$') { $c = '0x{0:X8}' -f [int64]$c -replace '^0xFFFFFFFF', '0x' }
    elseif ($c -match '(?:0x)?([0-9A-Fa-f]{8})') { $c = '0x' + $Matches[1].ToUpper() }
    else { return $null }
    $e = $WUErrorTable[$c]
    if ($e) {
        $link = $WUErrorSource[$e.Source]
        if ($e.Source -eq 'C') { $link += '#' + $c.ToLower() }
        return [pscustomobject]@{
            Code = $c; Message = $e.Message; Description = $e.Description
            Mitigation = if ($e.Mitigation) { $e.Mitigation } else { 'No mitigation listed on MS Learn for this code. See the link.' }
            Link = $link; Found = $true
        }
    }
    # Not on the MS Learn Windows Update pages. 0x8007xxxx is a Windows (Win32) error: use the system message.
    $sys = ''
    if ($c -match '^0x8007([0-9A-F]{4})$') {
        try { $sys = ([ComponentModel.Win32Exception][Convert]::ToInt32($Matches[1], 16)).Message } catch { }
        if ($sys -match '^Unknown error') { $sys = '' }
    }
    [pscustomobject]@{
        Code = $c; Message = ''
        Description = if ($sys) { "Not on the MS Learn Windows Update error pages. Windows system message: $sys" } else { 'Not on the MS Learn Windows Update error pages.' }
        Mitigation = 'Search MS Learn for the code (see the link).'
        Link = "https://learn.microsoft.com/search/?terms=$c"; Found = $false
    }
}
#endregion

# ---- 3b. Confirmed offers: what Windows Update on each device reported (Detect-WUFirmwareStatus.ps1) ----
# Output format: "ISSUE: <result> | Model=...; BIOS=...; EsrtVersion=...; LastCapsule=...; FwDevice=...;
#                 LastWUFirmware=...; Pending=...; RestartPending=Yes"
function ConvertFrom-DeviceCheck {
    param([string]$Text)
    $o = @{ Check = ''; Result = ''; Fields = @{} }
    if (-not $Text) { return $o }
    $head, $tail = $Text -split '\s\|\s', 2
    if ($head -match '^(OK|ISSUE):\s*(.*)$') { $o.Check = $Matches[1]; $o.Result = $Matches[2].Trim() } else { $o.Result = $head.Trim() }
    foreach ($pair in @($tail -split ';\s(?=[A-Za-z]+=)')) {
        $k, $v = $pair -split '=', 2
        if ($k -and $null -ne $v) { $o.Fields[$k.Trim()] = $v.Trim() }
    }
    $o
}

$deviceCheck = @{}   # Intune device ID -> run state
$offerScript = $null
if (-not $SkipDeviceCheck) {
    Write-Host "Reading device-reported Windows Update results (remediation matching '$OfferScriptName')..."
    try {
        $scripts = @(Get-AllPages -Uri "$beta/deviceManagement/deviceHealthScripts?`$select=id,displayName" | Where-Object { $_.displayName -like $OfferScriptName })
        $offerScript = $scripts | Sort-Object { if ($_.displayName -match 'WU.?Firmware') { 0 } else { 1 } }, displayName | Select-Object -First 1
        if (-not $offerScript) {
            Write-Warning "  No Intune remediation matches '$OfferScriptName'. Deploy Detect-WUFirmwareStatus.ps1 as a remediation, or set -OfferScriptName. Device columns will be empty."
        } else {
            Write-Host "  Using remediation: $($offerScript.displayName)"
            if ($scripts.Count -gt 1) { Write-Host "  Other matches ignored: $((@($scripts | Where-Object id -ne $offerScript.id) | ForEach-Object displayName) -join ', ')" }

            $sel = '$select=id,detectionState,lastStateUpdateDateTime,preRemediationDetectionScriptOutput,preRemediationDetectionScriptError'
            if ($single) {
                # One device at a time: its own run state for this remediation
                foreach ($dev in $devices.Values) {
                    try {
                        $st = Invoke-GraphGet -Uri "$beta/deviceManagement/deviceHealthScripts/$($offerScript.id)/deviceRunStates/$($offerScript.id):$($dev.intuneId)?$sel"
                        $deviceCheck[[string]$dev.intuneId] = $st
                    } catch { }   # 404 = the remediation has not run on this device
                }
            }
            # Full run, or single device lookup found nothing (falls back to reading every run state)
            if (-not $single -or $deviceCheck.Count -eq 0) {
                $wanted = @{}; foreach ($dev in $devices.Values) { $wanted[[string]$dev.intuneId] = $true }
                # Full run: all run states for the remediation (paged). Run state id = '<scriptId>:<intuneDeviceId>'
                $n = 0
                foreach ($st in Get-AllPages -Uri "$beta/deviceManagement/deviceHealthScripts/$($offerScript.id)/deviceRunStates?$sel&`$top=999") {
                    $mid = ([string]$st.id -split ':')[-1]
                    if ($mid -and $wanted.ContainsKey($mid)) { $deviceCheck[$mid] = $st; $n++ }
                }
                Write-Host "  Device results read: $n"
            }
        }
    } catch {
        Write-Warning "  Could not read device-reported results: $($_.Exception.Message)"
    }
}

# ---- 4. Build rows ----
$rows = New-Object System.Collections.Generic.List[object]
$policyDeviceCount = @{}
foreach ($id in $devices.Keys) {
    $dev  = $devices[$id]
    $pols = @(Get-DevicePolicies -Id $id)
    foreach ($p in $pols) { $policyDeviceCount[$p.Id] = 1 + [int]$policyDeviceCount[$p.Id] }

    # Device-reported Windows Update result
    $dc = @{ DeviceCheck = ''; DeviceResult = ''; OfferedNow = ''; LastWUFirmware = ''; FirmwarePackage = ''; RunningFirmware = ''; LastCapsule = ''; RestartPending = ''; BiosOnDevice = ''; Error = $null; Stale = $false; Issue = $false }
    if (-not $SkipDeviceCheck -and $offerScript) {
        $st = $deviceCheck[[string]$dev.intuneId]
        if (-not $st) {
            $dc.DeviceCheck = 'Not run'
        } else {
            $parsed = ConvertFrom-DeviceCheck ([string]$st.preRemediationDetectionScriptOutput)
            $when   = if ($st.lastStateUpdateDateTime) { [datetime]$st.lastStateUpdateDateTime } else { $null }
            $age    = if ($when) { [int]((Get-Date).ToUniversalTime() - $when.ToUniversalTime()).TotalDays } else { $null }
            $label  = if ($parsed.Check) { $parsed.Check } elseif ($st.preRemediationDetectionScriptError) { 'Script error' } else { [string]$st.detectionState }
            $dc.DeviceCheck     = "{0} ({1}{2})" -f $label, $(if ($when) { $when.ToString('yyyy-MM-dd') } else { 'no date' }), $(if ($null -ne $age -and $age -gt $DeviceCheckMaxAgeDays) { ", STALE $age days" } else { '' })
            $dc.DeviceResult    = if ($parsed.Result) { $parsed.Result } else { [string]$st.preRemediationDetectionScriptError }
            $dc.OfferedNow      = [string]$parsed.Fields['Pending']
            $dc.LastWUFirmware  = [string]$parsed.Fields['LastWUFirmware']
            $dc.FirmwarePackage = [string]$parsed.Fields['FwDevice']
            $dc.RunningFirmware = [string]$parsed.Fields['EsrtVersion']
            $dc.LastCapsule     = [string]$parsed.Fields['LastCapsule']
            $dc.RestartPending  = [string]$parsed.Fields['RestartPending']
            $dc.BiosOnDevice    = [string]$parsed.Fields['BIOS']
            # Error code: HResult of a failed firmware install, else any 0x8xxxxxxx code in a scan or script error
            $codeText = @($parsed.Fields['HResult'], $parsed.Fields['ScanError'], $parsed.Fields['Error'], [string]$st.preRemediationDetectionScriptError) -join ' '
            if ($codeText -match '0x[0-9A-Fa-f]{8}') { $dc.Error = Get-WUErrorInfo $Matches[0] }
            $dc.Stale           = ($null -ne $age -and $age -gt $DeviceCheckMaxAgeDays)
            $dc.Issue           = ($label -eq 'ISSUE' -or $label -eq 'Script error')
        }
    }

    # Status: device specific only. Policy membership from groups, everything else from the device itself.
    $status = if ($pols.Count -eq 0)                      { 'Not in any driver update policy' }
        elseif ($pols.Count -gt 1)                        { 'In more than one driver update policy (conflict)' }
        elseif ($SkipDeviceCheck -or -not $offerScript)   { 'In driver update policy (device not checked)' }
        elseif ($dc.DeviceCheck -eq 'Not run')            { 'In policy, device check not run' }
        elseif ($dc.Stale)                                { 'In policy, device result out of date' }
        elseif ($dc.OfferedNow)                           { 'Firmware offered, not installed' }
        elseif ($dc.Issue)                                { "Device issue: $($dc.DeviceResult)" }
        else                                              { 'Up to date (no firmware offered)' }

    $rows.Add([pscustomobject]@{
        DeviceName               = $dev.displayName
        Manufacturer             = $dev.manufacturer
        Model                    = $dev.model
        SerialNumber             = $dev.serialNumber
        PrimaryUser              = $dev.primaryUser
        LastSync                 = $dev.lastSync.ToString('yyyy-MM-dd')
        BiosVersion              = $dev.biosVersion
        BiosOnDevice             = $dc.BiosOnDevice
        Status                   = $status
        PolicyName               = (@($pols | ForEach-Object Name) -join ', ')
        ApprovalType             = (@($pols | ForEach-Object ApprovalType | Select-Object -Unique) -join ', ')
        DeviceCheck              = $dc.DeviceCheck
        DeviceResult             = $dc.DeviceResult
        OfferedNow               = $dc.OfferedNow
        LastWUFirmware           = $dc.LastWUFirmware
        FirmwarePackage          = $dc.FirmwarePackage
        RunningFirmware          = $dc.RunningFirmware
        LastCapsule              = $dc.LastCapsule
        RestartPending           = $dc.RestartPending
        NewestSeenForModel       = ''
        ErrorCode                = if ($dc.Error) { $dc.Error.Code } else { '' }
        ErrorMessage             = if ($dc.Error) { $dc.Error.Message } else { '' }
        ErrorMeaning             = if ($dc.Error) { $dc.Error.Description } else { '' }
        ErrorMitigation          = if ($dc.Error) { $dc.Error.Mitigation } else { '' }
        ErrorLink                = if ($dc.Error) { $dc.Error.Link } else { '' }
        EntraDeviceId            = $id
    })
}

# ---- 4b. Model comparison: newest firmware Windows Update delivered to the same model in this run ----
function ConvertTo-FwVersion { param([string]$Text) try { if ($Text) { [version]$Text } else { $null } } catch { $null } }
$newestByModel = @{}   # model -> @{ Version; Device }
foreach ($r in $rows) {
    $m = "$($r.Manufacturer)|$($r.Model)"
    foreach ($v in $r.FirmwarePackage, $r.RunningFirmware) {
        $ver = ConvertTo-FwVersion $v
        if ($ver -and (-not $newestByModel.ContainsKey($m) -or $ver -gt $newestByModel[$m].Version)) {
            $newestByModel[$m] = @{ Version = $ver; Device = $r.DeviceName }
        }
    }
}
foreach ($r in $rows) {
    $m = "$($r.Manufacturer)|$($r.Model)"
    if (-not $newestByModel.ContainsKey($m)) { continue }
    $best = $newestByModel[$m]
    $r.NewestSeenForModel = "$($best.Version) ($($best.Device))"
    $running = ConvertTo-FwVersion $r.RunningFirmware
    # Only overrides statuses that would otherwise look fine or unknown
    if ($running -and $running -lt $best.Version -and -not $r.OfferedNow -and
        $r.Status -in 'Up to date (no firmware offered)', 'In policy, device result out of date') {
        $r.Status = "Behind other devices of this model ($running, newest seen $($best.Version)), not offered"
    }
}

$summary = foreach ($p in $policies.Values) {
    $incNames = @($p.Include | ForEach-Object { Get-GroupName $_ })
    if ($p.AllDevices) { $incNames += 'All devices' }
    $incNames += $p.UserTargets
    [pscustomobject]@{
        PolicyName          = $p.Name
        ApprovalType        = $p.ApprovalType
        IncludeGroups       = ($incNames -join '; ')
        ExcludeGroups       = (@($p.Exclude | ForEach-Object { Get-GroupName $_ }) -join '; ')
        LiveDevicesInScope  = [int]$policyDeviceCount[$p.Id]
        InventoryEntries    = $p.InventoryCount
        InventoryReadError  = $p.InventoryError
        FirmwareApproved    = @($p.Firmware | Where-Object approvalStatus -eq 'approved').Count
        FirmwareNeedsReview = @($p.Firmware | Where-Object approvalStatus -eq 'needsReview').Count
        FirmwareDeclined    = @($p.Firmware | Where-Object approvalStatus -eq 'declined').Count
        FirmwarePaused      = @($p.Firmware | Where-Object approvalStatus -eq 'suspended').Count
        PolicyId            = $p.Id
    }
}

# ---- 5. Output ----
$f1 = Join-Path $OutputFolder "DriverPolicy-Devices_$stamp.csv"
$f2 = Join-Path $OutputFolder "DriverPolicy-Firmware_$stamp.csv"
$f3 = Join-Path $OutputFolder "DriverPolicy-PolicySummary_$stamp.csv"
$rows     | Sort-Object Status, Manufacturer, Model, DeviceName | Export-Csv -Path $f1 -NoTypeInformation -Encoding UTF8
$firmware | Sort-Object PolicyName, ApprovalStatus, Manufacturer, Name, Version | Export-Csv -Path $f2 -NoTypeInformation -Encoding UTF8
$summary  | Sort-Object PolicyName | Export-Csv -Path $f3 -NoTypeInformation -Encoding UTF8

Write-Host "`nLive devices by status:"
$rows | Group-Object Status | Sort-Object Count -Descending | Format-Table Count, Name -AutoSize | Out-String -Width 250 | Write-Host
if (-not $SkipDeviceCheck -and $offerScript) {
    Write-Host 'Device-reported Windows Update results:'
    $rows | Group-Object { if ($_.DeviceResult) { $_.DeviceResult } else { $_.DeviceCheck } } | Sort-Object Count -Descending |
        Format-Table Count, Name -AutoSize | Out-String -Width 250 | Write-Host
}
Write-Host 'Policies:'
$summary | Sort-Object PolicyName | Format-Table PolicyName, ApprovalType, LiveDevicesInScope, InventoryEntries, FirmwareApproved, FirmwareNeedsReview, FirmwareDeclined, FirmwarePaused -AutoSize | Out-String -Width 250 | Write-Host
if ($summary | Where-Object InventoryReadError) {
    Write-Warning 'One or more policies could not be read. Their firmware counts in the policy summary are incomplete. Rerun the script.'
}
Write-Host "  $f1"
Write-Host "  $f2"
Write-Host "  $f3"

# ---- Single device check: result per device ----
if ($single) {
    foreach ($r in $rows) {
        Write-Host "`n==== $($r.DeviceName) ===="
        Write-Host "  Model:          $($r.Manufacturer) $($r.Model)"
        Write-Host "  Serial / user:  $($r.SerialNumber) / $($r.PrimaryUser)"
        Write-Host "  BIOS (Intune):  $($r.BiosVersion)"
        if ($r.BiosOnDevice) { Write-Host "  BIOS (device):  $($r.BiosOnDevice)$(if ($r.BiosVersion -and $r.BiosOnDevice -ne $r.BiosVersion) { '   (Intune hardware inventory is out of date)' })" }
        if ($r.NewestSeenForModel) { Write-Host "  Newest firmware seen for this model: $($r.NewestSeenForModel)" }
        Write-Host "  Last check-in:  $($r.LastSync)"
        Write-Host "  Driver policy:  $(if ($r.PolicyName) { "$($r.PolicyName) ($($r.ApprovalType))" } else { 'None' })"
        Write-Host "  Result:         $($r.Status)"
        if (-not $SkipDeviceCheck -and $offerScript) {
            Write-Host "  ---- Reported by the device (Windows Update scan, $($offerScript.displayName)) ----"
            Write-Host "  Device check:   $($r.DeviceCheck)"
            if ($r.DeviceResult)    { Write-Host "  Device result:  $($r.DeviceResult)" }
            if ($r.ErrorCode)       { Write-Host "  Error:          $($r.ErrorCode) $($r.ErrorMessage)"; Write-Host "  Meaning:        $($r.ErrorMeaning)"; Write-Host "  Mitigation:     $($r.ErrorMitigation)"; Write-Host "  MS Learn:       $($r.ErrorLink)" }
            Write-Host "  Offered now:    $(if ($r.OfferedNow) { $r.OfferedNow } elseif ($r.DeviceCheck -like 'Not run*') { 'unknown' } else { 'none' })"
            if ($r.LastWUFirmware)  { Write-Host "  Last WU firmware: $($r.LastWUFirmware)" }
            if ($r.FirmwarePackage -or $r.RunningFirmware) { Write-Host "  Package / running firmware: $($r.FirmwarePackage) / $($r.RunningFirmware)" }
            if ($r.LastCapsule)     { Write-Host "  Last capsule:   $($r.LastCapsule)" }
            if ($r.RestartPending)  { Write-Host "  Restart pending: $($r.RestartPending)" }
        }
    }
}
