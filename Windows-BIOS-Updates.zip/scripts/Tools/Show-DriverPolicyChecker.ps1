#Requires -Version 5.1
<#
.SYNOPSIS
  Driver Policy Checker: GUI for checking BIOS and firmware approval and offers for a list of devices.

.DESCRIPTION
  Front end for Get-WUfBFirmwareOffers.ps1 (version 2.8 or later). Same look as the Entra Device Group Tool.
  1. Connect to Microsoft Graph (delegated, interactive or device code sign-in).
  2. Paste device names, or import them from CSV, TXT or XLSX.
  3. Run the check. It runs in the background, so the window stays usable, and progress shows in the log.
  4. Review the colour-coded results: driver update policy, firmware approval, and what the device itself
     reports from Windows Update (Detect-WUFirmwareStatus.ps1 remediation). Filter, copy names, export CSV.

  Graph permissions (delegated, read-only): DeviceManagementManagedDevices.Read.All,
  DeviceManagementConfiguration.Read.All, Group.Read.All, Device.Read.All

  Version 2.0: rebuilt in WPF with a navy theme (navy header, navy buttons, styled grid),
  WAM-safe sign-in and device code sign-in, XLSX import, text filter.
  Version 2.1: checks the report script version before running (needs 2.5 or later), and logs the
  report version used.
  Version 2.2: "Latest vendor firmware in policy" column removed (not model specific).
  Version 2.3: device specific only. Vendor-wide firmware columns removed. Row colour follows the new status:
  red = not found, no policy, conflict or device issue; amber = firmware offered, not installed;
  green = up to date; grey = device check not run or out of date.
  Version 2.4: BIOS (device) and BIOS (Intune) columns, Newest seen for model, and red for
  "Behind other devices of this model".

.PARAMETER TenantId
  Optional tenant ID or domain to sign in to. Can also be typed in the window.

.PARAMETER ClientId
  Optional app registration (client) ID to sign in with instead of "Microsoft Graph Command Line Tools".

.EXAMPLE
  .\Show-DriverPolicyChecker.ps1
  .\Show-DriverPolicyChecker.ps1 -TenantId contoso.onmicrosoft.com
#>
param(
    [string]$TenantId,
    [string]$ClientId
)

# ---- WPF needs a single-threaded apartment. Relaunch with -STA if needed ----
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    $exe     = (Get-Process -Id $PID).Path
    $argList = @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    if ($TenantId) { $argList += @('-TenantId', $TenantId) }
    if ($ClientId) { $argList += @('-ClientId', $ClientId) }
    Start-Process -FilePath $exe -ArgumentList $argList
    return
}

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
$ToolVersion = '2.4'

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

# ---- Console window control. WAM sign-in and device codes appear on the console window ----
if (-not ('DriverPolicyTool.NativeConsole' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace DriverPolicyTool {
    public static class NativeConsole {
        [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")]   public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [DllImport("user32.dll")]   public static extern bool SetForegroundWindow(IntPtr hWnd);
        public static void BringToFront() {
            IntPtr h = GetConsoleWindow();
            if (h != IntPtr.Zero) { ShowWindow(h, 9); SetForegroundWindow(h); }   // 9 = SW_RESTORE
        }
    }
}
'@
}

# ---- Typed row class for the grid (WPF binds to real properties more reliably than PSCustomObject) ----
if (-not ('DriverPolicyTool.CheckResult' -as [type])) {
    Add-Type -TypeDefinition @'
namespace DriverPolicyTool {
    public class CheckResult {
        public string DeviceName { get; set; }
        public string Status { get; set; }
        public string RowState { get; set; }      // Bad, Waiting, Blocked, Approved, None
        public string DeviceState { get; set; }   // Issue, Ok, Grey
        public string DeviceCheck { get; set; }
        public string DeviceResult { get; set; }
        public string OfferedNow { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public string BiosVersion { get; set; }
        public string BiosOnDevice { get; set; }
        public string NewestSeenForModel { get; set; }
        public string RunningFirmware { get; set; }
        public string FirmwarePackage { get; set; }
        public string LastWUFirmware { get; set; }
        public string LastCapsule { get; set; }
        public string RestartPending { get; set; }
        public string PolicyName { get; set; }
        public string ApprovalType { get; set; }
        public string FirmwareApproved { get; set; }
        public string FirmwareNeedsReview { get; set; }
        public string FirmwareDeclinedOrPaused { get; set; }
        public string LatestVendorFirmware { get; set; }
        public string WaitingForApproval { get; set; }
        public string PrimaryUser { get; set; }
        public string LastSync { get; set; }
        public string SerialNumber { get; set; }
        public string EntraDeviceId { get; set; }
    }
}
'@
}

# ---- Settings ----
$Scopes       = @('DeviceManagementManagedDevices.Read.All', 'DeviceManagementConfiguration.Read.All', 'Group.Read.All', 'Device.Read.All')
$ReportScript = Join-Path $PSScriptRoot 'Get-WUfBFirmwareOffers.ps1'
$PreferredColumns = @('Device Name', 'DeviceName', 'Device', 'Computer Name', 'ComputerName', 'Hostname', 'Host Name', 'Name', 'displayName', 'Asset Name')
$NotFoundStatus = 'Not found in Intune (or no Entra device ID)'
$MinReportVersion = '2.8'

# ---- Logging ----
$LogDir  = Join-Path $env:LOCALAPPDATA 'DriverPolicyChecker\Logs'
New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
$LogFile = Join-Path $LogDir ('DriverPolicyChecker_{0:yyyyMMdd}.log' -f (Get-Date))

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = '{0:yyyy-MM-dd HH:mm:ss} [{1}] {2}' -f (Get-Date), $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}

#region XAML
$xamlText = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Driver Policy Checker" Height="940" Width="1320" MinHeight="740" MinWidth="1040"
        WindowStartupLocation="CenterScreen" FontFamily="Segoe UI" FontSize="12"
        Background="#F2F5FA" Foreground="#1B2A44">
  <Window.Resources>
    <!-- Colour palette -->
    <SolidColorBrush x:Key="Navy"        Color="#012D71"/>
    <SolidColorBrush x:Key="NavyHover"   Color="#0A47A0"/>
    <SolidColorBrush x:Key="NavyPressed" Color="#011E4D"/>
    <SolidColorBrush x:Key="Line"        Color="#C9D5E8"/>
    <SolidColorBrush x:Key="Tint"        Color="#E8EEF8"/>

    <!-- Primary button: navy -->
    <Style TargetType="Button">
      <Setter Property="Background" Value="{StaticResource Navy}"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="BorderBrush" Value="{StaticResource Navy}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="12,0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="4" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
      <Style.Triggers>
        <Trigger Property="IsMouseOver" Value="True">
          <Setter Property="Background" Value="{StaticResource NavyHover}"/>
          <Setter Property="BorderBrush" Value="{StaticResource NavyHover}"/>
        </Trigger>
        <Trigger Property="IsPressed" Value="True">
          <Setter Property="Background" Value="{StaticResource NavyPressed}"/>
        </Trigger>
        <Trigger Property="IsEnabled" Value="False">
          <Setter Property="Background" Value="#C3CCDA"/>
          <Setter Property="BorderBrush" Value="#C3CCDA"/>
          <Setter Property="Foreground" Value="#F4F6FA"/>
        </Trigger>
      </Style.Triggers>
    </Style>

    <!-- Secondary button: white with navy outline -->
    <Style x:Key="SecondaryButton" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}">
      <Setter Property="Background" Value="White"/>
      <Setter Property="Foreground" Value="{StaticResource Navy}"/>
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
      <Style.Triggers>
        <Trigger Property="IsMouseOver" Value="True">
          <Setter Property="Background" Value="{StaticResource Tint}"/>
          <Setter Property="BorderBrush" Value="{StaticResource Navy}"/>
        </Trigger>
        <Trigger Property="IsPressed" Value="True">
          <Setter Property="Background" Value="#D6E1F3"/>
        </Trigger>
        <Trigger Property="IsEnabled" Value="False">
          <Setter Property="Background" Value="#F4F6FA"/>
          <Setter Property="BorderBrush" Value="#DDE3EC"/>
          <Setter Property="Foreground" Value="#A9B4C6"/>
        </Trigger>
      </Style.Triggers>
    </Style>

    <Style TargetType="GroupBox">
      <Setter Property="Background" Value="White"/>
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
      <Setter Property="HeaderTemplate">
        <Setter.Value>
          <DataTemplate>
            <TextBlock Text="{Binding}" FontWeight="SemiBold" FontSize="13" Foreground="#012D71"/>
          </DataTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style TargetType="TextBox">
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
      <Setter Property="Padding" Value="4,0"/>
    </Style>

    <Style TargetType="ProgressBar">
      <Setter Property="Foreground" Value="{StaticResource Navy}"/>
      <Setter Property="Background" Value="{StaticResource Tint}"/>
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
    </Style>

    <Style TargetType="DataGrid">
      <Setter Property="Background" Value="White"/>
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
      <Setter Property="RowBackground" Value="White"/>
      <Setter Property="AlternatingRowBackground" Value="#F6F8FC"/>
      <Setter Property="HorizontalGridLinesBrush" Value="#E3E9F3"/>
      <Setter Property="VerticalGridLinesBrush" Value="#E3E9F3"/>
      <Setter Property="RowHeight" Value="24"/>
    </Style>

    <Style TargetType="DataGridColumnHeader">
      <Setter Property="Background" Value="{StaticResource Navy}"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Padding" Value="6,5"/>
      <Setter Property="BorderBrush" Value="#23488A"/>
      <Setter Property="BorderThickness" Value="0,0,1,0"/>
    </Style>

    <Style TargetType="DataGridCell">
      <Setter Property="BorderThickness" Value="0"/>
      <Style.Triggers>
        <Trigger Property="IsSelected" Value="True">
          <Setter Property="Background" Value="#CFE0F7"/>
          <Setter Property="Foreground" Value="#012D71"/>
        </Trigger>
      </Style.Triggers>
    </Style>

    <!-- Device-reported columns: text colour from what the device reported -->
    <Style x:Key="DeviceCell" TargetType="TextBlock">
      <Setter Property="Padding" Value="2,0"/>
      <Style.Triggers>
        <DataTrigger Binding="{Binding DeviceState}" Value="Issue"><Setter Property="Foreground" Value="#B3261E"/></DataTrigger>
        <DataTrigger Binding="{Binding DeviceState}" Value="Ok"><Setter Property="Foreground" Value="#1E6B2F"/></DataTrigger>
        <DataTrigger Binding="{Binding DeviceState}" Value="Grey"><Setter Property="Foreground" Value="#8090A8"/></DataTrigger>
      </Style.Triggers>
    </Style>
    <Style x:Key="OfferCell" TargetType="TextBlock" BasedOn="{StaticResource DeviceCell}">
      <Setter Property="FontWeight" Value="SemiBold"/>
    </Style>
  </Window.Resources>

  <DockPanel>
    <!-- Header bar -->
    <Border DockPanel.Dock="Top" Background="{StaticResource Navy}" Padding="18,10">
      <DockPanel>
        <TextBlock x:Name="txtVersion" DockPanel.Dock="Right" Foreground="#B9CBEA" VerticalAlignment="Center"/>
        <StackPanel VerticalAlignment="Center">
          <TextBlock Text="Driver Policy Checker" Foreground="White" FontSize="18" FontWeight="SemiBold"/>
          <TextBlock Text="BIOS and firmware: driver update policy, approval and what each device is offered" Foreground="#B9CBEA" FontSize="12"/>
        </StackPanel>
      </DockPanel>
    </Border>

    <!-- Status bar -->
    <Border DockPanel.Dock="Bottom" Background="White" BorderBrush="{StaticResource Line}" BorderThickness="0,1,0,0" Padding="12,5">
      <TextBlock x:Name="txtStatus" Foreground="#5B6B85" TextTrimming="CharacterEllipsis"/>
    </Border>

  <Grid Margin="12">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>

    <!-- Connection -->
    <DockPanel Grid.Row="0" Margin="0,0,0,8">
      <TextBlock Text="Tenant:" VerticalAlignment="Center"/>
      <TextBox x:Name="txtTenant" Width="220" Height="26" Margin="6,0,0,0" VerticalContentAlignment="Center"
               ToolTip="Tenant domain or ID. Leave blank to use your home tenant."/>
      <TextBlock Text="Sign-in:" VerticalAlignment="Center" Margin="12,0,0,0"/>
      <ComboBox x:Name="cmbAuth" Width="230" Height="26" Margin="6,0,0,0"
                ToolTip="Use device code if the interactive sign-in never appears or hangs"/>
      <Button x:Name="btnConnect" Content="Connect" Width="100" Height="28" Margin="12,0,0,0"/>
      <Button x:Name="btnDisconnect" Content="Disconnect" Width="100" Height="28" Margin="6,0,0,0" IsEnabled="False" Style="{StaticResource SecondaryButton}"/>
      <TextBlock x:Name="txtConnection" Text="Not connected" VerticalAlignment="Center" Margin="12,0,0,0" Foreground="Firebrick" TextTrimming="CharacterEllipsis"/>
    </DockPanel>

    <!-- Devices and options -->
    <GroupBox Grid.Row="1" Header="1. Devices" Padding="6" Margin="0,0,0,8">
      <Grid>
        <Grid.ColumnDefinitions>
          <ColumnDefinition Width="*"/>
          <ColumnDefinition Width="250"/>
          <ColumnDefinition Width="330"/>
        </Grid.ColumnDefinitions>
        <TextBox x:Name="txtDevices" Grid.Column="0" Height="150" AcceptsReturn="True" TextWrapping="NoWrap"
                 VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto" FontFamily="Consolas"
                 ToolTip="One per line (commas, semicolons and spaces also work). FQDNs are cut to the device name."/>
        <StackPanel Grid.Column="1" Margin="10,0,0,0">
          <Button x:Name="btnImport" Content="Import CSV / TXT / XLSX..." Height="28" Style="{StaticResource SecondaryButton}"/>
          <Button x:Name="btnClearDevices" Content="Clear list" Height="28" Margin="0,6,0,0" Style="{StaticResource SecondaryButton}"/>
          <TextBlock x:Name="txtDeviceCount" Text="0 devices in list" Margin="0,10,0,0" FontWeight="SemiBold"/>
        </StackPanel>
        <StackPanel Grid.Column="2" Margin="14,0,0,0">
          <TextBlock Text="Output folder:"/>
          <DockPanel Margin="0,3,0,0">
            <Button x:Name="btnBrowse" DockPanel.Dock="Right" Content="..." Width="34" Height="26" Margin="6,0,0,0" Style="{StaticResource SecondaryButton}"/>
            <TextBox x:Name="txtOutput" Height="26" VerticalContentAlignment="Center" Text="C:\Temp\BIOSReport"/>
          </DockPanel>
          <CheckBox x:Name="chkDevice" Content="Include what the device reports (confirmed offers)" IsChecked="True" Margin="0,10,0,0"/>
          <DockPanel Margin="18,4,0,0">
            <TextBlock Text="Remediation:" VerticalAlignment="Center"/>
            <TextBox x:Name="txtRemediation" Height="24" Margin="6,0,0,0" VerticalContentAlignment="Center" Text="*Firmware*"
                     ToolTip="Intune name of the Detect-WUFirmwareStatus.ps1 remediation. Wildcards allowed."/>
          </DockPanel>
          <CheckBox x:Name="chkDrivers" Content="Include non-firmware drivers" Margin="0,8,0,0"/>
        </StackPanel>
      </Grid>
    </GroupBox>

    <!-- Run -->
    <DockPanel Grid.Row="2" Margin="0,0,0,8">
      <Button x:Name="btnRun" Content="Run check" Width="180" Height="32" FontWeight="SemiBold" IsEnabled="False"/>
      <Button x:Name="btnCancel" Content="Cancel" Width="100" Height="32" Margin="6,0,0,0" IsEnabled="False" Style="{StaticResource SecondaryButton}"/>
      <Button x:Name="btnOpenFolder" Content="Open output folder" Width="150" Height="32" Margin="6,0,0,0" Style="{StaticResource SecondaryButton}"/>
      <TextBlock x:Name="txtProgress" DockPanel.Dock="Right" Width="300" VerticalAlignment="Center" Margin="10,0,0,0" TextAlignment="Right"/>
      <ProgressBar x:Name="pbProgress" Height="14" Margin="10,0,0,0" Minimum="0" Maximum="100"/>
    </DockPanel>

    <!-- Results -->
    <GroupBox Grid.Row="3" Header="2. Results" Padding="6" Margin="0,0,0,8">
      <DockPanel>
        <DockPanel DockPanel.Dock="Top" Margin="0,0,0,6">
          <TextBlock Text="Filter:" VerticalAlignment="Center"/>
          <Button x:Name="btnExport" DockPanel.Dock="Right" Content="Export CSV..." Width="110" Height="26" Margin="6,0,0,0" IsEnabled="False" Style="{StaticResource SecondaryButton}"/>
          <Button x:Name="btnCopy" DockPanel.Dock="Right" Content="Copy selected names" Width="150" Height="26" Margin="6,0,0,0" IsEnabled="False" Style="{StaticResource SecondaryButton}"/>
          <ComboBox x:Name="cmbStatus" DockPanel.Dock="Right" Width="340" Margin="6,0,0,0" ToolTip="Show one status only"/>
          <TextBox x:Name="txtFilter" Height="26" Margin="6,0,0,0" VerticalContentAlignment="Center"
                   ToolTip="Matches device name, model, policy, user, serial, device result or offered firmware"/>
        </DockPanel>
        <TextBlock x:Name="txtSummary" DockPanel.Dock="Top" Margin="0,0,0,6" FontWeight="SemiBold" TextWrapping="Wrap"/>
        <DataGrid x:Name="dgResults" AutoGenerateColumns="False" IsReadOnly="True" CanUserAddRows="False"
                  HeadersVisibility="Column" ClipboardCopyMode="IncludeHeader" SelectionMode="Extended"
                  EnableRowVirtualization="True" FrozenColumnCount="1">
          <DataGrid.RowStyle>
            <Style TargetType="DataGridRow">
              <Style.Triggers>
                <DataTrigger Binding="{Binding RowState}" Value="Bad"><Setter Property="Background" Value="#FDECEA"/></DataTrigger>
                <DataTrigger Binding="{Binding RowState}" Value="Waiting"><Setter Property="Background" Value="#FFF4E0"/></DataTrigger>
                <DataTrigger Binding="{Binding RowState}" Value="Blocked"><Setter Property="Background" Value="#FCE8D8"/></DataTrigger>
                <DataTrigger Binding="{Binding RowState}" Value="Approved"><Setter Property="Background" Value="#E3F4E1"/></DataTrigger>
                <DataTrigger Binding="{Binding RowState}" Value="None"><Setter Property="Background" Value="#F0F0F0"/></DataTrigger>
              </Style.Triggers>
            </Style>
          </DataGrid.RowStyle>
          <DataGrid.Columns>
            <DataGridTextColumn Header="Device" Binding="{Binding DeviceName}" Width="120"/>
            <DataGridTextColumn Header="Status" Binding="{Binding Status}" Width="260"/>
            <DataGridTextColumn Header="Device check" Binding="{Binding DeviceCheck}" Width="150" ElementStyle="{StaticResource DeviceCell}"/>
            <DataGridTextColumn Header="Device result" Binding="{Binding DeviceResult}" Width="230" ElementStyle="{StaticResource DeviceCell}"/>
            <DataGridTextColumn Header="Offered now" Binding="{Binding OfferedNow}" Width="230" ElementStyle="{StaticResource OfferCell}"/>
            <DataGridTextColumn Header="Model" Binding="{Binding Model}" Width="170"/>
            <DataGridTextColumn Header="BIOS (device)" Binding="{Binding BiosOnDevice}" Width="90"/>
            <DataGridTextColumn Header="BIOS (Intune)" Binding="{Binding BiosVersion}" Width="90"/>
            <DataGridTextColumn Header="Running firmware" Binding="{Binding RunningFirmware}" Width="110"/>
            <DataGridTextColumn Header="Firmware package" Binding="{Binding FirmwarePackage}" Width="115"/>
            <DataGridTextColumn Header="Newest seen for model" Binding="{Binding NewestSeenForModel}" Width="170"/>
            <DataGridTextColumn Header="Last WU firmware" Binding="{Binding LastWUFirmware}" Width="230"/>
            <DataGridTextColumn Header="Last capsule" Binding="{Binding LastCapsule}" Width="140"/>
            <DataGridTextColumn Header="Restart" Binding="{Binding RestartPending}" Width="60"/>
            <DataGridTextColumn Header="Driver policy" Binding="{Binding PolicyName}" Width="240"/>
            <DataGridTextColumn Header="Approval" Binding="{Binding ApprovalType}" Width="75"/>
            <DataGridTextColumn Header="Primary user" Binding="{Binding PrimaryUser}" Width="200"/>
            <DataGridTextColumn Header="Last check-in" Binding="{Binding LastSync}" Width="90"/>
            <DataGridTextColumn Header="Serial" Binding="{Binding SerialNumber}" Width="100"/>
            <DataGridTextColumn Header="Entra device ID" Binding="{Binding EntraDeviceId}" Width="250"/>
          </DataGrid.Columns>
        </DataGrid>
      </DockPanel>
    </GroupBox>

    <!-- Log -->
    <GroupBox Grid.Row="4" Header="3. Log" Padding="6">
      <TextBox x:Name="txtLog" Height="140" IsReadOnly="True" FontFamily="Consolas" FontSize="11" TextWrapping="NoWrap"
               VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto" BorderThickness="0" Background="White"/>
    </GroupBox>

  </Grid>
  </DockPanel>
</Window>
'@
#endregion

# ---- Load the window and grab every named control into $ui ----
[xml]$xaml = $xamlText
$window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$ui = @{}
foreach ($node in $xaml.SelectNodes("//*[@*[local-name()='Name']]")) {
    $name = $node.GetAttribute('Name', 'http://schemas.microsoft.com/winfx/2006/xaml')
    if ($name) { $ui[$name] = $window.FindName($name) }
}

#region Branding
$ui.txtVersion.Text = "v$ToolVersion"
#endregion

# ---- State ----
$script:Connected = $false
$script:ps        = $null   # background PowerShell instance running the report
$script:async     = $null
$script:runStart  = $null
$script:runNames  = @()
$script:infoIdx   = 0; $script:warnIdx = 0; $script:errIdx = 0
$Results = New-Object 'System.Collections.ObjectModel.ObservableCollection[object]'
$ui.dgResults.ItemsSource = $Results
$ResultsView = [System.Windows.Data.CollectionViewSource]::GetDefaultView($Results)
[void]$ui.cmbStatus.Items.Add('All')
$ui.cmbStatus.SelectedIndex = 0
$AuthInteractive = 'Interactive (Windows sign-in)'
$AuthDeviceCode  = 'Device code (code shown in console)'
[void]$ui.cmbAuth.Items.Add($AuthInteractive)
[void]$ui.cmbAuth.Items.Add($AuthDeviceCode)
$ui.cmbAuth.SelectedIndex = 0
$ui.txtTenant.Text = $TenantId

$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(300)

#region UI helpers
function Update-UI {
    $window.Dispatcher.Invoke([Action]{ }, [System.Windows.Threading.DispatcherPriority]::Background)
}

function Set-Status {
    param([string]$Text, [string]$Level = 'INFO')
    $ui.txtStatus.Text = $Text
    Write-Log $Text $Level
}

function Add-LogLine {
    param([string]$Text)
    $ui.txtLog.AppendText("$Text`r`n")
    $ui.txtLog.ScrollToEnd()
    Write-Log $Text 'RUN'
}

function Show-Message {
    param([string]$Text, [string]$Title = 'Driver Policy Checker', [string]$Icon = 'Information', [string]$Buttons = 'OK')
    [System.Windows.MessageBox]::Show($window, $Text, $Title, $Buttons, $Icon)
}

function Test-Scopes {
    $ctx = Get-MgContext
    $ctx -and -not @($Scopes | Where-Object { $ctx.Scopes -notcontains $_ }).Count
}

function Update-Buttons {
    $busy       = $null -ne $script:ps
    $hasDevices = (Get-DeviceInputList -Text $ui.txtDevices.Text).Count -gt 0
    $ui.btnConnect.IsEnabled      = -not $script:Connected -and -not $busy
    $ui.txtTenant.IsEnabled       = -not $script:Connected -and -not $busy
    $ui.cmbAuth.IsEnabled         = -not $script:Connected -and -not $busy
    $ui.btnDisconnect.IsEnabled   = $script:Connected -and -not $busy
    $ui.btnRun.IsEnabled          = $script:Connected -and $hasDevices -and -not $busy
    $ui.btnCancel.IsEnabled       = $busy
    foreach ($c in 'btnImport', 'btnClearDevices', 'txtDevices', 'txtOutput', 'btnBrowse', 'chkDevice', 'chkDrivers') { $ui[$c].IsEnabled = -not $busy }
    $ui.txtRemediation.IsEnabled  = -not $busy -and [bool]$ui.chkDevice.IsChecked
    $ui.btnExport.IsEnabled       = $Results.Count -gt 0
    $ui.btnCopy.IsEnabled         = $Results.Count -gt 0
}

# Wraps every button action: error popup, log entry
function Invoke-UiAction {
    param([scriptblock]$Action, [string]$Name)
    $window.Cursor = [System.Windows.Input.Cursors]::Wait
    try { & $Action }
    catch {
        Write-Log "$Name failed: $($_.Exception.Message)" 'ERROR'
        $ui.txtStatus.Text = "$Name failed: $($_.Exception.Message)"
        Show-Message -Text "$Name failed:`n`n$($_.Exception.Message)" -Icon 'Error' | Out-Null
    }
    finally { $window.Cursor = $null; Update-Buttons }
}
#endregion

#region Graph sign-in
# The Graph SDK runs async code and waits on it. On the WPF thread that wait can deadlock. Removing the
# synchronisation context for the duration of the call makes it resume on a pool thread instead.
function Invoke-WithoutSyncContext {
    param([scriptblock]$Script)
    $previous = [System.Threading.SynchronizationContext]::Current
    [System.Threading.SynchronizationContext]::SetSynchronizationContext($null)
    try     { & $Script }
    finally { [System.Threading.SynchronizationContext]::SetSynchronizationContext($previous) }
}

function Get-ExceptionText {
    param($ErrorRecord)
    $parts = New-Object System.Collections.Generic.List[string]
    $e = $ErrorRecord.Exception
    while ($e) {
        if ($e.Message -and -not $parts.Contains($e.Message)) { $parts.Add($e.Message) }
        $e = $e.InnerException
    }
    $parts -join ' --> '
}

function Get-SignInHint {
    param([string]$Text)
    switch -Regex ($Text) {
        'AADSTS65001|AADSTS90094|consent'                 { return 'Admin consent is needed for the "Microsoft Graph Command Line Tools" app with these permissions. Ask a Global Admin or Cloud App Admin to consent, or use your own app registration with -ClientId.' }
        'AADSTS53003|AADSTS53000|AADSTS53001|Conditional' { return 'Blocked by Conditional Access. Check the Entra sign-in logs for your account.' }
        'AADSTS50105|AADSTS500011|AADSTS700016'           { return 'The app is not available to you in this tenant. Check the enterprise app "Microsoft Graph Command Line Tools", or use -ClientId.' }
        'AADSTS50020|AADSTS90072'                         { return 'The account is not in this tenant. Check the Tenant box.' }
        'window handle|parent window|WAM|broker'          { return 'The Windows sign-in broker (WAM) could not show its prompt. Choose "Device code" in the Sign-in box and connect again.' }
        'Could not load file or assembly|Method not found|Assembly with same name' { return 'Graph module assembly conflict. Close PowerShell and run the tool again from a fresh window.' }
        'canceled|cancelled|User canceled'                { return 'Sign-in was cancelled.' }
        'timed out|timeout'                               { return 'Sign-in timed out. Try "Device code" in the Sign-in box.' }
    }
    $null
}

function Connect-Graph {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
        $ans = Show-Message -Text "The Microsoft.Graph.Authentication module is not installed.`n`nInstall it now for the current user?" -Buttons 'YesNo' -Icon 'Question'
        if ([string]$ans -ne 'Yes') { return }
        Set-Status 'Installing Microsoft.Graph.Authentication from the PowerShell Gallery...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        Install-Module -Name Microsoft.Graph.Authentication -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
    }
    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop

    $tenant     = $ui.txtTenant.Text.Trim()
    $deviceCode = [string]$ui.cmbAuth.SelectedItem -eq $AuthDeviceCode
    $p = @{ Scopes = $Scopes; ErrorAction = 'Stop' }
    if ($tenant) { $p.TenantId = $tenant }
    if ((Get-Command Connect-MgGraph).Parameters.ContainsKey('NoWelcome')) { $p.NoWelcome = $true }
    if ($ClientId) {
        $p.ClientId = $ClientId
        if (Get-Command Set-MgGraphOption -ErrorAction SilentlyContinue) { try { Set-MgGraphOption -DisableLoginByWAM $true } catch { } }
    }
    if ($deviceCode) {
        $p.UseDeviceCode = $true
        Show-Message -Text ("The PowerShell console window will come to the front with a code.`n`n" +
                            "1. Go to https://microsoft.com/devicelogin in a browser`n" +
                            "2. Enter the code from the console`n" +
                            "3. Sign in, then come back to this window") -Title 'Device code sign-in' | Out-Null
    }

    $method = if ($deviceCode) { 'device code' } else { 'interactive' }
    Set-Status "Signing in ($method). The prompt appears over the PowerShell console window..."
    $window.WindowState = 'Minimized'
    [DriverPolicyTool.NativeConsole]::BringToFront()
    try {
        Invoke-WithoutSyncContext { Connect-MgGraph @p | Out-Null }
    } catch {
        $detail = Get-ExceptionText $_
        $hint   = Get-SignInHint $detail
        Write-Log "Sign-in failed: $detail" 'ERROR'
        $text = if ($hint) { "$hint`n`nDetail: $detail" } else { $detail }
        throw (New-Object System.Exception($text, $_.Exception))
    } finally {
        $window.WindowState = 'Normal'
        $window.Activate() | Out-Null
    }
    Update-Connection
    if (-not $script:Connected) { throw 'Sign-in did not complete, or some permissions were not granted. An admin may need to consent.' }
    Set-Status "Connected as $((Get-MgContext).Account)"
}

function Update-Connection {
    $ctx = $null
    try { if (Get-Command Get-MgContext -ErrorAction SilentlyContinue) { $ctx = Get-MgContext } } catch { }
    $script:Connected = [bool]($ctx -and (Test-Scopes))
    if ($script:Connected) {
        $ui.txtConnection.Text       = "Connected as $($ctx.Account) | Tenant $($ctx.TenantId)"
        $ui.txtConnection.Foreground = 'DarkGreen'
    } elseif ($ctx) {
        $ui.txtConnection.Text       = "Signed in as $($ctx.Account), but missing permissions. Connect again."
        $ui.txtConnection.Foreground = 'Firebrick'
    } else {
        $ui.txtConnection.Text       = 'Not connected'
        $ui.txtConnection.Foreground = 'Firebrick'
    }
}

function Disconnect-Graph {
    try { Disconnect-MgGraph -ErrorAction Stop | Out-Null } catch { }
    Update-Connection
    Set-Status 'Disconnected'
}
#endregion

#region Input helpers
# Clean, de-duplicated, upper-case device names. FQDNs are cut to the host name.
function Get-DeviceInputList {
    param([string]$Text)
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $list = New-Object System.Collections.Generic.List[string]
    foreach ($raw in ($Text -split '[\r\n,;\s]+')) {
        $v = $raw.Trim().Trim('"', "'").Trim()
        if (-not $v) { continue }
        if ($v.Contains('.')) { $v = $v.Split('.')[0] }
        $v = $v.ToUpper()
        if ($seen.Add($v)) { $list.Add($v) }
    }
    , $list
}

function Read-ExcelFirstSheet {
    param([string]$Path)
    if (Get-Module -ListAvailable -Name ImportExcel) {
        Import-Module ImportExcel -ErrorAction Stop
        return @(Import-Excel -Path $Path)
    }
    $xl = $null; $wb = $null
    try {
        $xl = New-Object -ComObject Excel.Application
        $xl.Visible = $false; $xl.DisplayAlerts = $false
        $wb   = $xl.Workbooks.Open($Path, 0, $true)
        $data = $wb.Worksheets.Item(1).UsedRange.Value2
        $rowCount = $data.GetLength(0); $colCount = $data.GetLength(1)
        $headers = @(for ($c = 1; $c -le $colCount; $c++) { $h = [string]$data[1, $c]; if (-not $h) { $h = "Column$c" }; $h })
        @(for ($r = 2; $r -le $rowCount; $r++) {
            $o = [ordered]@{}
            for ($c = 1; $c -le $colCount; $c++) { $o[$headers[$c - 1]] = $data[$r, $c] }
            [pscustomobject]$o
        })
    } catch {
        throw "Could not read the Excel file. Install ImportExcel (Install-Module ImportExcel -Scope CurrentUser) or save it as CSV. Detail: $($_.Exception.Message)"
    } finally {
        if ($wb) { $wb.Close($false) }
        if ($xl) { $xl.Quit(); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($xl) }
    }
}

function Import-DeviceFile {
    param([string]$Path)
    $ext = [IO.Path]::GetExtension($Path).ToLower()
    if ($ext -eq '.txt') { return [pscustomobject]@{ Column = '(one per line)'; Values = @(Get-Content -Path $Path | Where-Object { $_.Trim() }) } }
    if ($ext -eq '.csv')              { $rows = @(Import-Csv -Path $Path) }
    elseif ($ext -in '.xlsx', '.xls') { $rows = @(Read-ExcelFirstSheet -Path $Path) }
    else                              { throw "Unsupported file type '$ext'. Use CSV, TXT or XLSX." }
    if ($rows.Count -eq 0) { throw 'The file has no data rows.' }
    $headers = @($rows[0].PSObject.Properties.Name)
    $col = $null
    foreach ($p in $PreferredColumns) { $col = $headers | Where-Object { $_ -eq $p } | Select-Object -First 1; if ($col) { break } }
    if (-not $col) { $col = $headers[0] }
    [pscustomobject]@{ Column = $col; Values = @($rows | ForEach-Object { [string]$_.$col } | Where-Object { $_.Trim() }) }
}

function Import-Devices {
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Filter = 'Device lists (*.csv;*.txt;*.xlsx;*.xls)|*.csv;*.txt;*.xlsx;*.xls|All files (*.*)|*.*'
    if (-not $dlg.ShowDialog($window)) { return }
    Set-Status "Reading $($dlg.FileName)..."
    $data = Import-DeviceFile -Path $dlg.FileName
    $existing = $ui.txtDevices.Text.TrimEnd()
    $ui.txtDevices.Text = (@($existing) + $data.Values | Where-Object { $_ }) -join "`r`n"
    Set-Status "Imported $($data.Values.Count) values from column '$($data.Column)' in $([IO.Path]::GetFileName($dlg.FileName))"
}
#endregion

#region Run and results
function Get-RowState {
    param([string]$Status)
    switch -Wildcard ($Status) {
        'Not found*'          { 'Bad'; break }
        'Not in any*'         { 'Bad'; break }
        'In more than one*'   { 'Bad'; break }
        'Device issue*'       { 'Bad'; break }
        'Behind other*'       { 'Bad'; break }
        'Firmware offered*'   { 'Waiting'; break }
        'Up to date*'         { 'Approved'; break }
        default               { 'None' }   # not run, out of date, not checked
    }
}
function Get-DeviceState {
    param([string]$Check)
    if (-not $Check) { return '' }
    if ($Check -like '*STALE*' -or $Check -like 'Not run*') { return 'Grey' }
    if ($Check -like 'ISSUE*' -or $Check -like 'Script error*') { return 'Issue' }
    if ($Check -like 'OK*') { return 'Ok' }
    ''
}

function Start-Check {
    $names = Get-DeviceInputList -Text $ui.txtDevices.Text
    if ($names.Count -eq 0) { Show-Message -Text 'The device list is empty.' | Out-Null; return }
    if (-not (Test-Path $script:ReportScript)) {
        $dlg = New-Object Microsoft.Win32.OpenFileDialog
        $dlg.Title = 'Locate Get-WUfBFirmwareOffers.ps1'; $dlg.Filter = 'PowerShell script (*.ps1)|*.ps1'
        if (-not $dlg.ShowDialog($window)) { return }
        $script:ReportScript = $dlg.FileName
    }
    # The device columns need report 2.4 or later. Older copies ignore the extra parameters silently.
    $verLine = Select-String -Path $script:ReportScript -Pattern '^\s*Version\s+(\d+\.\d+)' -List | Select-Object -First 1
    $repVer  = if ($verLine) { [version]$verLine.Matches[0].Groups[1].Value } else { [version]'0.0' }
    if ($repVer -lt [version]$MinReportVersion) {
        Show-Message -Text ("The report script is version $repVer. This tool needs $MinReportVersion or later.`n`n" +
                            "Replace this file with the latest Get-WUfBFirmwareOffers.ps1:`n$($script:ReportScript)") -Icon 'Warning' | Out-Null
        return
    }

    Update-Connection
    if (-not $script:Connected) { Show-Message -Text 'Connect to Microsoft Graph first.' -Icon 'Warning' | Out-Null; return }

    $Results.Clear()
    $ui.txtSummary.Text = ''
    $ui.cmbStatus.Items.Clear(); [void]$ui.cmbStatus.Items.Add('All'); $ui.cmbStatus.SelectedIndex = 0
    $ui.txtLog.Clear()
    $script:runNames = @($names)
    $script:runStart = Get-Date
    $script:infoIdx = 0; $script:warnIdx = 0; $script:errIdx = 0
    Write-Log '=================================================================='
    Write-Log "Run v$ToolVersion | $($names.Count) devices | Report $($script:ReportScript)"
    Add-LogLine "Checking $($names.Count) device(s) with report v$repVer, started $($script:runStart.ToString('HH:mm:ss'))"

    # Background runspace in this process: shares the Graph sign-in, and the window stays responsive
    $iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    $iss.ExecutionPolicy = [Microsoft.PowerShell.ExecutionPolicy]::Bypass
    $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace($iss)
    $rs.ApartmentState = 'STA'
    $rs.Open()
    $script:ps = [System.Management.Automation.PowerShell]::Create()
    $script:ps.Runspace = $rs
    [void]$script:ps.AddCommand($script:ReportScript).AddParameter('DeviceName', [string[]]$names).AddParameter('OutputFolder', $ui.txtOutput.Text.Trim())
    if ($ui.chkDrivers.IsChecked) { [void]$script:ps.AddParameter('IncludeDrivers', $true) }
    if ($ui.chkDevice.IsChecked) {
        if ($ui.txtRemediation.Text.Trim()) { [void]$script:ps.AddParameter('OfferScriptName', $ui.txtRemediation.Text.Trim()) }
    } else { [void]$script:ps.AddParameter('SkipDeviceCheck', $true) }

    $ui.pbProgress.IsIndeterminate = $true
    $ui.txtProgress.Text = 'Running...'
    Set-Status "Running check for $($names.Count) device(s)..."
    $script:async = $script:ps.BeginInvoke()
    $timer.Start()
    Update-Buttons
}

function Read-RunOutput {
    $p = $script:ps
    if (-not $p) { return }
    $info = $p.Streams.Information
    while ($script:infoIdx -lt $info.Count) {
        $msg = [string]$info[$script:infoIdx].MessageData; $script:infoIdx++
        if ($msg -notmatch '^\s*$') { Add-LogLine $msg }
    }
    $warn = $p.Streams.Warning
    while ($script:warnIdx -lt $warn.Count) { Add-LogLine ("WARNING: " + $warn[$script:warnIdx].Message); $script:warnIdx++ }
    $err = $p.Streams.Error
    while ($script:errIdx -lt $err.Count) { Add-LogLine ("ERROR: " + $err[$script:errIdx].ToString()); $script:errIdx++ }
}

function Complete-Check {
    $timer.Stop()
    $p = $script:ps
    try { [void]$p.EndInvoke($script:async) }
    catch { Add-LogLine "ERROR: $(Get-ExceptionText $_)" }
    finally {
        Read-RunOutput
        try { $p.Runspace.Close(); $p.Runspace.Dispose() } catch { }
        $p.Dispose(); $script:ps = $null
        $ui.pbProgress.IsIndeterminate = $false
        $ui.pbProgress.Value = 100
    }

    $out = $ui.txtOutput.Text.Trim()
    $csv = Get-ChildItem -Path $out -Filter 'DriverPolicy-Devices_*.csv' -ErrorAction SilentlyContinue |
           Where-Object { $_.LastWriteTime -ge $script:runStart.AddSeconds(-2) } |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $rows = if ($csv) { @(Import-Csv -Path $csv.FullName) } else { @() }

    $found = @{}
    foreach ($r in $rows) {
        $item = New-Object DriverPolicyTool.CheckResult
        foreach ($prop in $item.PSObject.Properties.Name) {
            if ($r.PSObject.Properties[$prop]) { $item.$prop = [string]$r.$prop }
        }
        $item.RowState    = Get-RowState $item.Status
        $item.DeviceState = Get-DeviceState $item.DeviceCheck
        $Results.Add($item)
        $found[([string]$item.DeviceName).ToUpper()] = $true
    }
    foreach ($n in $script:runNames) {
        if (-not $found.ContainsKey($n)) {
            $item = New-Object DriverPolicyTool.CheckResult
            $item.DeviceName = $n; $item.Status = $NotFoundStatus; $item.RowState = 'Bad'
            $Results.Add($item)
        }
    }

    # Status filter list, with counts
    $groups = @($Results | Group-Object Status | Sort-Object Count -Descending)
    foreach ($g in $groups) { [void]$ui.cmbStatus.Items.Add($g.Name) }
    $ui.txtSummary.Text = "$($Results.Count) devices  |  " + (($groups | ForEach-Object { "$($_.Name): $($_.Count)" }) -join '  |  ')

    $took = [int]((Get-Date) - $script:runStart).TotalSeconds
    $ui.txtProgress.Text = "Done in $took s"
    if ($csv) { Set-Status "Finished in $took s. Results: $($csv.FullName)" }
    else      { Set-Status "Finished in $took s with no results file. None of the devices were found in Intune, or the run failed (see the log)." 'WARN' }
    $ResultsView.Refresh()
    Update-Buttons
}

function Stop-Check {
    if ($script:ps) {
        Add-LogLine 'Cancelling...'
        try { $script:ps.Stop() } catch { }
    }
}

function Export-Results {
    $rows = @(foreach ($item in $ResultsView) { $item })
    if ($rows.Count -eq 0) { Show-Message -Text 'Nothing to export with the current filter.' | Out-Null; return }
    $dlg = New-Object Microsoft.Win32.SaveFileDialog
    $dlg.Filter   = 'CSV file (*.csv)|*.csv'
    $dlg.FileName = 'DriverPolicyCheck_{0:yyyyMMdd_HHmm}.csv' -f (Get-Date)
    if (Test-Path $ui.txtOutput.Text) { $dlg.InitialDirectory = $ui.txtOutput.Text }
    if (-not $dlg.ShowDialog($window)) { return }
    $rows | Select-Object DeviceName, Status, DeviceCheck, DeviceResult, OfferedNow, Manufacturer, Model, BiosOnDevice, BiosVersion,
                          RunningFirmware, FirmwarePackage, NewestSeenForModel, LastWUFirmware, LastCapsule, RestartPending, PolicyName,
                          ApprovalType, PrimaryUser, LastSync, SerialNumber, EntraDeviceId |
        Export-Csv -Path $dlg.FileName -NoTypeInformation -Encoding UTF8
    Set-Status "Exported $($rows.Count) rows to $($dlg.FileName)"
}

function Copy-SelectedNames {
    $sel = @($ui.dgResults.SelectedItems | ForEach-Object { $_.DeviceName } | Where-Object { $_ })
    if (-not $sel.Count) { $sel = @(foreach ($item in $ResultsView) { $item.DeviceName }) }
    if ($sel.Count) {
        [System.Windows.Clipboard]::SetText($sel -join "`r`n")
        Set-Status "Copied $($sel.Count) device name(s) to the clipboard"
    }
}
#endregion

#region Events
$ui.btnConnect.Add_Click({      Invoke-UiAction -Name 'Connect'    -Action { Connect-Graph } })
$ui.btnDisconnect.Add_Click({   Invoke-UiAction -Name 'Disconnect' -Action { Disconnect-Graph } })
$ui.btnImport.Add_Click({       Invoke-UiAction -Name 'Import'     -Action { Import-Devices } })
$ui.btnRun.Add_Click({          Invoke-UiAction -Name 'Run'        -Action { Start-Check } })
$ui.btnCancel.Add_Click({       Stop-Check })
$ui.btnExport.Add_Click({       Invoke-UiAction -Name 'Export'     -Action { Export-Results } })
$ui.btnCopy.Add_Click({         Copy-SelectedNames })
$ui.btnClearDevices.Add_Click({ $ui.txtDevices.Clear() })
$ui.btnBrowse.Add_Click({
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.SelectedPath = $ui.txtOutput.Text
    if ($dlg.ShowDialog() -eq 'OK') { $ui.txtOutput.Text = $dlg.SelectedPath }
})
$ui.btnOpenFolder.Add_Click({
    if (Test-Path $ui.txtOutput.Text) { Start-Process explorer.exe $ui.txtOutput.Text }
    else { Show-Message -Text 'The output folder does not exist yet. It is created on the first run.' | Out-Null }
})
$ui.chkDevice.Add_Click({ Update-Buttons })

$ui.txtDevices.Add_TextChanged({
    $ui.txtDeviceCount.Text = "$((Get-DeviceInputList -Text $ui.txtDevices.Text).Count) unique devices in list"
    Update-Buttons
})

$timer.Add_Tick({
    try {
        Read-RunOutput
        if ($script:async -and $script:async.IsCompleted) { Complete-Check }
    } catch {
        $timer.Stop()
        Write-Log "Result handling failed: $($_.Exception.Message)" 'ERROR'
        Show-Message -Text "Could not load the results:`n`n$($_.Exception.Message)" -Icon 'Error' | Out-Null
        $script:ps = $null
        $ui.pbProgress.IsIndeterminate = $false
        Update-Buttons
    }
})

# Results filter: text box plus status drop-down
$ResultsView.Filter = [Predicate[object]]{
    param($item)
    $status = [string]$ui.cmbStatus.SelectedItem
    if ($status -and $status -ne 'All' -and $item.Status -ne $status) { return $false }
    $t = $ui.txtFilter.Text.Trim()
    if (-not $t) { return $true }
    foreach ($v in $item.DeviceName, $item.Model, $item.PolicyName, $item.PrimaryUser, $item.SerialNumber, $item.DeviceResult, $item.OfferedNow) {
        if ($v -and $v.IndexOf($t, [StringComparison]::OrdinalIgnoreCase) -ge 0) { return $true }
    }
    $false
}
$ui.txtFilter.Add_TextChanged({ $ResultsView.Refresh() })
$ui.cmbStatus.Add_SelectionChanged({ $ResultsView.Refresh() })

$window.Add_Closing({
    param($s, $e)
    if ($script:ps) {
        $ans = Show-Message -Text 'A check is still running. Stop it and close?' -Buttons 'YesNo' -Icon 'Question'
        if ([string]$ans -ne 'Yes') { $e.Cancel = $true; return }
        try { $script:ps.Stop() } catch { }
    }
    $timer.Stop()
})
#endregion

# ---- If already signed in to Graph in this session, reuse it ----
try { Import-Module Microsoft.Graph.Authentication -ErrorAction SilentlyContinue } catch { }
Update-Connection

Write-Log "Tool v$ToolVersion opened by $env:USERNAME on $env:COMPUTERNAME"
$ui.txtStatus.Text = "Report script: $ReportScript  |  Log: $LogFile"
Add-LogLine 'Connect, paste or import device names, then select Run check.'
Update-Buttons
$window.ShowDialog() | Out-Null
