#Requires -Version 5.1
<#
.SYNOPSIS
  GUI tool that adds devices to an Entra ID security group in bulk.

.DESCRIPTION
  1. Connect to Microsoft Graph (delegated, interactive sign-in).
  2. Search for the target group by name (or paste its object ID) and select it.
  3. Paste device names, FQDNs or Entra device IDs, or import them from CSV, TXT or XLSX.
  4. Run as a dry run first (resolve only), then for real.
  5. Review the colour-coded results, filter them, export them to CSV.

  Uses only the Microsoft.Graph.Authentication module (Invoke-MgGraphRequest), so there are
  no version clashes with the larger Graph SDK modules.

  Graph permissions (delegated): Group.Read.All, Device.Read.All, GroupMember.ReadWrite.All
  The signed-in account also needs a role that can manage the group (for example Groups
  Administrator or Intune Administrator) or be an owner of the group.

.PARAMETER TenantId
  Optional tenant ID or domain to sign in to. Can also be typed in the window.

.PARAMETER ClientId
  Optional app registration (client) ID to sign in with instead of the default
  "Microsoft Graph Command Line Tools" app. Use this if your tenant blocks that app.
  With a custom ClientId the tool turns off WAM and uses the normal browser sign-in.

.EXAMPLE
  .\Add-DevicesToEntraGroup.ps1
  .\Add-DevicesToEntraGroup.ps1 -TenantId contoso.onmicrosoft.com
  .\Add-DevicesToEntraGroup.ps1 -TenantId contoso.onmicrosoft.com -ClientId 00000000-0000-0000-0000-000000000000
#>
param(
    [string]$TenantId,
    [string]$ClientId
)

# ---- WPF needs a single-threaded apartment. Relaunch with -STA if needed ----
if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    $exe     = (Get-Process -Id $PID).Path
    $argList = @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    if ($TenantId) { $argList += @('-TenantId', $TenantId) }
    if ($ClientId) { $argList += @('-ClientId', $ClientId) }
    Start-Process -FilePath $exe -ArgumentList $argList
    return
}

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
$ToolVersion = '1.2'

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

# ---- Console window control. Graph sign-in (WAM) and device codes appear on the console window,
#      so the tool brings it to the front while signing in ----
if (-not ('EntraDeviceTool.NativeConsole' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace EntraDeviceTool {
    public static class NativeConsole {
        [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")]   public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [DllImport("user32.dll")]   public static extern bool SetForegroundWindow(IntPtr hWnd);
        public static void BringToFront() {
            IntPtr h = GetConsoleWindow();
            if (h != IntPtr.Zero) { ShowWindow(h, 9); SetForegroundWindow(h); }   // 9 = SW_RESTORE
        }
    }
}
'@
}

# ---- Typed classes for the grids (WPF binds to real properties more reliably than PSCustomObject) ----
if (-not ('EntraDeviceTool.DeviceResult' -as [type])) {
    Add-Type -TypeDefinition @'
namespace EntraDeviceTool {
    public class DeviceResult {
        public string Input { get; set; }
        public string Status { get; set; }
        public string DisplayName { get; set; }
        public string ObjectId { get; set; }
        public string DeviceId { get; set; }
        public string OperatingSystem { get; set; }
        public string OSVersion { get; set; }
        public string TrustType { get; set; }
        public string Enabled { get; set; }
        public string LastSignIn { get; set; }
        public string Message { get; set; }
    }
    public class GroupInfo {
        public string Id { get; set; }
        public string DisplayName { get; set; }
        public string GroupType { get; set; }
        public string Membership { get; set; }
        public string Description { get; set; }
        public bool IsDynamic { get; set; }
        public bool IsRoleAssignable { get; set; }
    }
}
'@
}

# ---- Settings ----
$GraphBase = 'https://graph.microsoft.com/v1.0'
$Scopes    = @('Group.Read.All', 'Device.Read.All', 'GroupMember.ReadWrite.All')
$GuidRegex = '^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$'
$MaxGroupResults = 200

# Column names tried, in order, when importing a CSV or XLSX. First match wins, otherwise column 1.
$PreferredColumns = @('Device Name', 'DeviceName', 'Device', 'Computer Name', 'ComputerName', 'Hostname',
                      'Host Name', 'Name', 'displayName', 'Entra Device ID', 'Azure AD Device ID',
                      'DeviceId', 'Device ID', 'Asset Name')

$StatusList = @('All', 'Added', 'WouldAdd', 'AlreadyMember', 'NotFound', 'Duplicate', 'DuplicateInput', 'Failed')

# ---- Logging ----
$LogDir  = Join-Path $env:LOCALAPPDATA 'EntraDeviceGroupTool\Logs'
New-Item -Path $LogDir -ItemType Directory -Force | Out-Null
$LogFile = Join-Path $LogDir ('EntraDeviceGroupTool_{0:yyyyMMdd}.log' -f (Get-Date))

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = '{0:yyyy-MM-dd HH:mm:ss} [{1}] {2}' -f (Get-Date), $Level, $Message
    try { Add-Content -Path $LogFile -Value $line } catch { }
}

#region XAML
$xamlText = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Entra Device Group Tool" Height="920" Width="1220" MinHeight="720" MinWidth="980"
        WindowStartupLocation="CenterScreen" FontFamily="Segoe UI" FontSize="12"
        Background="#F2F5FA" Foreground="#1B2A44">
  <Window.Resources>
    <!-- Colour palette -->
    <SolidColorBrush x:Key="Navy"        Color="#012D71"/>
    <SolidColorBrush x:Key="NavyHover"   Color="#0A47A0"/>
    <SolidColorBrush x:Key="NavyPressed" Color="#011E4D"/>
    <SolidColorBrush x:Key="Line"        Color="#C9D5E8"/>
    <SolidColorBrush x:Key="Tint"        Color="#E8EEF8"/>

    <!-- Primary button: navy -->
    <Style TargetType="Button">
      <Setter Property="Background" Value="{StaticResource Navy}"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="BorderBrush" Value="{StaticResource Navy}"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="12,0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="4" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
      <Style.Triggers>
        <Trigger Property="IsMouseOver" Value="True">
          <Setter Property="Background" Value="{StaticResource NavyHover}"/>
          <Setter Property="BorderBrush" Value="{StaticResource NavyHover}"/>
        </Trigger>
        <Trigger Property="IsPressed" Value="True">
          <Setter Property="Background" Value="{StaticResource NavyPressed}"/>
        </Trigger>
        <Trigger Property="IsEnabled" Value="False">
          <Setter Property="Background" Value="#C3CCDA"/>
          <Setter Property="BorderBrush" Value="#C3CCDA"/>
          <Setter Property="Foreground" Value="#F4F6FA"/>
        </Trigger>
      </Style.Triggers>
    </Style>

    <!-- Secondary button: white with navy outline -->
    <Style x:Key="SecondaryButton" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}">
      <Setter Property="Background" Value="White"/>
      <Setter Property="Foreground" Value="{StaticResource Navy}"/>
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
      <Style.Triggers>
        <Trigger Property="IsMouseOver" Value="True">
          <Setter Property="Background" Value="{StaticResource Tint}"/>
          <Setter Property="BorderBrush" Value="{StaticResource Navy}"/>
        </Trigger>
        <Trigger Property="IsPressed" Value="True">
          <Setter Property="Background" Value="#D6E1F3"/>
        </Trigger>
        <Trigger Property="IsEnabled" Value="False">
          <Setter Property="Background" Value="#F4F6FA"/>
          <Setter Property="BorderBrush" Value="#DDE3EC"/>
          <Setter Property="Foreground" Value="#A9B4C6"/>
        </Trigger>
      </Style.Triggers>
    </Style>

    <Style TargetType="GroupBox">
      <Setter Property="Background" Value="White"/>
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
      <Setter Property="HeaderTemplate">
        <Setter.Value>
          <DataTemplate>
            <TextBlock Text="{Binding}" FontWeight="SemiBold" FontSize="13" Foreground="#012D71"/>
          </DataTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style TargetType="TextBox">
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
      <Setter Property="Padding" Value="4,0"/>
    </Style>

    <Style TargetType="ProgressBar">
      <Setter Property="Foreground" Value="{StaticResource Navy}"/>
      <Setter Property="Background" Value="{StaticResource Tint}"/>
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
    </Style>

    <Style TargetType="DataGrid">
      <Setter Property="Background" Value="White"/>
      <Setter Property="BorderBrush" Value="{StaticResource Line}"/>
      <Setter Property="RowBackground" Value="White"/>
      <Setter Property="AlternatingRowBackground" Value="#F6F8FC"/>
      <Setter Property="HorizontalGridLinesBrush" Value="#E3E9F3"/>
      <Setter Property="VerticalGridLinesBrush" Value="#E3E9F3"/>
      <Setter Property="RowHeight" Value="24"/>
    </Style>

    <Style TargetType="DataGridColumnHeader">
      <Setter Property="Background" Value="{StaticResource Navy}"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Padding" Value="6,5"/>
      <Setter Property="BorderBrush" Value="#23488A"/>
      <Setter Property="BorderThickness" Value="0,0,1,0"/>
    </Style>

    <Style TargetType="DataGridCell">
      <Setter Property="BorderThickness" Value="0"/>
      <Style.Triggers>
        <Trigger Property="IsSelected" Value="True">
          <Setter Property="Background" Value="#CFE0F7"/>
          <Setter Property="Foreground" Value="#012D71"/>
        </Trigger>
      </Style.Triggers>
    </Style>
  </Window.Resources>

  <DockPanel>
    <!-- Header bar -->
    <Border DockPanel.Dock="Top" Background="{StaticResource Navy}" Padding="18,10">
      <DockPanel>
        <TextBlock x:Name="txtVersion" DockPanel.Dock="Right" Foreground="#B9CBEA" VerticalAlignment="Center"/>
        <StackPanel VerticalAlignment="Center">
          <TextBlock Text="Entra Device Group Tool" Foreground="White" FontSize="18" FontWeight="SemiBold"/>
          <TextBlock Text="Add devices to Entra ID security groups in bulk" Foreground="#B9CBEA" FontSize="12"/>
        </StackPanel>
      </DockPanel>
    </Border>

    <!-- Status bar -->
    <Border DockPanel.Dock="Bottom" Background="White" BorderBrush="{StaticResource Line}" BorderThickness="0,1,0,0" Padding="12,5">
      <TextBlock x:Name="txtStatus" Foreground="#5B6B85" TextTrimming="CharacterEllipsis"/>
    </Border>

  <Grid Margin="12">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
    </Grid.RowDefinitions>

    <!-- Connection -->
    <DockPanel Grid.Row="0" Margin="0,0,0,8">
      <TextBlock Text="Tenant:" VerticalAlignment="Center"/>
      <TextBox x:Name="txtTenant" Width="220" Height="26" Margin="6,0,0,0" VerticalContentAlignment="Center"
               ToolTip="Tenant domain or ID, for example contoso.onmicrosoft.com. Leave blank to use your home tenant."/>
      <TextBlock Text="Sign-in:" VerticalAlignment="Center" Margin="12,0,0,0"/>
      <ComboBox x:Name="cmbAuth" Width="230" Height="26" Margin="6,0,0,0"
                ToolTip="Use device code if the interactive sign-in never appears or hangs"/>
      <Button x:Name="btnConnect" Content="Connect" Width="100" Height="28" Margin="12,0,0,0"/>
      <Button x:Name="btnDisconnect" Content="Disconnect" Width="100" Height="28" Margin="6,0,0,0" IsEnabled="False" Style="{StaticResource SecondaryButton}"/>
      <TextBlock x:Name="txtConnection" Text="Not connected" VerticalAlignment="Center" Margin="12,0,0,0" Foreground="Firebrick" TextTrimming="CharacterEllipsis"/>
    </DockPanel>

    <!-- Group search -->
    <GroupBox Grid.Row="1" Header="1. Target group" Padding="6" Margin="0,0,0,8">
      <StackPanel>
        <DockPanel>
          <Button x:Name="btnSearch" DockPanel.Dock="Right" Content="Search" Width="90" Height="26" Margin="6,0,0,0" IsEnabled="False"/>
          <TextBox x:Name="txtGroupSearch" Height="26" VerticalContentAlignment="Center"
                   ToolTip="Start of the group name (word match), or the group object ID. Press Enter to search."/>
        </DockPanel>
        <DataGrid x:Name="dgGroups" Height="150" Margin="0,6,0,0" AutoGenerateColumns="False" IsReadOnly="True"
                  SelectionMode="Single" CanUserAddRows="False" HeadersVisibility="Column" ClipboardCopyMode="IncludeHeader">
          <DataGrid.Columns>
            <DataGridTextColumn Header="Name" Binding="{Binding DisplayName}" Width="2*"/>
            <DataGridTextColumn Header="Type" Binding="{Binding GroupType}" Width="140"/>
            <DataGridTextColumn Header="Membership" Binding="{Binding Membership}" Width="90"/>
            <DataGridTextColumn Header="Description" Binding="{Binding Description}" Width="2*"/>
            <DataGridTextColumn Header="Object ID" Binding="{Binding Id}" Width="250"/>
          </DataGrid.Columns>
        </DataGrid>
        <TextBlock x:Name="txtSelectedGroup" Margin="0,6,0,0" FontWeight="SemiBold" Text="No group selected" TextWrapping="Wrap"/>
      </StackPanel>
    </GroupBox>

    <!-- Devices -->
    <GroupBox Grid.Row="2" Header="2. Devices" Padding="6" Margin="0,0,0,8">
      <Grid>
        <Grid.ColumnDefinitions>
          <ColumnDefinition Width="*"/>
          <ColumnDefinition Width="270"/>
        </Grid.ColumnDefinitions>
        <TextBox x:Name="txtDevices" Grid.Column="0" Height="140" AcceptsReturn="True" TextWrapping="NoWrap"
                 VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto" FontFamily="Consolas"
                 ToolTip="One per line (commas and semicolons also work): device name, FQDN or Entra device ID"/>
        <StackPanel Grid.Column="1" Margin="10,0,0,0">
          <Button x:Name="btnImport" Content="Import CSV / TXT / XLSX..." Height="28" Style="{StaticResource SecondaryButton}"/>
          <Button x:Name="btnClearDevices" Content="Clear list" Height="28" Margin="0,6,0,0" Style="{StaticResource SecondaryButton}"/>
          <CheckBox x:Name="chkStripDomain" Content="Strip domain suffix (FQDN to name)" IsChecked="True" Margin="0,10,0,0"/>
          <CheckBox x:Name="chkPickLatest" Content="Duplicate names: use most recent sign-in" Margin="0,6,0,0"/>
          <CheckBox x:Name="chkDryRun" Content="Dry run (resolve only, no changes)" IsChecked="True" Margin="0,6,0,0"/>
          <TextBlock x:Name="txtDeviceCount" Text="0 devices in list" Margin="0,10,0,0"/>
        </StackPanel>
      </Grid>
    </GroupBox>

    <!-- Run -->
    <DockPanel Grid.Row="3" Margin="0,0,0,8">
      <Button x:Name="btnRun" Content="Check devices (dry run)" Width="220" Height="32" FontWeight="SemiBold" IsEnabled="False"/>
      <TextBlock x:Name="txtProgress" DockPanel.Dock="Right" Width="300" VerticalAlignment="Center" Margin="10,0,0,0" TextAlignment="Right"/>
      <ProgressBar x:Name="pbProgress" Height="14" Margin="10,0,0,0" Minimum="0" Maximum="100"/>
    </DockPanel>

    <!-- Results -->
    <GroupBox Grid.Row="4" Header="3. Results" Padding="6">
      <DockPanel>
        <DockPanel DockPanel.Dock="Top" Margin="0,0,0,6">
          <TextBlock Text="Filter:" VerticalAlignment="Center"/>
          <Button x:Name="btnExport" DockPanel.Dock="Right" Content="Export CSV..." Width="110" Height="26" Margin="6,0,0,0" IsEnabled="False" Style="{StaticResource SecondaryButton}"/>
          <ComboBox x:Name="cmbStatus" DockPanel.Dock="Right" Width="140" Margin="6,0,0,0" ToolTip="Show one status only"/>
          <TextBox x:Name="txtFilter" Height="26" Margin="6,0,0,0" VerticalContentAlignment="Center"
                   ToolTip="Matches input, name, IDs, OS or message"/>
        </DockPanel>
        <TextBlock x:Name="txtSummary" DockPanel.Dock="Top" Margin="0,0,0,6" FontWeight="SemiBold" TextWrapping="Wrap"/>
        <DataGrid x:Name="dgResults" AutoGenerateColumns="False" IsReadOnly="True" CanUserAddRows="False"
                  HeadersVisibility="Column" ClipboardCopyMode="IncludeHeader" SelectionMode="Extended">
          <DataGrid.RowStyle>
            <Style TargetType="DataGridRow">
              <Style.Triggers>
                <DataTrigger Binding="{Binding Status}" Value="Added"><Setter Property="Background" Value="#E3F4E1"/></DataTrigger>
                <DataTrigger Binding="{Binding Status}" Value="WouldAdd"><Setter Property="Background" Value="#E6F0FA"/></DataTrigger>
                <DataTrigger Binding="{Binding Status}" Value="AlreadyMember"><Setter Property="Background" Value="#F0F0F0"/></DataTrigger>
                <DataTrigger Binding="{Binding Status}" Value="NotFound"><Setter Property="Background" Value="#FDECEA"/></DataTrigger>
                <DataTrigger Binding="{Binding Status}" Value="Failed"><Setter Property="Background" Value="#FDECEA"/></DataTrigger>
                <DataTrigger Binding="{Binding Status}" Value="Duplicate"><Setter Property="Background" Value="#FFF4E0"/></DataTrigger>
                <DataTrigger Binding="{Binding Status}" Value="DuplicateInput"><Setter Property="Background" Value="#FFF4E0"/></DataTrigger>
              </Style.Triggers>
            </Style>
          </DataGrid.RowStyle>
          <DataGrid.Columns>
            <DataGridTextColumn Header="Input" Binding="{Binding Input}" Width="130"/>
            <DataGridTextColumn Header="Status" Binding="{Binding Status}" Width="105"/>
            <DataGridTextColumn Header="Entra name" Binding="{Binding DisplayName}" Width="130"/>
            <DataGridTextColumn Header="OS" Binding="{Binding OperatingSystem}" Width="80"/>
            <DataGridTextColumn Header="OS version" Binding="{Binding OSVersion}" Width="105"/>
            <DataGridTextColumn Header="Join type" Binding="{Binding TrustType}" Width="85"/>
            <DataGridTextColumn Header="Enabled" Binding="{Binding Enabled}" Width="60"/>
            <DataGridTextColumn Header="Last sign-in" Binding="{Binding LastSignIn}" Width="115"/>
            <DataGridTextColumn Header="Device ID" Binding="{Binding DeviceId}" Width="250"/>
            <DataGridTextColumn Header="Object ID" Binding="{Binding ObjectId}" Width="250"/>
            <DataGridTextColumn Header="Message" Binding="{Binding Message}" Width="*" MinWidth="200"/>
          </DataGrid.Columns>
        </DataGrid>
      </DockPanel>
    </GroupBox>

  </Grid>
  </DockPanel>
</Window>
'@
#endregion

# ---- Load the window and grab every named control into $ui ----
[xml]$xaml = $xamlText
$window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$ui = @{}
foreach ($node in $xaml.SelectNodes("//*[@*[local-name()='Name']]")) {
    $name = $node.GetAttribute('Name', 'http://schemas.microsoft.com/winfx/2006/xaml')
    if ($name) { $ui[$name] = $window.FindName($name) }
}

#region Branding
$ui.txtVersion.Text = "v$ToolVersion"
#endregion

# ---- State ----
$script:Connected     = $false
$script:SelectedGroup = $null
$script:LastRun       = $null
$GroupList = New-Object 'System.Collections.ObjectModel.ObservableCollection[object]'
$Results   = New-Object 'System.Collections.ObjectModel.ObservableCollection[object]'
$ui.dgGroups.ItemsSource  = $GroupList
$ui.dgResults.ItemsSource = $Results
$ResultsView = [System.Windows.Data.CollectionViewSource]::GetDefaultView($Results)
foreach ($s in $StatusList) { [void]$ui.cmbStatus.Items.Add($s) }
$ui.cmbStatus.SelectedIndex = 0
$AuthInteractive = 'Interactive (Windows sign-in)'
$AuthDeviceCode  = 'Device code (code shown in console)'
[void]$ui.cmbAuth.Items.Add($AuthInteractive)
[void]$ui.cmbAuth.Items.Add($AuthDeviceCode)
$ui.cmbAuth.SelectedIndex = 0
$ui.txtTenant.Text = $TenantId

#region UI helpers
# Lets WPF repaint while a long loop runs on the UI thread
function Update-UI {
    $window.Dispatcher.Invoke([Action]{ }, [System.Windows.Threading.DispatcherPriority]::Background)
}

function Wait-UI {
    param([int]$Seconds)
    $until = (Get-Date).AddSeconds($Seconds)
    while ((Get-Date) -lt $until) { Start-Sleep -Milliseconds 200; Update-UI }
}

function Set-Status {
    param([string]$Text, [string]$Level = 'INFO')
    $ui.txtStatus.Text = $Text
    Write-Log $Text $Level
    Update-UI
}

function Set-Progress {
    param([double]$Percent, [string]$Text)
    $ui.pbProgress.Value = [math]::Min(100, [math]::Max(0, $Percent))
    $ui.txtProgress.Text = $Text
    Update-UI
}

function Show-Message {
    param([string]$Text, [string]$Title = 'Entra Device Group Tool', [string]$Icon = 'Information', [string]$Buttons = 'OK')
    [System.Windows.MessageBox]::Show($window, $Text, $Title, $Buttons, $Icon)
}

function Update-Buttons {
    $hasDevices = $ui.txtDevices.Text.Trim().Length -gt 0
    $ui.btnConnect.IsEnabled    = -not $script:Connected
    $ui.txtTenant.IsEnabled     = -not $script:Connected
    $ui.cmbAuth.IsEnabled       = -not $script:Connected
    $ui.btnDisconnect.IsEnabled = $script:Connected
    $ui.btnSearch.IsEnabled     = $script:Connected
    $ui.btnImport.IsEnabled     = $true
    $ui.dgGroups.IsEnabled      = $true
    $ui.btnRun.IsEnabled        = $script:Connected -and ($null -ne $script:SelectedGroup) -and $hasDevices
    $ui.btnExport.IsEnabled     = $Results.Count -gt 0
    $ui.btnRun.Content          = if ($ui.chkDryRun.IsChecked) { 'Check devices (dry run)' } else { 'Add devices to group' }
}

function Set-Busy {
    param([bool]$Busy)
    if ($Busy) {
        foreach ($b in 'btnConnect', 'btnDisconnect', 'btnSearch', 'btnRun', 'btnImport', 'btnExport', 'dgGroups', 'txtTenant', 'cmbAuth') { $ui[$b].IsEnabled = $false }
        $window.Cursor = [System.Windows.Input.Cursors]::Wait
    } else {
        $window.Cursor = $null
        Update-Buttons
    }
    Update-UI
}

# Wraps every button action: busy state, error popup, log entry
function Invoke-UiAction {
    param([scriptblock]$Action, [string]$Name)
    Set-Busy $true
    try { & $Action }
    catch {
        Write-Log "$Name failed: $($_.Exception.Message)" 'ERROR'
        Write-Log "Stack: $($_.ScriptStackTrace)" 'ERROR'
        $ui.txtStatus.Text = "$Name failed: $($_.Exception.Message)"
        Show-Message -Text "$Name failed:`n`n$($_.Exception.Message)" -Icon 'Error' | Out-Null
    }
    finally { Set-Busy $false }
}
#endregion

#region Graph helpers
# The Graph SDK runs async code and waits on it. On the WPF thread that wait can deadlock, because
# the async code tries to resume on the same thread that is blocked waiting for it. Removing the
# synchronisation context for the duration of the call makes it resume on a pool thread instead.
function Invoke-WithoutSyncContext {
    param([scriptblock]$Script)
    $previous = [System.Threading.SynchronizationContext]::Current
    [System.Threading.SynchronizationContext]::SetSynchronizationContext($null)
    try     { & $Script }
    finally { [System.Threading.SynchronizationContext]::SetSynchronizationContext($previous) }
}

# Full message chain, so the real cause (often an inner exception) is not lost
function Get-ExceptionText {
    param($ErrorRecord)
    $parts = New-Object System.Collections.Generic.List[string]
    $e = $ErrorRecord.Exception
    while ($e) {
        if ($e.Message -and -not $parts.Contains($e.Message)) { $parts.Add($e.Message) }
        $e = $e.InnerException
    }
    $parts -join ' --> '
}

# Turns common sign-in failures into something actionable
function Get-SignInHint {
    param([string]$Text)
    switch -Regex ($Text) {
        'AADSTS65001|AADSTS90094|consent'                 { return 'Admin consent is needed for the "Microsoft Graph Command Line Tools" app with these permissions. Ask a Global Admin or Cloud App Admin to consent, or use your own app registration with -ClientId.' }
        'AADSTS53003|AADSTS53000|AADSTS53001|Conditional' { return 'Blocked by Conditional Access. The policy may require a compliant device, a specific location, or may block the Graph Command Line Tools app. Check the Entra sign-in logs for your account.' }
        'AADSTS50105|AADSTS500011|AADSTS700016'           { return 'The app is not available to you in this tenant (not assigned, or not present). Check the enterprise app "Microsoft Graph Command Line Tools", or use -ClientId with your own app registration.' }
        'AADSTS50020|AADSTS90072'                         { return 'The account is not in this tenant. Check the Tenant box, or sign in with an account from that tenant.' }
        'window handle|parent window|WAM|broker'          { return 'The Windows sign-in broker (WAM) could not show its prompt. Choose "Device code" in the Sign-in box and connect again.' }
        'Could not load file or assembly|Method not found|Assembly with same name' { return 'Graph module assembly conflict, usually with Az.Accounts or a second Graph version in the same session. Close PowerShell and run the tool again from a fresh window (the tool starts with -NoProfile).' }
        'canceled|cancelled|User canceled'                { return 'Sign-in was cancelled.' }
        'timed out|timeout'                               { return 'Sign-in timed out. Try "Device code" in the Sign-in box.' }
    }
    $null
}

function Get-GraphErrorText {
    param($ErrorRecord)
    $text = $ErrorRecord.ErrorDetails.Message
    if ($text) {
        try {
            $j = $text | ConvertFrom-Json
            if ($j.error.message) { return $j.error.message }
        } catch { }
        return $text
    }
    $ErrorRecord.Exception.Message
}

# Single Graph call with retry on throttling (429) and transient errors (503/504)
function Invoke-Graph {
    param([string]$Method = 'GET', [string]$Uri, $Body, [hashtable]$Headers = @{})
    $attempt = 0
    while ($true) {
        $attempt++
        try {
            $p = @{ Method = $Method; Uri = $Uri; Headers = $Headers; ErrorAction = 'Stop' }
            if ($null -ne $Body) {
                $p.Body        = $Body | ConvertTo-Json -Depth 10 -Compress
                $p.ContentType = 'application/json'
            }
            return Invoke-WithoutSyncContext { Invoke-MgGraphRequest @p }
        } catch {
            $msg  = Get-GraphErrorText $_
            $code = 0
            try { $code = [int]$_.Exception.Response.StatusCode } catch { }
            if (($code -in 429, 503, 504 -or $msg -match 'TooManyRequests|throttl') -and $attempt -le 4) {
                $wait = [int]([math]::Pow(2, $attempt) * 5)
                Write-Log "Throttled or transient error on $Method $Uri, waiting $wait s (attempt $attempt)" 'WARN'
                Wait-UI -Seconds $wait
                continue
            }
            throw (New-Object System.Exception($msg, $_.Exception))
        }
    }
}

# Follows @odata.nextLink until done (or MaxItems reached)
function Get-GraphAll {
    param([string]$Uri, [hashtable]$Headers = @{}, [int]$MaxItems = 0)
    $items = New-Object System.Collections.Generic.List[object]
    $next  = $Uri
    while ($next) {
        $r = Invoke-Graph -Uri $next -Headers $Headers
        foreach ($v in @($r.value)) { if ($null -ne $v) { $items.Add($v) } }
        if ($MaxItems -gt 0 -and $items.Count -ge $MaxItems) { break }
        $next = $r.'@odata.nextLink'
        Update-UI
    }
    , $items
}

# Sends up to 20 requests in one JSON batch call. Retries any that came back 429.
# Returns a hashtable: request id -> response (status, headers, body)
function Invoke-GraphBatch {
    param([object[]]$Requests)
    $out     = @{}
    $pending = @($Requests)
    for ($attempt = 1; $pending.Count -gt 0 -and $attempt -le 5; $attempt++) {
        $resp  = Invoke-Graph -Method POST -Uri "$GraphBase/`$batch" -Body @{ requests = $pending }
        $retry = @()
        $wait  = 0
        foreach ($r in @($resp.responses)) {
            if ([int]$r.status -eq 429 -and $attempt -lt 5) {
                $retry += @($pending | Where-Object { $_.id -eq [string]$r.id })
                $ra = 0
                try { $ra = [int]$r.headers.'Retry-After' } catch { }
                $wait = [math]::Max($wait, [math]::Max($ra, 5))
            } else {
                $out[[string]$r.id] = $r
            }
        }
        $pending = $retry
        if ($pending.Count -gt 0) {
            Write-Log "Batch throttled, retrying $($pending.Count) requests in $wait s" 'WARN'
            Wait-UI -Seconds $wait
        }
    }
    $out
}
#endregion

#region Input helpers
# Turns the text box into a clean, de-duplicated list
function Get-DeviceInputList {
    param([string]$Text, [bool]$StripDomain)
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $list = New-Object System.Collections.Generic.List[string]
    foreach ($raw in ($Text -split '[\r\n,;]+')) {
        $v = (($raw -split "`t")[0]).Trim().Trim('"').Trim()   # pasted Excel rows: first cell only
        if (-not $v) { continue }
        if ($StripDomain -and $v -notmatch $GuidRegex -and $v.Contains('.')) { $v = $v.Split('.')[0] }
        if ($seen.Add($v)) { $list.Add($v) }
    }
    , $list
}

# First worksheet of an Excel file as objects. ImportExcel module if present, otherwise Excel itself.
function Read-ExcelFirstSheet {
    param([string]$Path)
    if (Get-Module -ListAvailable -Name ImportExcel) {
        Import-Module ImportExcel -ErrorAction Stop
        return @(Import-Excel -Path $Path)
    }
    $xl = $null
    $wb = $null
    try {
        $xl = New-Object -ComObject Excel.Application
        $xl.Visible       = $false
        $xl.DisplayAlerts = $false
        $wb   = $xl.Workbooks.Open($Path, 0, $true)
        $data = $wb.Worksheets.Item(1).UsedRange.Value2
        $rowCount = $data.GetLength(0)
        $colCount = $data.GetLength(1)
        $headers = @(for ($c = 1; $c -le $colCount; $c++) {
            $h = [string]$data[1, $c]
            if (-not $h) { $h = "Column$c" }
            $h
        })
        $rows = @(for ($r = 2; $r -le $rowCount; $r++) {
            $o = [ordered]@{}
            for ($c = 1; $c -le $colCount; $c++) { $o[$headers[$c - 1]] = $data[$r, $c] }
            [pscustomobject]$o
        })
        $rows
    } catch {
        throw "Could not read the Excel file. Install ImportExcel (Install-Module ImportExcel -Scope CurrentUser) or save it as CSV. Detail: $($_.Exception.Message)"
    } finally {
        if ($wb) { $wb.Close($false) }
        if ($xl) { $xl.Quit(); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($xl) }
    }
}

# Returns the column used and its values
function Import-DeviceFile {
    param([string]$Path)
    $ext = [IO.Path]::GetExtension($Path).ToLower()
    if ($ext -eq '.txt') {
        return [pscustomobject]@{ Column = '(one per line)'; Values = @(Get-Content -Path $Path | Where-Object { $_.Trim() }) }
    }
    if ($ext -eq '.csv')                { $rows = @(Import-Csv -Path $Path) }
    elseif ($ext -in '.xlsx', '.xls')   { $rows = @(Read-ExcelFirstSheet -Path $Path) }
    else                                { throw "Unsupported file type '$ext'. Use CSV, TXT or XLSX." }

    if ($rows.Count -eq 0) { throw 'The file has no data rows.' }
    $headers = @($rows[0].PSObject.Properties.Name)
    $col = $null
    foreach ($p in $PreferredColumns) {
        $col = $headers | Where-Object { $_ -eq $p } | Select-Object -First 1
        if ($col) { break }
    }
    if (-not $col) { $col = $headers[0] }
    $values = @($rows | ForEach-Object { [string]$_.$col } | Where-Object { $_.Trim() })
    [pscustomobject]@{ Column = $col; Values = $values }
}

function Add-ResultMessage {
    param($Result, [string]$Text)
    $Result.Message = if ($Result.Message) { "$($Result.Message). $Text" } else { $Text }
}
#endregion

#region Actions
function Connect-Graph {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
        $ans = Show-Message -Text "The Microsoft.Graph.Authentication module is not installed.`n`nInstall it now for the current user?" -Buttons 'YesNo' -Icon 'Question'
        if ([string]$ans -ne 'Yes') { return }
        Set-Status 'Installing Microsoft.Graph.Authentication from the PowerShell Gallery...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        Install-Module -Name Microsoft.Graph.Authentication -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
    }
    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
    $mod = Get-Module Microsoft.Graph.Authentication
    Write-Log "PowerShell $($PSVersionTable.PSVersion) $($PSVersionTable.PSEdition) | Microsoft.Graph.Authentication $($mod.Version) | $($mod.ModuleBase)"
    if (Get-Module Az.Accounts) { Write-Log 'Az.Accounts is loaded in this session, which can clash with the Graph module' 'WARN' }

    $tenant     = $ui.txtTenant.Text.Trim()
    $deviceCode = [string]$ui.cmbAuth.SelectedItem -eq $AuthDeviceCode
    $cmd        = Get-Command Connect-MgGraph

    $p = @{ Scopes = $Scopes; ErrorAction = 'Stop' }
    if ($tenant)   { $p.TenantId = $tenant }
    if ($cmd.Parameters.ContainsKey('NoWelcome')) { $p.NoWelcome = $true }
    if ($ClientId) {
        $p.ClientId = $ClientId
        # WAM can only be switched off when a custom app ID is used
        if (Get-Command Set-MgGraphOption -ErrorAction SilentlyContinue) {
            try { Set-MgGraphOption -DisableLoginByWAM $true; Write-Log 'WAM disabled (custom ClientId), browser sign-in' } catch { }
        }
    }
    if ($deviceCode) {
        $p.UseDeviceCode = $true
        Show-Message -Text ("The PowerShell console window will come to the front with a code.`n`n" +
                            "1. Go to https://microsoft.com/devicelogin in a browser`n" +
                            "2. Enter the code from the console`n" +
                            "3. Sign in, then come back to this window") -Title 'Device code sign-in' | Out-Null
    }

    $method = if ($deviceCode) { 'device code' } else { 'interactive' }
    Write-Log "Connecting: method $method | tenant '$tenant' | client '$(if ($ClientId) { $ClientId } else { 'default' })'"
    Set-Status "Signing in ($method). The prompt appears over the PowerShell console window..."

    # The sign-in prompt (WAM) and the device code both attach to the console window, so get this
    # window out of the way and bring the console forward until sign-in finishes
    $window.WindowState = 'Minimized'
    [EntraDeviceTool.NativeConsole]::BringToFront()
    try {
        Invoke-WithoutSyncContext { Connect-MgGraph @p | Out-Null }
    } catch {
        $detail = Get-ExceptionText $_
        $hint   = Get-SignInHint $detail
        Write-Log "Sign-in failed: $detail" 'ERROR'
        if ($hint) { Write-Log "Hint: $hint" 'ERROR' }
        $text = if ($hint) { "$hint`n`nDetail: $detail" } else { $detail }
        throw (New-Object System.Exception($text, $_.Exception))
    } finally {
        $window.WindowState = 'Normal'
        $window.Activate() | Out-Null
    }

    $ctx = Get-MgContext
    if (-not $ctx) { throw 'Sign-in did not complete (no Graph context afterwards).' }
    $script:Connected = $true
    $ui.txtConnection.Text       = "Connected as $($ctx.Account) | Tenant $($ctx.TenantId)"
    $ui.txtConnection.Foreground = 'DarkGreen'
    Set-Status "Connected as $($ctx.Account). Granted scopes: $($ctx.Scopes -join ', ')"

    if (-not ($ctx.Scopes -match '^(GroupMember|Group|Directory)\.ReadWrite\.All$')) {
        Show-Message -Text "The token has no write permission for group membership (GroupMember.ReadWrite.All).`n`nDry runs will work, adding devices will fail. An admin may need to grant consent." -Icon 'Warning' | Out-Null
    }
}

function Disconnect-Graph {
    try { Disconnect-MgGraph -ErrorAction Stop | Out-Null } catch { }
    $script:Connected     = $false
    $script:SelectedGroup = $null
    $GroupList.Clear()
    $ui.txtConnection.Text       = 'Not connected'
    $ui.txtConnection.Foreground = 'Firebrick'
    $ui.txtSelectedGroup.Text    = 'No group selected'
    Set-Status 'Disconnected'
}

function Search-Groups {
    $text = $ui.txtGroupSearch.Text.Trim()
    if (-not $text) { Show-Message -Text 'Type part of a group name, or a group object ID.' | Out-Null; return }

    $select = 'id,displayName,description,groupTypes,securityEnabled,mailEnabled,isAssignableToRole'
    Set-Status "Searching groups for '$text'..."
    if ($text -match $GuidRegex) {
        $raw = @(Invoke-Graph -Uri "$GraphBase/groups/$($text)?`$select=$select")
    } else {
        # $search does word-prefix matching and needs the ConsistencyLevel header
        $term   = [uri]::EscapeDataString("`"displayName:$($text.Replace('"', ''))`"")
        $uri    = "$GraphBase/groups?`$search=$term&`$select=$select&`$top=100&`$count=true"
        $raw    = Get-GraphAll -Uri $uri -Headers @{ ConsistencyLevel = 'eventual' } -MaxItems $MaxGroupResults
    }

    $GroupList.Clear()
    $script:SelectedGroup = $null
    $ui.txtSelectedGroup.Text = 'No group selected'
    foreach ($g in ($raw | Sort-Object { [string]$_.displayName })) {
        $types = @($g.groupTypes)
        $gi = New-Object EntraDeviceTool.GroupInfo
        $gi.Id               = [string]$g.id
        $gi.DisplayName      = [string]$g.displayName
        $gi.Description      = [string]$g.description
        $gi.IsDynamic        = $types -contains 'DynamicMembership'
        $gi.IsRoleAssignable = [bool]$g.isAssignableToRole
        $gi.Membership       = if ($gi.IsDynamic) { 'Dynamic' } else { 'Assigned' }
        $gi.GroupType = if ($types -contains 'Unified') { 'Microsoft 365' }
                        elseif ($g.securityEnabled -and $g.mailEnabled) { 'Mail-enabled security' }
                        elseif ($g.securityEnabled) { 'Security' }
                        else { 'Distribution' }
        $GroupList.Add($gi)
    }
    $more = if ($raw.Count -ge $MaxGroupResults) { " (showing the first $MaxGroupResults, refine the search)" } else { '' }
    Set-Status "$($GroupList.Count) groups found for '$text'$more"
}

function Select-Group {
    $g = $ui.dgGroups.SelectedItem
    $script:SelectedGroup = $null
    $ui.txtSelectedGroup.Foreground = '#012D71'
    if (-not $g) { $ui.txtSelectedGroup.Text = 'No group selected'; return }

    $reason = $null
    if ($g.IsDynamic)                { $reason = 'it has dynamic membership, so members come from its rule' }
    elseif ($g.GroupType -ne 'Security') { $reason = "$($g.GroupType) groups cannot hold devices or cannot be changed through Graph" }

    if ($reason) {
        $ui.txtSelectedGroup.Text       = "Cannot use '$($g.DisplayName)': $reason."
        $ui.txtSelectedGroup.Foreground = 'Firebrick'
    } else {
        $script:SelectedGroup = $g
        $note = if ($g.IsRoleAssignable) { '  (role-assignable group: needs Privileged Role Administrator or group owner to change)' } else { '' }
        $ui.txtSelectedGroup.Text = "Selected: $($g.DisplayName)  |  $($g.Id)$note"
    }
}

# Builds a result row from one batch lookup response
function New-LookupResult {
    param([string]$InputValue, $Response, [bool]$PickLatest)
    $r = New-Object EntraDeviceTool.DeviceResult
    $r.Input = $InputValue
    if (-not $Response) { $r.Status = 'Failed'; $r.Message = 'No response for this lookup'; return $r }
    if ([int]$Response.status -ne 200) {
        $r.Status  = 'Failed'
        $r.Message = "Lookup failed (HTTP $($Response.status)): $($Response.body.error.message)"
        return $r
    }

    $found = @($Response.body.value | Where-Object { $_ })
    if ($found.Count -eq 0) { $r.Status = 'NotFound'; $r.Message = 'No Entra device with this name or ID'; return $r }

    $dev = $found[0]
    if ($found.Count -gt 1) {
        if (-not $PickLatest) {
            $r.Status      = 'Duplicate'
            $r.DisplayName = [string]$dev.displayName
            $r.Message     = "$($found.Count) Entra devices share this name, skipped. Use the Entra device ID or tick 'use most recent sign-in'"
            return $r
        }
        $dev = $found | Sort-Object -Descending {
            if ($_.approximateLastSignInDateTime) { [datetime]$_.approximateLastSignInDateTime } else { [datetime]::MinValue }
        } | Select-Object -First 1
        $r.Message = "$($found.Count) devices share this name, used the most recent sign-in"
    }

    $r.DisplayName     = [string]$dev.displayName
    $r.ObjectId        = [string]$dev.id
    $r.DeviceId        = [string]$dev.deviceId
    $r.OperatingSystem = [string]$dev.operatingSystem
    $r.OSVersion       = [string]$dev.operatingSystemVersion
    $r.TrustType       = [string]$dev.trustType
    $r.Enabled         = [string]$dev.accountEnabled
    $r.LastSignIn      = if ($dev.approximateLastSignInDateTime) { ([datetime]$dev.approximateLastSignInDateTime).ToString('yyyy-MM-dd HH:mm') } else { '' }
    if ($dev.accountEnabled -eq $false) { Add-ResultMessage $r 'Device is disabled in Entra' }
    $r.Status = 'Resolved'
    $r
}

# Fallback when a bulk add fails: one at a time so each device gets its own status
function Add-SingleMember {
    param($Group, $Result)
    try {
        Invoke-Graph -Method POST -Uri "$GraphBase/groups/$($Group.Id)/members/`$ref" `
                     -Body @{ '@odata.id' = "$GraphBase/directoryObjects/$($Result.ObjectId)" } | Out-Null
        $Result.Status = 'Added'
    } catch {
        $msg = $_.Exception.Message
        if ($msg -match 'already exist') { $Result.Status = 'AlreadyMember' }
        else { $Result.Status = 'Failed'; Add-ResultMessage $Result $msg }
    }
}

function Update-Summary {
    $counts = $Results | Group-Object Status | Sort-Object Name | ForEach-Object { "$($_.Name): $($_.Count)" }
    $mode   = if ($script:LastRun -and $script:LastRun.DryRun) { 'DRY RUN  |  ' } else { '' }
    $ui.txtSummary.Text = if ($Results.Count) { "$mode$($Results.Count) inputs  |  $($counts -join '  |  ')" } else { '' }
}

function Start-Run {
    $group      = $script:SelectedGroup
    $dryRun     = [bool]$ui.chkDryRun.IsChecked
    $pickLatest = [bool]$ui.chkPickLatest.IsChecked
    $inputs     = Get-DeviceInputList -Text $ui.txtDevices.Text -StripDomain ([bool]$ui.chkStripDomain.IsChecked)
    if ($inputs.Count -eq 0) { Show-Message -Text 'The device list is empty.' | Out-Null; return }

    if (-not $dryRun) {
        $ans = Show-Message -Text "Add up to $($inputs.Count) devices to '$($group.DisplayName)'?`n`nThis changes group membership, and any policies or apps assigned to the group will apply to these devices." -Buttons 'YesNo' -Icon 'Warning'
        if ([string]$ans -ne 'Yes') { return }
    }

    $Results.Clear()
    $ui.txtSummary.Text = ''
    $script:LastRun = [pscustomobject]@{ GroupName = $group.DisplayName; GroupId = $group.Id; DryRun = $dryRun; Time = Get-Date }
    Write-Log '=================================================================='
    Write-Log "Run v$ToolVersion | Group '$($group.DisplayName)' ($($group.Id)) | $($inputs.Count) inputs | Dry run $dryRun | Pick latest $pickLatest"

    # 1. Current members, so existing ones are reported instead of erroring
    Set-Progress 0 'Reading current group members...'
    $memberIds = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($m in (Get-GraphAll -Uri "$GraphBase/groups/$($group.Id)/members?`$select=id&`$top=999")) { [void]$memberIds.Add([string]$m.id) }
    Write-Log "Group has $($memberIds.Count) direct members"

    # 2. Resolve each input to an Entra device, 20 lookups per batch call
    $select   = 'id,deviceId,displayName,operatingSystem,operatingSystemVersion,trustType,accountEnabled,approximateLastSignInDateTime'
    $resolved = New-Object System.Collections.Generic.List[object]
    for ($i = 0; $i -lt $inputs.Count; $i += 20) {
        $chunk    = $inputs.GetRange($i, [math]::Min(20, $inputs.Count - $i))
        $requests = @()
        for ($j = 0; $j -lt $chunk.Count; $j++) {
            $value  = $chunk[$j]
            $field  = if ($value -match $GuidRegex) { 'deviceId' } else { 'displayName' }
            $filter = [uri]::EscapeDataString("$field eq '$($value.Replace("'", "''"))'")
            $requests += @{ id = [string]$j; method = 'GET'; url = "/devices?`$filter=$filter&`$select=$select" }
        }
        $responses = Invoke-GraphBatch -Requests $requests
        for ($j = 0; $j -lt $chunk.Count; $j++) {
            $resolved.Add((New-LookupResult -InputValue $chunk[$j] -Response $responses[[string]$j] -PickLatest $pickLatest))
        }
        $done = $i + $chunk.Count
        Set-Progress ($done / $inputs.Count * 50) "Resolving devices: $done of $($inputs.Count)"
    }

    # 3. Decide what to add
    $seenIds = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $toAdd   = New-Object System.Collections.Generic.List[object]
    foreach ($r in $resolved) {
        if ($r.Status -eq 'Resolved') {
            if (-not $seenIds.Add($r.ObjectId))       { $r.Status = 'DuplicateInput'; Add-ResultMessage $r 'Same Entra device as an earlier line' }
            elseif ($memberIds.Contains($r.ObjectId)) { $r.Status = 'AlreadyMember' }
            elseif ($dryRun)                          { $r.Status = 'WouldAdd' }
            else                                      { $r.Status = 'Pending'; $toAdd.Add($r) }
        }
        $Results.Add($r)
    }
    Update-Summary

    # 4. Add, 20 per PATCH (the Graph limit for members@odata.bind)
    for ($i = 0; $i -lt $toAdd.Count; $i += 20) {
        $chunk = $toAdd.GetRange($i, [math]::Min(20, $toAdd.Count - $i))
        $binds = [string[]]@($chunk | ForEach-Object { "$GraphBase/directoryObjects/$($_.ObjectId)" })
        try {
            Invoke-Graph -Method PATCH -Uri "$GraphBase/groups/$($group.Id)" -Body @{ 'members@odata.bind' = $binds } | Out-Null
            foreach ($r in $chunk) { $r.Status = 'Added' }
        } catch {
            Write-Log "Bulk add of $($chunk.Count) failed, retrying one at a time: $($_.Exception.Message)" 'WARN'
            foreach ($r in $chunk) { Add-SingleMember -Group $group -Result $r; Update-UI }
        }
        $done = $i + $chunk.Count
        Set-Progress (50 + $done / $toAdd.Count * 50) "Adding to group: $done of $($toAdd.Count)"
        $ResultsView.Refresh()
    }

    foreach ($r in $Results) { Write-Log ("{0} | {1} | {2} | {3}" -f $r.Status, $r.Input, $r.ObjectId, $r.Message) }
    $ResultsView.Refresh()
    Update-Summary
    Set-Progress 100 'Done'
    Set-Status "Finished. $($ui.txtSummary.Text). Log: $LogFile"
}

function Export-Results {
    $rows = @(foreach ($item in $ResultsView) { $item })   # what the grid shows, after filters
    if ($rows.Count -eq 0) { Show-Message -Text 'Nothing to export with the current filter.' | Out-Null; return }

    $safeName = ([string]$script:LastRun.GroupName) -replace '[\\/:*?"<>|]', '_'
    $dlg = New-Object Microsoft.Win32.SaveFileDialog
    $dlg.Filter   = 'CSV file (*.csv)|*.csv'
    $dlg.FileName = 'EntraGroupDevices_{0}_{1:yyyyMMdd_HHmm}.csv' -f $safeName, (Get-Date)
    if (-not $dlg.ShowDialog($window)) { return }

    $run = $script:LastRun
    $rows | Select-Object @{ n = 'Group'; e = { $run.GroupName } }, @{ n = 'GroupId'; e = { $run.GroupId } },
                          @{ n = 'DryRun'; e = { $run.DryRun } }, @{ n = 'RunTime'; e = { $run.Time.ToString('yyyy-MM-dd HH:mm:ss') } },
                          Input, Status, DisplayName, ObjectId, DeviceId, OperatingSystem, OSVersion,
                          TrustType, Enabled, LastSignIn, Message |
        Export-Csv -Path $dlg.FileName -NoTypeInformation -Encoding UTF8
    Set-Status "Exported $($rows.Count) rows to $($dlg.FileName)"
}

function Import-Devices {
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Filter = 'Device lists (*.csv;*.txt;*.xlsx;*.xls)|*.csv;*.txt;*.xlsx;*.xls|All files (*.*)|*.*'
    if (-not $dlg.ShowDialog($window)) { return }

    Set-Status "Reading $($dlg.FileName)..."
    $data = Import-DeviceFile -Path $dlg.FileName
    $existing = $ui.txtDevices.Text.TrimEnd()
    $ui.txtDevices.Text = (@($existing) + $data.Values | Where-Object { $_ }) -join "`r`n"
    Set-Status "Imported $($data.Values.Count) values from column '$($data.Column)' in $([IO.Path]::GetFileName($dlg.FileName))"
}
#endregion

#region Events
$ui.btnConnect.Add_Click({    Invoke-UiAction -Name 'Connect'       -Action { Connect-Graph } })
$ui.btnDisconnect.Add_Click({ Invoke-UiAction -Name 'Disconnect'    -Action { Disconnect-Graph } })
$ui.btnSearch.Add_Click({     Invoke-UiAction -Name 'Group search'  -Action { Search-Groups } })
$ui.btnImport.Add_Click({     Invoke-UiAction -Name 'Import'        -Action { Import-Devices } })
$ui.btnRun.Add_Click({        Invoke-UiAction -Name 'Run'           -Action { Start-Run } })
$ui.btnExport.Add_Click({     Invoke-UiAction -Name 'Export'        -Action { Export-Results } })
$ui.btnClearDevices.Add_Click({ $ui.txtDevices.Clear() })

$ui.txtGroupSearch.Add_KeyDown({
    if ($_.Key -eq 'Return' -and $script:Connected) { Invoke-UiAction -Name 'Group search' -Action { Search-Groups } }
})
$ui.dgGroups.Add_SelectionChanged({ Select-Group; Update-Buttons })

$ui.txtDevices.Add_TextChanged({
    $n = (Get-DeviceInputList -Text $ui.txtDevices.Text -StripDomain ([bool]$ui.chkStripDomain.IsChecked)).Count
    $ui.txtDeviceCount.Text = "$n unique devices in list"
    Update-Buttons
})
$ui.chkDryRun.Add_Click({ Update-Buttons })

# Results filter: text box plus status drop-down
$ResultsView.Filter = [Predicate[object]]{
    param($item)
    $status = [string]$ui.cmbStatus.SelectedItem
    if ($status -and $status -ne 'All' -and $item.Status -ne $status) { return $false }
    $t = $ui.txtFilter.Text.Trim()
    if (-not $t) { return $true }
    foreach ($v in $item.Input, $item.DisplayName, $item.DeviceId, $item.ObjectId, $item.OperatingSystem, $item.Message) {
        if ($v -and $v.IndexOf($t, [StringComparison]::OrdinalIgnoreCase) -ge 0) { return $true }
    }
    $false
}
$ui.txtFilter.Add_TextChanged({ $ResultsView.Refresh() })
$ui.cmbStatus.Add_SelectionChanged({ $ResultsView.Refresh() })
#endregion

# ---- If already signed in to Graph in this session, reuse it ----
try {
    if ((Get-Command Get-MgContext -ErrorAction SilentlyContinue) -and (Get-MgContext)) {
        $ctx = Get-MgContext
        $script:Connected = $true
        $ui.txtConnection.Text       = "Connected as $($ctx.Account) | Tenant $($ctx.TenantId) (existing session)"
        $ui.txtConnection.Foreground = 'DarkGreen'
    }
} catch { }

Write-Log "Tool v$ToolVersion opened by $env:USERNAME on $env:COMPUTERNAME"
$ui.txtStatus.Text = "Log: $LogFile"
Update-Buttons
$window.ShowDialog() | Out-Null
