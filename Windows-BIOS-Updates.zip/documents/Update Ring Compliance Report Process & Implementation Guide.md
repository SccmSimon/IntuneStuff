# Update Ring Compliance Report

**Process & Implementation Guide**

Oct 27, 2026 · @Simon

## Document Control

| Item | Detail |
| --- | --- |
| Document title | Update Ring Compliance Report: Process & Implementation Guide |
| Version | 1.3 |
| Date | 27 October 2026 |
| Author | Simon Diaz, Vulnerability Remediation SME |
| Audience | Intune and cyber security support staff |
| Scripts | Detect-WUInstallHistory.ps1 (v1.3), Get-UpdateRingComplianceReport.ps1 (v1.6) |
| Script location | Windows BIOS Updates project: scripts/WindowsUpdate/ |
| Related tools | DetectR (on-demand remediation runs), Windows Update expedite remediation |

## 1. Purpose

The report shows, for every Windows device in every Intune update ring, when each monthly Windows update was offered and installed, and whether that matched the ring's deferral and deadline settings.

It produces one Excel workbook:

- A **Summary** sheet with, per ring, how many devices installed the latest monthly cumulative update and the percentages.
- One sheet per **update ring**, with the ring settings at the top and every device in the ring below.
- A **No update ring** sheet for devices that no ring targets.
- A **Multiple rings** sheet for devices that more than one ring targets.

Each device row is coloured green (installed as the ring intends), red (not as the ring intends) or grey (not due yet, or no data).

## 2. Scope

**In scope**

- Windows devices enrolled in Intune, named to the standard convention (WL4, WL5, WL6, WD4, WD5, WD6), that have checked in within the last 30 days (both configurable).
- Every Intune Windows update ring (Windows Update for Business configuration profile), its settings and its group assignments.
- Monthly Windows cumulative and security updates (titles such as "2026-10 Cumulative Update for Windows 11...").
- The last 3 monthly updates by default (1 to 6 configurable).

**Out of scope**

- Preview, out-of-band, .NET, Defender and servicing stack updates.
- Feature updates and driver or firmware updates. These are covered by the feature update policies and the Driver Policy Checker.
- Installing or fixing updates. Both scripts are read-only.

## 3. Background & Business Justification

Cyber Essentials requires high and critical security updates to be installed within 14 days of release. Update rings decide when devices install them: the quality update deferral delays the offer, and the deadline and grace period force the install.

Intune shows ring assignment and policy status, but not when each device actually installed each month's update, or whether that matched the ring. Without that, support cannot tell whether a late device is a ring setting problem, a device fault, or a device in the wrong ring.

Windows Update for Business reports in Log Analytics would answer this, but access is not available to the team. This process collects the same data from the devices themselves, through an Intune remediation, and joins it to the ring settings and assignments in Intune.

To keep the report consistent with Microsoft's own reporting, each column is mapped to the matching Windows Update for Business reports field (UCClientUpdateStatus schema) on a Column guide sheet, and the Entra device ID is included so rows can be matched with WUfB reports if access is granted later. Error codes are explained using Microsoft's own text from MS Learn, not our own wording.

## 4. Process Overview

The two scripts never talk to each other directly. Intune stores what the device script writes, and the report script reads it back.

1. **Device.** Intune runs `Detect-WUInstallHistory.ps1` daily as SYSTEM. It reads the device's Windows Update history and writes one line of text: OS build, last scan, last boot, and for each month the KB, install date, download date and failed attempts.
2. **Intune.** Intune keeps the latest line for each device in the remediation's **Pre-remediation detection output**. Each run replaces the previous one.
3. **Report.** `Get-UpdateRingComplianceReport.ps1` reads the update rings and their assignments, works out which live devices are in each ring, downloads every device's latest line from the remediation, and judges each device against its ring for each month.
4. **Workbook.** The report writes the Excel workbook to `C:\Temp\UpdateRingReport`.

**Which devices are in a ring.** The same way Intune targets them: devices in the ring's include groups, including nested groups, and devices whose primary user is in an included user group, minus devices in an exclude group.

**How each month is judged**

| Date | How it is worked out |
| --- | --- |
| Release | Second Tuesday of the month in the update title (2026-10 = 13 October 2026) |
| Deferral ends | Release + ring quality update deferral (days) |
| Deadline | Deferral ends + ring quality deadline (days) + grace period (days) |

| Colour | When |
| --- | --- |
| Green | Installed on or after the deferral ended and on or before the deadline. Also green if the month was skipped but a later cumulative update installed before this month's deadline, as cumulative updates include earlier months. |
| Red | Installed before the deferral ended or after the deadline, failed, or not installed when the deadline has passed. Also red when ConfigMgr manages Windows Update on a co-managed device (the ring is not in effect), or the device is in more than one ring. |
| Grey | Not due yet, or no data from the device yet. |

## 5. Script Reference

**Detect-WUInstallHistory.ps1 (v1.3)** (link to be added)

Intune remediation, detection script only. Read-only, always exits 0. Looks back 6 months. Example output line:

```
WUHIST v1.2 | OS=19045.7807 | Scan=2026-10-27T07:16Z | Boot=2026-10-27T14:09Z | 2026-10=KB5126657,F:2,FD:2026-10-20T03:10Z,E:0x80240022 | 2026-09=KB5122878,I:2026-09-16T05:54Z,F:0
```

| Field | Meaning |
| --- | --- |
| OS | Build and update revision (UBR) |
| Scan | Last successful Windows Update scan (UTC) |
| Boot | Last boot (UTC). Shown in the report as Last reboot and Days since reboot |
| WMI=Broken | Win32\_OperatingSystem cannot be read. A broken WMI repository also stops Windows Update |
| YYYY-MM=KB | The monthly update for that month |
| I: | Installed (UTC) |
| D: | Download started, used as the offered date (from the WindowsUpdateClient event log, can be missing for older months) |
| F: / FD: | Failed attempts, and the first failure (UTC) |
| E: | Error code (HResult) of the most recent failed attempt that month. The report looks it up on MS Learn |
| P:1 | Started but not finished, usually waiting for a restart |
| NONE | No monthly update in the last 6 months |

**Get-UpdateRingComplianceReport.ps1 (v1.6)** (link to be added)

| Parameter | Default | Purpose |
| --- | --- | --- |
| `-OutputFolder` | C:\\Temp\\UpdateRingReport | Where the workbook is written |
| `-Months` | 3 | Monthly updates to check (1 to 6) |
| `-RemediationName` | \*InstallHistory\* | Intune name of the detection remediation (wildcards allowed) |
| `-StaleDays` | 30 | Only devices that checked in within this many days |
| `-NamePrefixes` | WL4, WL5, WL6, WD4, WD5, WD6 | Only devices whose name starts with these (the standard naming convention) |
| `-AllNames` | Off | Every live Windows device, whatever its name |
| `-DeviceName` | None | Only these devices (exact names) |
| `-DeviceListPath` | None | CSV or text file of device names to report on. Adds to -DeviceName. Listed devices are reported whatever their last check-in date |

**Workbook columns (ring sheets):** Device, Primary user, Model, OS build (device), Updates managed by, Last check-in, Update month, KB, Release date, Deferral ends, Deadline (incl. grace), Offered (download started), Installed, Days after release, Failed attempts, Error code, Error (MS Learn), What it means (MS Learn), Mitigation (MS Learn), MS Learn link, Compliance, Reason, Device data date, Last WU scan, Last reboot, Days since reboot, Device script, Entra device ID.

**Summary sheet figures.** The counts and percentages use the latest monthly cumulative update only (for example 2026-10), one result per device, so each device is counted once. Earlier months stay on the ring sheets as history and do not change the percentages.

- **With device data:** devices that have sent a valid result from the detection script.
- **Installed (month):** devices that installed the latest update.
- **Installed in window:** installed between the end of the deferral and the deadline (green).
- **Installed late / early:** installed, but outside the ring window.
- **Not installed** and **No device data.**
- **Installed %** = installed / devices with device data. **In window %** = installed in window / devices with device data.

The Summary also shows the same figure for all devices, and a red line counting devices still on a detection script older than 1.2, which cannot report error codes.

**Ring settings shown on each sheet:** quality and feature deferral, quality and feature deadline, grace period, automatic restart before deadline, automatic update behaviour, install schedule or active hours, pause state, servicing channel, Microsoft product updates, drivers excluded, assigned and excluded groups, last modified.

**Multiple rings sheet:** each affected device, the rings it is in, and the groups that put it in each ring (Assigned through).

**Errors sheet:** every error code reported by devices, how many devices reported it and which, with Microsoft's message, description and mitigation and a link to the MS Learn page.

**Column guide sheet:** each column, the matching Windows Update for Business reports field (UCClientUpdateStatus) and what it means.

**Where the error text comes from.** The script holds a table of 291 Windows Update error codes built from three MS Learn pages: [Common Windows Update errors](https://learn.microsoft.com/troubleshoot/windows-client/installing-updates-features-roles/common-windows-update-errors) (the only one with mitigation steps, used first), [Windows Update error codes by component](https://learn.microsoft.com/windows/deployment/update/windows-update-error-reference) and [WUA success and error codes](https://learn.microsoft.com/windows/win32/wua_sdk/wua-success-and-error-codes-). A code not on those pages says so, shows the Windows system message for 0x8007xxxx codes, and links to an MS Learn search.

## 6. Intune Deployment

**Prerequisites**

| Requirement | Detail |
| --- | --- |
| Intune role | Intune Administrator, or a role that can create remediations and read devices and configuration profiles |
| Licensing | Remediations need Windows Enterprise E3/E5 (or equivalent) |
| Admin workstation | Windows PowerShell 5.1 or PowerShell 7, Microsoft.Graph.Authentication, ImportExcel (the report offers to install it) |
| Graph permissions (delegated, read-only) | DeviceManagementConfiguration.Read.All, DeviceManagementManagedDevices.Read.All, Group.Read.All, Device.Read.All |

**Step by step: deploy the device script**

1. In Intune, go to **Devices > Scripts and remediations > Remediations** and select **Create**.
2. Name it with "InstallHistory" in the name, for example `WU Install History - Detect`.
3. Detection script: upload `Detect-WUInstallHistory.ps1`. Leave the remediation script empty.
4. Run this script using the logged-on credentials: **No**. Enforce script signature check: **No**. Run script in 64-bit PowerShell: **Yes**.
5. Assign it to all Windows devices, schedule **Daily**.
6. Allow a day for devices to report, or run it on demand with DetectR for a list of devices.
7. Check results under the remediation's **Device status**, column **Pre-remediation detection output**. Each line starts `WUHIST`.

**Step by step: run the report**

1. Open PowerShell on an admin workstation.
2. Run `.\Get-UpdateRingComplianceReport.ps1`.
3. Sign in with your admin account and accept the permissions prompt.
4. Check the console: number of rings, devices per ring, any multiple ring warning, and device results read.
5. Open the workbook in `C:\Temp\UpdateRingReport`. Start with **Summary**, then the **Multiple rings** sheet, then each ring.

**Optional parameters**

```powershell
.\Get-UpdateRingComplianceReport.ps1 -Months 6
.\Get-UpdateRingComplianceReport.ps1 -AllNames
.\Get-UpdateRingComplianceReport.ps1 -NamePrefixes WL5, WL6
.\Get-UpdateRingComplianceReport.ps1 -DeviceName WL5ABC123, WD6XYZ789
.\Get-UpdateRingComplianceReport.ps1 -DeviceListPath C:\Temp\Devices.csv
.\Get-UpdateRingComplianceReport.ps1 -RemediationName 'WU Install History - Detect'
```

**Device list file.** A CSV with a column called DeviceName, Device name, Device, Name, ComputerName or Hostname (an Intune device export works as it is), or a text file with one name per line. Names not found in Intune are shown in the console and listed on the Summary sheet.

**Step by step: act on the results**

1. **Multiple rings:** fix the include and exclude groups (Assigned through shows which group to change).
2. **No update ring:** add the device to the right ring group.
3. **Updates managed by ConfigMgr:** move the Windows Update workload to Intune for that collection, or accept that the ring does not apply.
4. **Installed before the deferral ended:** check for expedite policies, manual installs or Windows Update policy from another source.
5. **Installed after the deadline, failed, or not installed:** check the Error code columns. Mitigation (MS Learn) gives Microsoft's fix for that code, and the Errors sheet shows whether the same code is hitting many devices. Use the expedite remediation for urgent Cyber Essentials cases.
6. **WMI repository broken:** run `winmgmt /verifyrepository`, then `winmgmt /salvagerepository`, and recheck Windows Update.

## 7. Logging & Review

**Device log:** `%ProgramData%\Microsoft\IntuneManagementExtension\Logs\WUInstallHistory-Detection.log`. One line per run, the same line sent to Intune. Collected by the Intune **Collect diagnostics** action.

**Intune:** the remediation's Device status shows the latest output line and when it ran.

**Report:** the console shows rings, devices per ring, multiple ring warnings, device results read and the totals per ring. The workbook is the record of each run; the date and time are in the file name. The **Device data date** column shows how old each device's data is.

**Review cadence**

- Run the report monthly, about 3 weeks after Patch Tuesday, when the deadlines for most rings have passed.
- Run it after any change to update rings or their groups.
- Keep the workbooks with the Cyber Essentials patching evidence.

## 8. Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| Every device shows "No data from the device" | Remediation not found by name, or not run yet | Check the console line "Using remediation". Use `-RemediationName` with the exact Intune name |
| Some devices show "No data from the device" | Device offline, or outside the remediation assignment | Check the assignment. Run it with DetectR |
| Device data date is old | Device not running remediations (IME not checking in) | Check the device is online and the Intune Management Extension service is running |
| Output line contains `WMI=Broken` | Broken WMI repository (0x80041010) | `winmgmt /verifyrepository`, then `winmgmt /salvagerepository`. Recheck Windows Update |
| Output line is `NONE` | No monthly update installed in 6 months | Treat as unpatched. Check Windows Update and the WMI repository |
| Only the latest month appears for a device | Device rebuilt or re-imaged, so its Windows Update history was reset | Expected |
| Offered (download started) is empty | The WindowsUpdateClient event log has rolled over | Expected for older months. The install date is still correct |
| P:1 on a month (started but not finished) | Waiting for a restart | Check Last reboot and Days since reboot (the Reason also says when the device last restarted). Check the restart deadline in the ring. Restart the device |
| Many devices red on the same month | Deferral or deadline too long for that month, a pause, or a release issue | Check the ring settings block on the sheet and the Quality updates paused line |
| Device in more than one ring | Overlapping include groups, or a missing exclusion | Use the Multiple rings sheet, Assigned through column |
| "Updates managed by ConfigMgr" | Co-managed device with the Windows Update workload in ConfigMgr | Move the workload, or report the device under ConfigMgr patching |
| ImportExcel not installed | Module missing on the workstation | Accept the prompt, or `Install-Module ImportExcel -Scope CurrentUser` |
| Graph 403 | Permissions not consented | Ask a Global Administrator to consent to the four read scopes |
| Error code empty on a failed month | Device still running Detect-WUInstallHistory.ps1 1.1 or earlier (see the Device script column and the red line on the Summary) | Upload 1.3 to the remediation and wait for the next daily run |
| "Not on the MS Learn Windows Update error pages" | The code is a general Windows or servicing error, not a Windows Update one | Use the MS Learn search link in the row and the device's CBS.log |
| Listed devices not found in Intune | Name typo, device not enrolled, or no Entra device ID | Check the name in Intune. The Summary sheet lists them |

## 9. Security Considerations

- **Read-only.** The device script only reads Windows Update history, the event log and the registry. The report only sends GET requests to Graph.
- **Runs as SYSTEM** on devices, through the Intune Management Extension. No credentials are stored in either script.
- **Delegated sign-in** for the report. No app registration, secret or certificate.
- **Personal data in the workbook.** It holds device names, primary users and models. Store it in a restricted location and delete old copies in line with data retention policy.
- **Change control.** Do not add remediation or write calls to either script without change control. Fixing devices is done with the separate expedite remediation.

## 10. Change History

| Version | Date | Author | Change |
| --- | --- | --- | --- |
| 1.0 | 27 October 2026 | Simon Diaz | First release. Detect-WUInstallHistory.ps1 1.1 (broken WMI flag, started-but-not-finished flag) and Get-UpdateRingComplianceReport.ps1 1.3 (standard naming convention by default, -AllNames for every device; sheet per ring with settings, Summary, No update ring and Multiple rings sheets, green / red / grey rows). |
| 1.1 | 27 October 2026 | Simon Diaz | Detect-WUInstallHistory.ps1 1.2 (error code of the last failed attempt, E:). Get-UpdateRingComplianceReport.ps1 1.4 (-DeviceListPath to import a CSV or text list of devices; MS Learn error message, description, mitigation and link per row; Errors sheet; Column guide sheet mapped to the WUfB reports schema; Entra device ID column). |
| 1.2 | 27 October 2026 | Simon Diaz | Get-UpdateRingComplianceReport.ps1 1.5: Summary percentages use the latest monthly cumulative update only, one result per device, instead of every row; Device script column and a count of devices on a detection script too old to report error codes. Detect-WUInstallHistory.ps1 1.3: error code falls back to UnmappedResultCode when HResult is 0. |
| 1.3 | 28 October 2026 | Simon Diaz | Get-UpdateRingComplianceReport.ps1 1.6: Last reboot and Days since reboot columns from the device data. When an update is waiting for a restart, the Reason gives the last restart date. No change to the device script. |
