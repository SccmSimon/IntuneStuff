# WUfB BIOS and Firmware Approval Report

**Process & Implementation Guide**

Oct 15, 2026 · @Simon

## Document Control

| Item | Detail |
| --- | --- |
| Document title | WUfB BIOS and Firmware Approval Report: Process & Implementation Guide |
| Version | 2.9 |
| Date | 15 October 2026 |
| Author | Simon Diaz, Vulnerability Remediation SME |
| Audience | Intune and cyber security support staff |
| Script | Get-WUfBFirmwareOffers.ps1 |
| Script location | Windows BIOS Updates project: scripts/Tools/ |
| Related tools | HP BIOS Win32 app (HP CMSL), Dell BIOS Win32 app (Dell Command \| Update), Detect-BIOSPassword.ps1 |

## 1. Purpose

The report shows which live Windows devices have no approved BIOS or firmware update in their Intune driver update policy, and why.

It answers three questions for each device:

- Is it in a driver update policy at all?
- Has Windows Update for Business (WUfB) got a BIOS or firmware update for it?
- Is that update approved, scheduled, revoked or still waiting for review?

The output is three CSV files that support staff can filter, sort and act on.

## 2. Scope

**In scope**

- Windows devices enrolled in Intune with names starting WL4, WL5, WL6, WD4, WD5 or WD6.
- Devices that have checked in to Intune within the last 30 days (configurable).
- The 10 Intune driver update policies, their group assignments and their BIOS and firmware inventory.
- Approval state of each firmware update in each policy.

**Out of scope**

- Entra device objects with no live Intune record. Around 20,000 stale Entra objects share the naming convention and are ignored.
- BIOS updates delivered outside Windows Update, such as the HP CMSL and Dell Command | Update Win32 apps. Devices fixed by those apps still show here if WUfB has no update for them.
- Non-firmware drivers, unless the report is run with `-IncludeDrivers`.
- Approving, revoking or changing anything. The script is read-only.

## 3. Background & Business Justification

Out-of-date BIOS firmware is a vulnerability finding in its own right and blocks Cyber Essentials compliance. The Intune BIOS report showed many devices on older BIOS versions than the vendor's latest.

**Update rings do not deliver BIOS updates.** Update rings control quality and feature update timing only. Drivers and firmware are controlled by Intune driver update policies:

- Each driver update policy has a list of devices (an audience) in the WUfB deployment service.
- WUfB lists the drivers and firmware applicable to those devices.
- Each item must be approved in the policy before it is offered. With manual approval, nothing is offered until someone approves it.

A device can therefore sit in an update ring for months with no BIOS update offered, because it is in no driver update policy, or because the BIOS is waiting for approval.

**Why Intune and not Entra.** Entra keeps device objects after rebuilds and re-enrolments. Entra holds over 40,000 objects with our naming convention against roughly 20,000 live Intune devices. Reporting from Entra doubles the numbers and hides the real gaps.

**Why Intune and not the WUfB deployment service API (v2.0).** Testing on 15 October 2026 found that the Intune driver update policies in this tenant are not visible through the deployment service API. The policy ID returns 404, devices assigned to the policy are not members of any of the 81 visible audiences, and the Intune API returns 0 for devices reporting on all 10 policies, although the Intune portal shows real figures. Version 2.0 therefore reads everything from Intune: group assignments to link devices to policies, and each policy's driver inventory for approval status.

## 4. Process Overview

The script joins Intune device data to Intune driver update policy data in five steps.

1. **Live devices.** Reads all Windows devices from Intune. Keeps those matching the name prefixes, checked in within `-StaleDays`, and with an Entra device ID. Where a device has two Intune records, keeps the most recent.
2. **Policies and firmware.** Reads every Intune driver update policy, its include and exclude groups, and its driver inventory. Keeps the firmware entries and their approval status: approved, needs review, declined or paused.
3. **Device to policy.** Expands each assigned group to its device members, including nested groups. A device is in a policy if it is in an include group and not in an exclude group.
4. **Status per device.** Matches the policy's firmware to the device's manufacturer (HP firmware for HP devices, Dell for Dell) and sets a status.
5. **Output.** Writes three CSV files and prints a summary to the console.

**Device specific results (v2.7).** Intune driver inventory is per policy and does not say which model a firmware update is for, so it is only used in the policy-level CSVs (Firmware and PolicySummary). Each device's row uses only what is specific to that device: its policy, from group membership, and what the device reported from its own Windows Update scan.

**Confirmed offer details (v2.4).** To confirm what each device is actually offered, the report also reads the latest result of the **Detect-WUFirmwareStatus.ps1** Intune remediation (detection only, daily, as SYSTEM). That script asks Windows Update on the device which firmware it is offered and checks the UEFI capsule result. These columns come from the device, not the policy:

| Column | Meaning |
| --- | --- |
| DeviceCheck | OK, ISSUE, Not run or Script error, with the date of the last run. STALE when older than 7 days (`-DeviceCheckMaxAgeDays`) |
| DeviceResult | The detection result, for example "Firmware offered, not installed" or "No firmware offered by Windows Update" |
| OfferedNow | Firmware Windows Update is offering the device now and has not installed. This is the confirmed offer. |
| LastWUFirmware | Last firmware in the device's Windows Update history, its date and result |
| FirmwarePackage | Version of the System Firmware device (what Windows Update installed) |
| RunningFirmware | UEFI ESRT version (what the BIOS is running). Lower than FirmwarePackage means installed but not applied |
| LastCapsule | Result of the last BIOS capsule update attempt |
| RestartPending | Yes when a restart is waiting |

The remediation is found by its Intune name (`-OfferScriptName`, default `*Firmware*`). Devices outside the remediation's assignment show "Not run". Use `-SkipDeviceCheck` to leave these columns out.

## 5. Script Reference

**Script:** Get-WUfBFirmwareOffers.ps1, version 2.8. GUI: Show-DriverPolicyChecker.ps1, version 2.4. Device check: Detect-WUFirmwareStatus.ps1 remediation (link to be added)

**Parameters**

| Parameter | Default | Purpose |
| --- | --- | --- |
| `-OutputFolder` | C:\\Temp\\BIOSReport | Where the CSV files are written |
| `-NamePrefixes` | WL4, WL5, WL6, WD4, WD5, WD6 | Device name prefixes in scope |
| `-StaleDays` | 30 | Devices must have checked in to Intune within this many days |
| `-IncludeDrivers` | Off | Also report non-firmware drivers |
| `-DeviceName` | None | Check one or more devices by exact name. Ignores `-NamePrefixes` and `-StaleDays`, reads only the device's own groups, and prints the result to the console. |

**Output files**

| File | One row per | Use it to |
| --- | --- | --- |
| DriverPolicy-Devices\_\<date>.csv | Live device | Find devices with no policy, or whose policy has firmware waiting. Start here. |
| DriverPolicy-Firmware\_\<date>.csv | Firmware update per policy | See every firmware update, its approval status and how many devices it applies to |
| DriverPolicy-PolicySummary\_\<date>.csv | Driver update policy | See groups, live devices in scope and firmware counts per policy |

**Status values (Devices CSV)**

| Status | Meaning | Action |
| --- | --- | --- |
| Not in any driver update policy | The device is in no include group, or is in an exclude group of every policy | Add the device's group to a driver update policy |
| In more than one driver update policy (conflict) | The device is in the include groups of two or more policies | Fix the group exclusions so each device is in one policy |
| Firmware offered, not installed | Windows Update on the device is offering firmware it has not installed (OfferedNow) | Check for a pending restart, BIOS password or BitLocker. Check the Windows Driver Update Report in Intune |
| Device issue: \<result> | The device reported a problem, for example a failed capsule update or firmware installed but not applied | Follow the result text. Run Get-FirmwareUpdateDiag.ps1 on the device if needed |
| Up to date (no firmware offered) | In a policy, and Windows Update has no firmware to offer the device | None from Windows Update. To confirm against the vendor's latest, use DCU, the Dell catalogue detection or HP CMSL |
| In policy, device check not run | The Detect-WUFirmwareStatus.ps1 remediation has no result for this device | Check the remediation's assignment and schedule |
| In policy, device result out of date | The device's last result is older than 7 days | Check the device is online and the remediation is running |
| Not found in Intune (or no Entra device ID) | GUI only: the name is not in Intune | Check the name |

**Behind other devices of this model (v2.8).** Red status. The device runs older firmware (UEFI ESRT, reported by the device) than Windows Update has delivered to another device of the same model in the same run, and is not being offered it. Action: check the device's Windows Update scan and the Windows Driver Update Report, then use the Dell or HP BIOS Win32 app if needed. The comparison only covers devices in the same run, so check a whole model, or run the full report, for the best result.

**Key columns (Devices CSV):** DeviceName, Model, SerialNumber, PrimaryUser, LastSync, BiosVersion, Status, PolicyName, ApprovalType, DeviceCheck, DeviceResult, OfferedNow, BiosOnDevice (BIOS the device reports; Intune's BiosVersion can be stale), NewestSeenForModel, LastWUFirmware, FirmwarePackage, RunningFirmware, LastCapsule, RestartPending, ErrorCode, ErrorMessage, ErrorMeaning, ErrorMitigation, ErrorLink.

**Error columns (v2.9).** When the device reports an error code, the report shows Microsoft's own text for it from MS Learn. The code is taken from the HResult of a failed Windows Update firmware install, or from any 0x8xxxxxxx code in a scan or script error. ErrorMessage is Microsoft's name for the code, ErrorMeaning its description, ErrorMitigation the fix where MS Learn gives one, and ErrorLink the page the text came from. A single device check prints the same details in the console.

**Where the error text comes from.** The script holds a table of 291 Windows Update error codes built from three MS Learn pages: [Common Windows Update errors](https://learn.microsoft.com/troubleshoot/windows-client/installing-updates-features-roles/common-windows-update-errors) (the only one with mitigation steps, used first), [Windows Update error codes by component](https://learn.microsoft.com/windows/deployment/update/windows-update-error-reference) and [WUA success and error codes](https://learn.microsoft.com/windows/win32/wua_sdk/wua-success-and-error-codes-). A code not on those pages says so, shows the Windows system message for 0x8007xxxx codes, and links to an MS Learn search. The same table is used by the Update Ring Compliance Report.

**Firmware approval status (Firmware CSV, policy level):** approved, needsReview, declined, suspended (paused). Category is recommended, previouslyApproved or other.

## 6. Intune Deployment

The report runs from an admin workstation, not as an Intune script. Nothing is deployed to devices.

**Prerequisites**

| Requirement | Detail |
| --- | --- |
| PowerShell | Windows PowerShell 5.1 or PowerShell 7 |
| Module | Microsoft.Graph.Authentication |
| Account | Intune Administrator, or a role that can read Intune devices, driver update policies and Windows Update deployments |
| Licence | Windows E3/E5 (or equivalent) for WUfB deployment service data |
| Driver update policies | At least one Intune driver update policy must exist |

**Graph permissions (delegated)**

| Permission | Used for |
| --- | --- |
| DeviceManagementManagedDevices.Read.All | Live Intune devices |
| DeviceManagementConfiguration.Read.All | Driver update policies, assignments and driver inventory |
| Group.Read.All | Group names and group members |
| Device.Read.All | Device group membership (single device check) |

First run triggers a consent prompt. If you cannot consent, ask a Global Administrator or Privileged Role Administrator to grant consent for Microsoft Graph PowerShell.

**Step by step: run the report**

1. Open PowerShell on an admin workstation.
2. Install the module if missing: `Install-Module Microsoft.Graph.Authentication -Scope CurrentUser`
3. Go to the script folder: `Set-Location <folder containing the script>`
4. Run the report: `.\Get-WUfBFirmwareOffers.ps1`
5. Sign in with your admin account and accept the permissions prompt.
6. Check the device counts line. The live devices figure should be close to the expected live estate for the prefixes.
7. Check the group expansion lines. Each assigned group should show a sensible number of live devices.
8. Open the CSV files in `C:\Temp\BIOSReport`.

**Step by step: act on the results**

1. Open DriverPolicy-Devices\_\<date>.csv, or use the GUI, and filter on Status.
2. **Not in any driver update policy:** add the device's group to the right driver update policy in Intune (Devices > Windows updates > Driver updates).
3. **Conflict:** fix the exclude groups so the device sits in one policy only.
4. **Firmware offered, not installed:** check RestartPending, the BIOS password and BitLocker, and the Windows Driver Update Report for the device.
5. **Device issue:** follow the DeviceResult text.
6. **Up to date:** nothing to do from Windows Update. If the BIOS is still behind the vendor's latest, the vendor does not publish it to Windows Update: assign the HP or Dell BIOS Win32 app.
7. **Device check not run / out of date:** fix the Detect-WUFirmwareStatus.ps1 remediation assignment, then re-run after 24 hours.

**Optional parameters**

```powershell
.\Get-WUfBFirmwareOffers.ps1 -StaleDays 14
.\Get-WUfBFirmwareOffers.ps1 -NamePrefixes 'WL5','WD5'
.\Get-WUfBFirmwareOffers.ps1 -IncludeDrivers -OutputFolder 'D:\Reports\BIOS'
.\Get-WUfBFirmwareOffers.ps1 -DeviceName 'WL5ABC123'
.\Get-WUfBFirmwareOffers.ps1 -DeviceName 'WL5ABC123','WD6XYZ789'
```

**Single device check.** Use `-DeviceName` when a user or ticket reports one machine. The console shows the device's model, last check-in, driver update policy, each firmware update WUfB offers with its approval state, and a one-line result using the Status values in section 5. The CSVs are still written.

**Checking a list of devices with the GUI.** `Show-DriverPolicyChecker.ps1` is a front end for the report. Keep it in the same folder as `Get-WUfBFirmwareOffers.ps1`.

1. Start it: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Show-DriverPolicyChecker.ps1`. It relaunches itself in STA mode if needed.
2. Select **Connect**. The sign-in prompt appears over the PowerShell console window. If it never appears, choose **Device code** in the Sign-in box and connect again.
3. In **1. Devices**, paste device names (one per line, or separated by commas, spaces or semicolons), or select **Import CSV / TXT / XLSX**. FQDNs are cut to the device name and duplicates are removed.
4. Check the output folder, and the **Remediation** name if the Detect-WUFirmwareStatus.ps1 remediation is not named with "Firmware".
5. Select **Run check**. Progress shows in **3. Log**. The window stays usable and **Cancel** stops the run.
6. Review **2. Results**. Row colour shows the policy status: red = not found, no policy, conflict or device issue; amber = firmware offered, not installed; green = up to date; grey = device check not run or out of date. Text in the device columns is red for ISSUE, green for OK and grey when not run or stale. **Offered now** is in bold.
7. Filter by status or text, **Copy selected names** (all shown names if none are selected), and **Export CSV** for what is on screen. The full CSVs are also in the output folder.

The tool uses the same navy theme as the Entra Device Group Tool. Its log is in `%LOCALAPPDATA%\DriverPolicyChecker\Logs`. Names not found in Intune, or with no Entra device ID, are listed as "Not found in Intune (or no Entra device ID)".

## 7. Logging & Review

The script writes no log file. The console output and the three CSV files are the record of each run. Keep the CSVs: the date and time stamp in each file name lets you compare runs.

**Console output to check on every run**

| Line | What to look for |
| --- | --- |
| Windows devices in Intune ... wrong name ... not checked in ... no Entra ID ... duplicates | Counts for each filter. A large "no Entra ID" or "duplicates" figure points to enrolment problems worth raising. |
| Live devices in scope | Close to the expected live estate for the prefixes |
| \<policy> \| \<approval type> \| firmware approved, needs review, declined, paused | Firmware counts per policy. A manual policy with firmware waiting means devices are not being offered it. |
| \<group>: \<n> live devices in scope | Device members of each assigned group. 0 on an include group means the policy reaches no live devices. |
| Live devices by status | Headline figures for reporting |
| Policies table | Live devices and firmware counts per policy |

**Review cadence**

- Run weekly, and after any change to driver update policies or their group assignments.
- Track the headline figure over time. It should fall as policies and approvals are fixed.
- Store the CSVs with the vulnerability remediation evidence for Cyber Essentials.

## 8. Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| `Connect-MgGraph` fails or prompts for admin approval | Permissions not consented for Microsoft Graph PowerShell | Ask a Global Administrator to grant consent for the four scopes in section 6 |
| "No Intune driver update policies found" | Account cannot read driver update policies | Use an Intune Administrator account |
| Live devices in scope is 0 | Prefixes wrong, or `-StaleDays` too low | Check `-NamePrefixes`. Try `-StaleDays 90`. |
| "Could not expand group" warning | Group deleted, or Graph throttling | Check the group still exists. Re-run. |
| A group shows 0 live devices | The group holds users, not devices, or holds devices outside the name prefixes | Driver update policies target devices. Assign a device group. |
| Many devices "Not in any driver update policy" | Include groups miss them, or exclude groups catch them | Check the PolicySummary CSV include and exclude groups |
| Many devices in conflict | Ring groups overlap, for example AllManaged plus a pilot group without the matching exclusion | Add the missing exclusions |
| Devices "Policy has no firmware for this vendor" | Vendor does not publish those models' BIOS to Windows Update | Expected for some HP models (for example the EliteBook 645 G11). Use the HP or Dell BIOS Win32 app. |
| Firmware approved but the BIOS does not change | Device not scanning, BIOS password, or BitLocker suspend not allowed | Check Windows Update logs on the device and the Windows Driver Update Report in Intune |
| ErrorCode empty on a device issue | The issue has no error code, for example firmware offered but not installed, or capsule updates disabled | Expected. Use DeviceResult and LastCapsule |
| ErrorMeaning says "Not on the MS Learn Windows Update error pages" | A general Windows or servicing error, not a Windows Update one | Use the MS Learn search link in ErrorLink and the device's CBS.log |

**Diagnostic: one device**

Run `Test-WUfBDriverPolicyDevice.ps1` (scripts/Tools in the project) to check the device's Intune record, Entra object, group membership against the policy's include and exclude groups, and its Windows Update for Business registration.

```powershell
.\Test-WUfBDriverPolicyDevice.ps1 -DeviceName WL5ABC123 -PolicyId 00000000-0000-0000-0000-000000000000
```

## 9. Security Considerations

- **Read-only.** The report needs read permissions only. It sends GET requests only. Do not edit the script to add write calls (for example approving drivers) without change control.
- **Delegated sign-in only.** The script runs as the signed-in admin. No app registration, secret or certificate is stored.
- **Run from a secure admin workstation**, not a shared or user device.
- **Personal data in the output.** The CSVs hold device names, serial numbers and user principal names. Store them in a restricted location and delete old copies in line with data retention policy.
- **Disconnect after use:** run `Disconnect-MgGraph` when finished, or close the PowerShell window.
- **Approvals are a change.** Approving BIOS updates from the report results flashes firmware on live devices. Approve in line with change management, and pilot new BIOS versions on a small group first.

## 10. Change History

| Version | Date | Author | Change |
| --- | --- | --- | --- |
| 2.9 | 27 October 2026 | Simon Diaz | Error codes reported by the device shown with Microsoft's message, description, mitigation and link from MS Learn (ErrorCode, ErrorMessage, ErrorMeaning, ErrorMitigation, ErrorLink). Single device check prints them in the console. |
| 2.5 (GUI 2.0 / 2.1) | 22 October 2026 | Simon Diaz | GUI rebuilt in WPF with a navy theme (navy header, navy buttons, styled grid), matching the Entra Device Group Tool. Device code sign-in, XLSX import, text filter. Report 2.5: \[CmdletBinding()\] so unknown parameters fail, and tables show in the GUI log. GUI 2.1 refuses to run with a report older than 2.5. Report 2.6 / GUI 2.2 (22 October 2026): LatestVendorFirmware column removed, because Intune does not say which model a firmware update is for. Report 2.7 / GUI 2.3 (22 October 2026): device rows are device specific only. Vendor-wide firmware columns removed and Status rebuilt from policy membership and the device-reported result. Report 2.8 / GUI 2.4: BiosOnDevice and NewestSeenForModel columns; new status "Behind other devices of this model" (for example a device on 1.43.0 while another of the same model had 1.49.0, and Intune showed a stale 1.15.2). |
| 2.4 | 22 October 2026 | Simon Diaz | Confirmed offer details from the Detect-WUFirmwareStatus.ps1 remediation: DeviceCheck, DeviceResult, OfferedNow, LastWUFirmware, FirmwarePackage, RunningFirmware, LastCapsule, RestartPending. GUI 1.1 shows them. |
| 2.3 | 22 October 2026 | Simon Diaz | Reuses an existing Graph sign-in with the required scopes. File names include seconds. New GUI, Show-DriverPolicyChecker.ps1 1.0, for checking a list of devices. |
| 2.2 | October 2026 | Simon Diaz | Graph retries on 429 / 503 / 504. Unread driver inventory flagged per policy. Installed BIOS version (single device mode, or -IncludeBiosVersion). |
| 2.1 | 15 October 2026 | Simon Diaz | Fixed devices with no vendor firmware showing as "approved". Vendor matching ignores punctuation (Dell, Inc.). Single device check lists the policy's firmware manufacturers when none match. |
| 2.0 | 15 October 2026 | Simon Diaz | Reads Intune only. Device to policy through group assignments, approvals from each policy's driver inventory. New CSV outputs. WUfB deployment service API dropped: the tenant's policies are not visible through it. |
| 1.1 | 15 October 2026 | Simon Diaz | Added `-DeviceName` single device check. |
| 1.0 | 15 October 2026 | Simon Diaz | First release. Live Intune device scope, approval state per device, Intune policy and group names, NoApproval CSV. |
