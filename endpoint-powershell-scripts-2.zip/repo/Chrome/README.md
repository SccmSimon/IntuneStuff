# Chrome force update and auto-update enforcement (Intune Remediation pair)

| Script | Role |
|---|---|
| `Detect-ChromeVersion.ps1` | Detection |
| `Remediate-ChromeForceUpdate.ps1` | Remediation (also usable as a standalone or patching post-action script) |

## Detection
Non-compliant (exit 1) when either:
- system-wide Chrome is below `$MinimumVersion` (a staged `new_chrome.exe` counts as compliant while `$PendingRestartIsCompliant = $true`), or
- something blocks updates: `AutoUpdateCheckPeriodMinutes=0`, `UpdateDefault`/`Update{Chrome GUID}` not 1 or 3, install blocked, `TargetVersionPrefix`/`RollbackToTargetVersion` pins, disabled Google Update services or scheduled tasks.

Output example: `NonCompliant: Chrome 155.0.8059.85 | AutoUpdateCheckPeriodMinutes=0`

## Remediation
1. Exports `HKLM\SOFTWARE\Policies\Google\Update` to a `.reg` backup and logs the "before" values.
2. Removes blocking or pinning values and sets `UpdateDefault` and `Update{8A69D345-...}` to 1.
3. Re-enables disabled Google Update services and scheduled tasks.
4. If still below the minimum, downloads the Chrome Enterprise MSI from `dl.google.com`, checks the Authenticode signature is Google LLC, installs silently.
5. Starts the Google Update scheduled task so the updater runs immediately.

## Settings
| Setting | Default | Notes |
|---|---|---|
| `$MinimumVersion` | 156.0.8078.73 | Keep the same in both scripts |
| `$ForceCloseChrome` | `$false` | `$true` applies the update immediately but closes open browsers |
| `$PendingRestartIsCompliant` | `$true` | Detection only |

## Logs
| File | Location |
|---|---|
| Script log (rolls over at 5 MB) | `%ProgramData%\Microsoft\IntuneManagementExtension\Logs\ChromeForceUpdate.log` |
| msiexec verbose log | `...\IntuneManagementExtension\Logs\ChromeForceUpdate-msiexec.log` |
| Policy backups and MSI download | `%ProgramData%\ChromeForceUpdate` |

## Notes
- This pair takes ownership of Chrome update settings. Do not use it where another tool (Patch My PC, ConfigMgr, a PSADT wrapper) deliberately controls Chrome updates.
- Devices need to reach `dl.google.com` as SYSTEM. Behind an authenticated proxy, host the MSI internally and change `$MsiUrl`.
- While Chrome is open the new build is staged and scanners may still flag the device until the browser restarts.
- Intune: SYSTEM, 64-bit PowerShell.
