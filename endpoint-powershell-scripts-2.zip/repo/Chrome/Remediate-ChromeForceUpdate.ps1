# Remediate-ChromeForceUpdate.ps1
# Puts Chrome into a self-updating state and forces it up to the minimum version.
# Intune Remediations remediation script (also works standalone, e.g. as a patching post-action).
# Run as SYSTEM, 64-bit PowerShell. Exit 0 = success, exit 1 = failed.
# Author: Simon Diaz
#
# Nothing else is meant to manage Chrome update settings, so this script takes ownership of them:
#   1. Backs up the Google Update policy key (for audit)
#   2. Removes anything that blocks or pins updates, and sets updates to "always allow"
#   3. Re-enables the Google Update services and scheduled tasks
#   4. If Chrome is below the minimum version, downloads the Chrome Enterprise MSI from Google,
#      checks the signature and installs it
#   5. Starts an update check so the updater is active straight away
#
# If something does write the blocking values back, the detection script will catch it on its
# next run and this script will put them right again. The log shows the before values each time.
#
# Log:     C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\ChromeForceUpdate.log
# MSI log: C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\ChromeForceUpdate-msiexec.log
# Policy backups (.reg): C:\ProgramData\ChromeForceUpdate

#region Settings

# Must match the detection script
$MinimumVersion = [version]'156.0.8078.73'

# $true closes Chrome so the new version applies straight away. Users lose unsaved work in open
# tabs (Chrome normally restores the session). $false stages the update for the next restart.
$ForceCloseChrome = $false

$ChromeAppGuid = '{8A69D345-D564-463C-AFF1-A69D9E530F96}'
$PolicyPath    = 'HKLM:\SOFTWARE\Policies\Google\Update'
$Stamp         = Get-Date -Format 'yyyyMMdd-HHmmss'

# Logs go in the IME folder so they are included in Intune "Collect diagnostics"
$LogFolder     = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs'
$LogFile       = Join-Path $LogFolder 'ChromeForceUpdate.log'
$MsiLog        = Join-Path $LogFolder 'ChromeForceUpdate-msiexec.log'
$MaxLogSizeMB  = 5

# Working files (MSI download, policy backups) stay out of the log folder
$WorkFolder    = Join-Path $env:ProgramData 'ChromeForceUpdate'

$MsiUrl = if ([Environment]::Is64BitOperatingSystem) {
    'https://dl.google.com/dl/chrome/install/googlechromestandaloneenterprise64.msi'
} else {
    'https://dl.google.com/dl/chrome/install/googlechromestandaloneenterprise.msi'
}
$MsiPath = Join-Path $WorkFolder 'GoogleChromeEnterprise.msi'

# Removed: anything that stops, delays or pins updates
$RemoveValues = @(
    'AutoUpdateCheckPeriodMinutes',
    'InstallDefault',
    "Install$ChromeAppGuid",
    "TargetVersionPrefix$ChromeAppGuid",
    "RollbackToTargetVersion$ChromeAppGuid",
    'DisableAutoUpdateChecksCheckboxValue'
)

# Set: updates always allowed (1 = always allow updates)
$SetValues = @{
    'UpdateDefault'        = 1
    "Update$ChromeAppGuid" = 1
}

#endregion

#region Helpers

New-Item -ItemType Directory -Path $WorkFolder, $LogFolder -Force | Out-Null

# One log file appended each run. Roll it over when it gets large so the IME folder stays tidy.
if ((Test-Path $LogFile) -and ((Get-Item $LogFile).Length / 1MB) -gt $MaxLogSizeMB) {
    Move-Item -Path $LogFile -Destination (Join-Path $LogFolder 'ChromeForceUpdate-old.log') -Force
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'   # Invoke-WebRequest is very slow with the progress bar on
$script:Failed = $false

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0} [{1}] {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    Write-Output $line
    Add-Content -Path $LogFile -Value $line
    if ($Level -eq 'ERROR') { $script:Failed = $true }
}

function Get-FileVersion {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return $null }
    $v = (Get-Item $Path).VersionInfo.ProductVersion
    if ($v -match '(\d+\.\d+\.\d+\.\d+)') { return [version]$Matches[1] }
    return $null
}

function Get-ChromeAppDir {
    @("$env:ProgramFiles\Google\Chrome\Application",
      "${env:ProgramFiles(x86)}\Google\Chrome\Application") |
        Where-Object { Test-Path (Join-Path $_ 'chrome.exe') } | Select-Object -First 1
}

#endregion

Write-Log "Starting on $env:COMPUTERNAME"

$appDir = Get-ChromeAppDir
if (-not $appDir) {
    Write-Log 'Chrome is not installed system-wide. Nothing to do.'
    exit 0
}
$before = Get-FileVersion (Join-Path $appDir 'chrome.exe')
Write-Log "Installed version: $before. Minimum: $MinimumVersion"

#region 1-2. Policies

if (Test-Path $PolicyPath) {
    & reg.exe export 'HKLM\SOFTWARE\Policies\Google\Update' (Join-Path $WorkFolder "GoogleUpdatePolicy-before-$Stamp.reg") /y | Out-Null

    (Get-ItemProperty -Path $PolicyPath).PSObject.Properties |
        Where-Object { $_.Name -notlike 'PS*' } |
        ForEach-Object { Write-Log "Before: $($_.Name) = $($_.Value)" }

    $key = Get-Item $PolicyPath
    foreach ($name in $RemoveValues) {
        if ($key.GetValueNames() -contains $name) {
            try {
                Remove-ItemProperty -Path $PolicyPath -Name $name -ErrorAction Stop
                Write-Log "Removed $name" 'CHANGE'
            }
            catch { Write-Log "Failed to remove $name : $($_.Exception.Message)" 'ERROR' }
        }
    }
}
else {
    New-Item -Path $PolicyPath -Force | Out-Null
}

foreach ($name in $SetValues.Keys) {
    $current = (Get-ItemProperty -Path $PolicyPath -Name $name -ErrorAction SilentlyContinue).$name
    if ($current -ne $SetValues[$name]) {
        try {
            New-ItemProperty -Path $PolicyPath -Name $name -Value $SetValues[$name] -PropertyType DWord -Force -ErrorAction Stop | Out-Null
            Write-Log "Set $name = $($SetValues[$name]) (was $current)" 'CHANGE'
        }
        catch { Write-Log "Failed to set $name : $($_.Exception.Message)" 'ERROR' }
    }
}

#endregion

#region 3. Services and scheduled tasks

# Legacy: gupdate, gupdatem. New updater: GoogleUpdaterService<ver>, GoogleUpdaterInternalService<ver>
Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '^gupdatem?$|^GoogleUpdater(Internal)?Service' -and $_.StartMode -eq 'Disabled' } |
    ForEach-Object {
        $newMode = if ($_.Name -match 'gupdatem|Internal') { 'Manual' } else { 'Automatic' }
        try {
            Set-Service -Name $_.Name -StartupType $newMode -ErrorAction Stop
            Write-Log "Service $($_.Name) changed from Disabled to $newMode" 'CHANGE'
        }
        catch { Write-Log "Failed to change service $($_.Name): $($_.Exception.Message)" 'ERROR' }
    }

Get-ScheduledTask -ErrorAction SilentlyContinue |
    Where-Object { $_.TaskName -match '^GoogleUpdate(r)?Task' -and $_.State -eq 'Disabled' } |
    ForEach-Object {
        try {
            Enable-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -ErrorAction Stop | Out-Null
            Write-Log "Enabled task $($_.TaskName)" 'CHANGE'
        }
        catch { Write-Log "Failed to enable task $($_.TaskName): $($_.Exception.Message)" 'ERROR' }
    }

#endregion

#region 4. Install the latest version if below minimum

$staged = Get-FileVersion (Join-Path $appDir 'new_chrome.exe')

if ($before -ge $MinimumVersion) {
    Write-Log 'Version already meets the minimum. No install needed.'
}
elseif ($staged -ge $MinimumVersion) {
    Write-Log "Chrome $staged is already staged and applies on next browser restart. No install needed."
}
else {
    try {
        Write-Log "Downloading $MsiUrl"
        Invoke-WebRequest -Uri $MsiUrl -OutFile $MsiPath -UseBasicParsing -ErrorAction Stop
        Write-Log ("Downloaded {0:N0} MB" -f ((Get-Item $MsiPath).Length / 1MB))

        # Only install if the file is genuinely signed by Google
        $sig = Get-AuthenticodeSignature -FilePath $MsiPath
        if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'O=Google LLC') {
            throw "MSI signature check failed: $($sig.Status) / $($sig.SignerCertificate.Subject)"
        }
        Write-Log 'Signature valid (Google LLC)'

        if ($ForceCloseChrome) {
            $procs = Get-Process -Name chrome -ErrorAction SilentlyContinue
            if ($procs) {
                $procs | Stop-Process -Force -ErrorAction SilentlyContinue
                Write-Log "Closed $(@($procs).Count) Chrome process(es)"
            }
        }

        Write-Log 'Running msiexec'
        $proc = Start-Process -FilePath "$env:SystemRoot\System32\msiexec.exe" `
            -ArgumentList "/i `"$MsiPath`" /qn /norestart /l*v `"$MsiLog`"" `
            -Wait -PassThru
        Write-Log "msiexec exit code: $($proc.ExitCode)"

        # 0 = success, 3010 = success but reboot required
        if ($proc.ExitCode -notin 0, 3010) {
            throw "msiexec failed with $($proc.ExitCode). See $MsiLog"
        }

        $appDir = Get-ChromeAppDir
        $after  = Get-FileVersion (Join-Path $appDir 'chrome.exe')
        $staged = Get-FileVersion (Join-Path $appDir 'new_chrome.exe')

        if ($after -ge $MinimumVersion) {
            Write-Log "Chrome updated: $before -> $after"
        }
        elseif ($staged -ge $MinimumVersion) {
            Write-Log "Chrome $staged installed and staged. Applies when the browser restarts (running $after)."
        }
        else {
            Write-Log "Install finished but version is still $after (staged: $staged). Check $MsiLog" 'ERROR'
        }
    }
    catch {
        Write-Log $_.Exception.Message 'ERROR'
    }
    finally {
        Remove-Item $MsiPath -Force -ErrorAction SilentlyContinue
    }
}

#endregion

#region 5. Start an update check

# Legacy: GoogleUpdateTaskMachineUA. New updater: GoogleUpdaterTaskSystem<ver>
Get-ScheduledTask -ErrorAction SilentlyContinue |
    Where-Object { $_.TaskName -match '^GoogleUpdateTaskMachineUA|^GoogleUpdaterTaskSystem' } |
    ForEach-Object {
        try {
            Start-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -ErrorAction Stop
            Write-Log "Started $($_.TaskName)"
        }
        catch { Write-Log "Could not start $($_.TaskName): $($_.Exception.Message)" 'WARN' }
    }

#endregion

if ($script:Failed) {
    Write-Log 'Completed with errors.' 'ERROR'
    exit 1
}
Write-Log 'Completed. Chrome is set to update automatically.'
exit 0
