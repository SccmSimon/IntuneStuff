# Detect-ChromeVersion.ps1
# Intune Remediations detection script. Exit 1 = non-compliant (remediation runs), exit 0 = compliant.
# Run as SYSTEM, 64-bit PowerShell.
# Author: Simon Diaz
#
# Non-compliant if EITHER:
#   - Chrome is below the minimum version, or
#   - anything is stopping Chrome from updating itself (policy, disabled service or task)

# Minimum Chrome version. Keep in step with the remediation script.
$MinimumVersion = [version]'156.0.8078.73'

# $true  = an update installed and waiting for a browser restart counts as compliant
# $false = stays non-compliant until Chrome is actually running the new version
$PendingRestartIsCompliant = $true

$ChromeAppGuid = '{8A69D345-D564-463C-AFF1-A69D9E530F96}'
$PolicyPath    = 'HKLM:\SOFTWARE\Policies\Google\Update'

function Get-FileVersion {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return $null }
    $v = (Get-Item $Path).VersionInfo.ProductVersion
    if ($v -match '(\d+\.\d+\.\d+\.\d+)') { return [version]$Matches[1] }
    return $null
}

$appDir = @(
    "$env:ProgramFiles\Google\Chrome\Application",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application"
) | Where-Object { Test-Path (Join-Path $_ 'chrome.exe') } | Select-Object -First 1

if (-not $appDir) {
    Write-Output 'Compliant: Chrome not installed system-wide'
    exit 0
}

$issues = New-Object System.Collections.Generic.List[string]

#region Version

$current = Get-FileVersion (Join-Path $appDir 'chrome.exe')
$staged  = Get-FileVersion (Join-Path $appDir 'new_chrome.exe')
$versionText = "Chrome $current"

if ($current -lt $MinimumVersion) {
    if ($staged -and $staged -ge $MinimumVersion) {
        $versionText = "Chrome $current, staged $staged (pending browser restart)"
        if (-not $PendingRestartIsCompliant) { $issues.Add("waiting for restart to apply $staged") }
    }
    else {
        $issues.Add("Chrome $current < $MinimumVersion")
    }
}

#endregion

#region Update blockers

if (Test-Path $PolicyPath) {
    $p = Get-ItemProperty -Path $PolicyPath

    if ($null -ne $p.AutoUpdateCheckPeriodMinutes -and $p.AutoUpdateCheckPeriodMinutes -eq 0) {
        $issues.Add('AutoUpdateCheckPeriodMinutes=0')
    }
    foreach ($name in 'UpdateDefault', "Update$ChromeAppGuid") {
        $val = $p.$name
        if ($null -ne $val -and $val -notin 1, 3) { $issues.Add("$name=$val") }
    }
    foreach ($name in 'InstallDefault', "Install$ChromeAppGuid") {
        $val = $p.$name
        if ($null -ne $val -and $val -eq 0) { $issues.Add("$name=0") }
    }
    foreach ($name in "TargetVersionPrefix$ChromeAppGuid", "RollbackToTargetVersion$ChromeAppGuid", 'DisableAutoUpdateChecksCheckboxValue') {
        if ($null -ne $p.$name) { $issues.Add("$name=$($p.$name)") }
    }
}

Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match '^gupdatem?$|^GoogleUpdater(Internal)?Service' -and $_.StartMode -eq 'Disabled' } |
    ForEach-Object { $issues.Add("service $($_.Name) disabled") }

Get-ScheduledTask -ErrorAction SilentlyContinue |
    Where-Object { $_.TaskName -match '^GoogleUpdate(r)?Task' -and $_.State -eq 'Disabled' } |
    ForEach-Object { $issues.Add("task $($_.TaskName) disabled") }

#endregion

if ($issues.Count -eq 0) {
    Write-Output "Compliant: $versionText, auto-update enabled"
    exit 0
}

Write-Output "NonCompliant: $versionText | $($issues -join '; ')"
exit 1
