# Detect-DotNetRuntimeDependency.ps1

Intune Remediations detection script for an end-of-life .NET / .NET Core runtime (Qualys EOL findings such as .NET Core 3.1 or .NET 6). It finds the runtime, the apps that depend on it, and which architecture roots (x86, x64) can be removed safely.

Version 1.3.1.

## What it reports
1. Shared framework versions installed in the x64 and x86 `dotnet\shared` roots.
2. Framework-dependent apps whose `*.runtimeconfig.json` declares the target version, with architecture read from the apphost PE header and the `rollForward` policy.
3. Self-contained apps carrying a private copy (bundled `coreclr.dll`).
4. A per-device verdict:

| Verdict | Meaning |
|---|---|
| CAT A | Runtime installed, nothing uses it. Removal candidate |
| CAT B | Dependent apps exist but all can roll forward to a newer installed major. Verify, then remove |
| CAT C | At least one app blocks removal, either pinned by `rollForward` or with no newer major of its framework installed |

Read the `removable:` field, not just the category. A device can be CAT C overall and still have a removable x86 root.

## Settings (top of script)
| Variable | Default | Purpose |
|---|---|---|
| `$TargetVersion` | `'6.0'` | Version prefix. Set to `3.1`, `8.0` and so on to reuse |
| `$IncludeSelfContained` | `$true` | Check bundled `coreclr.dll` versions |
| `$SearchPaths` | Program Files, Program Files (x86), ProgramData, inetpub\wwwroot | Folders scanned |
| `$ExcludePathPatterns` | dotnet\shared, dotnet\sdk, Common7\IDE\CommonExtensions | Tooling configs that are not apps |

## Exit codes
- 0: runtime not installed and no self-contained copies
- 1: runtime installed or a private copy present (keeps the device in the report)

## Intune settings
| Setting | Value |
|---|---|
| Run using logged-on credentials | No (SYSTEM) |
| Run in 64-bit PowerShell | Yes (required) |

Log: `%ProgramData%\Microsoft\IntuneManagementExtension\Logs\DotNetRuntime-Dependency-Detection.log` (CMTrace format).

## Known gaps
- Single-file published apps embed `runtimeconfig.json` in the exe.
- Per-user installs are not visible to SYSTEM.
- Apps launched via `dotnet app.dll` have no apphost, so architecture is Unknown and treated as blocking both roots.
- Roll-forward is checked per framework: a WPF/WinForms app needs a newer `Microsoft.WindowsDesktop.App`, not just `Microsoft.NETCore.App`.
