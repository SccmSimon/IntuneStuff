<#
.SYNOPSIS
    Detects an end-of-life .NET / .NET Core runtime, the applications that
    genuinely depend on it, and which architecture roots can safely be removed.

.DESCRIPTION
    Reports per device:
      1. Installed shared framework versions in the x64 and x86 roots.
      2. Framework-dependent applications declaring a dependency, with true
         architecture read from the apphost PE header and roll-forward policy.
      3. Self-contained applications carrying a private copy.
      4. A computed verdict: which architecture roots are removable, which are
         blocked, and by what.

    Tooling artefacts are excluded by path (shared framework configs, SDK
    testhost templates, Visual Studio test infrastructure).

    Exit 1 if the runtime is installed OR any self-contained copy is present.
    Exit 0 only if neither is true.

.NOTES
    Author:     Simon Diaz
    Version:    1.3.1
    Changes:    1.3.1 - Roll-forward availability now evaluated per framework
                        (Microsoft.WindowsDesktop.App, Microsoft.AspNetCore.App
                        and Microsoft.NETCore.App are tracked separately) rather
                        than assuming Microsoft.NETCore.App. Blocking apps now
                        distinguish "pinned" from "no newer major installed".
                        Framework name restored to the MATCH log line.
                1.3.0 - PE-header architecture, per-device removability verdict.
                1.2.0 - Path exclusions for tooling, deduplicated output.
                1.1.0 - Dual-architecture inventory, rollForward reporting.
                1.0.1 - Fixed -replace parse error inside hashtable literal.
                1.0.0 - Initial version.

    Deployment: Intune > Devices > Scripts and remediations > Detection script
                Run in 64-bit PowerShell: Yes (required)
                Run using logged-on credentials: No (SYSTEM)

    KNOWN GAPS: single-file published applications embed runtimeconfig.json in
    the executable. Per-user installations are not visible to SYSTEM. Apps
    launched via "dotnet app.dll" have no apphost and report Unknown
    architecture, which is treated conservatively as blocking both roots.
#>

#region Configuration
$TargetVersion        = '6.0'      # version prefix, e.g. '3.1', '6.0', '8.0'
$IncludeSelfContained = $true

$SearchPaths = @(
    "$env:ProgramFiles",
    "${env:ProgramFiles(x86)}",
    "$env:ProgramData",
    "C:\inetpub\wwwroot"
)

$ExcludePathPatterns = @(
    '*\dotnet\shared\*',                # shared framework's own configs
    '*\dotnet\sdk\*',                   # SDK testhost-*.runtimeconfig templates
    '*\Common7\IDE\CommonExtensions\*'  # Visual Studio test infrastructure
)

$DotnetRoots = @(
    @{ Arch = 'x64'; Path = Join-Path $env:ProgramFiles 'dotnet\shared' },
    @{ Arch = 'x86'; Path = Join-Path ${env:ProgramFiles(x86)} 'dotnet\shared' }
)

$LogFolder    = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs'
$LogFile      = Join-Path $LogFolder 'DotNetRuntime-Dependency-Detection.log'
$Component    = 'DotNetRuntimeDependencyDetection'
$MaxLogSizeMB = 5

$TargetMajor = [int]($TargetVersion.Split('.')[0])
#endregion

#region Logging (CMTrace format)
function Write-CMLog {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('Info', 'Warning', 'Error')][string]$Severity = 'Info'
    )
    $typeMap  = @{ Info = 1; Warning = 2; Error = 3 }
    $time     = Get-Date -Format 'HH:mm:ss.fff'
    $date     = Get-Date -Format 'MM-dd-yyyy'
    $template = '<![LOG[{0}]LOG]!><time="{1}+000" date="{2}" component="{3}" context="" type="{4}" thread="{5}" file="">'
    $line     = $template -f $Message, $time, $date, $Component, $typeMap[$Severity], $PID
    try { Add-Content -Path $LogFile -Value $line -Encoding UTF8 -ErrorAction Stop } catch { }
}

try {
    if (-not (Test-Path $LogFolder)) {
        New-Item -Path $LogFolder -ItemType Directory -Force | Out-Null
    }
    if ((Test-Path $LogFile) -and ((Get-Item $LogFile).Length / 1MB -gt $MaxLogSizeMB)) {
        $rolled = $LogFile -replace '\.log$', '.lo_'
        Move-Item -Path $LogFile -Destination $rolled -Force -ErrorAction SilentlyContinue
    }
} catch { }
#endregion

#region PE architecture
# A framework-dependent app's apphost is a native executable; its bitness
# determines which dotnet root it loads hostfxr from. This is deterministic,
# unlike guessing from the install path.
function Get-PEArchitecture {
    param([Parameter(Mandatory)][string]$Path)

    $fs = $null
    try {
        $fs = [System.IO.File]::OpenRead($Path)
        $size = [Math]::Min(4096, $fs.Length)
        if ($size -lt 0x40) { return 'Unknown' }

        $buffer = New-Object byte[] $size
        [void]$fs.Read($buffer, 0, $size)

        $peOffset = [BitConverter]::ToInt32($buffer, 0x3C)
        if ($peOffset -le 0 -or ($peOffset + 6) -ge $size) { return 'Unknown' }
        if ([BitConverter]::ToUInt32($buffer, $peOffset) -ne 0x00004550) { return 'Unknown' }  # 'PE\0\0'

        switch ([BitConverter]::ToUInt16($buffer, $peOffset + 4)) {
            0x014C  { 'x86'     }
            0x8664  { 'x64'     }
            0xAA64  { 'ARM64'   }
            default { 'Unknown' }
        }
    } catch {
        'Unknown'
    } finally {
        if ($fs) { $fs.Dispose() }
    }
}
#endregion

Write-CMLog -Message "=== Scan start: target .NET $TargetVersion, host $env:COMPUTERNAME, script v1.3.1 ==="

#region 1. Installed shared runtime inventory
# All versions are inventoried, not just the target. A newer major installed
# alongside is what makes roll-forward a viable remediation route.
$allRuntimes = [System.Collections.Generic.List[object]]::new()

foreach ($root in $DotnetRoots) {
    if (-not (Test-Path $root.Path)) { continue }

    Get-ChildItem -Path $root.Path -Directory -ErrorAction SilentlyContinue |
        ForEach-Object {
            $frameworkName = $_.Name
            Get-ChildItem -Path $_.FullName -Directory -ErrorAction SilentlyContinue |
                ForEach-Object {
                    $major = 0
                    [void][int]::TryParse(($_.Name.Split('.')[0]), [ref]$major)
                    $allRuntimes.Add([PSCustomObject]@{
                        Framework = $frameworkName
                        Version   = $_.Name
                        Major     = $major
                        Arch      = $root.Arch
                        Path      = $_.FullName
                    })
                }
        }
}

$targetRuntimes = @($allRuntimes | Where-Object { $_.Version -like "$TargetVersion*" })
$targetArches   = @($targetRuntimes.Arch | Sort-Object -Unique)

# Newer-major availability, keyed per architecture AND per framework.
# A WPF/WinForms app needs a newer Microsoft.WindowsDesktop.App, not just
# Microsoft.NETCore.App. Checking only the latter gives false "safe" results.
$newerMajorLookup = @{}
foreach ($r in $allRuntimes) {
    if ($r.Major -gt $TargetMajor) {
        $newerMajorLookup["$($r.Arch)|$($r.Framework)"] = $true
    }
}

foreach ($r in $targetRuntimes) {
    Write-CMLog -Message "RUNTIME: $($r.Framework) $($r.Version) [$($r.Arch)] - $($r.Path)"
}
if ($targetRuntimes.Count -eq 0) {
    Write-CMLog -Message "RUNTIME: no .NET $TargetVersion shared framework installed"
}
foreach ($key in ($newerMajorLookup.Keys | Sort-Object)) {
    Write-CMLog -Message "ROLLFORWARD-TARGET: newer major available for $key"
}
#endregion

#region 2. Application dependency scan
$findings             = [System.Collections.Generic.List[object]]::new()
$script:excludedCount = 0

foreach ($root in $SearchPaths | Where-Object { $_ -and (Test-Path $_) }) {
    Get-ChildItem -Path $root -Recurse -Filter '*.runtimeconfig.json' -ErrorAction SilentlyContinue |
        ForEach-Object {
            $configFile = $_

            foreach ($pattern in $ExcludePathPatterns) {
                if ($configFile.FullName -like $pattern) {
                    $script:excludedCount++
                    return
                }
            }

            try {
                $config = Get-Content $configFile.FullName -Raw -ErrorAction Stop |
                          ConvertFrom-Json -ErrorAction Stop
            } catch {
                Write-CMLog -Severity Warning -Message "Parse failed: $($configFile.FullName) - $($_.Exception.Message)"
                return
            }

            $appName = $configFile.BaseName -replace '\.runtimeconfig$', ''

            $rollForward = if ($config.runtimeOptions.rollForward) {
                $config.runtimeOptions.rollForward
            } else {
                'minor (default)'
            }
            $crossesMajor = $rollForward -match '^(Major|LatestMajor)$'

            # True architecture from the apphost next to the config.
            $appHost = Join-Path $configFile.DirectoryName "$appName.exe"
            $arch    = if (Test-Path $appHost) { Get-PEArchitecture -Path $appHost } else { 'Unknown' }

            $frameworks = @()
            if ($config.runtimeOptions.framework)  { $frameworks += $config.runtimeOptions.framework }
            if ($config.runtimeOptions.frameworks) { $frameworks += $config.runtimeOptions.frameworks }

            foreach ($fw in $frameworks) {
                if ($fw.version -like "$TargetVersion*") {

                    $classification = if ($fw.version -match '-preview|-rc|-beta|-alpha') {
                        'Placeholder version - verify'
                    } else {
                        'Application'
                    }

                    $rollTargetAvailable = [bool]$newerMajorLookup["$arch|$($fw.name)"]

                    # Which architecture roots does this app prevent us from
                    # removing, and is that pinned or merely unsatisfied?
                    if ($arch -eq 'Unknown') {
                        $impact = 'BLOCKS (arch unknown)'
                        $blocks = @('x86', 'x64')
                    } elseif ($crossesMajor -and $rollTargetAvailable) {
                        $impact = 'Roll-forward available'
                        $blocks = @()
                    } elseif ($crossesMajor) {
                        $impact = "BLOCKS $arch (no newer $($fw.name) installed)"
                        $blocks = @($arch)
                    } else {
                        $impact = "BLOCKS $arch (pinned by rollForward)"
                        $blocks = @($arch)
                    }

                    $findings.Add([PSCustomObject]@{
                        Application    = $appName
                        Path           = $configFile.FullName
                        Framework      = $fw.name
                        Version        = $fw.version
                        RollForward    = $rollForward
                        Arch           = $arch
                        Type           = 'Framework-dependent'
                        Classification = $classification
                        Impact         = $impact
                        Blocks         = $blocks
                    })
                }
            }

            if ($IncludeSelfContained -and -not $frameworks) {
                $coreclr = Join-Path $configFile.DirectoryName 'coreclr.dll'
                if (Test-Path $coreclr) {
                    $fileVersion = (Get-Item $coreclr).VersionInfo.ProductVersion
                    if ($fileVersion -like "$TargetVersion*") {
                        # A private copy is separate exposure, but it does not
                        # depend on the shared runtime and so blocks nothing.
                        $findings.Add([PSCustomObject]@{
                            Application    = $appName
                            Path           = $configFile.FullName
                            Framework      = '(bundled)'
                            Version        = $fileVersion
                            RollForward    = 'n/a'
                            Arch           = $arch
                            Type           = 'Self-contained'
                            Classification = 'Application'
                            Impact         = 'Private copy - vendor update required'
                            Blocks         = @()
                        })
                    }
                }
            }
        }
}

Write-CMLog -Message "Excluded $($script:excludedCount) tooling/framework config file(s) by path"

foreach ($f in $findings) {
    Write-CMLog -Message ("MATCH: {0} | {1} | {2} | {3} v{4} | rf={5} | {6} | {7} | {8}" -f `
        $f.Application, $f.Type, $f.Arch, $f.Framework, $f.Version, $f.RollForward,
        $f.Impact, $f.Classification, $f.Path)
}
#endregion

#region 3. Verdict
$frameworkDependent = @($findings | Where-Object { $_.Type -eq 'Framework-dependent' })
$selfContained      = @($findings | Where-Object { $_.Type -eq 'Self-contained' })
$blockingApps       = @($frameworkDependent | Where-Object { $_.Blocks.Count -gt 0 })

if ($targetRuntimes.Count -eq 0 -and $selfContained.Count -eq 0) {
    Write-CMLog -Message "RESULT: Compliant - no .NET $TargetVersion runtime or bundled copy present"
    Write-Output "Compliant: no .NET $TargetVersion runtime installed and no self-contained copies found"
    exit 0
}

$blockedArches   = @($blockingApps | ForEach-Object { $_.Blocks } | Sort-Object -Unique)
$removableArches = @($targetArches | Where-Object { $_ -notin $blockedArches })

$verdict = if ($blockingApps.Count -gt 0) {
    'CAT C'   # migration required for at least one architecture
} elseif ($frameworkDependent.Count -gt 0) {
    'CAT B'   # dependencies exist but all can roll forward - verify then remove
} else {
    'CAT A'   # nothing consumes the runtime - removal candidate
}

$runtimeSummary = if ($targetRuntimes.Count -gt 0) {
    ($targetRuntimes | Group-Object Arch | ForEach-Object {
        "{0}:{1}" -f $_.Name, (($_.Group.Version | Sort-Object -Unique) -join ',')
    }) -join ' '
} else {
    'none (self-contained only)'
}

$removableText = if ($removableArches.Count) { $removableArches -join ',' } else { 'none' }
$blockedText   = if ($blockedArches.Count)   { $blockedArches -join ','   } else { 'none' }
$scText        = if ($selfContained.Count)   { "; $($selfContained.Count) self-contained copy(ies)" } else { '' }

Write-CMLog -Message "RESULT: $verdict | installed $runtimeSummary | removable: $removableText | blocked: $blockedText | $($frameworkDependent.Count) dependent occurrence(s)$scText"

$grouped = $findings | Group-Object Application, Version, Type, Arch, Impact
$lines = $grouped | ForEach-Object {
    $f      = $_.Group[0]
    $suffix = if ($_.Count -gt 1) { " x$($_.Count)" } else { '' }
    $flag   = if ($f.Classification -ne 'Application') { ", $($f.Classification)" } else { '' }
    "{0} (v{1}, {2}, rf={3}, {4}{5}){6}" -f `
        $f.Application, $f.Version, $f.Arch, $f.RollForward, $f.Impact, $flag, $suffix
}

$header = "[$verdict] .NET $TargetVersion on $($env:COMPUTERNAME) | installed $runtimeSummary | removable: $removableText | blocked: $blockedText | $($grouped.Count) distinct, $($findings.Count) occurrence(s)$scText | Log: $LogFile`n"

# Intune shows up to 2048 characters of output. Keep under that.
$budget = 2000 - $header.Length
$kept = [System.Collections.Generic.List[string]]::new()
$used = 0
foreach ($line in $lines) {
    if (($used + $line.Length + 2) -gt $budget) { break }
    $kept.Add($line)
    $used += $line.Length + 2
}
$body = $kept -join '; '
if ($kept.Count -lt $lines.Count) {
    $body += "; ... ($($lines.Count - $kept.Count) more, see log)"
}
if ($findings.Count -eq 0) {
    $body = 'No dependent applications found - runtime is a removal candidate on all installed architectures'
}

Write-Output ($header + $body)
exit 1
#endregion
