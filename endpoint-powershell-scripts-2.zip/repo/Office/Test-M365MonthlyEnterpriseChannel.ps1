<#
.SYNOPSIS
    Tests whether a device can reach the Microsoft 365 Apps Monthly Enterprise Channel update source.

.DESCRIPTION
    Runs four groups of checks:
      1. Reports the device's current Click-to-Run channel and any update policy (registry).
      2. Reports the WinHTTP proxy (the Click-to-Run service runs as SYSTEM and uses this, not the user's browser proxy).
      3. For each required endpoint: DNS resolution and TCP connect on the required ports.
      4. Fetches the Monthly Enterprise Channel version cab (v64.cab / v32.cab) from the CDN with an HTTP HEAD request.
         If this works, the device can see what build is current on the channel.

    Returns exit code 0 if every critical check passes, 1 if any fail.
    Usable as an Intune Remediations detection script.

.PARAMETER LogPath
    Optional path to write a CSV of the results.

.PARAMETER TimeoutMs
    TCP connect timeout in milliseconds. Default 3000.

.EXAMPLE
    .\Test-M365MonthlyEnterpriseChannel.ps1

.EXAMPLE
    .\Test-M365MonthlyEnterpriseChannel.ps1 -LogPath C:\Temp\MEC-Connectivity.csv

.NOTES
    Author : Simon Diaz
    Works on Windows PowerShell 5.1 and PowerShell 7.
    For a true picture of what the Office update service sees, run it as SYSTEM
    (e.g. via Intune, or psexec -s -i powershell.exe) because SYSTEM may use a different proxy than your user.
#>

[CmdletBinding()]
param(
    [string]$LogPath,
    [int]$TimeoutMs = 3000
)

# Monthly Enterprise Channel GUID (used in the CDN path)
$ChannelName = 'Monthly Enterprise Channel'
$ChannelGuid = '55336b82-a18d-4dd6-b5f6-9e5095c314a6'
$CdnBase     = "https://officecdn.microsoft.com/pr/$ChannelGuid"

# Endpoints Click-to-Run needs for updates. Critical = update fails without it.
$Endpoints = @(
    [pscustomobject]@{ Host = 'officecdn.microsoft.com';               Ports = 80,443; Critical = $true;  Purpose = 'Office CDN (update payload)' }
    [pscustomobject]@{ Host = 'officecdn.microsoft.com.edgesuite.net'; Ports = 80,443; Critical = $true;  Purpose = 'Office CDN (Akamai edge)' }
    [pscustomobject]@{ Host = 'clients.config.office.net';             Ports = ,443;   Critical = $false; Purpose = 'Servicing / version info' }
    [pscustomobject]@{ Host = 'config.office.com';                     Ports = ,443;   Critical = $false; Purpose = 'Cloud Policy / Servicing profile' }
    [pscustomobject]@{ Host = 'officeclient.microsoft.com';            Ports = ,443;   Critical = $false; Purpose = 'Office client config service' }
)

# Force TLS 1.2 for Windows PowerShell 5.1 (it can default to older protocols)
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
} catch { }

$Results = New-Object System.Collections.Generic.List[object]

function Add-Result {
    param($Check, $Target, $Passed, $Critical, $Detail)
    $Results.Add([pscustomobject]@{
        Check    = $Check
        Target   = $Target
        Result   = if ($Passed) { 'PASS' } else { 'FAIL' }
        Critical = $Critical
        Detail   = $Detail
    })
}

function Test-TcpPort {
    # TcpClient with a manual timeout. Test-NetConnection is slower and has no timeout control.
    param([string]$HostName, [int]$Port, [int]$Timeout)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($HostName, $Port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne($Timeout, $false)) { return 'Timed out' }
        $client.EndConnect($async)
        return 'Connected'
    } catch {
        return $_.Exception.InnerException.Message
    } finally {
        $client.Close()
    }
}

Write-Host ""
Write-Host "=== Microsoft 365 Apps: $ChannelName connectivity test ===" -ForegroundColor Cyan
Write-Host "Device: $env:COMPUTERNAME   Running as: $([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
Write-Host ""

# ---------- 1. Current Click-to-Run configuration ----------
Write-Host "[1] Current Office configuration" -ForegroundColor Yellow
$c2r = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration' -ErrorAction SilentlyContinue
if ($c2r) {
    $currentChannelGuid = if ($c2r.UpdateChannel) { ($c2r.UpdateChannel -split '/')[-1] } elseif ($c2r.CDNBaseUrl) { ($c2r.CDNBaseUrl -split '/')[-1] } else { $null }
    "    Version       : {0}" -f $c2r.VersionToReport | Write-Host
    "    CDNBaseUrl    : {0}" -f $c2r.CDNBaseUrl      | Write-Host
    "    UpdateChannel : {0}" -f $c2r.UpdateChannel   | Write-Host
    "    UpdateUrl     : {0}" -f $c2r.UpdateUrl       | Write-Host
    if ($c2r.UpdateUrl) {
        Write-Host "    Note: UpdateUrl is set, so Office updates from that location, not the CDN." -ForegroundColor DarkYellow
    }
    if ($currentChannelGuid -eq $ChannelGuid) {
        Write-Host "    Device is on $ChannelName." -ForegroundColor Green
    } else {
        Write-Host "    Device is NOT currently on $ChannelName (GUID: $currentChannelGuid)." -ForegroundColor DarkYellow
    }
} else {
    Write-Host "    Click-to-Run not found. Microsoft 365 Apps may not be installed." -ForegroundColor DarkYellow
}

$policy = Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\office\16.0\common\officeupdate' -ErrorAction SilentlyContinue
if ($policy) {
    "    Policy updatebranch : {0}" -f $policy.updatebranch | Write-Host
    "    Policy updatepath   : {0}" -f $policy.updatepath   | Write-Host
    "    Policy enableautomaticupdates : {0}" -f $policy.enableautomaticupdates | Write-Host
}
Write-Host ""

# ---------- 2. Proxy ----------
Write-Host "[2] WinHTTP proxy (used by the Click-to-Run service)" -ForegroundColor Yellow
$winhttp = (netsh winhttp show proxy) -join "`n"
$proxyLine = ($winhttp -split "`n" | Where-Object { $_ -match 'Proxy Server|Direct access' }) -join '; '
Write-Host "    $($proxyLine.Trim())"
Write-Host ""

# ---------- 3. DNS and TCP per endpoint ----------
Write-Host "[3] DNS and TCP checks" -ForegroundColor Yellow
foreach ($ep in $Endpoints) {
    try {
        $ips = [System.Net.Dns]::GetHostAddresses($ep.Host) | Select-Object -ExpandProperty IPAddressToString
        Add-Result 'DNS' $ep.Host $true $ep.Critical ($ips -join ', ')
        $dnsOk = $true
    } catch {
        Add-Result 'DNS' $ep.Host $false $ep.Critical $_.Exception.InnerException.Message
        $dnsOk = $false
    }

    foreach ($port in $ep.Ports) {
        if (-not $dnsOk) {
            Add-Result "TCP $port" $ep.Host $false $ep.Critical 'Skipped, DNS failed'
            continue
        }
        $tcp = Test-TcpPort -HostName $ep.Host -Port $port -Timeout $TimeoutMs
        Add-Result "TCP $port" $ep.Host ($tcp -eq 'Connected') $ep.Critical $tcp
    }
}

# ---------- 4. Channel content check ----------
Write-Host "[4] Channel content check (HTTP HEAD on version cabs)" -ForegroundColor Yellow
foreach ($cab in 'v64.cab','v32.cab') {
    $url = "$CdnBase/Office/Data/$cab"
    try {
        $params = @{ Uri = $url; Method = 'Head'; TimeoutSec = 15; ErrorAction = 'Stop' }
        if ($PSVersionTable.PSVersion.Major -lt 6) { $params.UseBasicParsing = $true }
        $resp = Invoke-WebRequest @params
        $size = $resp.Headers['Content-Length']
        $mod  = $resp.Headers['Last-Modified']
        Add-Result 'HTTPS HEAD' $url $true $true "HTTP $($resp.StatusCode), $size bytes, Last-Modified $mod"
    } catch {
        $status = $null
        if ($_.Exception.Response) { $status = [int]$_.Exception.Response.StatusCode }
        $msg = if ($status) { "HTTP $status" } else { $_.Exception.Message }
        Add-Result 'HTTPS HEAD' $url $false $true $msg
    }
}
Write-Host ""

# ---------- Output ----------
$Results | Format-Table Check, Target, Result, Critical, Detail -AutoSize -Wrap

if ($LogPath) {
    $Results | Export-Csv -Path $LogPath -NoTypeInformation -Force
    Write-Host "Results written to $LogPath"
}

$criticalFails = @($Results | Where-Object { $_.Result -eq 'FAIL' -and $_.Critical })
$otherFails    = @($Results | Where-Object { $_.Result -eq 'FAIL' -and -not $_.Critical })

if ($criticalFails.Count -eq 0) {
    Write-Host "RESULT: Device CAN reach the $ChannelName update source." -ForegroundColor Green
    if ($otherFails.Count -gt 0) {
        Write-Host "        $($otherFails.Count) non-critical check(s) failed. Updates should work, but Cloud Policy / servicing features may not." -ForegroundColor DarkYellow
    }
    exit 0
} else {
    Write-Host "RESULT: Device CANNOT reliably reach the $ChannelName update source. $($criticalFails.Count) critical check(s) failed." -ForegroundColor Red
    exit 1
}
