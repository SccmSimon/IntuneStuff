<#
.SYNOPSIS
    Intune Remediations detection script. Checks whether classic Outlook in
    Microsoft 365 Apps (Click-to-Run) is at or above a fixed security build.

.DESCRIPTION
    Mirrors the Qualys QID logic for the Outlook vulnerability:
      - Install path for Microsoft Office read from the registry
      - File version of the Office executable checked against the fixed build
      - Result reported against root\Office16\OUTLOOK.EXE

    This script does the same:
      1. Reads InstallPath from the Click-to-Run registry key
      2. Reads the file version of OUTLOOK.EXE (the file Qualys reports)
      3. Also reads GRAPH.EXE (named in the QID detection logic)
      4. Compares both against the Monthly Enterprise fixed build

    The channel is read and reported, so any device that has drifted to
    another channel shows up in the output.

    Exit 1 = vulnerable (remediation runs)
    Exit 0 = patched, Outlook not installed, or not Click-to-Run

    Run as SYSTEM, 64-bit PowerShell: Yes

.NOTES
    Version : 2.1
    Author  : Simon Diaz
    History : 1.0  Initial. Checked VersionToReport against per-channel minimum build
              2.0  Aligned to QID 110543. Checks OUTLOOK.EXE and GRAPH.EXE file versions from the
                   Click-to-Run InstallPath. Output includes the QID and the file Qualys reports
              2.1  Single fixed build for Monthly Enterprise. Removed the per-channel table.
                   Devices not on Monthly Enterprise are flagged in the output

    Update $qid and $fixedBuild for each new advisory.
#>

# ===== Settings =====
$qid             = '110543'
$fixedBuild      = [version]'16.0.20527.20194'   # Monthly Enterprise, November 2026
$expectedChannel = 'MonthlyEnterprise'

$channelMap = @{
    '492350f6-3a01-4f97-b9c0-c7c6ddf67d60' = 'Current'
    '64256afe-f5d9-4f86-8936-8840a6a4f5be' = 'CurrentPreview'
    '55336b82-a18d-4dd6-b5f6-9e5095c314a6' = 'MonthlyEnterprise'
    '7ffbc6bf-bc32-4f92-8982-f9dd17fd3114' = 'SemiAnnual'
    'b8f9b850-328d-4355-9145-c59439a0c4cf' = 'SemiAnnualPreview'
}

$c2rKey   = 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun'
$cfgKey   = "$c2rKey\Configuration"
$cloudKey = 'HKLM:\SOFTWARE\Policies\Microsoft\cloud\office\16.0\Common\officeupdate'

function Get-FileVer ($Path) {
    if (-not (Test-Path $Path)) { return $null }
    $vi = (Get-Item $Path).VersionInfo
    # Build from the numeric parts. FileVersion is a string and can carry extra text.
    [version]('{0}.{1}.{2}.{3}' -f $vi.FileMajorPart, $vi.FileMinorPart, $vi.FileBuildPart, $vi.FilePrivatePart)
}

# ===== 1. Office install path from the registry =====
$c2r = Get-ItemProperty $c2rKey -ErrorAction SilentlyContinue
$cfg = Get-ItemProperty $cfgKey -ErrorAction SilentlyContinue

if (-not $c2r.InstallPath) {
    Write-Output "QID $qid | Not applicable | Click-to-Run Office not installed"
    exit 0
}

$office16 = Join-Path $c2r.InstallPath 'root\Office16'
$outlook  = Join-Path $office16 'OUTLOOK.EXE'
$graph    = Join-Path $office16 'GRAPH.EXE'

# ===== 2. File versions =====
$outlookVer = Get-FileVer $outlook
$graphVer   = Get-FileVer $graph

if (-not $outlookVer) {
    Write-Output "QID $qid | Not applicable | OUTLOOK.EXE not found in $office16 | Suite=$($cfg.VersionToReport)"
    exit 0
}

# ===== 3. Channel (reported only) =====
# Cloud Update branch first, then UpdateChannel, then the install source
$channel = (Get-ItemProperty $cloudKey -ErrorAction SilentlyContinue).updatebranch
if (-not $channel) {
    $source  = if ($cfg.UpdateChannel) { $cfg.UpdateChannel } else { $cfg.CDNBaseUrl }
    $guid    = [regex]::Match("$source", '[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}').Value.ToLower()
    $channel = $channelMap[$guid]
}
if (-not $channel) { $channel = 'unknown' }

$channelNote = if ($channel -ne $expectedChannel) { " | WARNING: not on $expectedChannel" } else { '' }

$detail = "OUTLOOK.EXE=$outlookVer | GRAPH.EXE=$(if ($graphVer) { $graphVer } else { 'not found' }) | " +
          "Suite=$($cfg.VersionToReport) | Channel=$channel$channelNote"

# ===== 4. Compare =====
# Flag if either executable is below the fixed build. Qualys reports OUTLOOK.EXE and
# its logic names GRAPH.EXE, so checking both avoids a mismatch with the scan.
$vulnerable = ($outlookVer -lt $fixedBuild) -or ($graphVer -and $graphVer -lt $fixedBuild)

if ($vulnerable) {
    Write-Output "QID $qid | VULNERABLE | Needs $fixedBuild+ | $detail"
    exit 1
}

Write-Output "QID $qid | OK | $detail"
exit 0
