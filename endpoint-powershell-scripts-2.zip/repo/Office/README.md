# Microsoft 365 Apps forced security update (Intune Remediation pair)

| Script | Role |
|---|---|
| `Detect-OfficeUpdate.ps1` | Detection: is classic Outlook below the fixed build? |
| `Remediate-OfficeUpdateDiag.ps1` | Remediation: warn users, force the exact build, report why it did or didn't update |

Built for an Outlook vulnerability (Qualys QID 110543, fixed build 16.0.20527.20194 on Monthly Enterprise Channel). Change `$qid`, `$fixedBuild` and `$targetBuild` for each new advisory.

## Detect-OfficeUpdate.ps1 (v2.1)
Matches how Qualys detects the issue:
1. Reads `InstallPath` from `HKLM:\SOFTWARE\Microsoft\Office\ClickToRun` and builds `root\Office16`.
2. Reads the file versions of `OUTLOOK.EXE` and `GRAPH.EXE` (numeric parts, not the FileVersion string).
3. Compares both to `$fixedBuild`. Exit 1 if either is lower.
4. Reports the channel from Cloud Update, `UpdateChannel` or `CDNBaseUrl`, and warns if a device is not on Monthly Enterprise.

Output example: `QID 110543 | VULNERABLE | Needs 16.0.20527.20194+ | OUTLOOK.EXE=... | Channel=MonthlyEnterprise`

## Remediate-OfficeUpdateDiag.ps1
1. Logs the update configuration: channel, CDN, update URL, SCCM management, GPO pins and every Cloud Update value.
2. If Office apps are open, shows a popup forced on top of other windows (WTSSendMessage via inline C#), waits `$countdownMinutes` (default 10) with a 2-minute reminder.
3. Raises Cloud Update `updatetargetversion` to the target build if it is lower or missing (never lowers it).
4. Runs `OfficeC2RClient.exe /update user updatetoversion=<build> forceappshutdown=true`.
5. Polls `VersionToReport` every 30 seconds for up to `$maxWaitMinutes` (default 40), then shows a completion popup.
6. Removes `updatetargetversion` only if the script created it, so the device is not pinned.
7. Extracts relevant lines from the Click-to-Run logs in `%windir%\Temp` and writes a summary (under 2,000 characters) to the Intune output column.

Log: `%ProgramData%\Microsoft\IntuneManagementExtension\Logs\OfficeForceUpdate.log`

## Intune settings
| Setting | Value |
|---|---|
| Run using logged-on credentials | No (SYSTEM) |
| Run in 64-bit PowerShell | Yes |
| Schedule | Daily, assign to a pilot group first |

## Notes
- Worst-case runtime is about 50 minutes, under the remediation timeout. If you raise the countdown, lower the wait by the same amount.
- Where Cloud Update (`ignoregpo=1`) manages updates it will overwrite the target on its next sync. That is expected once the device is patched.
- If the build does not change, check the device's rollout wave or exclusions in the Microsoft 365 Apps admin center.
- Users who are not running Office get no popups and are updated silently.

---

# Test-M365MonthlyEnterpriseChannel.ps1

Checks whether a device can reach the Microsoft 365 Apps Monthly Enterprise Channel update source.

1. Reports the Click-to-Run channel (`CDNBaseUrl`, `UpdateChannel`, `UpdateUrl`) and any `officeupdate` policy. Flags `UpdateUrl` because it overrides the CDN.
2. Shows the WinHTTP proxy, which the SYSTEM-run Click-to-Run service uses.
3. DNS and TCP (3-second timeout) checks for the Office CDN and config endpoints. CDN hosts are critical, config hosts are warnings.
4. HTTP HEAD on `Office/Data/v64.cab` and `v32.cab` on the channel CDN path.

Exit 0 if all critical checks pass, 1 otherwise, so it works as a detection script.

```powershell
.\Test-M365MonthlyEnterpriseChannel.ps1 -LogPath C:\Temp\MEC.csv
```
Run as SYSTEM (`psexec -s -i powershell.exe` or Intune) for a result that matches the update service.
