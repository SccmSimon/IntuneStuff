# Microsoft 365 Apps - forced build with user popups and diagnostics
# Intune Remediations remediation script. Pair with Detect-OfficeUpdate.ps1.
# Run as SYSTEM, 64-bit PowerShell: Yes
#
# Author: Simon Diaz
#
# What it does:
#   1. Records the update settings (channel, source, pin, SCCM, Cloud Update)
#   2. Warns logged-on users with popups forced on top of other windows
#   3. Raises the Cloud Update target version to the patched build, then asks the C2R
#      client for that exact build with updatetoversion and closes Office apps
#   4. Waits for the build to change, then shows the completion popup
#   5. Reads the C2R logs written during this run and reports why it did or didn't update
#
# Update $targetBuild for each new advisory.

# ===== Settings =====
$targetBuild      = '16.0.20527.20194'
$countdownMinutes = 10    # minimum 3
$maxWaitMinutes   = 40    # countdown + wait must stay under the remediation timeout
$c2r        = "$env:CommonProgramFiles\microsoft shared\ClickToRun\OfficeC2RClient.exe"
$cfgKey     = 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration'
$polKey     = 'HKLM:\SOFTWARE\Policies\Microsoft\office\16.0\common\officeupdate'
$log        = "$env:ProgramData\Microsoft\IntuneManagementExtension\Logs\OfficeForceUpdate.log"
$officeApps = 'outlook','winword','excel','powerpnt','onenote','msaccess','mspub','visio','winproj'
$popupTitle = 'IT Security Update'

function Write-Log ($Message) {
    Add-Content -Path $log -Value "$(Get-Date -Format s) $Message"
}

# ===== Popup helper: WTSSendMessage so the popup is forced on top =====
if (-not ('WtsPopup' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class WtsPopup
{
    [DllImport("wtsapi32.dll", CharSet = CharSet.Unicode, EntryPoint = "WTSSendMessageW", SetLastError = true)]
    static extern bool WTSSendMessage(IntPtr hServer, int sessionId, string title, int titleLength,
        string message, int messageLength, int style, int timeout, out int response, bool wait);

    [DllImport("wtsapi32.dll", CharSet = CharSet.Unicode, EntryPoint = "WTSEnumerateSessionsW", SetLastError = true)]
    static extern bool WTSEnumerateSessions(IntPtr hServer, int reserved, int version,
        out IntPtr sessionInfo, out int count);

    [DllImport("wtsapi32.dll")]
    static extern void WTSFreeMemory(IntPtr memory);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct WTS_SESSION_INFO
    {
        public int SessionId;
        public string WinStationName;
        public int State;
    }

    public static int Send(string title, string message, int timeoutSeconds, int style)
    {
        IntPtr buffer;
        int count;
        int sent = 0;

        if (!WTSEnumerateSessions(IntPtr.Zero, 0, 1, out buffer, out count))
            return -1;

        int size = Marshal.SizeOf(typeof(WTS_SESSION_INFO));
        for (int i = 0; i < count; i++)
        {
            var info = (WTS_SESSION_INFO)Marshal.PtrToStructure(
                new IntPtr(buffer.ToInt64() + (i * size)), typeof(WTS_SESSION_INFO));

            if (info.State == 0 && info.SessionId != 0)
            {
                int response;
                if (WTSSendMessage(IntPtr.Zero, info.SessionId, title, title.Length * 2,
                        message, message.Length * 2, style, timeoutSeconds, out response, false))
                    sent++;
            }
        }

        WTSFreeMemory(buffer);
        return sent;
    }
}
'@
}

# Warning icon + system modal + bring to foreground + always on top
$popupStyle = 0x30 -bor 0x1000 -bor 0x10000 -bor 0x40000

function Send-UserPopup ($Text, $Seconds) {
    $sent = [WtsPopup]::Send($popupTitle, $Text, $Seconds, $popupStyle)
    Write-Log "Popup sent to $sent session(s)"
}

# ===== 1. Current settings =====
$cfg = Get-ItemProperty $cfgKey -ErrorAction SilentlyContinue
$pol = Get-ItemProperty $polKey -ErrorAction SilentlyContinue

# Cloud Update / servicing profile settings. These override the normal Office update policy.
$cloudKey = 'HKLM:\SOFTWARE\Policies\Microsoft\cloud\office\16.0\Common\officeupdate'
$cloud = if (Test-Path $cloudKey) {
    $item = Get-Item $cloudKey
    $vals = $item.GetValueNames() | ForEach-Object { "$_=$($item.GetValue($_))" }
    if ($vals) { $vals -join ', ' } else { 'key present, no values' }
} else { 'not present' }

$settings = "Channel=$($cfg.UpdateChannel); CDN=$($cfg.CDNBaseUrl); UpdateUrl=$($cfg.UpdateUrl); " +
            "UpdatesEnabled=$($cfg.UpdatesEnabled); SCCM=$($cfg.OfficeMgmtCOM); " +
            "PolBranch=$($pol.updatebranch); PolPin=$($pol.updatetargetversion); PolPath=$($pol.updatepath); " +
            "PolEnabled=$($pol.enableautomaticupdates); Cloud=[$cloud]"
Write-Log "SETTINGS $settings"

if (-not (Test-Path $c2r)) {
    Write-Log "OfficeC2RClient.exe not found"
    Write-Output "OfficeC2RClient.exe not found | $settings"
    exit 1
}

# ===== 2. Warn users if Office apps are open =====
$running = Get-Process -Name $officeApps -ErrorAction SilentlyContinue

if ($running) {
    $names = ($running.ProcessName | Sort-Object -Unique) -join ', '
    Write-Log "Office apps running: $names. Starting $countdownMinutes minute countdown."

    Send-UserPopup -Seconds ($countdownMinutes * 60) -Text @"
A critical security update for Microsoft Office needs to be installed.

Please SAVE YOUR WORK NOW. Outlook, Word, Excel and other Office apps will close automatically in $countdownMinutes minutes.

The update takes around 10 to 15 minutes. You can reopen Office once it finishes.
"@

    Start-Sleep -Seconds (($countdownMinutes - 2) * 60)

    if (Get-Process -Name $officeApps -ErrorAction SilentlyContinue) {
        Send-UserPopup -Seconds 120 -Text @"
REMINDER: Office apps will close in 2 minutes.

Please save your work now.
"@
    }

    Start-Sleep -Seconds 120
}
else {
    Write-Log "No Office apps running. Updating without prompt."
}

# ===== 3. Trigger the exact build and close Office apps =====
$start      = Get-Date
$startBuild = [version](Get-ItemProperty $cfgKey).VersionToReport
Write-Log "Build before update: $startBuild. Target: $targetBuild"

# ----- Override the Cloud Update target version -----
# Cloud Update (ignoregpo=1) holds the device at its wave's target build. Raise it to the
# patched build so the client is allowed to install now. Cloud Update overwrites this on its
# next sync, which is fine once the device is patched.
# Done here, after the countdown, so a cloud sync during the countdown can't undo it.
$targetCreated = $false
if (-not (Test-Path $cloudKey)) { New-Item -Path $cloudKey -Force | Out-Null }

$oldTarget = (Get-ItemProperty $cloudKey -ErrorAction SilentlyContinue).updatetargetversion
if (-not $oldTarget) {
    $targetCreated = $true
    Write-Log "Cloud updatetargetversion not set. Creating it as $targetBuild"
    Set-ItemProperty -Path $cloudKey -Name updatetargetversion -Value $targetBuild -Type String
}
elseif ([version]$oldTarget -lt [version]$targetBuild) {
    Write-Log "Cloud updatetargetversion was $oldTarget. Changing to $targetBuild"
    Set-ItemProperty -Path $cloudKey -Name updatetargetversion -Value $targetBuild -Type String
}
else {
    Write-Log "Cloud updatetargetversion is $oldTarget (already at or above target). Not changed"
}

$c2rArgs = "/update user updatetoversion=$targetBuild updatepromptuser=false forceappshutdown=true displaylevel=true"
Write-Log "Triggering: $c2r $c2rArgs"
Start-Process -FilePath $c2r -ArgumentList $c2rArgs -WindowStyle Hidden

if ($running) {
    Send-UserPopup -Seconds 600 -Text @"
Microsoft Office is now updating.

Please do not reopen Office apps until the update has finished (around 10 to 15 minutes).

You will see another message when it is complete.
"@
}

# ===== 4. Wait for the build to change =====
$deadline = (Get-Date).AddMinutes($maxWaitMinutes)
do {
    Start-Sleep -Seconds 30
    $currentBuild = [version](Get-ItemProperty $cfgKey -ErrorAction SilentlyContinue).VersionToReport
} while ($currentBuild -le $startBuild -and (Get-Date) -lt $deadline)

$updated = $currentBuild -gt $startBuild

# If we created the target value (device had no Cloud Update target), remove it once patched
# so it doesn't pin the device to this build forever. If it already existed, leave it for
# Cloud Update to overwrite. Never put the old lower value back, as that could cause a downgrade.
if ($updated -and $targetCreated) {
    Remove-ItemProperty -Path $cloudKey -Name updatetargetversion -ErrorAction SilentlyContinue
    Write-Log "Removed the updatetargetversion value this script created"
}

if ($updated) {
    Write-Log "Update installed: $startBuild -> $currentBuild"

    if ($running) {
        Send-UserPopup -Seconds 3600 -Text @"
The Microsoft Office security update has been installed.

You can now reopen Outlook, Word, Excel and your other Office apps.

Thank you for your patience.
"@
    }
}
else {
    Write-Log "Build still $currentBuild after $maxWaitMinutes minutes."
}

# ===== 5. Read the C2R logs written during this run =====
$c2rLogs = Get-ChildItem "$env:windir\Temp" -Filter "$env:COMPUTERNAME-*.log" -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -ge $start } |
    Sort-Object LastWriteTime

$pattern = 'throttl|version|update|cdn|policy|channel|error|fail|download|apply|available'

$hits = foreach ($c2rLog in $c2rLogs) {
    Get-Content $c2rLog.FullName | Where-Object { $_ -match $pattern } | ForEach-Object {
        $cols = $_ -split "`t"
        # Columns: Timestamp, Process, TID, Area, Category, EventID, Level, Message, Correlation
        if ($cols.Count -ge 8) {
            $msg = $cols[7]
            # Pull the readable "message" out of ContextData where there is one
            if ($msg -match '\\"message\\":\\"([^\\]+)') { "$($cols[5]) $($Matches[1])" }
            else { "$($cols[5]) $($msg.Substring(0, [Math]::Min(200, $msg.Length)))" }
        }
    }
}
$hits = $hits | Where-Object { $_ -notmatch 'Telemetry|Identity\.|Experimentation|SendEvent|DroppedAggregated' } |
    Select-Object -Unique

Write-Log "C2R logs read: $(($c2rLogs.Name) -join ', ')"
$hits | ForEach-Object { Write-Log "  C2R: $_" }

# ===== Intune output (column is limited, so keep it short) =====
$result  = if ($updated) { "UPDATED $startBuild -> $currentBuild" } else { "NOT UPDATED, still $currentBuild" }
$summary = "$result | Target=$targetBuild | CloudTargetWas=$(if ($oldTarget) { $oldTarget } else { 'none' }) | Apps open at start: $(if ($running) { $names } else { 'none' }) | " +
           "Logs=$($c2rLogs.Count) | $settings | " + (($hits | Select-Object -Last 8) -join ' || ')
if ($summary.Length -gt 2000) { $summary = $summary.Substring(0, 2000) }

Write-Output $summary
exit 0
