# Firefox usage detection (Intune Remediation or custom compliance)

| File | Purpose |
|---|---|
| `Detect-FirefoxUsage.ps1` | Detection / compliance discovery script |
| `FirefoxCompliance.json` | Rules file for custom compliance (Compliance mode only) |

## Results
| Status | Condition | Compliance |
|---|---|---|
| InUse | A user-launched `firefox.exe` is running, or Firefox is installed and a profile shows activity within `$UsageWindow` days | Non-compliant |
| InstalledNotUsed | Installed, no recent profile activity | Compliant |
| NotInstalled | No install found and nothing running | Compliant |

## How it works
- **Install**: HKLM uninstall keys (both views), loaded user hives, `firefox.exe` in Program Files and each profile's `AppData\Local`, and the Store (MSIX) package.
- **Running**: `Win32_Process` command lines, excluding the background update task (`--backgroundtask`) and content processes (`-contentproc`).
- **Usage**: last write time of `places.sqlite`, `sessionstore.jsonlz4`, `recovery.jsonlz4` and `prefs.js` in each profile. The background update task does not touch these.

## Modes
Set `$Mode` at the top:
- `Remediation`: exit 1 when InUse, summary line in the report column. Remediation script can be left empty.
- `Compliance`: outputs `{"FirefoxStatus":"..."}` for a custom compliance policy. Upload `FirefoxCompliance.json` with it and change `MoreInfoUrl`.

## Intune settings
SYSTEM, 64-bit PowerShell. Test with `psexec -s -i powershell.exe -ExecutionPolicy Bypass -File .\Detect-FirefoxUsage.ps1`.

## Known limits
- A portable Firefox that is not running at detection time is not caught.
- Leftover profile data after an uninstall does not count, because profile activity is only checked when Firefox is installed.
