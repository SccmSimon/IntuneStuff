<#
.SYNOPSIS
    Detects Firefox installation and recent usage for Intune.

.DESCRIPTION
    InUse            = non-compliant
    InstalledNotUsed = compliant
    NotInstalled     = compliant

    Run as SYSTEM in 64-bit PowerShell.

    Mode 'Remediation' : exit 1 when InUse, exit 0 otherwise
    Mode 'Compliance'  : outputs JSON for an Intune custom compliance policy

.NOTES
    Author : Simon Diaz
#>

$Mode        = 'Remediation'   # 'Remediation' or 'Compliance'
$UsageWindow = 30              # days; profile activity inside this window counts as used

$cutoff = (Get-Date).AddDays(-$UsageWindow)

#region Install detection
function Get-FirefoxInstall {
    $found = New-Object System.Collections.Generic.List[string]

    # Machine-wide installs, both registry views
    $uninstallPaths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )

    # Per-user installs, only for users whose hive is loaded (logged on)
    Get-ChildItem -Path 'Registry::HKEY_USERS' -ErrorAction SilentlyContinue |
        Where-Object { $_.PSChildName -match '^S-1-5-21-[\d-]+$' } |
        ForEach-Object {
            $uninstallPaths += "Registry::HKEY_USERS\$($_.PSChildName)\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
        }

    foreach ($path in $uninstallPaths) {
        Get-ItemProperty -Path $path -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -like '*Firefox*' -and $_.Publisher -like '*Mozilla*' } |
            ForEach-Object { $found.Add("Reg: $($_.DisplayName) $($_.DisplayVersion)") }
    }

    # File system fallback, catches per-user installs for users not logged on
    $exeCandidates = @(
        "$env:ProgramFiles\Mozilla Firefox\firefox.exe"
        "${env:ProgramFiles(x86)}\Mozilla Firefox\firefox.exe"
        "$env:SystemDrive\Users\*\AppData\Local\Mozilla Firefox\firefox.exe"
    )
    foreach ($exe in $exeCandidates) {
        Get-Item -Path $exe -ErrorAction SilentlyContinue |
            ForEach-Object { $found.Add("File: $($_.FullName)") }
    }

    # Microsoft Store (MSIX) version
    try {
        Get-AppxPackage -AllUsers -Name 'Mozilla.Firefox*' -ErrorAction Stop |
            ForEach-Object { $found.Add("Store: $($_.Name) $($_.Version)") }
    }
    catch { }

    return @($found | Select-Object -Unique)
}
#endregion

#region Usage detection
function Get-FirefoxRunning {
    $evidence = New-Object System.Collections.Generic.List[string]

    # Exclude the background update task and child content processes
    Get-CimInstance -ClassName Win32_Process -Filter "Name = 'firefox.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -notmatch '--backgroundtask|-contentproc' } |
        ForEach-Object {
            $owner = (Invoke-CimMethod -InputObject $_ -MethodName GetOwner -ErrorAction SilentlyContinue).User
            $evidence.Add("Running: PID $($_.ProcessId) user $owner")
        }

    return @($evidence)
}

function Get-FirefoxProfileActivity {
    param([datetime]$Since)

    $evidence = New-Object System.Collections.Generic.List[string]

    $profileRoots = @(
        "$env:SystemDrive\Users\*\AppData\Roaming\Mozilla\Firefox\Profiles\*"
        "$env:SystemDrive\Users\*\AppData\Local\Packages\Mozilla.Firefox_*\LocalCache\Roaming\Mozilla\Firefox\Profiles\*"
    )

    # Files Firefox writes during normal use
    $markerFiles = @(
        'places.sqlite'
        'sessionstore.jsonlz4'
        'sessionstore-backups\recovery.jsonlz4'
        'prefs.js'
    )

    foreach ($root in $profileRoots) {
        Get-Item -Path $root -ErrorAction SilentlyContinue |
            Where-Object { $_.PSIsContainer } |
            ForEach-Object {
                $profileDir = $_.FullName

                $latest = $markerFiles |
                    ForEach-Object { Get-Item -LiteralPath (Join-Path $profileDir $_) -ErrorAction SilentlyContinue } |
                    Sort-Object -Property LastWriteTime -Descending |
                    Select-Object -First 1

                if ($latest -and $latest.LastWriteTime -ge $Since) {
                    $user = ($profileDir -split '\\')[2]
                    $evidence.Add("Profile: $user last active $($latest.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))")
                }
            }
    }

    return @($evidence)
}
#endregion

#region Evaluate
$installs = @(Get-FirefoxInstall)
$running  = @(Get-FirefoxRunning)
$activity = @()

if ($installs.Count -gt 0) {
    $activity = @(Get-FirefoxProfileActivity -Since $cutoff)
}

if ($running.Count -gt 0 -or $activity.Count -gt 0) {
    $status = 'InUse'
}
elseif ($installs.Count -gt 0) {
    $status = 'InstalledNotUsed'
}
else {
    $status = 'NotInstalled'
}
#endregion

#region Output
if ($Mode -eq 'Compliance') {
    @{ FirefoxStatus = $status } | ConvertTo-Json -Compress
    exit 0
}

$summary = "Status: $status"
if ($installs.Count) { $summary += " | Installs: $($installs -join '; ')" }
if ($running.Count)  { $summary += " | $($running -join '; ')" }
if ($activity.Count) { $summary += " | $($activity -join '; ')" }

# Remediation output column is capped at 2048 characters
if ($summary.Length -gt 2000) { $summary = $summary.Substring(0, 2000) + '...' }

Write-Output $summary

if ($status -eq 'InUse') { exit 1 } else { exit 0 }
#endregion
