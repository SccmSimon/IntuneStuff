# Stale User Profiles (Intune Remediation pair)

| Script | Role |
|---|---|
| `Remove-StaleUserProfiles-Detection.ps1` | Detection (read-only) |
| `Remove-StaleUserProfiles-Remediation.ps1` | Remediation (deletes profiles) |

Version 2.1.5.

## What it does
Both scripts enumerate `Win32_UserProfile` via CIM, skip special profiles, and evaluate every other profile.

A profile is a candidate only when all of these are true:
- not a protected SID (`S-1-5-18`, `-19`, `-20`)
- not currently loaded
- path exists and is not a system folder (Default, Public, systemprofile and so on)
- `LastUseTime` is readable and older than `-DaysThreshold` (default 90)

**Detection** exits 1 if any candidate is found, 0 otherwise. **Remediation** re-reads the profile by SID and deletes it with `Remove-CimInstance`, which removes the folder, the registry hive and the WMI record in one OS-managed call. It exits 1 if any deletion failed.

Every profile gets a logged outcome (skipped by guard, within threshold, unknown age, candidate/deleted, failed), and the summary checks that the outcome count matches the number evaluated.

## Safety
- **No age fallback.** A profile with no readable `LastUseTime` is reported as unknown age and never deleted. An earlier version fell back to the folder's `LastWriteTime`, which is not a reliable indicator of use and led to an active profile being removed.
- Loaded profiles are never touched.
- Run the detection script on its own first and read the log before assigning the remediation.

## Intune settings
| Setting | Value |
|---|---|
| Run using logged-on credentials | No (SYSTEM) |
| Run in 64-bit PowerShell | Yes |
| Schedule | Daily |

Logs: `%ProgramData%\Microsoft\IntuneManagementExtension\Logs\Remove-StaleUserProfiles-Detection.log` and `-Remediation.log`.

Intune does not pass parameters, so change `$DaysThreshold`'s default in the `param()` block if you need a different value.
