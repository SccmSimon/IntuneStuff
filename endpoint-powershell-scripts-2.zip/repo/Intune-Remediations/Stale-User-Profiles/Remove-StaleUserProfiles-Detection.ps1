<#
.SYNOPSIS
    Detects stale user profiles on managed Windows endpoints based on
    inactivity threshold alone.

.DESCRIPTION
    Designed to run as an Intune Proactive Remediation DETECTION script
    (SYSTEM context). Read-only. Makes no changes to the system.

    The script:
      1. Enumerates all local user profiles via CIM (Win32_UserProfile)
      2. Skips protected profiles (currently loaded, system, default, service accounts)
      3. Detects Azure AD profiles (SID prefix S-1-12-1-*)
      4. Checks last use age against the configured threshold
      5. Exits 1 (non-compliant) if stale profiles found, 0 (compliant) if clean
      6. Writes a structured log to the Intune IME log directory

    Profiles with no readable LastUseTime are reported as unknown age and are
    NOT treated as stale. They do not trigger remediation.

    Every profile is accounted for in the summary. Each skip is logged with
    its reason so that repeated near-misses are visible in the log.

    Pair with Remove-StaleUserProfiles-Remediation.ps1, which performs the
    actual deletion when this script reports non-compliant.

.PARAMETER DaysThreshold
    Profiles not used within this many days are candidates for removal.
    Default: 90

.PARAMETER LogPath
    Path to write the log file.
    Default: C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\Remove-StaleUserProfiles-Detection.log

.EXAMPLE
    .\Remove-StaleUserProfiles-Detection.ps1

.EXAMPLE
    .\Remove-StaleUserProfiles-Detection.ps1 -DaysThreshold 60

.NOTES
    Author     : Simon Diaz
    Requires   : PowerShell 5.1+ or PowerShell 7+
    Run context: SYSTEM (Intune default for Proactive Remediation scripts)
    Exit codes : 0 = compliant   1 = non-compliant

.VERSION HISTORY
    1.0.0   Initial release. Profile enumeration, app detection (Zoom/Teams/Chrome),
            registry hive cleanup, Robocopy folder deletion, WMI record removal,
            WhatIf dry-run mode, structured logging.

    1.0.1   Fixed duplicate -WhatIf parameter conflict. Removed SupportsShouldProcess
            from CmdletBinding.

    1.0.2   Fixed log directory creation error. Wrapped log initialisation in
            try/catch with fallback to $env:TEMP. Added per-write error handling.

    1.0.3   Added version history block. Version logged at script start.

    1.0.4   Fixed CmdletBinding syntax error. Moved $ScriptVersion to after param().

    1.0.5   Fixed PropertyNotFoundException under Set-StrictMode -Version Latest.
            Wrapped pipeline results in @() for null-safe .Count access.

    1.0.6   Added -DetectionMode switch for Intune remediation detection.

    1.0.7   Made -DetectionMode the default ($true).

    1.0.8   Made -WhatIf the default ($true). Script is safe by default.

    2.0.0   Major refactor. Replaced Get-WmiObject with Get-CimInstance (modern,
            faster). Replaced manual folder/registry/WMI deletion with
            Invoke-CimMethod -MethodName Delete. Added Azure AD SID detection.
            Streamlined loop logic. Retained full comment block, coloured logging,
            fallback log path, summary output, and version history.

    2.1.0   Removed application-based filtering (Zoom, Teams, Chrome). Script now
            targets all profiles inactive for DaysThreshold or more, regardless
            of installed applications.

    2.1.1   Split into separate detection and remediation scripts for Intune
            Proactive Remediations (this is the detection half). No functional
            changes to the detection logic itself.

    2.1.2   Remediation script only. No change to detection.

    2.1.3   Remediation script only. No change to detection.

    2.1.4   Removed the folder LastWriteTime fallback for profile age. It was
            unreliable and could misrepresent a profile's true age. Profiles
            with no readable LastUseTime are now reported as unknown age and
            excluded from the stale count. Renamed the loop variable from
            $profile to $userProfile, as $profile is a PowerShell automatic
            variable.

    2.1.5   Fixed the profile counters. "Total profiles evaluated" previously
            counted only summary entries, which in 2.1.x were added only once
            a profile was already a candidate, so clean runs reported 0
            evaluated even when profiles had been enumerated and skipped.
            The summary now reports CIM total, special profiles excluded,
            profiles evaluated, and a full breakdown by outcome.
            Restored per-profile skip logging with reasons, dropped in the
            2.0.0 refactor. Skips are now logged at SKIP level so that a
            profile repeatedly saved by a guard is visible in the log.
#>

[CmdletBinding()]
param (
    [Parameter()]
    [ValidateRange(1, 365)]
    [int]$DaysThreshold = 90,

    [Parameter()]
    [string]$LogPath = 'C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\Remove-StaleUserProfiles-Detection.log'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -- Version -------------------------------------------------------------------
$ScriptVersion = '2.1.5'

#region -- Logging ------------------------------------------------------------

$script:LogPathResolved = $LogPath
try {
    $logDir = Split-Path -Path $LogPath -Parent
    if (-not (Test-Path -Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force -ErrorAction Stop | Out-Null
    }
    Add-Content -Path $LogPath -Value '' -Encoding UTF8 -ErrorAction Stop
}
catch {
    $script:LogPathResolved = Join-Path $env:TEMP 'Remove-StaleUserProfiles-Detection.log'
    Write-Host "[WARN] Could not write to '$LogPath'. Falling back to: $($script:LogPathResolved)" -ForegroundColor Yellow
    Write-Host "[WARN] Reason: $_" -ForegroundColor Yellow
    Add-Content -Path $script:LogPathResolved -Value '' -Encoding UTF8
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','ACTION','SKIP','DRYRUN')]
        [string]$Level = 'INFO'
    )
    $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [$Level] $Message"
    try { Add-Content -Path $script:LogPathResolved -Value $line -Encoding UTF8 -ErrorAction Stop }
    catch { Write-Host "[WARN] Log write failed: $_" -ForegroundColor Yellow }

    $colour = switch ($Level) {
        'INFO'   { 'Cyan'    }
        'WARN'   { 'Yellow'  }
        'ERROR'  { 'Red'     }
        'ACTION' { 'Green'   }
        'SKIP'   { 'Gray'    }
        'DRYRUN' { 'Magenta' }
    }
    Write-Host $line -ForegroundColor $colour
}

#endregion

#region -- Main ---------------------------------------------------------------

$cutoffDate = (Get-Date).AddDays(-$DaysThreshold)
$rule  = '==========================================================='
$rule2 = '-----------------------------------------------------------'

Write-Log $rule
Write-Log "Remove-StaleUserProfiles-Detection started (v$ScriptVersion)"
Write-Log "Mode          : DETECTION (Intune detection script, no changes)"
Write-Log "Days threshold: $DaysThreshold days (cutoff: $($cutoffDate.ToString('yyyy-MM-dd')))"
Write-Log "Log path      : $script:LogPathResolved"
Write-Log "Running as    : $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"
Write-Log "Computer      : $env:COMPUTERNAME"
Write-Log $rule

# -- Protected SIDs --------------------------------------------------------
$protectedSIDs = @('S-1-5-18', 'S-1-5-19', 'S-1-5-20')

# -- Skip system default profile folders -----------------------------------
$skipFolders   = @('Default', 'Default User', 'Public', 'All Users',
                   'LocalService', 'NetworkService', 'systemprofile')

# -- Enumerate profiles via CIM --------------------------------------------
Write-Log "Enumerating user profiles via CIM (Win32_UserProfile)..."

$allProfilesRaw  = @(Get-CimInstance Win32_UserProfile)
$specialProfiles = @($allProfilesRaw | Where-Object {      $_.Special })
$allProfiles     = @($allProfilesRaw | Where-Object { -not $_.Special })

Write-Log "Profiles returned by CIM  : $($allProfilesRaw.Count)"
Write-Log "Special profiles excluded : $($specialProfiles.Count)"
Write-Log "Profiles to evaluate      : $($allProfiles.Count)"
Write-Log $rule2

$summary = [System.Collections.Generic.List[PSCustomObject]]::new()

function Add-Result {
    param(
        [string]$Profile,
        [string]$Action,
        [string]$Reason
    )
    $summary.Add([PSCustomObject]@{
        Profile = $Profile
        Action  = $Action
        Reason  = $Reason
    })
}

foreach ($userProfile in $allProfiles) {

    $profilePath = $userProfile.LocalPath
    $sid         = $userProfile.SID
    $loaded      = $userProfile.Loaded

    Write-Log "Evaluating: $profilePath (SID: $sid)"

    # -- Azure AD profile detection ----------------------------------------
    if ($sid -like 'S-1-12-1-*') {
        Write-Log "Azure AD profile detected (SID: $sid) - $profilePath"
    }

    # -- Guards ------------------------------------------------------------
    if ($sid -in $protectedSIDs) {
        Write-Log "SKIP: $profilePath | Protected system account SID" -Level SKIP
        Add-Result -Profile $profilePath -Action 'Skipped' -Reason 'Protected system account SID'
        continue
    }

    if ($loaded) {
        Write-Log "SKIP: $profilePath | Profile currently loaded (user is logged on)" -Level SKIP
        Add-Result -Profile $profilePath -Action 'Skipped' -Reason 'Profile currently loaded'
        continue
    }

    if (-not (Test-Path $profilePath)) {
        Write-Log "SKIP: $profilePath | Profile path not found on disk" -Level SKIP
        Add-Result -Profile $profilePath -Action 'Skipped' -Reason 'Profile path not found on disk'
        continue
    }

    if ((Split-Path $profilePath -Leaf) -in $skipFolders) {
        Write-Log "SKIP: $profilePath | System or default profile folder" -Level SKIP
        Add-Result -Profile $profilePath -Action 'Skipped' -Reason 'System or default profile folder'
        continue
    }

    # -- Last use time -----------------------------------------------------
    # No fallback. If LastUseTime cannot be read the age is unknown, and an
    # unknown-age profile is reported only, never counted as stale.
    $lastUseTime = $null
    if ($userProfile.LastUseTime) {
        try {
            $lastUseTime = [System.Management.ManagementDateTimeConverter]::ToDateTime($userProfile.LastUseTime)
        }
        catch { }
    }
    if (-not $lastUseTime) {
        Write-Log "SKIP: $profilePath | Age unknown, no readable LastUseTime. Reported only, not counted as stale." -Level WARN
        Add-Result -Profile $profilePath -Action 'Unknown age' -Reason 'No readable LastUseTime'
        continue
    }

    $ageDays = [math]::Round(((Get-Date) - $lastUseTime).TotalDays, 1)

    if ($lastUseTime -ge $cutoffDate) {
        Write-Log "SKIP: $profilePath | Within threshold, last used $ageDays days ago" -Level SKIP
        Add-Result -Profile $profilePath -Action 'Within threshold' -Reason "Last used $ageDays days ago"
        continue
    }

    Write-Log "Candidate: $profilePath | Age: $ageDays days"
    Write-Log "[DETECTION] Would delete: $profilePath ($ageDays days inactive)" -Level DRYRUN
    Add-Result -Profile $profilePath -Action 'Would delete' -Reason "$ageDays days inactive"
}

# -- Summary ---------------------------------------------------------------
$staleProfiles   = @($summary | Where-Object { $_.Action -eq 'Would delete'     })
$unknownAge      = @($summary | Where-Object { $_.Action -eq 'Unknown age'      })
$withinThreshold = @($summary | Where-Object { $_.Action -eq 'Within threshold' })
$skippedByGuard  = @($summary | Where-Object { $_.Action -eq 'Skipped'          })

Write-Log $rule
Write-Log "SUMMARY - DETECTION"
Write-Log "Profiles returned by CIM  : $($allProfilesRaw.Count)"
Write-Log "Special profiles excluded : $($specialProfiles.Count)"
Write-Log "Profiles evaluated        : $($allProfiles.Count)"
Write-Log $rule2
Write-Log "  Skipped by guard        : $($skippedByGuard.Count)"
Write-Log "  Within threshold        : $($withinThreshold.Count)"
Write-Log "  Unknown age (no action) : $($unknownAge.Count)"
Write-Log "  To action               : $($staleProfiles.Count)"
Write-Log $rule2

if ($summary.Count -ne $allProfiles.Count) {
    Write-Log "Count mismatch: $($summary.Count) outcomes recorded for $($allProfiles.Count) profiles evaluated" -Level WARN
}

foreach ($s in $skippedByGuard) {
    Write-Log "  [Skipped         ] $($s.Profile) | $($s.Reason)"
}
foreach ($w in $withinThreshold) {
    Write-Log "  [Within threshold] $($w.Profile) | $($w.Reason)"
}
foreach ($u in $unknownAge) {
    Write-Log "  [Unknown age     ] $($u.Profile) | $($u.Reason)" -Level WARN
}
foreach ($t in $staleProfiles) {
    Write-Log "  [To action       ] $($t.Profile) | $($t.Reason)" -Level DRYRUN
}

Write-Log $rule
Write-Log "Remove-StaleUserProfiles-Detection completed (v$ScriptVersion)"
Write-Log $rule

# -- Exit ------------------------------------------------------------------
$staleCount   = $staleProfiles.Count
$unknownCount = $unknownAge.Count

$unknownNote = ''
if ($unknownCount -gt 0) {
    $unknownNote = " ($unknownCount profile(s) of unknown age, no action taken)"
}

if ($staleCount -gt 0) {

    $profileNames = $staleProfiles |
        ForEach-Object {
            Split-Path $_.Profile -Leaf
        }

    $profileList = $profileNames -join ', '

    Write-Host "Non-compliant: $staleCount stale profile(s) found. Profiles: $profileList$unknownNote"

    Write-Log "DETECTION: Non-compliant - $staleCount stale profile(s) found: $profileList" -Level WARN

    exit 1
}
else {

    Write-Host "Compliant: No stale profiles found.$unknownNote"

    Write-Log "DETECTION: Compliant - no stale profiles found" -Level INFO

    exit 0
}

#endregion
