# BitLocker recovery key escrow to Entra ID

`BitLockerEscrow-Remediate.ps1` backs up existing BitLocker recovery password protectors to Entra ID. It runs as an Intune Remediation remediation script or as a ConfigMgr task sequence step.

## What it does
1. Relaunches in 64-bit PowerShell if started from a 32-bit host.
2. Stops cleanly in WinPE, when not elevated, or when BitLocker cmdlets are missing.
3. Logs MBAM state (read only). On MBAM-managed devices the same recovery password is copied to Entra, so key IDs match.
4. Checks `dsregcmd /status` for `AzureAdJoined : YES`.
5. For each encrypted OS volume (and data volumes if `$IncludeDataDrives`), runs `BackupToAAD-BitLockerKeyProtector` per RecoveryPassword protector.
6. Waits up to `$EventWaitSeconds` for event 845 in `Microsoft-Windows-BitLocker/BitLocker Management`, then records the protector ID under `$MarkerKey`.

It never creates, removes or changes protectors.

## Exit codes
| Context | Result | Exit |
|---|---|---|
| Intune | Success / NothingToBackUp | 0 |
| Intune | Failed / NotJoined | 1 |
| Task sequence | NotJoined | 0 (WARN) |
| Task sequence | Failed | 0 unless `$FailTaskSequenceOnError = $true` |

In a task sequence it also sets `BitLockerEscrowResult` and writes `BitLockerEscrow.log` next to `smsts.log`.

## Detection script
Pair it with a detection script that reads the same `$MarkerKey` (default `HKLM:\SOFTWARE\EndpointScripts\BitLockerEscrow`) and exits 1 if any current RecoveryPassword protector ID is not recorded there. Keep `$MarkerKey` and `$IncludeDataDrives` identical in both.

## Task sequence step
Run PowerShell Script step, execution policy Bypass, full OS, after Enable BitLocker. No need for Continue on error.

Log: `%ProgramData%\Microsoft\IntuneManagementExtension\Logs\BitLockerEscrow.log`
