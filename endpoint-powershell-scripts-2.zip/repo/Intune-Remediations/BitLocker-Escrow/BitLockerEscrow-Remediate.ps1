<#
.SYNOPSIS
    Remediation: back up BitLocker recovery keys to Entra ID.
    Works as an Intune remediation and as a ConfigMgr task sequence step.

.NOTES
    Author: Simon Diaz

    Only backs up existing RecoveryPassword protectors. Never creates, removes or changes protectors.
    On MBAM managed devices this sends the SAME recovery password MBAM already holds to Entra,
    so the key ID is identical in both places. The MBAM client and policy are not touched.
    A protector is marked in the registry only after Windows logs event 845 (backup succeeded).

    Exit codes under Intune:
        0 = all backups confirmed (or nothing to back up)
        1 = any failure, including device not Entra joined

    Task sequence behaviour:
        - Relaunches itself in 64-bit PowerShell if started from a 32-bit host, so the
          registry marker and BitLocker cmdlets are the 64-bit ones.
        - Also writes the log to the TS log folder (_SMSTSLogPath) next to smsts.log.
        - Device not yet Entra joined is expected during OSD. Logged as WARN, step does not fail.
        - Other failures do not fail the TS unless $FailTaskSequenceOnError = $true.
        - Sets TS variable BitLockerEscrowResult = Success | NotJoined | NothingToBackUp | Failed
          so later steps can use it in conditions.
        - Must run in the full OS after the Enable BitLocker step. Not supported in WinPE.
#>

# Relaunch in 64-bit PowerShell if started 32-bit on a 64-bit OS
if ($env:PROCESSOR_ARCHITEW6432 -eq 'AMD64') {
    & "$env:WINDIR\SysNative\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit $LASTEXITCODE
}

$LogPath                 = "$env:ProgramData\Microsoft\IntuneManagementExtension\Logs\BitLockerEscrow.log"
$MarkerKey               = 'HKLM:\SOFTWARE\EndpointScripts\BitLockerEscrow'   # must match the detection script
$IncludeDataDrives       = $false                                             # must match the detection script
$FailTaskSequenceOnError = $false                                             # $true = real failures fail the TS step
$EventWaitSeconds        = 30                                                 # how long to wait for event 845
$ErrorActionPreference   = 'Stop'
$failed   = $false
$backedUp = 0

# Detect whether we are running inside a ConfigMgr task sequence
$tsenv = $null
try { $tsenv = New-Object -ComObject Microsoft.SMS.TSEnvironment } catch { }
$InTaskSequence = $null -ne $tsenv
$TsLogPath = $null
if ($InTaskSequence) {
    try {
        $tsLogDir = $tsenv.Value('_SMSTSLogPath')
        if ($tsLogDir) { $TsLogPath = Join-Path $tsLogDir 'BitLockerEscrow.log' }
    } catch { }
}
$Tag = if ($InTaskSequence) { 'Remediate-TS' } else { 'Remediate' }

function Write-Log {
    param([string]$Message, [ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO')
    $line = '{0} [{1}] [{2}] {3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Tag, $Level, $Message
    foreach ($path in @($LogPath, $TsLogPath)) {
        if (-not $path) { continue }
        try {
            $dir = Split-Path $path -Parent
            if (-not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }
            Add-Content -Path $path -Value $line
        } catch { }
    }
    Write-Output $line   # ends up in smsts.log in a TS, and in the Intune output otherwise
}

# Sets the TS variable, decides the exit code and exits
function Complete-Script {
    param([ValidateSet('Success','NotJoined','NothingToBackUp','Failed')][string]$Result)

    $code = if ($Result -in 'Failed','NotJoined') { 1 } else { 0 }

    if ($InTaskSequence) {
        try { $tsenv.Value('BitLockerEscrowResult') = $Result }
        catch { Write-Log "Could not set TS variable BitLockerEscrowResult: $($_.Exception.Message)" 'WARN' }

        if ($Result -eq 'NotJoined') {
            Write-Log 'Not Entra joined yet, which is normal during OSD. Returning 0. The Intune remediation will back up the key after the build.' 'WARN'
            $code = 0
        }
        elseif ($Result -eq 'Failed' -and -not $FailTaskSequenceOnError) {
            Write-Log 'Backup failed. Returning 0 so the task sequence continues. The Intune remediation will retry after the build.' 'WARN'
            $code = 0
        }
    }

    Write-Log "Finished. Result: $Result, exit code $code."
    exit $code
}

# Read-only MBAM check, logged for the record only
function Write-MbamState {
    $svc = Get-Service -DisplayName 'BitLocker Management Client Service' -ErrorAction SilentlyContinue
    if (-not $svc) { $svc = Get-Service -Name 'MBAMAgent' -ErrorAction SilentlyContinue }   # fallback, unverified service name
    $pol = Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\FVE\MDOPBitLockerManagement' -ErrorAction SilentlyContinue
    if ($svc -or $pol.KeyRecoveryServiceEndPoint) {
        $agent = if ($svc) { "agent $($svc.Status)" } else { 'agent not found' }
        Write-Log "MBAM detected: $agent, endpoint '$($pol.KeyRecoveryServiceEndPoint)'. Existing recovery passwords will be copied to Entra as they are."
    } else {
        Write-Log 'MBAM not detected.'
    }
}

Write-Log "Starting BitLocker escrow on $env:COMPUTERNAME. Task sequence: $InTaskSequence. 64-bit process: $([Environment]::Is64BitProcess)."

# Not supported in WinPE (no dsregcmd, no BitLocker cmdlets, OS not booted)
if (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\MiniNT') {
    Write-Log 'Running in WinPE. Place this step in the full OS after Enable BitLocker.' 'ERROR'
    Complete-Script -Result Failed
}

# Must be elevated
$principal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log 'Must run elevated or as SYSTEM.' 'ERROR'
    Complete-Script -Result Failed
}

# BitLocker cmdlets must be available
if (-not (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue)) {
    Write-Log 'BitLocker PowerShell cmdlets not found.' 'ERROR'
    Complete-Script -Result Failed
}

Write-MbamState

# Must be Entra joined or hybrid joined
try {
    $dsreg = & "$env:WINDIR\System32\dsregcmd.exe" /status | Out-String
} catch {
    Write-Log "dsregcmd failed: $($_.Exception.Message)" 'ERROR'
    Complete-Script -Result Failed
}
if ($dsreg -notmatch 'AzureAdJoined\s*:\s*YES') {
    Write-Log 'Device is not Entra joined or hybrid joined. Cannot back up to Entra ID.' 'WARN'
    Complete-Script -Result NotJoined
}

try {
    $volumes = Get-BitLockerVolume | Where-Object {
        $_.VolumeType -eq 'OperatingSystem' -or ($IncludeDataDrives -and $_.VolumeType -eq 'Data')
    }
} catch {
    Write-Log "Get-BitLockerVolume failed: $($_.Exception.Message)" 'ERROR'
    Complete-Script -Result Failed
}

foreach ($vol in $volumes) {
    $mp = $vol.MountPoint
    try {
        if ($vol.VolumeStatus -eq 'FullyDecrypted') {
            Write-Log "$mp is not encrypted. Skipping." 'WARN'
            continue
        }

        $protectors = @($vol.KeyProtector | Where-Object KeyProtectorType -eq 'RecoveryPassword')

        # No recovery password: log it and leave the volume untouched
        if ($protectors.Count -eq 0) {
            Write-Log "$mp has no recovery password protector. Nothing backed up and no changes made." 'WARN'
            continue
        }

        foreach ($kp in $protectors) {
            $id    = $kp.KeyProtectorId
            $start = (Get-Date).AddSeconds(-1)
            Write-Log "Backing up protector $id for $mp to Entra ID."
            BackupToAAD-BitLockerKeyProtector -MountPoint $mp -KeyProtectorId $id | Out-Null

            # Confirm with event 845 (backup to Entra ID succeeded), polling up to $EventWaitSeconds
            $evt      = $null
            $deadline = (Get-Date).AddSeconds($EventWaitSeconds)
            do {
                Start-Sleep -Seconds 3
                $evt = Get-WinEvent -FilterHashtable @{
                    LogName   = 'Microsoft-Windows-BitLocker/BitLocker Management'
                    Id        = 845
                    StartTime = $start
                } -ErrorAction SilentlyContinue
            } until ($evt -or (Get-Date) -ge $deadline)

            if ($evt) {
                if (-not (Test-Path $MarkerKey)) { New-Item -Path $MarkerKey -Force | Out-Null }
                New-ItemProperty -Path $MarkerKey -Name $id -Value (Get-Date).ToUniversalTime().ToString('s') `
                    -PropertyType String -Force | Out-Null
                Write-Log "Confirmed (event 845) and marked $id for $mp."
                $backedUp++
            } else {
                Write-Log "No error from backup of $id on $mp, but event 845 not found within $EventWaitSeconds seconds. Not marked, will retry next run." 'ERROR'
                $failed = $true
            }
        }
    }
    catch {
        Write-Log "Failed on ${mp}: $($_.Exception.Message)" 'ERROR'
        $failed = $true
    }
}

if ($failed)          { Complete-Script -Result Failed }
if ($backedUp -eq 0)  { Complete-Script -Result NothingToBackUp }
Complete-Script -Result Success
