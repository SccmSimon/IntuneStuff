# Edge latest version (Intune Remediation pair)

| Script | Role |
|---|---|
| `Detect-EdgeLatestVersion.ps1` | Detection |
| `Remediate-EdgeLatestVersion.ps1` | Remediation |

## What it does
**Detection** reads the installed Edge Stable version from the EdgeUpdate `pv` registry value and compares it to the latest Windows x64 Stable release from `https://edgeupdates.microsoft.com/api/products?view=enterprise`. Exit 1 if older.

**Remediation** gets the same release, downloads the Enterprise MSI, verifies the SHA256 hash the API publishes, then installs silently with `msiexec /qn /norestart`. Exit 0 on 0 or 3010.

## Intune settings
| Setting | Value |
|---|---|
| Run using logged-on credentials | No (SYSTEM) |
| Run in 64-bit PowerShell | Yes |
| Schedule | Daily |

## Notes
- `pv` is used instead of `msedge.exe` file version because the running browser can hold the old binary until relaunch.
- Versions are compared as `[version]`, not strings, so `128.x` sorts above `9.x`.
- The device must reach `edgeupdates.microsoft.com` and the MSI CDN as SYSTEM. MSI verbose log: `%TEMP%\EdgeRemediation\EdgeInstall.log` (SYSTEM temp).
- Stable channel, x64 only.
