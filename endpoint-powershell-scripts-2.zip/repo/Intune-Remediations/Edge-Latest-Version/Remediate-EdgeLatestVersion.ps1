<#
.SYNOPSIS
    Intune Remediation script. Downloads and silently installs the latest
    Microsoft Edge Stable MSI after verifying its SHA256 hash.
.NOTES
    Author : Simon Diaz
    Run as SYSTEM, 64-bit PowerShell.
    Exit 0 = success (including 3010, restart required)
    Exit 1 = failure
#>

$ErrorActionPreference = 'Stop'

$workingDir = Join-Path $env:TEMP 'EdgeRemediation'
if (-not (Test-Path $workingDir)) {
    New-Item -Path $workingDir -ItemType Directory -Force | Out-Null
}
$logFile = Join-Path $workingDir 'EdgeInstall.log'

try {
    $response = Invoke-RestMethod -Uri 'https://edgeupdates.microsoft.com/api/products?view=enterprise' -Method Get -UseBasicParsing

    $stable  = $response | Where-Object { $_.Product -eq 'Stable' }
    $release = $stable.Releases | Where-Object {
        $_.Platform -eq 'Windows' -and $_.Architecture -eq 'x64'
    } | Sort-Object { [version]$_.ProductVersion } -Descending | Select-Object -First 1

    if (-not $release) {
        Write-Output "Could not resolve latest Edge Stable release from API."
        exit 1
    }

    $msiArtifact = $release.Artifacts | Where-Object { $_.ArtifactName -eq 'msi' } | Select-Object -First 1
    if (-not $msiArtifact) {
        Write-Output "No MSI artifact found for latest release."
        exit 1
    }

    $downloadUrl  = $msiArtifact.Location
    $expectedHash = $msiArtifact.Hash
    $msiPath      = Join-Path $workingDir "MicrosoftEdgeEnterpriseX64_$($release.ProductVersion).msi"

    Write-Output "Downloading Edge $($release.ProductVersion) from $downloadUrl"
    Invoke-WebRequest -Uri $downloadUrl -OutFile $msiPath -UseBasicParsing

    # Verify integrity before executing anything downloaded from the internet.
    $actualHash = (Get-FileHash -Path $msiPath -Algorithm SHA256).Hash
    if ($actualHash -ne $expectedHash) {
        Write-Output "Hash mismatch. Expected $expectedHash, got $actualHash. Aborting install."
        Remove-Item $msiPath -Force -ErrorAction SilentlyContinue
        exit 1
    }

    Write-Output "Hash verified. Installing..."
    $msiArgs = "/i `"$msiPath`" /qn /norestart /l*v `"$logFile`""
    $process = Start-Process -FilePath 'msiexec.exe' -ArgumentList $msiArgs -Wait -PassThru
    $exitCode = $process.ExitCode

    if ($exitCode -eq 0 -or $exitCode -eq 3010) {
        Write-Output "Edge installed successfully. MSI exit code: $exitCode"
        Remove-Item $msiPath -Force -ErrorAction SilentlyContinue
        exit 0
    }
    Write-Output "MSI install failed. Exit code: $exitCode. See $logFile"
    exit 1
}
catch {
    Write-Output "Remediation script error: $($_.Exception.Message)"
    exit 1
}
