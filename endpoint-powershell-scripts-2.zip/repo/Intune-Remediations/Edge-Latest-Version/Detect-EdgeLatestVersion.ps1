<#
.SYNOPSIS
    Intune Remediation detection script. Checks the installed Microsoft Edge
    Stable version against the latest published version.
.NOTES
    Author : Simon Diaz
    Run as SYSTEM, 64-bit PowerShell.
    Exit 0 = compliant (no remediation needed)
    Exit 1 = non-compliant (remediation will run)
#>

$ErrorActionPreference = 'Stop'

# Registry key written by the Edge Enterprise (system-wide) installer.
# More reliable than msedge.exe's file version: it reflects what EdgeUpdate
# believes is installed, and works even if Edge is not running.
$edgeRegPaths = @(
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{56EB18F8-8008-4CBD-B6D2-8C97FE7E9062}',
    'HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{56EB18F8-8008-4CBD-B6D2-8C97FE7E9062}'
)

try {
    $installedVersion = $null
    foreach ($path in $edgeRegPaths) {
        if (Test-Path $path) {
            $installedVersion = (Get-ItemProperty -Path $path -Name 'pv' -ErrorAction SilentlyContinue).pv
            if ($installedVersion) { break }
        }
    }

    if (-not $installedVersion) {
        Write-Output "Microsoft Edge not found via EdgeUpdate registry key."
        exit 1
    }

    # Query Microsoft's Edge Update API for the current Stable release.
    $response = Invoke-RestMethod -Uri 'https://edgeupdates.microsoft.com/api/products?view=enterprise' -Method Get -UseBasicParsing

    $stable  = $response | Where-Object { $_.Product -eq 'Stable' }
    $release = $stable.Releases | Where-Object {
        $_.Platform -eq 'Windows' -and $_.Architecture -eq 'x64'
    } | Sort-Object { [version]$_.ProductVersion } -Descending | Select-Object -First 1

    if (-not $release) {
        Write-Output "Could not resolve latest Edge Stable release from API."
        exit 1
    }

    $latestVersion = $release.ProductVersion
    Write-Output "Installed: $installedVersion | Latest: $latestVersion"

    if ([version]$installedVersion -lt [version]$latestVersion) {
        Write-Output "Edge is out of date. Remediation required."
        exit 1
    }
    Write-Output "Edge is up to date."
    exit 0
}
catch {
    Write-Output "Detection script error: $($_.Exception.Message)"
    exit 1
}
