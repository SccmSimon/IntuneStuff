#Requires -Version 5.1
<#
    Name:     Detect-AsrBlockEvents.ps1
    Author:   Simon Diaz
    Purpose:  Intune Remediations detection script. Reports Microsoft Defender
              Attack Surface Reduction (ASR) block and audit events, writes a
              CMTrace-format log to the IME log folder, and returns a compact
              single-line summary for the Intune detection output column.

    Deploy:   Devices > Scripts and remediations > Remediations
              Detection script  : this file
              Remediation script: leave empty (report-only package)
              Run this script using the logged-on credentials : No
              Enforce script signature check                  : as per your org
              Run script in 64-bit PowerShell                 : Yes

    Exit 0  = no qualifying ASR events. Reports as "Without issues".
    Exit 1  = qualifying ASR events found. Reports as "With issues".
    STDERR  = script failure. Reports as "Detection script error".
#>

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

#region Configuration

# Match this to your remediation schedule so counts do not overlap between runs.
# Daily schedule = 1. Weekly = 7.
$LookbackDays = 1

# Minimum number of qualifying events before the device is flagged.
$MinimumEventCount = 1

# $true  = both blocks (1121) and audits (1122) count towards the flag.
# $false = only real blocks (1121) flag the device. Audits are still logged.
$IncludeAuditEvents = $true

# Restrict to specific rule GUIDs. Empty array = all ASR rules.
# Example: @('d4f940ab-401b-4efc-aadc-ad5f3c50688a','3b576869-a4ec-4529-8536-b80a7769e899')
$RuleScope = @()

# 'Summary' = human readable single line for the on-screen report column.
# 'Json'    = compact JSON, easier to parse out of the CSV export.
$OutputFormat = 'Summary'

# How many top offenders to name in the detection output.
$TopOffenderCount = 3

# Hard ceiling on returned events, protects against a very noisy device.
$MaxEventsToRead = 2000

$LogFolder      = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs'
$LogFileName    = 'ASR-Detection.log'
$LogMaxBytes    = 2MB
$LogComponent   = 'Detect-AsrBlockEvents'

# Intune truncates the detection output column. Documented limit is 2048 characters.
$MaxOutputChars = 2000

$DefenderLog = 'Microsoft-Windows-Windows Defender/Operational'

#endregion

#region Reference data

$EventMap = @{
    1121 = 'Blocked'
    1122 = 'Audited'
}

$AsrRules = @{
    '56a863a9-875e-4185-98a7-b882c64b5ce5' = 'Vulnerable signed drivers'
    '7674ba52-37eb-4a4f-a9a1-f0f9a1619a2c' = 'Adobe Reader child process'
    'd4f940ab-401b-4efc-aadc-ad5f3c50688a' = 'Office child process'
    '9e6c4e1f-7d60-472f-ba1a-a39ef669e4b2' = 'LSASS credential theft'
    'be9ba2d9-53ea-4cdc-84e5-9b1eeee46550' = 'Executable content from email'
    '01443614-cd74-433a-b99e-2ecdc07bfc25' = 'Prevalence age trusted list'
    '5beb7efe-fd9a-4556-801d-275e5ffc04cc' = 'Obfuscated script execution'
    'd3e037e1-3eb8-44c8-a917-57927947596d' = 'JS VBScript launching payload'
    '3b576869-a4ec-4529-8536-b80a7769e899' = 'Office executable content'
    '75668c1f-73b5-4cf0-bb93-3ecf5cb7cc84' = 'Office code injection'
    '26190899-1602-49e8-8b27-eb1d0a1ce869' = 'Office comms child process'
    'e6db77e5-3df2-4cf1-b95a-636979351e5b' = 'WMI event subscription persistence'
    'd1e49aac-8f56-4280-b9ba-993a6d77406c' = 'PSExec and WMI process creation'
    '33ddedf1-c6e0-47cb-833e-de6133960387' = 'Reboot to Safe Mode'
    'b2b3f03d-6a65-4f7b-a9c7-1c7ef74a9ba4' = 'Untrusted unsigned USB process'
    'c0033c00-d16d-4114-a5a0-dc9b3a7d2ceb' = 'Copied impersonated system tools'
    'a8f5898e-1dc8-49a9-9878-85004b8a61e6' = 'Webshell creation on servers'
    '92e97fa1-2edf-4476-bdd6-9dd0b4dddc7b' = 'Win32 API from Office macro'
    'c1db55ab-c21a-4637-bb3f-a12568109d35' = 'Advanced ransomware protection'
}

$ActionCodes = @{
    0 = 'Disabled'
    1 = 'Block'
    2 = 'Audit'
    5 = 'NotConfigured'
    6 = 'Warn'
}

#endregion

#region Logging

function Initialize-ImeLog {
    <#
        Creates the log path if the IME folder is missing, and rolls the file at
        the size ceiling using the same .lo_ convention the IME itself uses.
    #>
    param([string]$Folder, [string]$FileName, [int64]$MaxBytes)

    if (-not (Test-Path -LiteralPath $Folder)) {
        New-Item -Path $Folder -ItemType Directory -Force | Out-Null
    }

    $full = Join-Path $Folder $FileName

    if (Test-Path -LiteralPath $full) {
        $size = (Get-Item -LiteralPath $full).Length
        if ($size -ge $MaxBytes) {
            $archive = [System.IO.Path]::ChangeExtension($full, 'lo_')
            if (Test-Path -LiteralPath $archive) { Remove-Item -LiteralPath $archive -Force }
            Move-Item -LiteralPath $full -Destination $archive -Force
        }
    }

    return $full
}

function Write-ImeLog {
    <#
        Emits a CMTrace-format line. Deliberately does not write to the
        PowerShell output stream: anything on STDOUT lands in the Intune report
        column, so logging and reporting are kept strictly separate.
    #>
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('Info', 'Warning', 'Error')][string]$Severity = 'Info',
        [string]$Path = $script:LogPath,
        [string]$Component = $script:LogComponent
    )

    if ([string]::IsNullOrWhiteSpace($Path)) { return }

    $typeMap = @{ Info = 1; Warning = 2; Error = 3 }
    $now = Get-Date

    # CMTrace expects the UTC bias in minutes, inverted, appended to the time.
    $bias = -([int]([TimeZoneInfo]::Local.GetUtcOffset($now).TotalMinutes))

    $line = '<![LOG[{0}]LOG]!><time="{1}{2}" date="{3}" component="{4}" context="" type="{5}" thread="{6}" file="">' -f `
        $Message,
        $now.ToString('HH:mm:ss.fff'),
        $bias,
        $now.ToString('MM-dd-yyyy'),
        $Component,
        $typeMap[$Severity],
        $PID

    try {
        Add-Content -LiteralPath $Path -Value $line -Encoding UTF8 -ErrorAction Stop
    }
    catch {
        # Logging must never be the reason a detection script fails.
    }
}

#endregion

#region Helpers

function Get-AsrConfiguredState {
    <#
        AttackSurfaceReductionRules_Ids and _Actions are two parallel arrays
        matched by index. This tells you whether a rule that fired is currently
        set to Block, Audit or Warn, which the event itself does not record.
    #>
    $state = @{}
    try {
        $pref = Get-MpPreference -ErrorAction Stop
    }
    catch {
        Write-ImeLog -Message "Get-MpPreference failed: $($_.Exception.Message)" -Severity Warning
        return $state
    }

    $ids     = @($pref.AttackSurfaceReductionRules_Ids)
    $actions = @($pref.AttackSurfaceReductionRules_Actions)

    for ($i = 0; $i -lt $ids.Count; $i++) {
        if ([string]::IsNullOrWhiteSpace($ids[$i])) { continue }
        $code = if ($i -lt $actions.Count) { [int]$actions[$i] } else { -1 }
        $name = if ($ActionCodes.ContainsKey($code)) { $ActionCodes[$code] } else { "Unknown$code" }
        $state[$ids[$i].ToString().Trim('{','}').ToLower()] = $name
    }

    return $state
}

function ConvertFrom-DefenderEvent {
    <#
        Reads the structured EventData from the record XML first, then falls back
        to regex over the rendered message, which is localised and varies across
        Windows builds.
    #>
    param(
        [Parameter(Mandatory)][System.Diagnostics.Eventing.Reader.EventRecord]$EventRecord,
        [hashtable]$RuleState = @{}
    )

    $fields = @{}
    try {
        $xml = [xml]$EventRecord.ToXml()
        if ($xml.Event.EventData -and $xml.Event.EventData.Data) {
            foreach ($node in $xml.Event.EventData.Data) {
                if ($node.Name) { $fields[$node.Name] = [string]$node.'#text' }
            }
        }
    }
    catch { }

    $message = ''
    try { $message = $EventRecord.FormatDescription() } catch { }

    function Resolve-Field {
        param([string[]]$Names, [string]$Pattern)
        foreach ($n in $Names) {
            if ($fields.ContainsKey($n) -and -not [string]::IsNullOrWhiteSpace($fields[$n])) {
                return $fields[$n].Trim()
            }
        }
        if ($Pattern -and $message -match $Pattern) { return $Matches[1].Trim() }
        return $null
    }

    $ruleId = Resolve-Field -Names @('ID','Id')      -Pattern '(?m)^\s*ID:\s*\{?([0-9A-Fa-f-]{36})\}?\s*$'
    $target = Resolve-Field -Names @('Path')         -Pattern '(?m)^\s*Path:\s*(.+?)\s*$'
    $parent = Resolve-Field -Names @('Process Name') -Pattern '(?m)^\s*Process Name:\s*(.+?)\s*$'
    $user   = Resolve-Field -Names @('User')         -Pattern '(?m)^\s*User:\s*(.+?)\s*$'

    $key = if ($ruleId) { $ruleId.Trim('{','}').ToLower() } else { $null }

    $ruleName = 'UnknownRule'
    if ($key) {
        $ruleName = if ($AsrRules.ContainsKey($key)) { $AsrRules[$key] } else { "Unmapped $($key.Substring(0,8))" }
    }

    [pscustomobject]@{
        TimeCreated       = $EventRecord.TimeCreated
        EventId           = [int]$EventRecord.Id
        Action            = $EventMap[[int]$EventRecord.Id]
        RuleId            = $key
        RuleName          = $ruleName
        ConfiguredAction  = if ($key -and $RuleState.ContainsKey($key)) { $RuleState[$key] } else { 'Unknown' }
        InitiatingProcess = $parent
        InitiatingLeaf    = if ($parent) { Split-Path -Path $parent -Leaf } else { 'Unknown' }
        BlockedTarget     = $target
        User              = $user
    }
}

function Limit-OutputString {
    param([string]$Value, [int]$MaxLength)
    if ([string]::IsNullOrEmpty($Value)) { return '' }
    if ($Value.Length -le $MaxLength) { return $Value }
    return $Value.Substring(0, $MaxLength - 3) + '...'
}

#endregion

#region Main

$script:LogPath      = $null
$script:LogComponent = $LogComponent

try {
    $script:LogPath = Initialize-ImeLog -Folder $LogFolder -FileName $LogFileName -MaxBytes $LogMaxBytes
}
catch {
    # Carry on without a log rather than failing the detection.
}

Write-ImeLog -Message ("=" * 60)
Write-ImeLog -Message "Detection started. Device: $env:COMPUTERNAME. Lookback: $LookbackDays day(s). Bitness: $([IntPtr]::Size * 8)-bit."

try {
    if (-not (Get-WinEvent -ListLog $DefenderLog -ErrorAction SilentlyContinue)) {
        throw "Event log '$DefenderLog' not present. Defender Antivirus may be disabled or replaced."
    }

    $ruleState = Get-AsrConfiguredState
    Write-ImeLog -Message "Configured ASR rules read from Get-MpPreference: $($ruleState.Count)."

    $enabledBlock = @($ruleState.GetEnumerator() | Where-Object { $_.Value -eq 'Block' }).Count
    $enabledAudit = @($ruleState.GetEnumerator() | Where-Object { $_.Value -eq 'Audit' }).Count
    Write-ImeLog -Message "Rules in Block mode: $enabledBlock. Rules in Audit mode: $enabledAudit."

    $targetIds = if ($IncludeAuditEvents) { @(1121, 1122) } else { @(1121) }

    $filter = @{
        LogName   = $DefenderLog
        Id        = $targetIds
        StartTime = (Get-Date).AddDays(-[Math]::Abs($LookbackDays))
    }

    $raw = @(Get-WinEvent -FilterHashtable $filter -MaxEvents $MaxEventsToRead -ErrorAction SilentlyContinue)
    Write-ImeLog -Message "Raw Exploit Guard records returned: $($raw.Count)."

    $parsed = @()
    foreach ($record in $raw) {
        $parsed += ConvertFrom-DefenderEvent -EventRecord $record -RuleState $ruleState
    }

    if ($RuleScope.Count -gt 0) {
        $scope = $RuleScope | ForEach-Object { $_.ToString().Trim('{','}').ToLower() }
        $parsed = @($parsed | Where-Object { $_.RuleId -and $scope -contains $_.RuleId })
        Write-ImeLog -Message "Rule scope filter applied. Records remaining: $($parsed.Count)."
    }

    $parsed = @($parsed | Sort-Object TimeCreated -Descending)

    # Full detail goes to the log. Only the summary goes to the report column.
    foreach ($evt in $parsed) {
        $severity = if ($evt.Action -eq 'Blocked') { 'Warning' } else { 'Info' }
        Write-ImeLog -Severity $severity -Message (
            "{0} | Rule: {1} | Mode: {2} | Initiator: {3} | Target: {4} | User: {5} | Time: {6:yyyy-MM-dd HH:mm:ss}" -f `
            $evt.Action, $evt.RuleName, $evt.ConfiguredAction,
            $evt.InitiatingProcess, $evt.BlockedTarget, $evt.User, $evt.TimeCreated
        )
    }

    $blockCount = @($parsed | Where-Object { $_.Action -eq 'Blocked' }).Count
    $auditCount = @($parsed | Where-Object { $_.Action -eq 'Audited' }).Count
    $flagCount  = if ($IncludeAuditEvents) { $parsed.Count } else { $blockCount }

    if ($flagCount -lt $MinimumEventCount) {
        $clean = "OK: no qualifying ASR events in last ${LookbackDays}d. Blocks=$blockCount Audits=$auditCount Threshold=$MinimumEventCount"
        Write-ImeLog -Message "Result: compliant. $clean"
        Write-ImeLog -Message "Detection finished. Exit 0."
        Write-Output (Limit-OutputString -Value $clean -MaxLength $MaxOutputChars)
        exit 0
    }

    $top = @(
        $parsed |
        Group-Object RuleName, InitiatingLeaf |
        Sort-Object Count -Descending |
        Select-Object -First $TopOffenderCount
    )

    $latest = $parsed[0]

    if ($OutputFormat -eq 'Json') {
        $payload = [ordered]@{
            d = $env:COMPUTERNAME
            w = $LookbackDays
            b = $blockCount
            a = $auditCount
            l = $latest.TimeCreated.ToString('yyyy-MM-ddTHH:mm:ss')
            t = @(
                $top | ForEach-Object {
                    [ordered]@{
                        r = $_.Group[0].RuleName
                        p = $_.Group[0].InitiatingLeaf
                        m = $_.Group[0].ConfiguredAction
                        c = $_.Count
                    }
                }
            )
        }
        $output = $payload | ConvertTo-Json -Compress -Depth 4
    }
    else {
        $topText = ($top | ForEach-Object {
            "{0} x{1} via {2} [{3}]" -f $_.Group[0].RuleName, $_.Count, $_.Group[0].InitiatingLeaf, $_.Group[0].ConfiguredAction
        }) -join '; '

        $output = "ASR HITS: Blocks=$blockCount Audits=$auditCount in ${LookbackDays}d | Top: $topText | Last: $($latest.TimeCreated.ToString('yyyy-MM-dd HH:mm'))"
    }

    $output = Limit-OutputString -Value $output -MaxLength $MaxOutputChars

    Write-ImeLog -Severity Warning -Message "Result: issues found. Blocks=$blockCount Audits=$auditCount."
    Write-ImeLog -Message "Report output: $output"
    Write-ImeLog -Message "Detection finished. Exit 1."

    Write-Output $output
    exit 1
}
catch {
    $failure = "DETECTION FAILED: $($_.Exception.Message)"
    Write-ImeLog -Severity Error -Message $failure
    Write-ImeLog -Severity Error -Message "Trace: $($_.ScriptStackTrace)"

    # STDERR makes Intune report a detection script error rather than a device with issues.
    [Console]::Error.WriteLine($failure)
    exit 1
}

#endregion
