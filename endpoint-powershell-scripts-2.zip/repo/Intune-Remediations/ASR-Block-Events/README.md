# Detect-AsrBlockEvents.ps1 (report-only Intune Remediation)

Reports Microsoft Defender Attack Surface Reduction (ASR) block (event 1121) and audit (event 1122) events from the Defender Operational log, and turns the Intune Remediations report into an ASR impact report.

## What it does
- Reads ASR events for the last `$LookbackDays`, parsing structured EventData first and falling back to the rendered message.
- Maps rule GUIDs to friendly names and looks up each rule's configured mode (Block, Audit, Warn) from `Get-MpPreference`.
- Writes every event to a CMTrace log: `%ProgramData%\Microsoft\IntuneManagementExtension\Logs\ASR-Detection.log` (rotates at 2 MB to `.lo_`).
- Writes one summary line to the report column, for example:
  `ASR HITS: Blocks=3 Audits=12 in 1d | Top: Office child process x9 via WINWORD.EXE [Audit]; ...`

| Result | Report status |
|---|---|
| exit 0 + `OK:` line | Without issues |
| exit 1 + `ASR HITS:` line | With issues |
| STDERR | Detection script error |

## Settings
| Variable | Default | Notes |
|---|---|---|
| `$LookbackDays` | 1 | Match your schedule so events are not counted twice |
| `$MinimumEventCount` | 1 | Raise to cut noise |
| `$IncludeAuditEvents` | `$true` | Turn off once rules are in Block |
| `$RuleScope` | all | List rule GUIDs to focus on |
| `$OutputFormat` | Summary | `Json` for compact parseable output in the CSV export |

## Deployment
Detection script only, remediation left empty. SYSTEM, 64-bit PowerShell.

## Suggested rollout
1. Baseline: 7-day window, audits on, threshold 1, run once.
2. Narrow: set `$RuleScope` to the rules you are about to enforce, daily schedule, 1-day window.

The log contains file paths and usernames. Check that suits your data handling rules before deploying widely. Where devices are onboarded to Defender for Endpoint, Advanced Hunting on `DeviceEvents` gives the same data centrally.
