<#
.SYNOPSIS
    No-op remediation script for Intune Remediations.
.DESCRIPTION
    Makes no changes. Only runs if detection returns exit 1,
    which the paired detection script never does.
.NOTES
    Author : Simon Diaz
#>

Write-Output "No-op remediation: no action taken"
exit 0
