# No-op Intune Remediation pair

| Script | Role |
|---|---|
| `Detect-NoOp.ps1` | Always exits 0 (compliant) |
| `Remediate-NoOp.ps1` | Does nothing, exits 0 |

## Uses
- Confirm the Remediations pipeline works on a device or group (licensing, IME health, check-in timing).
- Hold a placeholder assignment while the real logic is built.
- Test reporting and schedules with no risk to endpoints.

To exercise the remediation path, change detection to `exit 1`. Output then appears in both report columns. If you see "No-op remediation: no action taken" from a different package, that is Intune's own message meaning detection returned compliant and remediation never ran.
