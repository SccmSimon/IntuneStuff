<#
.SYNOPSIS
    No-op detection script for Intune Remediations.
.DESCRIPTION
    Always reports compliant. Exit code 0 tells Intune "no issue found",
    so the remediation script is never triggered.
.NOTES
    Author : Simon Diaz
    Change to 'exit 1' to test the remediation path (which still changes nothing).
#>

Write-Output "No-op detection: compliant"
exit 0
