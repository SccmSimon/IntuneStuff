# Company Portal (Intune Remediation pair)

| Script | Role |
|---|---|
| `Detect-CompanyPortal.ps1` | Detection |
| `Remediate-CompanyPortal.ps1` | Remediation |

## What it does
**Detection** checks `Microsoft.CompanyPortal` with `Get-AppxPackage -AllUsers` and `Get-AppxProvisionedPackage -Online`. Exit 0 if installed for any user or provisioned.

**Remediation** finds the newest `Microsoft.DesktopAppInstaller` folder under `Program Files\WindowsApps` (SYSTEM has no winget alias), runs `winget install --id 9WZDNCRFJ3PZ --source msstore --scope machine --silent`, then confirms the package actually landed rather than trusting winget's exit code.

Log: `%ProgramData%\Microsoft\IntuneManagementExtension\Logs\Remediation-CompanyPortal.log` (picked up by Collect diagnostics).

## Intune settings
| Setting | Value |
|---|---|
| Run using logged-on credentials | No (SYSTEM) |
| Run in 64-bit PowerShell | Yes (Appx cmdlets fail in 32-bit) |
| Schedule | Daily |

## Notes
- Best used as a safety net alongside a Required Microsoft Store app (new) assignment.
- Fails if App Installer is missing or the Store endpoints are blocked at the proxy.
- Test as SYSTEM with `psexec -s -i powershell.exe`.
