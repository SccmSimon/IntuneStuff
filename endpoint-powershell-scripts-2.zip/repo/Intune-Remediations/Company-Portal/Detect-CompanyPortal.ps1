<#
.SYNOPSIS
    Intune Remediation detection: Company Portal
.DESCRIPTION
    Checks whether the Intune Company Portal is installed for any user
    or provisioned for new users on the device.
.NOTES
    Author : Simon Diaz
    Run as SYSTEM, 64-bit PowerShell (required for Appx cmdlets).
    Exit 0 = compliant (installed), Exit 1 = non-compliant (run remediation)
#>

$PackageName = 'Microsoft.CompanyPortal'

try {
    $installed   = Get-AppxPackage -AllUsers -Name $PackageName -ErrorAction Stop
    $provisioned = Get-AppxProvisionedPackage -Online -ErrorAction Stop |
        Where-Object { $_.DisplayName -eq $PackageName }

    if ($installed -or $provisioned) {
        $version = ($installed | Select-Object -First 1).Version
        if (-not $version) { $version = ($provisioned | Select-Object -First 1).Version }
        Write-Output "COMPLIANT: Company Portal present. Version $version"
        exit 0
    }
    Write-Output "NON-COMPLIANT: Company Portal not installed or provisioned"
    exit 1
}
catch {
    Write-Output "NON-COMPLIANT: Detection error - $($_.Exception.Message)"
    exit 1
}
