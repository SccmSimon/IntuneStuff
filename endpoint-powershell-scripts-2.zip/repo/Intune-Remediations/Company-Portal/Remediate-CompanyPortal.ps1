<#
.SYNOPSIS
    Intune Remediation: Install Company Portal
.DESCRIPTION
    Resolves winget.exe in SYSTEM context and installs Company Portal
    from the msstore source. Logs to the IME logs folder so it is
    collected with Intune diagnostics.
.NOTES
    Author : Simon Diaz
    Run as SYSTEM, 64-bit PowerShell.
#>

$StoreId     = '9WZDNCRFJ3PZ'              # Company Portal Store ID
$PackageName = 'Microsoft.CompanyPortal'
$LogFile     = "$env:ProgramData\Microsoft\IntuneManagementExtension\Logs\Remediation-CompanyPortal.log"

function Write-Log {
    param([string]$Message)
    $line = "{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue
}

try {
    Write-Log "===== Remediation started ====="

    # 1. Find winget.exe. SYSTEM has no user app execution alias, so resolve it from WindowsApps.
    $wingetFolder = Get-ChildItem -Path "$env:ProgramFiles\WindowsApps" -Directory `
                        -Filter 'Microsoft.DesktopAppInstaller_*_x64__8wekyb3d8bbwe' -ErrorAction Stop |
                    Sort-Object { [version]($_.Name -split '_')[1] } -Descending |
                    Select-Object -First 1

    if (-not $wingetFolder) { throw "App Installer (winget) not found on device" }

    $winget = Join-Path $wingetFolder.FullName 'winget.exe'
    if (-not (Test-Path $winget)) { throw "winget.exe missing at $winget" }
    Write-Log "Using winget: $winget"

    # 2. Install from the Microsoft Store source
    $wingetArgs = @(
        'install'
        '--id', $StoreId
        '--source', 'msstore'
        '--scope', 'machine'
        '--silent'
        '--accept-package-agreements'
        '--accept-source-agreements'
        '--disable-interactivity'
    )

    Write-Log "Running: winget $($wingetArgs -join ' ')"
    $result   = & $winget @wingetArgs 2>&1
    $exitCode = $LASTEXITCODE
    $result | ForEach-Object { Write-Log "winget: $_" }
    Write-Log "winget exit code: $exitCode"

    # 3. Verify rather than trusting the exit code alone
    Start-Sleep -Seconds 10
    $check = Get-AppxPackage -AllUsers -Name $PackageName -ErrorAction SilentlyContinue

    if ($check) {
        Write-Log "SUCCESS: Company Portal installed. Version $($check[0].Version)"
        Write-Output "REMEDIATED: Company Portal installed. Version $($check[0].Version)"
        exit 0
    }
    throw "Install ran (exit $exitCode) but package not detected afterwards"
}
catch {
    Write-Log "FAILED: $($_.Exception.Message)"
    Write-Output "FAILED: $($_.Exception.Message)"
    exit 1
}
