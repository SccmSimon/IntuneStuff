<#
.SYNOPSIS
    Detects vulnerable per-user application installs in dormant (unloaded)
    user profiles.

.DESCRIPTION
    Intune Proactive Remediation DETECTION script (SYSTEM context).
    Read-only. Makes no changes to disk or registry.

    Targets per-user installs of Zoom, Microsoft Teams (classic) and
    Google Chrome that sit inside profiles no one is currently using.
    These are a common Qualys finding because per-user installs miss
    machine-wide patching.

    Checks two kinds of evidence, matching how Qualys may detect either:
      1. Application folders on disk under the profile
      2. Uninstall registry keys inside the profile's NTUSER.DAT hive

    Registry checks mount the profile hive via reg.exe, then unload it.
    The PowerShell registry provider is deliberately not used, as it
    holds handles that block hive unload.

    This file contains ASCII characters only. Do not introduce box drawing
    characters, em dashes or other non-ASCII text. Windows PowerShell 5.1
    reads a UTF-8 file without a BOM as ANSI, which corrupts multi byte
    sequences and produces parser errors far from the real fault.

.PARAMETER DaysThreshold
    Optional. If greater than 0, only profiles unused for this many days
    are checked. Default 0, meaning all unloaded profiles are checked.
    Where age cannot be determined the profile is still checked, as the
    remediation action is reversible.

.PARAMETER SkipRegistryCheck
    Skip the NTUSER.DAT hive checks and inspect folders only.

.PARAMETER LogPath
    Path to write the log file.

.NOTES
    Author     : Simon Diaz
    Requires   : PowerShell 5.1+
    Run context: SYSTEM
    Exit codes : 0 = compliant   1 = non-compliant

    Does not cover new Teams, which is an MSIX package and is serviced
    through the Store or Intune rather than a per-user folder install.

.VERSION HISTORY
    1.0.0   Initial release. Folder and registry hive detection for per-user
            Zoom, Teams (classic) and Chrome installs in unloaded profiles.

    1.0.1   Fixed parser error reported by the Intune Management Extension
            ("Unexpected token '}'"). Two statements placed script blocks
            inside a subexpression inside a double quoted string, which the
            Windows PowerShell 5.1 parser did not handle reliably. Both have
            been rewritten as plain statements.
            Replaced the SID derived hive mount name with a GUID. The former
            stripped all non digit characters from the SID and took the last
            12, which could collide between two profiles on one device and
            cause a mount onto a name already in use.
            Removed all non ASCII characters from the file, including box
            drawing separators, to eliminate encoding related parse failures
            when the script is delivered through Intune.

    1.0.2   Fixed "NativeCommandError" thrown by reg.exe. A query against a
            key that does not exist is the routine not-found case: reg.exe
            writes to stderr and returns 1. With $ErrorActionPreference set
            to Stop, that stderr output was promoted to a terminating error,
            so the script failed on the first profile lacking a target app,
            which is the case the check exists to identify.
            All reg.exe calls now route through Invoke-RegCommand, which
            relaxes the preference for the duration of the call and restores
            it, and splats arguments as an array so key names containing
            spaces are passed correctly. Detection logic is unchanged.

    1.0.3   Console output now lists the artefacts found, not just a count and
            a list of app names. Intune shows standard output in the
            "Pre-remediation detection output" column, so the console alone
            now tells you which profile holds what, and whether the evidence
            was a folder (F), a registry key (R) or both. Output is grouped by
            profile and trimmed to fit the 2048 character column, with a count
            of anything dropped. No change to what is detected.
#>

[CmdletBinding()]
param (
    [Parameter()]
    [ValidateRange(0, 365)]
    [int]$DaysThreshold = 0,

    [Parameter()]
    [switch]$SkipRegistryCheck,

    [Parameter()]
    [string]$LogPath = 'C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\Remove-StaleProfileApps-Detection.log'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- Version ----------------------------------------------------------------
$ScriptVersion = '1.0.3'

#region ---- Logging ----------------------------------------------------------

$script:LogPathResolved = $LogPath
try {
    $logDir = Split-Path -Path $LogPath -Parent
    if (-not (Test-Path -Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force -ErrorAction Stop | Out-Null
    }
    Add-Content -Path $LogPath -Value '' -Encoding UTF8 -ErrorAction Stop
}
catch {
    $script:LogPathResolved = Join-Path $env:TEMP 'Remove-StaleProfileApps-Detection.log'
    Write-Host "[WARN] Could not write to '$LogPath'. Falling back to: $($script:LogPathResolved)" -ForegroundColor Yellow
    Add-Content -Path $script:LogPathResolved -Value '' -Encoding UTF8
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','ACTION','SKIP','FOUND')]
        [string]$Level = 'INFO'
    )
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line  = "[$stamp] [$Level] $Message"

    try { Add-Content -Path $script:LogPathResolved -Value $line -Encoding UTF8 -ErrorAction Stop }
    catch { Write-Host "[WARN] Log write failed: $_" -ForegroundColor Yellow }

    $colour = switch ($Level) {
        'INFO'   { 'Cyan'    }
        'WARN'   { 'Yellow'  }
        'ERROR'  { 'Red'     }
        'ACTION' { 'Green'   }
        'SKIP'   { 'Gray'    }
        'FOUND'  { 'Magenta' }
    }
    Write-Host $line -ForegroundColor $colour
}

$RuleLine = '-----------------------------------------------------------'
$BarLine  = '==========================================================='

#endregion

#region ---- Target application definitions -----------------------------------

# Paths are relative to the profile root.
# UninstallKeys are key names under
#   Software\Microsoft\Windows\CurrentVersion\Uninstall
# inside the profile's own NTUSER.DAT hive.
$targetApps = @(
    [PSCustomObject]@{
        Name          = 'Zoom'
        Paths         = @('AppData\Local\Zoom')
        UninstallKeys = @('ZoomUMX')
    },
    [PSCustomObject]@{
        Name          = 'Microsoft Teams (classic)'
        Paths         = @('AppData\Local\Microsoft\Teams')
        UninstallKeys = @('Teams')
    },
    [PSCustomObject]@{
        Name          = 'Google Chrome'
        Paths         = @('AppData\Local\Google\Chrome\Application')
        UninstallKeys = @('Google Chrome')
    }
)

#endregion

#region ---- Hive helpers -----------------------------------------------------

function Invoke-RegCommand {
    param([string[]]$Arguments)

    # reg.exe writes to stderr on any non-zero result, including the routine
    # "key not found" case. Under $ErrorActionPreference = 'Stop' that stderr
    # output is promoted to a terminating NativeCommandError, so the preference
    # is relaxed for the duration of the call and restored afterwards.
    # The array splat passes each argument separately, which handles key names
    # containing spaces such as "Google Chrome" without extra quoting.
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $null = & reg.exe @Arguments 2>&1
        return $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $previousPreference
    }
}

function Mount-ProfileHive {
    param(
        [string]$ProfilePath,
        [string]$MountName
    )
    $ntUserDat = Join-Path $ProfilePath 'NTUSER.DAT'

    if (-not (Test-Path -LiteralPath $ntUserDat)) {
        Write-Log "No NTUSER.DAT at $ntUserDat" -Level WARN
        return $false
    }

    $exitCode = Invoke-RegCommand -Arguments @('load', "HKU\$MountName", $ntUserDat)
    if ($exitCode -ne 0) {
        Write-Log "Hive load failed for $ProfilePath (reg.exe exit $exitCode)" -Level WARN
        return $false
    }
    return $true
}

function Dismount-ProfileHive {
    param([string]$MountName)

    for ($attempt = 1; $attempt -le 3; $attempt++) {
        [System.GC]::Collect()
        [System.GC]::WaitForPendingFinalizers()

        if ((Invoke-RegCommand -Arguments @('unload', "HKU\$MountName")) -eq 0) { return $true }

        Start-Sleep -Seconds 2
    }

    Write-Log "Hive unload FAILED for HKU\$MountName after 3 attempts. Profile may be locked." -Level ERROR
    return $false
}

function Test-HiveKey {
    param([string]$FullKeyPath)

    return ((Invoke-RegCommand -Arguments @('query', $FullKeyPath)) -eq 0)
}

#endregion

#region ---- Main -------------------------------------------------------------

# Build header values as plain statements. Do not inline an if block inside
# a string subexpression, as that is what broke the 1.0.0 parse.
$regCheckState = 'ENABLED'
if ($SkipRegistryCheck) { $regCheckState = 'DISABLED' }

$thresholdText = 'not applied, all unloaded profiles checked'
if ($DaysThreshold -gt 0) {
    $cutoffDate    = (Get-Date).AddDays(-$DaysThreshold)
    $cutoffText    = $cutoffDate.ToString('yyyy-MM-dd')
    $thresholdText = "$DaysThreshold days (cutoff: $cutoffText)"
}

$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name

Write-Log $BarLine
Write-Log "Remove-StaleProfileApps-Detection started (v$ScriptVersion)"
Write-Log "Mode          : DETECTION (read-only)"
Write-Log "Days threshold: $thresholdText"
Write-Log "Registry check: $regCheckState"
Write-Log "Log path      : $script:LogPathResolved"
Write-Log "Running as    : $identity"
Write-Log "Computer      : $env:COMPUTERNAME"
Write-Log $BarLine

$protectedSIDs = @('S-1-5-18', 'S-1-5-19', 'S-1-5-20')
$skipFolders   = @('Default', 'Default User', 'Public', 'All Users',
                   'LocalService', 'NetworkService', 'systemprofile')

$allProfilesRaw = @(Get-CimInstance Win32_UserProfile)
$allProfiles    = @($allProfilesRaw | Where-Object { -not $_.Special })

Write-Log "Profiles returned by CIM  : $($allProfilesRaw.Count)"
Write-Log "Profiles to evaluate      : $($allProfiles.Count)"
Write-Log $RuleLine

$findings = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($userProfile in $allProfiles) {

    $profilePath = $userProfile.LocalPath
    $sid         = $userProfile.SID

    Write-Log "Evaluating: $profilePath (SID: $sid)"

    # ---- Guards ------------------------------------------------------------
    if ($sid -in $protectedSIDs) {
        Write-Log "SKIP: $profilePath | Protected system account SID" -Level SKIP
        continue
    }
    if ($userProfile.Loaded) {
        Write-Log "SKIP: $profilePath | Profile currently loaded" -Level SKIP
        continue
    }
    if (-not (Test-Path -LiteralPath $profilePath)) {
        Write-Log "SKIP: $profilePath | Path not found on disk" -Level SKIP
        continue
    }
    if ((Split-Path $profilePath -Leaf) -in $skipFolders) {
        Write-Log "SKIP: $profilePath | System or default profile folder" -Level SKIP
        continue
    }

    # ---- Optional age gate -------------------------------------------------
    if ($DaysThreshold -gt 0) {

        $lastUseTime = $null
        if ($userProfile.LastUseTime) {
            try {
                $lastUseTime = [System.Management.ManagementDateTimeConverter]::ToDateTime($userProfile.LastUseTime)
            }
            catch { }
        }

        if ($lastUseTime) {
            if ($lastUseTime -ge $cutoffDate) {
                $ageDays = [math]::Round(((Get-Date) - $lastUseTime).TotalDays, 1)
                Write-Log "SKIP: $profilePath | Within threshold, last used $ageDays days ago" -Level SKIP
                continue
            }
        }
        else {
            Write-Log "Age unknown for $profilePath. Proceeding, action is reversible." -Level WARN
        }
    }

    # ---- Folder evidence ---------------------------------------------------
    foreach ($app in $targetApps) {
        foreach ($relPath in $app.Paths) {

            $fullPath = Join-Path $profilePath $relPath
            if (-not (Test-Path -LiteralPath $fullPath)) { continue }

            Write-Log "FOUND (folder): $($app.Name) | $fullPath" -Level FOUND
            $findings.Add([PSCustomObject]@{
                Profile  = $profilePath
                App      = $app.Name
                Evidence = 'Folder'
                Detail   = $fullPath
            })
        }
    }

    # ---- Registry evidence -------------------------------------------------
    if ($SkipRegistryCheck) { continue }

    # GUID based mount name. A SID derived name can collide between profiles.
    $mountName = 'StaleAppScan_' + [guid]::NewGuid().ToString('N').Substring(0, 12)

    if (-not (Mount-ProfileHive -ProfilePath $profilePath -MountName $mountName)) { continue }

    try {
        foreach ($app in $targetApps) {
            foreach ($keyName in $app.UninstallKeys) {

                $keyPath = "HKU\$mountName\Software\Microsoft\Windows\CurrentVersion\Uninstall\$keyName"
                if (-not (Test-HiveKey -FullKeyPath $keyPath)) { continue }

                Write-Log "FOUND (registry): $($app.Name) | $keyName" -Level FOUND
                $findings.Add([PSCustomObject]@{
                    Profile  = $profilePath
                    App      = $app.Name
                    Evidence = 'Registry'
                    Detail   = $keyName
                })
            }
        }
    }
    finally {
        $null = Dismount-ProfileHive -MountName $mountName
    }
}

# ---- Summary ---------------------------------------------------------------
$affectedProfiles = @($findings | Select-Object -ExpandProperty Profile -Unique)

Write-Log $BarLine
Write-Log "SUMMARY - DETECTION"
Write-Log "Profiles evaluated   : $($allProfiles.Count)"
Write-Log "Profiles with finds  : $($affectedProfiles.Count)"
Write-Log "Total artefacts found: $($findings.Count)"
Write-Log $RuleLine

foreach ($f in $findings) {
    Write-Log "  [$($f.Evidence)] $($f.App) | $($f.Detail)"
}

Write-Log $BarLine
Write-Log "Remove-StaleProfileApps-Detection completed (v$ScriptVersion)"
Write-Log $BarLine

# ---- Build the console output ----------------------------------------------
# Intune shows the script's standard output in the "Pre-remediation detection
# output" column, capped at 2048 characters. The artefacts are listed there so
# the console alone tells you what was found, without opening the device log.
# Format is one group per profile:
#   <profile>: <App>(F,R), <App>(F)
# where F is a folder artefact and R is a registry artefact.

function Get-FindingsSummary {
    param(
        [System.Collections.Generic.List[PSCustomObject]]$Findings,
        [int]$MaxLength = 1800
    )

    $groups = @()

    foreach ($profileGroup in ($Findings | Group-Object -Property Profile)) {

        $profileName = Split-Path $profileGroup.Name -Leaf
        $appParts    = @()

        foreach ($appGroup in ($profileGroup.Group | Group-Object -Property App)) {

            $marks = @()
            if ($appGroup.Group | Where-Object { $_.Evidence -eq 'Folder'   }) { $marks += 'F' }
            if ($appGroup.Group | Where-Object { $_.Evidence -eq 'Registry' }) { $marks += 'R' }

            $appParts += ($appGroup.Name + '(' + ($marks -join ',') + ')')
        }

        $groups += ($profileName + ': ' + ($appParts -join ', '))
    }

    $summary = $groups -join ' | '

    # Trim rather than let Intune truncate mid-word, and say how much was cut.
    if ($summary.Length -gt $MaxLength) {
        $kept          = @()
        $runningLength = 0
        $dropped       = 0

        foreach ($g in $groups) {
            if (($runningLength + $g.Length + 3) -le ($MaxLength - 20)) {
                $kept += $g
                $runningLength += ($g.Length + 3)
            }
            else {
                $dropped++
            }
        }
        $summary = ($kept -join ' | ') + " | +$dropped more"
    }

    return $summary
}

# ---- Exit ------------------------------------------------------------------
if ($findings.Count -gt 0) {

    $summaryText = Get-FindingsSummary -Findings $findings

    Write-Host "Non-compliant: $($findings.Count) artefact(s), $($affectedProfiles.Count) profile(s). $summaryText"
    Write-Log "DETECTION: Non-compliant. $($findings.Count) artefact(s) found." -Level WARN
    Write-Log "DETECTION: $summaryText" -Level WARN

    exit 1
}
else {

    Write-Host "Compliant: No per-user app installs found in dormant profiles."
    Write-Log "DETECTION: Compliant. Nothing found." -Level INFO

    exit 0
}

#endregion
