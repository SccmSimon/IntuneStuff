# Stale Profile Apps (Intune Remediation pair)

| Script | Role |
|---|---|
| `Remove-StaleProfileApps-Detection.ps1` | Detection (read-only) |
| `Remove-StaleProfileApps-Remediation.ps1` | Remediation |

Version 1.0.3.

Removes per-user installs of Zoom, classic Teams and Chrome from dormant (unloaded) profiles **without deleting the profile**. Per-user installs miss machine-wide patching, so they are a common Qualys finding.

## What it checks and removes
| App | Folder (under profile) | Uninstall key (in the profile's NTUSER.DAT) |
|---|---|---|
| Zoom | `AppData\Local\Zoom` | `ZoomUMX` |
| Teams (classic) | `AppData\Local\Microsoft\Teams` | `Teams` |
| Chrome | `AppData\Local\Google\Chrome\Application` | `Google Chrome` |

Chrome's `User Data` folder is left alone, so bookmarks and settings survive. New Teams (MSIX) is out of scope.

Hives are loaded and unloaded with `reg.exe` under a GUID mount name. The PowerShell registry provider is avoided because it holds handles that block the unload. All `reg.exe` calls go through `Invoke-RegCommand`, which stops a normal "key not found" result from becoming a terminating error.

## Output
Detection writes a grouped line to the Intune "Pre-remediation detection output" column:
```
Non-compliant: 4 artefact(s), 2 profile(s). USER01: Zoom(F,R), Google Chrome(F) | USER02: Microsoft Teams (classic)(F,R)
```
`F` = folder, `R` = registry key, `H` = hive load/unload failure (remediation only). Trimmed on a profile boundary to fit the 2048 character limit.

## Parameters
| Parameter | Default | Purpose |
|---|---|---|
| `-DaysThreshold` | 0 (all unloaded profiles) | Only act on profiles unused for this many days |
| `-SkipRegistryCheck` / `-SkipRegistryCleanup` | off | Folders only |

## Intune settings
| Setting | Value |
|---|---|
| Run using logged-on credentials | No (SYSTEM) |
| Run in 64-bit PowerShell | Yes |

Logs: `%ProgramData%\Microsoft\IntuneManagementExtension\Logs\Remove-StaleProfileApps-Detection.log` and `-Remediation.log`.

## Notes
- Loaded profiles are always skipped, so a signed-in user's apps are never touched.
- For classic Teams across all profiles, Microsoft's own uninstall script plus removal of the Teams Machine-Wide Installer is the better route (see `Classic-Teams`). Consider removing the Teams entry from `$targetApps` in both scripts if you deploy that pair.
- Files are ASCII only. Keep them that way: Windows PowerShell 5.1 reads BOM-less UTF-8 as ANSI and non-ASCII characters cause parse errors.
