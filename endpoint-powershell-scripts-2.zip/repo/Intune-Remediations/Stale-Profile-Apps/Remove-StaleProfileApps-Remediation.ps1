<#
.SYNOPSIS
    Removes vulnerable per-user application installs from dormant (unloaded)
    user profiles. Does not remove the profile itself.

.DESCRIPTION
    Intune Proactive Remediation REMEDIATION script (SYSTEM context).

    Removes per-user installs of Zoom, Microsoft Teams (classic) and
    Google Chrome from profiles no one is currently using, by deleting
    the application folder and the corresponding uninstall registry key
    inside the profile's own NTUSER.DAT hive.

    The profile, its data, and its other contents are left intact. The
    action is reversible in practice: apps reinstall on next launch or
    via Intune redeployment.

    Registry work is performed with reg.exe rather than the PowerShell
    registry provider. The provider holds open handles on a mounted hive
    which block the subsequent unload and leave the profile locked.

    Each artefact is removed independently. A failure on one does not
    stop the run.

    This file contains ASCII characters only. Do not introduce box drawing
    characters, em dashes or other non-ASCII text. Windows PowerShell 5.1
    reads a UTF-8 file without a BOM as ANSI, which corrupts multi byte
    sequences and produces parser errors far from the real fault.

.PARAMETER DaysThreshold
    Optional. If greater than 0, only profiles unused for this many days
    are actioned. Default 0, meaning all unloaded profiles. Where age
    cannot be determined the profile is still actioned, as the action is
    reversible.

.PARAMETER SkipRegistryCleanup
    Remove application folders only. Leaves uninstall registry keys in place.

.PARAMETER LogPath
    Path to write the log file.

.NOTES
    Author     : Simon Diaz
    Requires   : PowerShell 5.1+
    Run context: SYSTEM
    Exit codes : 0 = success (no failures)   1 = one or more failures

    Chrome's User Data folder is deliberately left in place. Qualys detects
    on the binary under Application. Leaving User Data preserves bookmarks
    and settings for a returning user.

    Does not cover new Teams, which is an MSIX package.

.VERSION HISTORY
    1.0.0   Initial release. Folder and registry hive removal for per-user
            Zoom, Teams (classic) and Chrome installs in unloaded profiles.

    1.0.1   Fixed the same parser fault found in the detection script
            ("Unexpected token '}'"). A script block placed inside a
            subexpression inside a double quoted string was not handled
            reliably by the Windows PowerShell 5.1 parser. Rewritten as a
            plain statement.
            Standardised the hive mount name on a GUID.
            Removed all non ASCII characters from the file, including box
            drawing separators, to eliminate encoding related parse failures
            when the script is delivered through Intune.

    1.0.2   Fixed "NativeCommandError" thrown by reg.exe. A query against a
            key that does not exist is the routine not-found case: reg.exe
            writes to stderr and returns 1. With $ErrorActionPreference set
            to Stop, that stderr output was promoted to a terminating error,
            so the script failed on the first profile lacking a target app,
            which is the case the check exists to identify.
            All reg.exe calls now route through Invoke-RegCommand, which
            relaxes the preference for the duration of the call and restores
            it, and splats arguments as an array so key names containing
            spaces are passed correctly. Removal logic is unchanged.

    1.0.3   Summary output now lists what was removed, grouped by profile and
            marked F for folder, R for registry key and H for a hive load or
            unload failure. Uses the same format as the detection script so
            the two can be read side by side. Written to the log and to
            standard output. Note that Intune does not surface remediation
            script output in the Remediations report the way it surfaces
            detection output, so this is primarily for the device log.
            No change to what is removed.
#>

[CmdletBinding()]
param (
    [Parameter()]
    [ValidateRange(0, 365)]
    [int]$DaysThreshold = 0,

    [Parameter()]
    [switch]$SkipRegistryCleanup,

    [Parameter()]
    [string]$LogPath = 'C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\Remove-StaleProfileApps-Remediation.log'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- Version ----------------------------------------------------------------
$ScriptVersion = '1.0.3'

#region ---- Logging ----------------------------------------------------------

$script:LogPathResolved = $LogPath
try {
    $logDir = Split-Path -Path $LogPath -Parent
    if (-not (Test-Path -Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force -ErrorAction Stop | Out-Null
    }
    Add-Content -Path $LogPath -Value '' -Encoding UTF8 -ErrorAction Stop
}
catch {
    $script:LogPathResolved = Join-Path $env:TEMP 'Remove-StaleProfileApps-Remediation.log'
    Write-Host "[WARN] Could not write to '$LogPath'. Falling back to: $($script:LogPathResolved)" -ForegroundColor Yellow
    Add-Content -Path $script:LogPathResolved -Value '' -Encoding UTF8
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR','ACTION','SKIP')]
        [string]$Level = 'INFO'
    )
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line  = "[$stamp] [$Level] $Message"

    try { Add-Content -Path $script:LogPathResolved -Value $line -Encoding UTF8 -ErrorAction Stop }
    catch { Write-Host "[WARN] Log write failed: $_" -ForegroundColor Yellow }

    $colour = switch ($Level) {
        'INFO'   { 'Cyan'   }
        'WARN'   { 'Yellow' }
        'ERROR'  { 'Red'    }
        'ACTION' { 'Green'  }
        'SKIP'   { 'Gray'   }
    }
    Write-Host $line -ForegroundColor $colour
}

$RuleLine = '-----------------------------------------------------------'
$BarLine  = '==========================================================='

#endregion

#region ---- Target application definitions -----------------------------------

$targetApps = @(
    [PSCustomObject]@{
        Name          = 'Zoom'
        Paths         = @('AppData\Local\Zoom')
        UninstallKeys = @('ZoomUMX')
    },
    [PSCustomObject]@{
        Name          = 'Microsoft Teams (classic)'
        Paths         = @('AppData\Local\Microsoft\Teams')
        UninstallKeys = @('Teams')
    },
    [PSCustomObject]@{
        Name          = 'Google Chrome'
        Paths         = @('AppData\Local\Google\Chrome\Application')
        UninstallKeys = @('Google Chrome')
    }
)

#endregion

#region ---- Hive helpers -----------------------------------------------------

function Invoke-RegCommand {
    param([string[]]$Arguments)

    # reg.exe writes to stderr on any non-zero result, including the routine
    # "key not found" case. Under $ErrorActionPreference = 'Stop' that stderr
    # output is promoted to a terminating NativeCommandError, so the preference
    # is relaxed for the duration of the call and restored afterwards.
    # The array splat passes each argument separately, which handles key names
    # containing spaces such as "Google Chrome" without extra quoting.
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $null = & reg.exe @Arguments 2>&1
        return $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $previousPreference
    }
}

function Mount-ProfileHive {
    param(
        [string]$ProfilePath,
        [string]$MountName
    )
    $ntUserDat = Join-Path $ProfilePath 'NTUSER.DAT'

    if (-not (Test-Path -LiteralPath $ntUserDat)) {
        Write-Log "No NTUSER.DAT at $ntUserDat" -Level WARN
        return $false
    }

    $exitCode = Invoke-RegCommand -Arguments @('load', "HKU\$MountName", $ntUserDat)
    if ($exitCode -ne 0) {
        Write-Log "Hive load failed for $ProfilePath (reg.exe exit $exitCode)" -Level WARN
        return $false
    }
    return $true
}

function Dismount-ProfileHive {
    param([string]$MountName)

    for ($attempt = 1; $attempt -le 3; $attempt++) {
        [System.GC]::Collect()
        [System.GC]::WaitForPendingFinalizers()

        if ((Invoke-RegCommand -Arguments @('unload', "HKU\$MountName")) -eq 0) { return $true }

        Start-Sleep -Seconds 2
    }

    Write-Log "Hive unload FAILED for HKU\$MountName after 3 attempts. Profile may be locked until reboot." -Level ERROR
    return $false
}

function Test-HiveKey {
    param([string]$FullKeyPath)

    return ((Invoke-RegCommand -Arguments @('query', $FullKeyPath)) -eq 0)
}

function Remove-HiveKey {
    param([string]$FullKeyPath)

    return ((Invoke-RegCommand -Arguments @('delete', $FullKeyPath, '/f')) -eq 0)
}

#endregion

#region ---- Main -------------------------------------------------------------

# Build header values as plain statements. Do not inline an if block inside
# a string subexpression, as that is what broke the 1.0.0 parse.
$regCleanState = 'ENABLED'
if ($SkipRegistryCleanup) { $regCleanState = 'DISABLED' }

$thresholdText = 'not applied, all unloaded profiles actioned'
if ($DaysThreshold -gt 0) {
    $cutoffDate    = (Get-Date).AddDays(-$DaysThreshold)
    $cutoffText    = $cutoffDate.ToString('yyyy-MM-dd')
    $thresholdText = "$DaysThreshold days (cutoff: $cutoffText)"
}

$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name

Write-Log $BarLine
Write-Log "Remove-StaleProfileApps-Remediation started (v$ScriptVersion)"
Write-Log "Mode          : REMOVE APPS (live run). Profiles are NOT deleted."
Write-Log "Days threshold: $thresholdText"
Write-Log "Registry clean: $regCleanState"
Write-Log "Log path      : $script:LogPathResolved"
Write-Log "Running as    : $identity"
Write-Log "Computer      : $env:COMPUTERNAME"
Write-Log $BarLine

$protectedSIDs = @('S-1-5-18', 'S-1-5-19', 'S-1-5-20')
$skipFolders   = @('Default', 'Default User', 'Public', 'All Users',
                   'LocalService', 'NetworkService', 'systemprofile')

$allProfilesRaw = @(Get-CimInstance Win32_UserProfile)
$allProfiles    = @($allProfilesRaw | Where-Object { -not $_.Special })

Write-Log "Profiles returned by CIM  : $($allProfilesRaw.Count)"
Write-Log "Profiles to evaluate      : $($allProfiles.Count)"
Write-Log $RuleLine

$results = [System.Collections.Generic.List[PSCustomObject]]::new()

function Add-Result {
    param(
        [string]$ProfilePath,
        [string]$App,
        [string]$Type,
        [string]$Outcome,
        [string]$Detail
    )
    $results.Add([PSCustomObject]@{
        Profile = $ProfilePath
        App     = $App
        Type    = $Type
        Outcome = $Outcome
        Detail  = $Detail
    })
}

foreach ($userProfile in $allProfiles) {

    $profilePath = $userProfile.LocalPath
    $sid         = $userProfile.SID

    Write-Log "Evaluating: $profilePath (SID: $sid)"

    # ---- Guards ------------------------------------------------------------
    if ($sid -in $protectedSIDs) {
        Write-Log "SKIP: $profilePath | Protected system account SID" -Level SKIP
        continue
    }
    if ($userProfile.Loaded) {
        Write-Log "SKIP: $profilePath | Profile currently loaded" -Level SKIP
        continue
    }
    if (-not (Test-Path -LiteralPath $profilePath)) {
        Write-Log "SKIP: $profilePath | Path not found on disk" -Level SKIP
        continue
    }
    if ((Split-Path $profilePath -Leaf) -in $skipFolders) {
        Write-Log "SKIP: $profilePath | System or default profile folder" -Level SKIP
        continue
    }

    # ---- Optional age gate -------------------------------------------------
    if ($DaysThreshold -gt 0) {

        $lastUseTime = $null
        if ($userProfile.LastUseTime) {
            try {
                $lastUseTime = [System.Management.ManagementDateTimeConverter]::ToDateTime($userProfile.LastUseTime)
            }
            catch { }
        }

        if ($lastUseTime) {
            if ($lastUseTime -ge $cutoffDate) {
                $ageDays = [math]::Round(((Get-Date) - $lastUseTime).TotalDays, 1)
                Write-Log "SKIP: $profilePath | Within threshold, last used $ageDays days ago" -Level SKIP
                continue
            }
        }
        else {
            Write-Log "Age unknown for $profilePath. Proceeding, action is reversible." -Level WARN
        }
    }

    # ---- Folder removal ----------------------------------------------------
    foreach ($app in $targetApps) {
        foreach ($relPath in $app.Paths) {

            $fullPath = Join-Path $profilePath $relPath
            if (-not (Test-Path -LiteralPath $fullPath)) { continue }

            try {
                Remove-Item -LiteralPath $fullPath -Recurse -Force -ErrorAction Stop
                Write-Log "Removed folder: $($app.Name) | $fullPath" -Level ACTION
                Add-Result -ProfilePath $profilePath -App $app.Name -Type 'Folder' -Outcome 'Removed' -Detail $fullPath
            }
            catch {
                Write-Log "Folder removal FAILED: $fullPath. $_" -Level ERROR
                Add-Result -ProfilePath $profilePath -App $app.Name -Type 'Folder' -Outcome 'Failed' -Detail $_.Exception.Message
            }
        }
    }

    # ---- Registry cleanup --------------------------------------------------
    if ($SkipRegistryCleanup) { continue }

    # GUID based mount name. A SID derived name can collide between profiles.
    $mountName = 'StaleAppClean_' + [guid]::NewGuid().ToString('N').Substring(0, 12)

    if (-not (Mount-ProfileHive -ProfilePath $profilePath -MountName $mountName)) {
        Add-Result -ProfilePath $profilePath -App 'n/a' -Type 'Hive' -Outcome 'Failed' -Detail 'Hive load failed'
        continue
    }

    try {
        foreach ($app in $targetApps) {
            foreach ($keyName in $app.UninstallKeys) {

                $keyPath = "HKU\$mountName\Software\Microsoft\Windows\CurrentVersion\Uninstall\$keyName"
                if (-not (Test-HiveKey -FullKeyPath $keyPath)) { continue }

                if (Remove-HiveKey -FullKeyPath $keyPath) {
                    Write-Log "Removed registry key: $($app.Name) | $keyName" -Level ACTION
                    Add-Result -ProfilePath $profilePath -App $app.Name -Type 'Registry' -Outcome 'Removed' -Detail $keyName
                }
                else {
                    Write-Log "Registry removal FAILED: $keyName" -Level ERROR
                    Add-Result -ProfilePath $profilePath -App $app.Name -Type 'Registry' -Outcome 'Failed' -Detail $keyName
                }
            }
        }
    }
    finally {
        if (-not (Dismount-ProfileHive -MountName $mountName)) {
            Add-Result -ProfilePath $profilePath -App 'n/a' -Type 'Hive' -Outcome 'Failed' -Detail 'Hive unload failed'
        }
    }
}

# ---- Summary ---------------------------------------------------------------
$removed = @($results | Where-Object { $_.Outcome -eq 'Removed' })
$failed  = @($results | Where-Object { $_.Outcome -eq 'Failed'  })
$touched = @($results | Select-Object -ExpandProperty Profile -Unique)

Write-Log $BarLine
Write-Log "SUMMARY - REMOVE APPS (live run)"
Write-Log "Profiles evaluated   : $($allProfiles.Count)"
Write-Log "Profiles actioned    : $($touched.Count)"
Write-Log "Artefacts removed    : $($removed.Count)"
Write-Log "Failures             : $($failed.Count)"
Write-Log $RuleLine

foreach ($r in $removed) {
    Write-Log "  [Removed] $($r.Type) | $($r.App) | $($r.Detail)" -Level ACTION
}
foreach ($f in $failed) {
    Write-Log "  [Failed ] $($f.Type) | $($f.App) | $($f.Detail)" -Level ERROR
}

# Same grouped format as the detection script:
#   <profile>: <App>(F,R), <App>(F)
# F = folder, R = registry key, H = hive load or unload failure.
function Get-ResultsSummary {
    param(
        [object[]]$Rows,
        [int]$MaxLength = 1800
    )

    $groups = @()

    foreach ($profileGroup in ($Rows | Group-Object -Property Profile)) {

        $profileName = Split-Path $profileGroup.Name -Leaf
        $appParts    = @()

        foreach ($appGroup in ($profileGroup.Group | Group-Object -Property App)) {

            $marks = @()
            if ($appGroup.Group | Where-Object { $_.Type -eq 'Folder'   }) { $marks += 'F' }
            if ($appGroup.Group | Where-Object { $_.Type -eq 'Registry' }) { $marks += 'R' }
            if ($appGroup.Group | Where-Object { $_.Type -eq 'Hive'     }) { $marks += 'H' }

            $label = $appGroup.Name
            if ($label -eq 'n/a') { $label = 'Hive' }
            $appParts += ($label + '(' + ($marks -join ',') + ')')
        }

        $groups += ($profileName + ': ' + ($appParts -join ', '))
    }

    $summary = $groups -join ' | '

    if ($summary.Length -gt $MaxLength) {
        $kept          = @()
        $runningLength = 0
        $dropped       = 0

        foreach ($g in $groups) {
            if (($runningLength + $g.Length + 3) -le ($MaxLength - 20)) {
                $kept += $g
                $runningLength += ($g.Length + 3)
            }
            else {
                $dropped++
            }
        }
        $summary = ($kept -join ' | ') + " | +$dropped more"
    }

    return $summary
}

$removedText = 'none'
if ($removed.Count -gt 0) { $removedText = Get-ResultsSummary -Rows $removed }

$failedText = 'none'
if ($failed.Count -gt 0) { $failedText = Get-ResultsSummary -Rows $failed }

Write-Log $RuleLine
Write-Log "Removed: $removedText"
Write-Log "Failed : $failedText"

Write-Log $BarLine
Write-Log "Remove-StaleProfileApps-Remediation completed (v$ScriptVersion)"
Write-Log $BarLine

# ---- Exit ------------------------------------------------------------------
if ($failed.Count -gt 0) {
    Write-Host "Completed with $($failed.Count) failure(s). $($removed.Count) artefact(s) removed. Removed: $removedText. Failed: $failedText. Log: $script:LogPathResolved"
    exit 1
}
else {
    Write-Host "Completed. $($removed.Count) artefact(s) removed across $($touched.Count) profile(s). Removed: $removedText"
    exit 0
}

#endregion
