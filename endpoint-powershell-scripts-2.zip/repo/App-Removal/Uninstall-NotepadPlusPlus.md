# Uninstall-NotepadPlusPlus.ps1

Removes every installed copy of Notepad++ from a Windows device: machine-wide (64-bit and 32-bit) and per-user installs in every local profile, including profiles of users who are logged off.

## How it works
1. **Machine scan**: reads the HKLM 64-bit, WOW6432Node and current HKCU uninstall keys for `Notepad++*`.
2. **Vendor uninstall**: runs each entry's NSIS `uninstall.exe /S` and waits for the `Au_` temp process to finish.
3. **Manual fallback**: if the uninstaller is missing or leaves the entry behind, stops `notepad++.exe`, deletes the install folder, uninstall key, App Paths entries and public shortcuts.
4. **Per-user sweep**: walks `ProfileList` for `S-1-5-21-*` SIDs, uses already-mounted hives or loads `NTUSER.DAT` with `reg.exe load`, removes entries, and unloads only the hives it loaded itself.
5. **Verification**: exit 0 if nothing is left, exit 1 if anything survives.

## Deployment
Single script, no bundled payload. Run as SYSTEM, 64-bit (Intune Remediation, Win32 app uninstall, or ConfigMgr).

## Notes
- Removing the uninstall key is what clears registry-based scanner findings even if some files inside a user profile survive.
- The `$weLoaded` guard prevents unloading a signed-in user's hive.
- `GC::Collect()` before `reg unload` releases .NET handles that otherwise make the unload fail.
- Only profiles that exist on the device are scanned.
