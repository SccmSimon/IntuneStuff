<#
.SYNOPSIS
    Silently removes all installed versions of Notepad++, covering
    per-machine installs AND per-user installs found in every user
    profile's registry hive, with a manual cleanup fallback for
    orphaned installs where the NSIS uninstaller is missing.

.DESCRIPTION
    Machine scan: reads the HKLM 64-bit and 32-bit uninstall hives plus
    the running account's own HKCU.

    Per-user scan: enumerates ProfileList, then for each real user SID
    either uses the already-mounted hive under HKEY_USERS (logged-on
    users) or temporarily loads that profile's NTUSER.DAT (logged-off
    users), scans the user's uninstall keys, removes what it finds, and
    unloads only the hives it loaded itself.

    For every entry it runs the vendor uninstaller silently (/S) when
    uninstall.exe is present, and falls back to manual file/registry/
    shortcut removal when it is missing or the vendor uninstall leaves
    the entry behind.

.NOTES
    Author  : Simon Diaz
    Version : 3.0.0
    Run as SYSTEM (Intune) or elevated admin. SYSTEM/elevated context is
    required to load other users' hives.
    Exit 0 = clean, Exit 1 = Notepad++ still detected.
#>

[CmdletBinding()]
param()

# HKLM machine hives plus the running account's own HKCU.
$machineUninstallPaths = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
)

# Sub-paths to check inside any given hive root (used for user hives).
$userUninstallSubPaths = @(
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
    'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
)

# --- Scanning helpers --------------------------------------------------

function Get-NppMachineEntries {
    foreach ($path in $machineUninstallPaths) {
        if (Test-Path $path) {
            Get-ChildItem -Path $path -ErrorAction SilentlyContinue |
                ForEach-Object { Get-ItemProperty -Path $_.PSPath -ErrorAction SilentlyContinue } |
                Where-Object { $_.DisplayName -like 'Notepad++*' }
        }
    }
}

# Scan a single hive root (e.g. Registry::HKEY_USERS\<SID>) for Notepad++.
function Get-NppEntriesUnderRoot {
    param([Parameter(Mandatory)][string]$HiveRoot)

    foreach ($sub in $userUninstallSubPaths) {
        $full = Join-Path $HiveRoot $sub
        if (Test-Path $full) {
            Get-ChildItem -Path $full -ErrorAction SilentlyContinue |
                ForEach-Object { Get-ItemProperty -Path $_.PSPath -ErrorAction SilentlyContinue } |
                Where-Object { $_.DisplayName -like 'Notepad++*' }
        }
    }
}

# --- Removal helpers ---------------------------------------------------

# Manual removal for orphaned installs or vendor-uninstall survivors.
function Remove-NppManual {
    param(
        [Parameter(Mandatory)] $Entry,
        [string] $ProfilePath
    )

    Write-Output "Falling back to manual removal for $($Entry.DisplayName)."

    # Stop any running instance so file locks do not block deletion.
    Get-Process -Name 'notepad++' -ErrorAction SilentlyContinue |
        Stop-Process -Force -ErrorAction SilentlyContinue

    # Work out the install directory from the registry first, then guess.
    $installDir = $null
    if ($Entry.InstallLocation) {
        $installDir = $Entry.InstallLocation.Trim('"').TrimEnd('\')
    }
    elseif ($Entry.UninstallString) {
        $exe = $Entry.UninstallString.Trim('"')
        if ($exe -match '(?i)(.*uninstall\.exe)') { $exe = $matches[1].Trim('"') }
        $installDir = Split-Path -Path $exe -Parent -ErrorAction SilentlyContinue
    }

    $candidateDirs = @(
        $installDir,
        "$env:ProgramFiles\Notepad++",
        "${env:ProgramFiles(x86)}\Notepad++"
    )
    if ($ProfilePath) {
        $candidateDirs += "$ProfilePath\AppData\Local\Programs\Notepad++"
        $candidateDirs += "$ProfilePath\AppData\Local\Notepad++"
    }
    $candidateDirs = $candidateDirs | Where-Object { $_ } | Select-Object -Unique

    foreach ($dir in $candidateDirs) {
        if (Test-Path $dir) {
            Write-Output "Removing install directory: $dir"
            Remove-Item -Path $dir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    # Remove the uninstall key itself. This clears Add/Remove Programs
    # and registry-based vulnerability scanner detection.
    if ($Entry.PSPath) {
        Write-Output "Removing uninstall registry key: $($Entry.PSChildName)"
        Remove-Item -Path $Entry.PSPath -Recurse -Force -ErrorAction SilentlyContinue
    }

    $appPaths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\notepad++.exe',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\notepad++.exe'
    )
    foreach ($ap in $appPaths) {
        if (Test-Path $ap) { Remove-Item -Path $ap -Recurse -Force -ErrorAction SilentlyContinue }
    }

    $shortcuts = @(
        "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Notepad++.lnk",
        "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Notepad++",
        "$env:PUBLIC\Desktop\Notepad++.lnk"
    )
    foreach ($sc in $shortcuts) {
        if (Test-Path $sc) { Remove-Item -Path $sc -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

# Act on one entry: vendor silent uninstall if possible, else manual.
function Remove-NppEntry {
    param(
        [Parameter(Mandatory)] $Entry,
        [string] $ProfilePath
    )

    $exePath = $null
    if ($Entry.UninstallString) {
        $exePath = $Entry.UninstallString.Trim('"')
        if ($exePath -match '(?i)(.*uninstall\.exe)') {
            $exePath = $matches[1].Trim('"')
        }
    }

    if ($exePath -and (Test-Path $exePath)) {
        Write-Output "Running silent uninstall: $exePath /S"
        Start-Process -FilePath $exePath -ArgumentList '/S' -PassThru | Out-Null

        # NSIS hands off to a temp 'Au_' copy, so wait for the real work.
        Start-Sleep -Seconds 3
        $procName = [System.IO.Path]::GetFileNameWithoutExtension($exePath)
        while (Get-Process -Name $procName -ErrorAction SilentlyContinue) { Start-Sleep -Seconds 2 }
        while (Get-Process -Name 'Au_*'    -ErrorAction SilentlyContinue) { Start-Sleep -Seconds 2 }

        Write-Output "Vendor uninstall finished for $($Entry.DisplayName)."
    }
    else {
        Write-Warning "Uninstaller not found for $($Entry.DisplayName)."
        Remove-NppManual -Entry $Entry -ProfilePath $ProfilePath
    }
}

# --- Per-user hive sweep ----------------------------------------------

# Scan every real user profile's hive and remove Notepad++ from it.
# Returns the count of entries still present after cleanup.
function Invoke-NppUserHiveRemoval {

    $survivors = 0
    $profileListKey = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList'

    # Real interactive users have SIDs of the form S-1-5-21-...
    $userProfiles = Get-ChildItem -Path $profileListKey -ErrorAction SilentlyContinue |
        Where-Object { $_.PSChildName -match '^S-1-5-21-' } |
        ForEach-Object {
            [PSCustomObject]@{
                SID  = $_.PSChildName
                Path = (Get-ItemProperty -Path $_.PSPath -ErrorAction SilentlyContinue).ProfileImagePath
            }
        }

    foreach ($userProfile in $userProfiles) {

        $sid      = $userProfile.SID
        $hiveRoot = "Registry::HKEY_USERS\$sid"
        $weLoaded = $false

        # If the hive is not already mounted (user is logged off), load it.
        if (-not (Test-Path $hiveRoot)) {
            $ntUserDat = Join-Path $userProfile.Path 'NTUSER.DAT'
            if (-not (Test-Path $ntUserDat)) { continue }

            & reg.exe load "HKU\$sid" "$ntUserDat" *> $null
            if ($LASTEXITCODE -ne 0) {
                Write-Warning "Could not load hive for SID $sid. Skipping."
                continue
            }
            $weLoaded = $true
        }

        $entries = Get-NppEntriesUnderRoot -HiveRoot $hiveRoot
        if ($entries) {
            foreach ($entry in $entries) {
                Write-Output "User ($sid): found $($entry.DisplayName) $($entry.DisplayVersion)"
                Remove-NppEntry -Entry $entry -ProfilePath $userProfile.Path
            }

            $left = Get-NppEntriesUnderRoot -HiveRoot $hiveRoot
            foreach ($entry in $left) {
                Remove-NppManual -Entry $entry -ProfilePath $userProfile.Path
            }
            $survivors += (Get-NppEntriesUnderRoot -HiveRoot $hiveRoot | Measure-Object).Count
        }

        # Only ever unload a hive we loaded ourselves. Unloading a hive
        # belonging to a logged-on user would break their session.
        if ($weLoaded) {
            # Release .NET handles on the hive so reg unload succeeds.
            [System.GC]::Collect()
            [System.GC]::WaitForPendingFinalizers()
            & reg.exe unload "HKU\$sid" *> $null
            if ($LASTEXITCODE -ne 0) {
                Write-Warning "Hive for SID $sid did not unload cleanly."
            }
        }
    }

    return $survivors
}

# --- Main execution ----------------------------------------------------

Write-Output "Searching for Notepad++ (machine scope)..."
$machineEntries = Get-NppMachineEntries

foreach ($entry in $machineEntries) {
    Write-Output "Found: $($entry.DisplayName) $($entry.DisplayVersion)"
    Remove-NppEntry -Entry $entry
}

$machineRemaining = Get-NppMachineEntries
foreach ($entry in $machineRemaining) {
    Remove-NppManual -Entry $entry
}

Write-Output "Searching for Notepad++ (all user profiles)..."
$userSurvivors = Invoke-NppUserHiveRemoval

$machineStillThere = (Get-NppMachineEntries | Measure-Object).Count

if (($machineStillThere -gt 0) -or ($userSurvivors -gt 0)) {
    Write-Warning "Notepad++ still detected after all removal attempts (machine: $machineStillThere, user: $userSurvivors)."
    exit 1
}
Write-Output "All Notepad++ installations removed successfully (machine and per-user)."
exit 0
