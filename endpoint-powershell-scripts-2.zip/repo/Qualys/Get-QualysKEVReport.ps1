<#
.SYNOPSIS
    Retrieves CISA Known Exploited Vulnerability (KEV) findings on Windows 11
    devices from Qualys and reports by exploit, ranked by affected device count.

.DESCRIPTION
    Connects to the Qualys API using Basic Auth, API Token, or JWT authentication.
    Queries host detection data filtered to Windows 11 assets, identifies findings
    flagged as CISA KEV (Real-Time Threat Indicator), then produces two reports:

      1. KEV Summary   - each known exploit ranked by total number of affected devices
      2. Device Detail - for each KEV, a full list of affected device hostnames/IPs

    Supports both the Classic API and Qualys Gateway (Cloud) API platforms.

.PARAMETER QualysBaseUrl
    Your Qualys platform URL.
    Classic API examples : https://qualysapi.qualys.com
                           https://qualysapi.qualys.eu
    Gateway API examples : https://gateway.qg1.apps.qualys.com
                           https://gateway.qg1.apps.qualys.eu

.PARAMETER AuthMethod
    BasicAuth   - Username + Password (default)
    ApiToken    - Pre-generated Bearer token
    JWT         - OAuth2 JWT via Qualys Gateway

.PARAMETER Credential
    PSCredential object.
    BasicAuth : username / password
    JWT       : client_id (username) / client_secret (password)
    ApiToken  : not used, supply -ApiToken instead

.PARAMETER ApiToken
    Pre-generated Qualys API token string (AuthMethod ApiToken only).

.PARAMETER OutputPath
    Optional. Export results as CSV.
    Exports two files:
      <OutputPath>_Summary.csv  - KEV summary ranked by device count
      <OutputPath>_Devices.csv  - per-KEV device list
    Example: C:\Reports\KEV  ->  C:\Reports\KEV_Summary.csv + C:\Reports\KEV_Devices.csv

.PARAMETER DaysThreshold
    Only include detections updated within this many days.
    Default: 0 (all active detections, no date filter)

.EXAMPLE
    # Basic Auth - Classic API
    $cred = Get-Credential
    .\Get-QualysKEVReport.ps1 -QualysBaseUrl 'https://qualysapi.qualys.eu' -Credential $cred

.EXAMPLE
    # JWT - Gateway API with CSV export
    $cred = Get-Credential
    .\Get-QualysKEVReport.ps1 -QualysBaseUrl 'https://gateway.qg1.apps.qualys.com' `
        -AuthMethod JWT -Credential $cred -OutputPath 'C:\Reports\KEV'

.EXAMPLE
    # API Token - last 30 days only
    .\Get-QualysKEVReport.ps1 -QualysBaseUrl 'https://qualysapi.qualys.com' `
        -AuthMethod ApiToken -ApiToken 'your-token-here' -DaysThreshold 30

.NOTES
    Author   : Simon Diaz
    Version  : 1.0.1
    Requires : PowerShell 5.1+ or PowerShell 7+
    API docs : https://docs.qualys.com/en/vm/api/index.htm

    KEV detection in Qualys:
    Qualys flags KEV findings via Real-Time Threat Indicators (RTIs).
    The RTI tag 'CISA_KNOWN_EXPLOITED' identifies CVEs on the CISA KEV catalogue.
    This script filters detections for this RTI and cross-references the
    Knowledge Base for title, CVE, category and CVSS detail.

.VERSION HISTORY
    1.0.0   Initial release. Windows 11 KEV detection via Qualys VMDR API.
            Basic Auth, API Token, and JWT authentication. Summary and device
            detail reports. Optional CSV export. Ranked by device count.

    1.0.1   AuthMethod defaults to BasicAuth. Removed PowerShell 7-only syntax
            (inline "if" used as an expression) so the script runs on Windows
            PowerShell 5.1. Renamed the host loop variable from $host, which is
            a read-only automatic variable. KB CVE list read with SelectNodes so
            it is safe under Set-StrictMode. Removed non-ASCII banner characters.
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string]$QualysBaseUrl,

    [Parameter()]
    [ValidateSet('BasicAuth', 'ApiToken', 'JWT')]
    [string]$AuthMethod = 'BasicAuth',

    [Parameter()]
    [System.Management.Automation.PSCredential]$Credential,

    [Parameter()]
    [string]$ApiToken,

    [Parameter()]
    [string]$OutputPath,

    [Parameter()]
    [ValidateRange(0, 365)]
    [int]$DaysThreshold = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -- Version -------------------------------------------------------------------
$ScriptVersion = '1.0.1'

#region -- Helpers ------------------------------------------------------------

function Write-Step   { param([string]$M) Write-Host "  --> $M" -ForegroundColor Cyan    }
function Write-Ok     { param([string]$M) Write-Host "  [OK] $M" -ForegroundColor Green   }
function Write-Warn   { param([string]$M) Write-Host "  [!]  $M" -ForegroundColor Yellow  }
function Write-Header { param([string]$M) Write-Host $M -ForegroundColor DarkCyan         }

function Write-Banner {
    param([string]$Title)
    $bar = '=' * 60
    Write-Header $bar
    Write-Header ('  ' + $Title)
    Write-Header $bar
}

function Get-OrDefault {
    # PowerShell 5.1 cannot use "if" as an inline expression, so this
    # returns the value or a fallback in one call.
    param($Value, [string]$Default = 'N/A')
    if ([string]::IsNullOrWhiteSpace([string]$Value)) { return $Default }
    return [string]$Value
}

function Get-AuthHeaders {
    param(
        [string]$Method,
        [System.Management.Automation.PSCredential]$Cred,
        [string]$Token,
        [string]$BaseUrl
    )

    $headers = @{
        'X-Requested-With' = 'PowerShell-QualysKEVScript'
        'Accept'           = 'application/xml'
    }

    switch ($Method) {

        'BasicAuth' {
            if (-not $Cred) { throw "BasicAuth requires -Credential (username/password)." }
            $pair  = "$($Cred.UserName):$($Cred.GetNetworkCredential().Password)"
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($pair)
            $b64   = [Convert]::ToBase64String($bytes)
            $headers['Authorization'] = "Basic $b64"
            Write-Step "Auth: Basic Auth (user: $($Cred.UserName))"
        }

        'ApiToken' {
            if ([string]::IsNullOrWhiteSpace($Token)) { throw "ApiToken requires -ApiToken value." }
            $headers['Authorization'] = "Bearer $Token"
            Write-Step "Auth: API Token (Bearer)"
        }

        'JWT' {
            if (-not $Cred) { throw "JWT requires -Credential (client_id / client_secret)." }
            Write-Step "Auth: JWT - fetching token from Gateway..."
            $authBody = @{
                username = $Cred.UserName
                password = $Cred.GetNetworkCredential().Password
                token    = 'true'
            }
            try {
                $response = Invoke-RestMethod -Uri "$BaseUrl/auth" -Method Post `
                    -Body $authBody -ContentType 'application/x-www-form-urlencoded'
                $jwt = $response
                if ($response.PSObject.Properties['token']) { $jwt = $response.token }
                $headers['Authorization'] = "Bearer $jwt"
                Write-Ok "JWT obtained."
            }
            catch {
                throw "JWT authentication failed. Check client_id/secret and Gateway URL.`nError: $_"
            }
        }
    }

    return $headers
}

function Invoke-QualysRequest {
    param(
        [string]$Uri,
        [hashtable]$Headers,
        [hashtable]$Body,
        [int]$MaxRetries = 3
    )

    $attempt = 0
    while ($attempt -lt $MaxRetries) {
        $attempt++
        try {
            $params = @{ Uri = $Uri; Headers = $Headers }
            if ($Body) {
                $params['Method']      = 'POST'
                $params['Body']        = $Body
                $params['ContentType'] = 'application/x-www-form-urlencoded'
            }
            else {
                $params['Method'] = 'GET'
            }
            return Invoke-RestMethod @params
        }
        catch {
            $statusCode = $null
            if ($_.Exception.PSObject.Properties['Response'] -and $_.Exception.Response) {
                $statusCode = [int]$_.Exception.Response.StatusCode
            }
            if ($statusCode -in @(429, 503) -and $attempt -lt $MaxRetries) {
                $wait = $attempt * 10
                Write-Warn "Rate limited (HTTP $statusCode). Retrying in ${wait}s..."
                Start-Sleep -Seconds $wait
            }
            elseif ($statusCode -eq 401) { throw "Authentication failed (HTTP 401). SSO/SAML accounts cannot use the API." }
            elseif ($statusCode -eq 403) { throw "Access denied (HTTP 403). Check API permissions." }
            else { throw "API request failed (attempt $attempt): $_" }
        }
    }
}

function Get-SeverityLabel {
    param([string]$Severity)
    $map = @{ '5' = 'Critical'; '4' = 'High'; '3' = 'Medium'; '2' = 'Low'; '1' = 'Info' }
    if ($Severity -and $map.ContainsKey($Severity)) { return $map[$Severity] }
    return 'Unknown'
}

function Get-SeverityColour {
    param([string]$Label)
    switch ($Label) {
        'Critical' { return 'Red'     }
        'High'     { return 'DarkRed' }
        'Medium'   { return 'Yellow'  }
        'Low'      { return 'Cyan'    }
        default    { return 'Gray'    }
    }
}

#endregion

#region -- Main ---------------------------------------------------------------

Write-Host ""
Write-Banner "Qualys KEV Report - Windows 11 Devices  v$ScriptVersion"
Write-Host ""

$QualysBaseUrl = $QualysBaseUrl.TrimEnd('/')

# -- Step 1: Authenticate --------------------------------------------------
Write-Host "[1/4] Authenticating..." -ForegroundColor White
$headers = Get-AuthHeaders -Method $AuthMethod -Cred $Credential -Token $ApiToken -BaseUrl $QualysBaseUrl
Write-Ok "Headers prepared."
Write-Host ""

# -- Step 2: Fetch host detections for Windows 11 --------------------------
Write-Host "[2/4] Fetching active detections for Windows 11 devices..." -ForegroundColor White
Write-Step "Querying host detection API. This may take a moment on large estates."

$detectionBody = @{
    action           = 'list'
    os_pattern       = '^.*Windows 11.*$'
    status           = 'Active'
    show_results     = '1'
    show_igs         = '0'             # exclude information-only findings
    truncation_limit = '0'             # return all results
}

# Optionally filter by recency
if ($DaysThreshold -gt 0) {
    $sinceDate = (Get-Date).AddDays(-$DaysThreshold).ToString('yyyy-MM-dd')
    $detectionBody['detection_updated_since'] = $sinceDate
    Write-Step "Date filter: detections updated since $sinceDate"
}

try {
    [xml]$detectionXml = Invoke-QualysRequest `
        -Uri "$QualysBaseUrl/api/2.0/fo/asset/host/vm/detection/" `
        -Headers $headers `
        -Body $detectionBody
}
catch {
    throw "Failed to retrieve detection data: $_"
}

# XML structure: HOST_LIST_VM_DETECTION_OUTPUT > RESPONSE > HOST_LIST > HOST
$hostNodes = @($detectionXml.SelectNodes('//HOST'))

if ($hostNodes.Count -eq 0) {
    Write-Warn "No Windows 11 hosts found in detection results."
    Write-Warn "Verify that Windows 11 assets have been scanned and the OS field matches the filter."
    exit 0
}

Write-Ok "Found $($hostNodes.Count) Windows 11 host record(s)."
Write-Host ""

# -- Step 3: Filter for KEV findings ---------------------------------------
# Qualys flags KEV via the Real-Time Threat Indicator (RTI) field on each detection.
# KEV entries contain 'CISA_KNOWN_EXPLOITED'.

Write-Host "[3/4] Identifying KEV findings..." -ForegroundColor White

function Get-NodeText {
    # Returns the inner text of a child element, or '' if it is missing.
    # Safe under Set-StrictMode, where $node.MISSING would throw.
    param($Node, [string]$Name)
    $child = $Node.SelectSingleNode($Name)
    if ($child) { return $child.InnerText }
    return ''
}

# kevMap: QID -> { QID, Title, CVEs, Category, CVSS, Severity, Hosts }
$kevMap   = @{}
$rawCount = 0

foreach ($hostNode in $hostNodes) {

    # $host is a read-only automatic variable, so the loop uses $hostNode
    $dns      = Get-NodeText $hostNode 'DNS'
    $netbios  = Get-NodeText $hostNode 'NETBIOS'
    $ip       = Get-NodeText $hostNode 'IP'
    $os       = Get-NodeText $hostNode 'OS'

    $hostname = $ip
    if ($netbios) { $hostname = $netbios }
    if ($dns)     { $hostname = $dns }

    $detections = @($hostNode.SelectNodes('DETECTION_LIST/DETECTION'))
    if ($detections.Count -eq 0) { continue }

    foreach ($det in $detections) {
        $rawCount++
        $rti = Get-NodeText $det 'RTI'

        # Only process if CISA KEV indicator is present
        if ([string]::IsNullOrWhiteSpace($rti)) { continue }
        if ($rti -notmatch 'CISA_KNOWN_EXPLOITED') { continue }

        $qid = Get-NodeText $det 'QID'

        if (-not $kevMap.ContainsKey($qid)) {
            $kevMap[$qid] = [PSCustomObject]@{
                QID       = $qid
                Title     = ''        # enriched from KB in step 4
                CVEs      = ''
                Category  = ''
                CVSS_v3   = (Get-NodeText $det 'CVSS3_BASE')
                QSeverity = (Get-NodeText $det 'SEVERITY')
                HostCount = 0
                Hosts     = [System.Collections.Generic.List[PSCustomObject]]::new()
            }
        }

        $kevMap[$qid].HostCount++
        $kevMap[$qid].Hosts.Add([PSCustomObject]@{
            Hostname  = $hostname
            IP        = $ip
            OS        = $os
            LastFound = (Get-NodeText $det 'LAST_FOUND_DATETIME')
            Status    = (Get-NodeText $det 'STATUS')
        })
    }
}

Write-Ok "Processed $rawCount total detections."

if ($kevMap.Count -eq 0) {
    Write-Warn "No CISA KEV findings found on Windows 11 devices."
    Write-Warn "This may mean:"
    Write-Warn "  - No KEV-flagged vulnerabilities are present (good news)"
    Write-Warn "  - RTI data is not enabled on your Qualys subscription"
    Write-Warn "  - Detections need a rescan to populate RTI fields"
    exit 0
}

Write-Ok "Identified $($kevMap.Count) unique KEV QID(s) across Windows 11 devices."
Write-Host ""

# -- Step 4: Enrich from Knowledge Base ------------------------------------
Write-Host "[4/4] Enriching with Knowledge Base data..." -ForegroundColor White

$qidList = @($kevMap.Keys) -join ','

try {
    [xml]$kbXml = Invoke-QualysRequest `
        -Uri "$QualysBaseUrl/api/2.0/fo/knowledge_base/vuln/" `
        -Headers $headers `
        -Body @{ action = 'list'; ids = $qidList; details = 'All' }

    foreach ($vuln in @($kbXml.SelectNodes('//VULN'))) {
        $qid = Get-NodeText $vuln 'QID'
        if (-not $kevMap.ContainsKey($qid)) { continue }

        $kevMap[$qid].Title    = Get-NodeText $vuln 'TITLE'
        $kevMap[$qid].CVEs     = (@($vuln.SelectNodes('CVE_LIST/CVE/ID') | ForEach-Object { $_.InnerText }) -join ', ')
        $kevMap[$qid].Category = Get-NodeText $vuln 'CATEGORY'

        # Use CVSS v3 from KB if the detection did not carry one
        if ([string]::IsNullOrWhiteSpace($kevMap[$qid].CVSS_v3)) {
            $kevMap[$qid].CVSS_v3 = Get-NodeText $vuln 'CVSS_V3/BASE'
        }
    }
    Write-Ok "Knowledge Base enrichment complete."
}
catch {
    Write-Warn "KB enrichment failed. Results will show QIDs only. Error: $_"
}

Write-Host ""

# -- Build ranked output ---------------------------------------------------
$rankedKEVs = @($kevMap.Values | Sort-Object -Property HostCount -Descending)

# -- Display: Summary table ------------------------------------------------
Write-Host ""
Write-Banner "KEV SUMMARY - RANKED BY AFFECTED DEVICES"
Write-Host ""

$rank = 1
foreach ($kev in $rankedKEVs) {

    $sevLabel = Get-SeverityLabel $kev.QSeverity
    $colour   = Get-SeverityColour $sevLabel
    $title    = Get-OrDefault $kev.Title "QID $($kev.QID)"

    Write-Host ("#$rank - " + $title) -ForegroundColor $colour
    Write-Host ("     QID             : " + $kev.QID)
    Write-Host ("     CVEs            : " + (Get-OrDefault $kev.CVEs))
    Write-Host ("     Category        : " + (Get-OrDefault $kev.Category))
    Write-Host ("     Severity        : $sevLabel  |  CVSS v3: " + (Get-OrDefault $kev.CVSS_v3))
    Write-Host ("     Devices affected: $($kev.HostCount)")
    Write-Host ""
    $rank++
}

# -- Display: Device detail per KEV ----------------------------------------
Write-Banner "DEVICE DETAIL - PER KEV"
Write-Host ""

$rank = 1
foreach ($kev in $rankedKEVs) {

    $title    = Get-OrDefault $kev.Title "QID $($kev.QID)"
    $sevLabel = Get-SeverityLabel $kev.QSeverity
    $colour   = Get-SeverityColour $sevLabel

    Write-Host ('-' * 60) -ForegroundColor DarkGray
    Write-Host "#$rank - $title" -ForegroundColor $colour
    Write-Host ("     QID: $($kev.QID)  |  CVEs: " + (Get-OrDefault $kev.CVEs) + "  |  Severity: $sevLabel")
    Write-Host "     Affected devices ($($kev.HostCount)):"
    Write-Host ""

    foreach ($device in ($kev.Hosts | Sort-Object Hostname)) {
        $lastFound = 'Unknown'
        if ($device.LastFound -and $device.LastFound.Length -ge 10) { $lastFound = $device.LastFound.Substring(0, 10) }
        Write-Host ("       {0,-40} {1,-18} Last found: {2}" -f $device.Hostname, $device.IP, $lastFound)
    }

    Write-Host ""
    $rank++
}

# -- Optional CSV export ---------------------------------------------------
if ($OutputPath) {

    # Summary CSV
    $summaryCsv = for ($i = 0; $i -lt $rankedKEVs.Count; $i++) {
        $kev = $rankedKEVs[$i]
        [PSCustomObject]@{
            Rank             = $i + 1
            QID              = $kev.QID
            Title            = $kev.Title
            CVEs             = $kev.CVEs
            Category         = $kev.Category
            Severity         = (Get-SeverityLabel $kev.QSeverity)
            CVSS_v3          = $kev.CVSS_v3
            Devices_Affected = $kev.HostCount
        }
    }

    # Device detail CSV - one row per device per KEV
    $deviceCsv = foreach ($kev in $rankedKEVs) {
        $sevLabel = Get-SeverityLabel $kev.QSeverity
        foreach ($device in $kev.Hosts) {
            [PSCustomObject]@{
                QID        = $kev.QID
                Title      = $kev.Title
                CVEs       = $kev.CVEs
                Severity   = $sevLabel
                CVSS_v3    = $kev.CVSS_v3
                Hostname   = $device.Hostname
                IP         = $device.IP
                OS         = $device.OS
                Last_Found = $device.LastFound
                Status     = $device.Status
            }
        }
    }

    try {
        $summaryPath = "${OutputPath}_Summary.csv"
        $devicePath  = "${OutputPath}_Devices.csv"
        $summaryCsv | Export-Csv -Path $summaryPath -NoTypeInformation -Encoding UTF8
        $deviceCsv  | Export-Csv -Path $devicePath  -NoTypeInformation -Encoding UTF8
        Write-Ok "Summary CSV : $summaryPath"
        Write-Ok "Devices CSV : $devicePath"
    }
    catch {
        Write-Warn "CSV export failed: $_"
    }
}

# -- Final stats -----------------------------------------------------------
$totalDevicesAffected = ($rankedKEVs | Measure-Object -Property HostCount -Sum).Sum
$uniqueDevices        = @($rankedKEVs | ForEach-Object { $_.Hosts } | ForEach-Object { $_.Hostname } | Sort-Object -Unique).Count

Write-Banner "TOTALS"
Write-Host ""
Write-Host "  Unique KEVs found          : $($kevMap.Count)"
Write-Host "  Total device/KEV instances : $totalDevicesAffected"
Write-Host "  Unique devices affected    : $uniqueDevices"
Write-Host ""

# Return summary objects to the pipeline
$rankedKEVs

exit 0

#endregion
