<#
.SYNOPSIS
    Retrieves the top 10 vulnerabilities detected on Windows 10/11 devices from Qualys.

.DESCRIPTION
    Connects to the Qualys API using Basic Auth, API Token, or JWT authentication.
    Queries host detection data filtered to Windows 10/11 assets, then ranks
    vulnerabilities by detection count and severity.

    Supports both the Classic API and Qualys Gateway (Cloud) API platforms.

.PARAMETER QualysBaseUrl
    Your Qualys platform API URL.
    Classic API examples : https://qualysapi.qualys.com
                           https://qualysapi.qualys.eu
    Gateway API examples : https://gateway.qg1.apps.qualys.com
                           https://gateway.qg1.apps.qualys.eu

.PARAMETER AuthMethod
    BasicAuth   - Username + Password (most common for Classic API)
    ApiToken    - Pre-generated API token passed as a Bearer token
    JWT         - OAuth2 JWT via Qualys Gateway (token fetched automatically)

.PARAMETER Credential
    PSCredential object.
    BasicAuth : username / password
    JWT       : client_id (username) / client_secret (password)
    ApiToken  : not used, supply -ApiToken instead

.PARAMETER ApiToken
    Pre-generated Qualys API token string (AuthMethod ApiToken only).

.PARAMETER OutputPath
    Optional. Path to export results as CSV.

.EXAMPLE
    $cred = Get-Credential
    .\Get-QualysTop10Threats.ps1 -QualysBaseUrl 'https://qualysapi.qualys.eu' -Credential $cred

.EXAMPLE
    $cred = Get-Credential   # client_id / client_secret
    .\Get-QualysTop10Threats.ps1 -QualysBaseUrl 'https://gateway.qg1.apps.qualys.com' `
        -AuthMethod JWT -Credential $cred -OutputPath 'C:\Reports\top10.csv'

.NOTES
    Author   : Simon Diaz
    Version  : 1.0.1
    Requires : PowerShell 5.1+ or PowerShell 7+

    Uses the Host Detection API (/api/2.0/fo/asset/host/vm/detection/)
    and the Knowledge Base API (/api/2.0/fo/knowledge_base/vuln/).

    Version history
    1.0.0   Initial release.
    1.0.1   AuthMethod defaults to BasicAuth. Removed PowerShell 7-only syntax
            so the script runs on Windows PowerShell 5.1.
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string]$QualysBaseUrl,

    [Parameter()]
    [ValidateSet('BasicAuth', 'ApiToken', 'JWT')]
    [string]$AuthMethod = 'BasicAuth',

    [Parameter()]
    [System.Management.Automation.PSCredential]$Credential,

    [Parameter()]
    [string]$ApiToken,

    [Parameter()]
    [string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ScriptVersion = '1.0.1'

#region Helpers

function Write-Step    { param([string]$Message) Write-Host "  --> $Message" -ForegroundColor Cyan }
function Write-Success { param([string]$Message) Write-Host "  [OK] $Message" -ForegroundColor Green }
function Write-Warn    { param([string]$Message) Write-Host "  [!]  $Message" -ForegroundColor Yellow }

# Build a consistent headers hashtable based on chosen auth method
function Get-AuthHeaders {
    param(
        [string]$Method,
        [System.Management.Automation.PSCredential]$Cred,
        [string]$Token,
        [string]$BaseUrl
    )

    $headers = @{
        'X-Requested-With' = 'PowerShell-QualysScript'
        'Accept'           = 'application/xml'
    }

    switch ($Method) {
        'BasicAuth' {
            if (-not $Cred) { throw "BasicAuth requires -Credential (username/password)." }
            $pair  = "$($Cred.UserName):$($Cred.GetNetworkCredential().Password)"
            $b64   = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($pair))
            $headers['Authorization'] = "Basic $b64"
            Write-Step "Auth method: Basic Auth (username: $($Cred.UserName))"
        }
        'ApiToken' {
            if ([string]::IsNullOrWhiteSpace($Token)) { throw "ApiToken requires -ApiToken value." }
            $headers['Authorization'] = "Bearer $Token"
            Write-Step "Auth method: API Token (Bearer)"
        }
        'JWT' {
            if (-not $Cred) { throw "JWT requires -Credential (client_id / client_secret)." }
            Write-Step "Auth method: JWT, fetching token from Gateway..."
            $authBody = @{
                username = $Cred.UserName
                password = $Cred.GetNetworkCredential().Password
                token    = 'true'
            }
            try {
                $response = Invoke-RestMethod -Uri "$BaseUrl/auth" -Method Post `
                    -Body $authBody -ContentType 'application/x-www-form-urlencoded'
                $jwt = if ($response.PSObject.Properties['token']) { $response.token } else { $response }
                $headers['Authorization'] = "Bearer $jwt"
                Write-Success "JWT obtained successfully."
            }
            catch {
                throw "JWT authentication failed. Check your client_id/client_secret and Gateway URL.`nError: $_"
            }
        }
    }
    return $headers
}

# Invoke a Qualys API call with retry on transient errors
function Invoke-QualysRequest {
    param(
        [string]$Uri,
        [string]$Method = 'GET',
        [hashtable]$Headers,
        [hashtable]$Body,
        [int]$MaxRetries = 3
    )

    $attempt = 0
    while ($attempt -lt $MaxRetries) {
        $attempt++
        try {
            $params = @{ Uri = $Uri; Method = $Method; Headers = $Headers }
            if ($Body) {
                $params['Body']        = $Body
                $params['Method']      = 'POST'
                $params['ContentType'] = 'application/x-www-form-urlencoded'
            }
            return Invoke-RestMethod @params
        }
        catch {
            $statusCode = $null
            if ($_.Exception.PSObject.Properties['Response'] -and $_.Exception.Response) {
                $statusCode = [int]$_.Exception.Response.StatusCode
            }
            if ($statusCode -in @(429, 503) -and $attempt -lt $MaxRetries) {
                $wait = $attempt * 10
                Write-Warn "Rate limited or service unavailable (HTTP $statusCode). Retrying in ${wait}s..."
                Start-Sleep -Seconds $wait
            }
            elseif ($statusCode -eq 401) { throw "Authentication failed (HTTP 401). Check your credentials or token." }
            elseif ($statusCode -eq 403) { throw "Access denied (HTTP 403). Your account may lack API or module permissions." }
            else { throw "API request failed: $_" }
        }
    }
}

#endregion

#region Main

Write-Host ""
Write-Host "Qualys - Top 10 Threats on Windows 10/11 (v$ScriptVersion)" -ForegroundColor DarkCyan
Write-Host ""

$QualysBaseUrl = $QualysBaseUrl.TrimEnd('/')

# Step 1: Authenticate
Write-Host "[1/4] Authenticating..." -ForegroundColor White
$headers = Get-AuthHeaders -Method $AuthMethod -Cred $Credential -Token $ApiToken -BaseUrl $QualysBaseUrl
Write-Success "Headers prepared."

# Step 2: Fetch host detections filtered to Windows 10/11
Write-Host "[2/4] Fetching host detections for Windows 10/11 assets..." -ForegroundColor White
Write-Step "This may take a moment depending on your estate size."

$detectionBody = @{
    action           = 'list'
    os_pattern       = '^.*Windows (10|11).*$'
    status           = 'Active'
    show_results     = '1'
    truncation_limit = '0'   # 0 = return all results (use with care on large estates)
}

try {
    [xml]$detectionXml = Invoke-QualysRequest -Uri "$QualysBaseUrl/api/2.0/fo/asset/host/vm/detection/" -Headers $headers -Body $detectionBody
}
catch {
    throw "Failed to retrieve detection data.`nError: $_"
}

$detectionNodes = @($detectionXml.SelectNodes('//DETECTION'))
if ($detectionNodes.Count -eq 0) {
    Write-Warn "No active detections found for Windows 10/11 assets."
    exit 0
}
Write-Success "Retrieved $($detectionNodes.Count) raw detection records."

# Step 3: Aggregate by QID and rank
Write-Host "[3/4] Aggregating and ranking vulnerabilities..." -ForegroundColor White
$qidMap = @{}
foreach ($detection in $detectionNodes) {
    $qid      = $detection.QID
    $severity = 0
    if ($detection.SEVERITY) { $severity = [int]$detection.SEVERITY }

    if (-not $qidMap.ContainsKey($qid)) {
        $qidMap[$qid] = @{
            QID       = $qid
            Severity  = $severity
            CvssBase  = $detection.CVSS_BASE
            HostCount = 0
            Type      = $detection.TYPE
        }
    }
    $qidMap[$qid].HostCount++
}

$top10 = @($qidMap.Values |
    Sort-Object -Property @{Expression = { $_.HostCount }; Descending = $true},
                          @{Expression = { $_.Severity };  Descending = $true} |
    Select-Object -First 10)
Write-Success "Top 10 QIDs identified."

# Step 4: Enrich with KB data
Write-Host "[4/4] Enriching with Qualys Knowledge Base data..." -ForegroundColor White
$kbBody = @{ action = 'list'; ids = (($top10 | ForEach-Object { $_.QID }) -join ','); details = 'All' }
$kbXml  = $null
try {
    [xml]$kbXml = Invoke-QualysRequest -Uri "$QualysBaseUrl/api/2.0/fo/knowledge_base/vuln/" -Headers $headers -Body $kbBody
}
catch {
    Write-Warn "Could not retrieve Knowledge Base details. Results will show QIDs only. Error: $_"
}

$kbLookup = @{}
if ($kbXml) {
    foreach ($vuln in $kbXml.SelectNodes('//VULN')) {
        $kbLookup[$vuln.QID] = @{
            Title          = $vuln.TITLE
            Category       = $vuln.CATEGORY
            CveList        = (@($vuln.SelectNodes('CVE_LIST/CVE/ID') | ForEach-Object { $_.InnerText }) -join ', ')
            CvssV3Base     = $vuln.SelectSingleNode('CVSS_V3/BASE').InnerText
            CvssV3Temporal = $vuln.SelectSingleNode('CVSS_V3/TEMPORAL').InnerText
            PciFlag        = $vuln.PCI_FLAG
            Published      = $vuln.PUBLISHED_DATETIME
        }
    }
}

$severityMap = @{ 5 = 'Critical'; 4 = 'High'; 3 = 'Medium'; 2 = 'Low'; 1 = 'Info'; 0 = 'Unknown' }
$results = @()
$rank = 1
foreach ($item in $top10) {
    $kb = $kbLookup[$item.QID]
    $results += [PSCustomObject]@{
        Rank             = $rank
        QID              = $item.QID
        Title            = if ($kb) { $kb.Title } else { 'N/A - KB lookup failed' }
        Category         = if ($kb) { $kb.Category } else { '' }
        Type             = $item.Type
        QualysSeverity   = $severityMap[[int]$item.Severity]
        CVSS_v3_Base     = if ($kb) { $kb.CvssV3Base } else { $item.CvssBase }
        CVSS_v3_Temporal = if ($kb) { $kb.CvssV3Temporal } else { '' }
        CVEs             = if ($kb) { $kb.CveList } else { '' }
        AffectedHosts    = $item.HostCount
        PCI_Flag         = if ($kb) { $kb.PciFlag } else { '' }
        Published        = if ($kb) { $kb.Published } else { '' }
    }
    $rank++
}

Write-Host ""
foreach ($r in $results) {
    $rankColor = switch ($r.QualysSeverity) {
        'Critical' { 'Red' } 'High' { 'DarkRed' } 'Medium' { 'Yellow' } 'Low' { 'Cyan' } default { 'Gray' }
    }
    Write-Host "#$($r.Rank) - $($r.Title)" -ForegroundColor $rankColor
    Write-Host "     QID       : $($r.QID)"
    Write-Host "     Severity  : $($r.QualysSeverity) | CVSS v3 Base: $($r.CVSS_v3_Base) | Temporal: $($r.CVSS_v3_Temporal)"
    Write-Host "     Affected  : $($r.AffectedHosts) host(s)"
    Write-Host "     CVEs      : $(if ($r.CVEs) { $r.CVEs } else { 'None listed' })"
    Write-Host ""
}

if ($OutputPath) {
    try {
        $results | Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8
        Write-Success "Results exported to: $OutputPath"
    }
    catch { Write-Warn "Could not write CSV to $OutputPath - $_" }
}

$results

#endregion
