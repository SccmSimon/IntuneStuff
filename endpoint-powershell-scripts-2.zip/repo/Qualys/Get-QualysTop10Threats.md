# Get-QualysTop10Threats.ps1

Pulls active Qualys VMDR detections for Windows 10 and 11 assets, ranks QIDs by how many hosts they affect (then by severity), and enriches the top 10 from the Qualys Knowledge Base.

## What it does
1. Builds auth headers for Basic Auth, API token or Gateway JWT.
2. Calls the Host Detection API (`/api/2.0/fo/asset/host/vm/detection/`) filtered to Windows 10/11 and `status=Active`.
3. Groups detections by QID and counts affected hosts.
4. Looks up title, category, CVEs, CVSS v3 base/temporal and PCI flag for the top 10 from `/api/2.0/fo/knowledge_base/vuln/`.
5. Prints a colour-coded summary, returns objects to the pipeline, optionally exports CSV.

## Usage
```powershell
$cred = Get-Credential
.\Get-QualysTop10Threats.ps1 -QualysBaseUrl 'https://qualysapi.qualys.eu' -Credential $cred -OutputPath .\top10.csv
```

| Parameter | Required | Notes |
|---|---|---|
| QualysBaseUrl | Yes | Your platform API URL (Help > About in the portal) |
| AuthMethod | No | BasicAuth (default), ApiToken, JWT |
| Credential | Basic/JWT | Username/password, or client_id/client_secret for JWT |
| ApiToken | ApiToken | Bearer token |
| OutputPath | No | CSV export path |

## Requirements
- Windows PowerShell 5.1 or PowerShell 7
- Qualys account with VM module and API access. SAML/SSO portal accounts cannot use Basic Auth against the API; use a local API account.

## Notes
- `truncation_limit = 0` returns everything. On very large estates, consider paging.
- Read only. Makes no changes in Qualys.
