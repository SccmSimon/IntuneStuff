# Get-QualysKEVReport.ps1

Lists CISA Known Exploited Vulnerabilities (KEV) found on Windows 11 devices in Qualys VMDR, ranked by how many devices each one affects, with a per-device breakdown.

Version 1.0.1. Run `Test-QualysKEVAccess.ps1` first to confirm API access and that RTI data is present.

## How it works
1. Authenticates with Basic Auth (default), an API token, or a Gateway JWT.
2. Pulls active, non-informational detections for hosts matching `Windows 11` from `/api/2.0/fo/asset/host/vm/detection/`.
3. Keeps detections whose RTI field contains `CISA_KNOWN_EXPLOITED`.
4. Enriches each QID from the Knowledge Base (title, CVEs, category, CVSS v3).
5. Prints a ranked summary, a device list per KEV, and totals. Returns the ranked objects to the pipeline.

## Usage
```powershell
$cred = Get-Credential
.\Get-QualysKEVReport.ps1 -QualysBaseUrl 'https://qualysapi.qualys.eu' -Credential $cred

# With CSV export, last 30 days only
.\Get-QualysKEVReport.ps1 -QualysBaseUrl 'https://qualysapi.qualys.eu' -Credential $cred `
    -OutputPath 'C:\Reports\KEV' -DaysThreshold 30
```

| Parameter | Default | Purpose |
|---|---|---|
| `-QualysBaseUrl` | required | API server for your platform |
| `-AuthMethod` | `BasicAuth` | `BasicAuth`, `ApiToken` or `JWT` |
| `-Credential` | | Username/password, or client_id/secret for JWT |
| `-ApiToken` | | Token for `ApiToken` |
| `-OutputPath` | | Writes `<path>_Summary.csv` and `<path>_Devices.csv` |
| `-DaysThreshold` | 0 | Only detections updated in the last N days |

## Notes
- SSO/SAML accounts cannot authenticate to the API. Use a local API account.
- No KEV results usually means RTI/ThreatProtect is not enabled, or detections need a rescan.
- Unique device count is by hostname, as cloud agent records can lack an IP.
- `truncation_limit=0` returns everything in one response. On very large estates the call can be slow.
