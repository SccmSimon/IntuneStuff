# Test-QualysKEVAccess.ps1

Quick read-only check that a machine and account can reach the Qualys API and that CISA KEV (RTI) data is available, before running a full KEV report.

## Tests
| # | Test | Checks |
|---|---|---|
| 1 | TCP | Port 443 reachable on the API host |
| 2 | TLS | HTTPS handshake completes (catches proxy/inspection issues) |
| 3 | Auth | `/api/2.0/fo/user/?action=list` accepts the credentials; shows login and role |
| 4 | Detection API | Pulls 5 hosts to confirm the VM detection endpoint responds |
| 5 | KEV/RTI | Pulls 20 Windows detections and checks for `CISA_KNOWN_EXPLOITED` in the RTI field |

## Usage
```powershell
$cred = Get-Credential
.\Test-QualysKEVAccess.ps1 -QualysBaseUrl 'https://qualysapi.qualys.eu' -Credential $cred
```

Exit code 0 if all tests pass, 1 if any fail. Console output only, nothing written to disk.

## Troubleshooting
- **401 on test 3**: SSO/SAML accounts cannot authenticate to the API. Ask your Qualys admin for a local API account.
- **No RTI fields in test 5**: ThreatProtect/RTI may not be enabled on the subscription, or detections need a rescan.
