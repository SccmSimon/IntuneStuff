<#
.SYNOPSIS
    Basic connectivity and authentication test for the Qualys API.
    Confirms access and retrieves a small sample of KEV data.

.DESCRIPTION
    Tests the following in order:
      1. Network connectivity to the Qualys API endpoint
      2. HTTPS / TLS handshake
      3. Authentication (Basic Auth) and account info
      4. Host detection call, pulls first 5 hosts
      5. KEV check, confirms RTI/KEV data is present in your subscription

    Run this before deploying the full KEV report script.

.PARAMETER QualysBaseUrl
    Qualys API base URL, for example https://qualysapi.qualys.eu

.PARAMETER Credential
    PSCredential, your Qualys username and password.

.EXAMPLE
    $cred = Get-Credential
    .\Test-QualysKEVAccess.ps1 -QualysBaseUrl 'https://qualysapi.qualys.eu' -Credential $cred

.NOTES
    Author : Simon Diaz
    No data is written to disk. Output is console only.
    Read-only API calls only.

.VERSION HISTORY
    1.0.0   Initial release. Connectivity, auth, account info, host detection
            sample, and KEV RTI presence test.
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string]$QualysBaseUrl,

    [Parameter(Mandatory)]
    [System.Management.Automation.PSCredential]$Credential
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ScriptVersion = '1.0.0'

#region Helpers

function Write-Pass  { param([string]$M) Write-Host "  [PASS] $M" -ForegroundColor Green  }
function Write-Fail  { param([string]$M) Write-Host "  [FAIL] $M" -ForegroundColor Red    }
function Write-Info  { param([string]$M) Write-Host "  [INFO] $M" -ForegroundColor Cyan   }
function Write-Warn  { param([string]$M) Write-Host "  [WARN] $M" -ForegroundColor Yellow }
function Write-Title { param([string]$M) Write-Host "`n$M" -ForegroundColor DarkCyan      }

function Get-BasicAuthHeader {
    param([System.Management.Automation.PSCredential]$Cred)
    $pair  = "$($Cred.UserName):$($Cred.GetNetworkCredential().Password)"
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($pair)
    return "Basic $([Convert]::ToBase64String($bytes))"
}

function Get-HttpStatus {
    param($ErrorRecord)
    if ($ErrorRecord.Exception.PSObject.Properties['Response'] -and $ErrorRecord.Exception.Response) {
        return [int]$ErrorRecord.Exception.Response.StatusCode
    }
    return $null
}

#endregion

Write-Host ""
Write-Host "Qualys API - Connectivity and KEV Access Test v$ScriptVersion" -ForegroundColor DarkCyan
Write-Host ""
Write-Info "Platform : $QualysBaseUrl"
Write-Info "User     : $($Credential.UserName)"
Write-Info "Time     : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Host ""

$QualysBaseUrl = $QualysBaseUrl.TrimEnd('/')
$headers = @{
    'Authorization'    = Get-BasicAuthHeader -Cred $Credential
    'X-Requested-With' = 'PowerShell-QualysTest'
    'Accept'           = 'application/xml'
}

$passed = 0
$failed = 0

#region Test 1: Network Connectivity
Write-Title "[ Test 1 ] Network Connectivity"
try {
    $uri     = [System.Uri]$QualysBaseUrl
    $tcpTest = New-Object System.Net.Sockets.TcpClient
    $connect = $tcpTest.BeginConnect($uri.Host, 443, $null, $null)
    $wait    = $connect.AsyncWaitHandle.WaitOne(5000)
    if ($wait -and $tcpTest.Connected) {
        Write-Pass "TCP port 443 reachable at $($uri.Host)"
        $passed++
    }
    else {
        Write-Fail "Cannot reach $($uri.Host) on port 443 - check network/firewall/proxy"
        $failed++
    }
    $tcpTest.Close()
}
catch {
    Write-Fail "TCP connectivity test threw an error: $_"
    $failed++
}
#endregion

#region Test 2: TLS / HTTPS
Write-Title "[ Test 2 ] HTTPS / TLS Handshake"
try {
    $null = Invoke-WebRequest -Uri $QualysBaseUrl -Method Get `
        -Headers @{ 'X-Requested-With' = 'PowerShell-QualysTest' } `
        -UseBasicParsing -TimeoutSec 10
    Write-Pass "HTTPS connection established - TLS handshake successful"
    $passed++
}
catch {
    # A 400/401/403 here is fine: TLS worked, auth just was not provided
    $statusCode = Get-HttpStatus $_
    if ($statusCode -in @(401, 403, 400)) {
        Write-Pass "HTTPS/TLS working - server responded with HTTP $statusCode (expected without auth on root)"
        $passed++
    }
    else {
        Write-Fail "HTTPS connection failed: $_"
        $failed++
    }
}
#endregion

#region Test 3: Authentication
Write-Title "[ Test 3 ] Authentication - Account Info"
try {
    [xml]$userXml = Invoke-RestMethod -Uri "$QualysBaseUrl/api/2.0/fo/user/?action=list" `
        -Method Get -Headers $headers -TimeoutSec 30

    $userNode = $userXml.SelectSingleNode('//USER')
    if ($userNode) {
        Write-Pass "Authenticated successfully"
        Write-Info "Login     : $($userNode.LOGIN)"
        Write-Info "Role      : $($userNode.ROLE)"
        Write-Info "Last login: $($userNode.LAST_LOGIN_DATETIME)"
    }
    else {
        Write-Pass "API responded - authentication accepted"
        Write-Warn "Could not parse user details from response"
    }
    $passed++
}
catch {
    $statusCode = Get-HttpStatus $_
    if     ($statusCode -eq 401) { Write-Fail "Authentication failed (HTTP 401) - check username and password" }
    elseif ($statusCode -eq 403) { Write-Fail "Access denied (HTTP 403) - account may lack API access permission" }
    else                         { Write-Fail "Auth test failed (HTTP $statusCode): $_" }
    $failed++
}
#endregion

#region Test 4: Host Detection sample
Write-Title "[ Test 4 ] Host Detection API - Sample Pull (limit 5 hosts)"
try {
    [xml]$detXml = Invoke-RestMethod -Uri "$QualysBaseUrl/api/2.0/fo/asset/host/vm/detection/" `
        -Method Post -Headers $headers -ContentType 'application/x-www-form-urlencoded' `
        -Body @{ action = 'list'; truncation_limit = '5'; status = 'Active'; show_results = '1' } `
        -TimeoutSec 60

    $hosts = @($detXml.SelectNodes('//HOST'))
    if ($hosts.Count -gt 0) {
        Write-Pass "Host detection API returned $($hosts.Count) host(s) in sample"
        foreach ($h in $hosts) {
            $name = if ($h.SelectSingleNode('DNS')) { $h.DNS } elseif ($h.SelectSingleNode('NETBIOS')) { $h.NETBIOS } else { $h.IP }
            $os   = if ($h.SelectSingleNode('OS'))  { $h.OS } else { 'OS not available' }
            $dets = @($h.SelectNodes('DETECTION_LIST/DETECTION')).Count
            Write-Info "  $("$name".PadRight(45)) OS: $($os.Substring(0, [Math]::Min(35, $os.Length)).PadRight(35))  Detections: $dets"
        }
    }
    else {
        Write-Warn "Host detection API returned no hosts - subscription may have no scanned assets yet"
    }
    $passed++
}
catch {
    Write-Fail "Host detection API call failed (HTTP $(Get-HttpStatus $_)): $_"
    $failed++
}
#endregion

#region Test 5: KEV / RTI data presence
Write-Title "[ Test 5 ] KEV / RTI Data - Windows Hosts"
try {
    [xml]$kevXml = Invoke-RestMethod -Uri "$QualysBaseUrl/api/2.0/fo/asset/host/vm/detection/" `
        -Method Post -Headers $headers -ContentType 'application/x-www-form-urlencoded' `
        -Body @{ action = 'list'; os_pattern = '^.*Windows.*$'; status = 'Active'; show_results = '1'; truncation_limit = '20' } `
        -TimeoutSec 60

    $allDetections = @($kevXml.SelectNodes('//DETECTION'))
    if ($allDetections.Count -eq 0) {
        Write-Warn "No Windows detections found in sample"
    }
    else {
        Write-Info "Windows detection sample: $($allDetections.Count) record(s) across $(@($kevXml.SelectNodes('//HOST')).Count) host(s)"

        $withRTI  = @($allDetections | Where-Object { $_.SelectSingleNode('RTI') -and -not [string]::IsNullOrWhiteSpace($_.RTI) })
        $kevCount = @($withRTI | Where-Object { $_.RTI -match 'CISA_KNOWN_EXPLOITED' })

        Write-Info "Detections with RTI data       : $($withRTI.Count) of $($allDetections.Count)"
        Write-Info "Detections flagged as CISA KEV : $($kevCount.Count)"

        if ($kevCount.Count -gt 0) {
            Write-Pass "KEV/RTI data confirmed present - found $($kevCount.Count) KEV finding(s) in sample"
            $kevCount | Select-Object -First 5 | ForEach-Object {
                Write-Info "  QID: $($_.QID) | Severity: $($_.SEVERITY) | RTI: $($_.RTI)"
            }
        }
        elseif ($withRTI.Count -gt 0) {
            Write-Warn "RTI field is present but no CISA_KNOWN_EXPLOITED entries in this sample"
        }
        else {
            Write-Warn "No RTI fields found in detection sample. Possible reasons:"
            Write-Warn "  - RTI data requires a rescan to populate on older detections"
            Write-Warn "  - Your Qualys subscription may not include RTI/ThreatProtect"
            Write-Warn "  - The sampled hosts may have no RTI-flagged vulnerabilities"
        }
    }
    $passed++
}
catch {
    Write-Fail "KEV/Windows detection test failed (HTTP $(Get-HttpStatus $_)): $_"
    $failed++
}
#endregion

#region Summary
Write-Host ""
Write-Host "TEST SUMMARY" -ForegroundColor DarkCyan
Write-Host "  Tests passed : $passed" -ForegroundColor Green
Write-Host "  Tests failed : $failed" -ForegroundColor $(if ($failed -gt 0) { 'Red' } else { 'Green' })
Write-Host ""
if ($failed -eq 0) { Write-Host "  All tests passed - safe to run the full KEV report script." -ForegroundColor Green }
else               { Write-Host "  One or more tests failed - resolve the issues above first." -ForegroundColor Yellow }

exit $(if ($failed -gt 0) { 1 } else { 0 })
#endregion
