# DetectR

WPF desktop tool that runs an Intune Remediations script package on demand against a list of devices and shows the detection and remediation result for each one.

Uses the Graph `initiateOnDemandProactiveRemediation` action, so no WinRM is needed and it works with Entra-only devices. Tested on up to 50 devices in a single run.

## Requirements
- Windows PowerShell 5.1 or PowerShell 7 on Windows (WPF, so not macOS or Linux)
- `Microsoft.Graph.Authentication` module
- Delegated scopes: `DeviceManagementConfiguration.Read.All`, `DeviceManagementManagedDevices.Read.All`, `DeviceManagementManagedDevices.PrivilegedOperations.All`

## How to use
1. Run `.\DetectR.ps1` and click **Connect to Graph**.
2. Search for and pick a remediation package.
3. Paste device names (one per line) or **Import list...** from a TXT or CSV (first column, header row skipped).
4. Click **Run on devices** and confirm.
5. Results refresh every 30 seconds. **Export CSV...** saves `DetectR_Results_<date>.csv`.

## Reading the results
| Detection | Remediation | Meaning |
|---|---|---|
| Issue found | Fixed | Problem found and fixed |
| Issue found | Fix failed | Problem found, fix did not work |
| No issue | Not needed | Device was already fine |
| Script error | | The script itself failed to run |

**From this run** shows whether the result is newer than the trigger, so an old result is not mistaken for the new one.

## Notes
- Devices must be online to pick up the trigger. Results usually take a few minutes.
- Where a name matches more than one Intune record, the most recently synced one is used and the Trigger column says so.
- If Windows blocks the file after download, run `Unblock-File .\DetectR.ps1`.
