<#
.SYNOPSIS
    Intune Remediations Explorer. Read-only WinForms GUI for Intune Remediations (device health scripts).

.DESCRIPTION
    For every remediation package it shows:
      - Run summary (Dashboard)
      - Package properties (Packages)
      - Assignments with group names, filters and schedules (Assignments)
      - Decoded detection and remediation scripts
      - Per-device results including script output and errors (Device Results)
    Everything can be exported to CSV, JSON or .ps1 files (Export).

.NOTES
    Author   : Simon Diaz
    Requires : Microsoft.Graph.Authentication
    Runs on  : Windows PowerShell 5.1 or PowerShell 7 on Windows, STA mode
    Scopes   : DeviceManagementConfiguration.Read.All
               DeviceManagementManagedDevices.Read.All
               Group.Read.All
    API      : Graph beta. deviceHealthScripts is only exposed on beta.
#>

#Requires -Modules Microsoft.Graph.Authentication

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

if ([System.Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    Write-Warning 'Not running in STA mode. Clipboard and file dialogs may fail. Use: powershell.exe -STA -File .\IntuneRemediationsExplorer.ps1'
}

#region Settings and state
$script:GraphBase = 'https://graph.microsoft.com/beta'
$script:Scopes = @(
    'DeviceManagementConfiguration.Read.All'
    'DeviceManagementManagedDevices.Read.All'
    'Group.Read.All'
)

# Everything loaded from Graph is cached here so switching packages is fast
$script:State = @{
    Packages      = $null   # raw package list from Graph
    Details       = @{}     # package id -> full package object (includes script content)
    Summaries     = @{}     # package id -> runSummary
    Assignments   = @{}     # package id -> assignment rows
    RunStates     = @{}     # package id -> device result rows
    Groups        = @{}     # group id -> display name
    Filters       = @{}     # assignment filter id -> display name
    DashboardRows = $null
    PackageRows   = $null
    SelectedId    = $null
    Loading       = $false  # suppresses grid events while data is being bound
}

# Device Results "Show" dropdown -> DataView RowFilter expression
$script:ResultFilters = [ordered]@{
    'All devices'        = ''
    'Issue detected'     = "DetectionState = 'fail'"
    'Remediated'         = "RemediationState = 'success'"
    'Remediation failed' = "RemediationState = 'remediationFailed'"
    'Script errors'      = "DetectionState = 'scriptError' OR RemediationState = 'scriptError'"
    'No issue detected'  = "DetectionState = 'success' AND ISNULL(RemediationState, '') <> 'success'"
    'Pending'            = "DetectionState = 'pending'"
    'Not applicable'     = "DetectionState = 'notApplicable'"
}

$script:HeaderLabels = New-Object System.Collections.Generic.List[object]
$script:AllGrids     = New-Object System.Collections.Generic.List[object]
#endregion

#region General helpers
function Set-Status {
    param([string]$Text)
    $script:StatusLabel.Text = $Text
    [System.Windows.Forms.Application]::DoEvents()
}

function Invoke-UiAction {
    # Wraps every button action: wait cursor, error popup, no crash
    param([scriptblock]$Action)
    $script:Form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
    try {
        & $Action
    }
    catch {
        Set-Status ('Error: {0}' -f $_.Exception.Message)
        [void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Error', 'OK', 'Error')
    }
    finally {
        $script:Form.Cursor = [System.Windows.Forms.Cursors]::Default
    }
}

function Format-Date {
    param($Value)
    if (-not $Value) { return '' }
    try {
        $d = [datetime]$Value
        if ($d.Year -lt 2000) { return '' }   # Graph uses 0001-01-01 for "never"
        return $d.ToLocalTime().ToString('yyyy-MM-dd HH:mm')
    }
    catch { return [string]$Value }
}

function ConvertTo-Long {
    param($Value)
    if ($null -eq $Value) { return [long]0 }
    return [long]$Value
}

function ConvertFrom-ScriptContent {
    # Graph returns script content as base64. Decode and strip any BOM.
    param([string]$Content)
    if ([string]::IsNullOrWhiteSpace($Content)) { return '' }
    try {
        $bytes = [Convert]::FromBase64String($Content)
        return [System.Text.Encoding]::UTF8.GetString($bytes).TrimStart([char]0xFEFF)
    }
    catch { return $Content }
}

function Get-SafeName {
    param([string]$Name)
    $invalid = [System.IO.Path]::GetInvalidFileNameChars()
    $clean = -join ($Name.ToCharArray() | ForEach-Object { if ($invalid -contains $_) { '_' } else { $_ } })
    return $clean.Trim()
}

function ConvertTo-LikeSafe {
    # Escapes text for a DataView LIKE filter
    param([string]$Text)
    $Text = $Text -replace "'", "''"
    return ($Text -replace '([\[\]\*%])', '[$1]')
}

function Get-Sum {
    param($Rows, [string]$Property)
    if (-not $Rows) { return 0 }
    return [long](($Rows | Measure-Object -Property $Property -Sum).Sum)
}
#endregion

#region Graph helpers
function Invoke-GraphGet {
    param([string]$Uri)
    Invoke-MgGraphRequest -Method GET -Uri $Uri -OutputType PSObject -ErrorAction Stop
}

function Get-GraphAll {
    # Follows @odata.nextLink so large collections are returned in full
    param([string]$Uri)
    $results = New-Object System.Collections.Generic.List[object]
    while ($Uri) {
        $response = Invoke-GraphGet -Uri $Uri
        foreach ($item in @($response.value)) {
            if ($null -ne $item) { $results.Add($item) }
        }
        $Uri = $response.'@odata.nextLink'
        [System.Windows.Forms.Application]::DoEvents()
    }
    return ,$results   # comma stops PowerShell unrolling the list
}

function Get-GroupName {
    param([string]$GroupId)
    if (-not $GroupId) { return '' }
    if (-not $script:State.Groups.ContainsKey($GroupId)) {
        try {
            $g = Invoke-GraphGet -Uri ('https://graph.microsoft.com/v1.0/groups/{0}?$select=displayName' -f $GroupId)
            $script:State.Groups[$GroupId] = $g.displayName
        }
        catch {
            $script:State.Groups[$GroupId] = "(unresolved) $GroupId"
        }
    }
    return $script:State.Groups[$GroupId]
}

function Get-PackageName {
    param([string]$Id)
    $p = $script:State.Packages | Where-Object { $_.id -eq $Id } | Select-Object -First 1
    if ($p) { return $p.displayName }
    return $Id
}

function Format-Schedule {
    param($Schedule)
    if (-not $Schedule) { return '' }
    $type = [string]$Schedule.'@odata.type'
    $zone = if ($Schedule.useUtc) { 'UTC' } else { 'device local time' }
    if ($type -like '*DailySchedule')   { return 'Every {0} day(s) at {1} {2}' -f $Schedule.interval, $Schedule.time, $zone }
    if ($type -like '*HourlySchedule')  { return 'Every {0} hour(s)' -f $Schedule.interval }
    if ($type -like '*RunOnceSchedule') { return 'Once on {0} at {1} {2}' -f $Schedule.date, $Schedule.time, $zone }
    return ($Schedule | ConvertTo-Json -Compress -Depth 5)
}

function Get-PackageDetail {
    param([string]$Id)
    if (-not $script:State.Details.ContainsKey($Id)) {
        $script:State.Details[$Id] = Invoke-GraphGet -Uri ('{0}/deviceManagement/deviceHealthScripts/{1}' -f $script:GraphBase, $Id)
    }
    return $script:State.Details[$Id]
}

function Get-PackageAssignments {
    param([string]$Id)
    if ($script:State.Assignments.ContainsKey($Id)) { return ,$script:State.Assignments[$Id] }

    $rows = New-Object System.Collections.Generic.List[object]
    $raw  = Get-GraphAll -Uri ('{0}/deviceManagement/deviceHealthScripts/{1}/assignments' -f $script:GraphBase, $Id)

    foreach ($a in $raw) {
        $t    = $a.target
        $type = [string]$t.'@odata.type'
        $mode = 'Include'

        # Exclusion must be checked first because it also matches *groupAssignmentTarget
        if     ($type -like '*exclusionGroupAssignmentTarget')   { $mode = 'Exclude'; $targetName = Get-GroupName $t.groupId }
        elseif ($type -like '*groupAssignmentTarget')            { $targetName = Get-GroupName $t.groupId }
        elseif ($type -like '*allDevicesAssignmentTarget')       { $targetName = 'All devices' }
        elseif ($type -like '*allLicensedUsersAssignmentTarget') { $targetName = 'All users' }
        else                                                     { $targetName = $type }

        $filterName = ''
        $filterId   = [string]$t.deviceAndAppManagementAssignmentFilterId
        if ($filterId -and $filterId -ne '00000000-0000-0000-0000-000000000000') {
            $filterName = if ($script:State.Filters.ContainsKey($filterId)) { $script:State.Filters[$filterId] } else { $filterId }
        }

        # Parentheses around the -replace are required inside a hashtable literal
        $rows.Add([pscustomobject][ordered]@{
            Mode           = $mode
            Target         = $targetName
            TargetType     = ($type -replace '#microsoft.graph.', '')
            Filter         = $filterName
            FilterType     = $t.deviceAndAppManagementAssignmentFilterType
            Schedule       = (Format-Schedule $a.runSchedule)
            RunRemediation = $a.runRemediationScript
            GroupId        = $t.groupId
            AssignmentId   = $a.id
        })
    }

    $script:State.Assignments[$Id] = $rows
    return ,$rows
}

function Get-PackageRunStates {
    param([string]$Id, [switch]$Force)
    if (-not $Force -and $script:State.RunStates.ContainsKey($Id)) { return ,$script:State.RunStates[$Id] }

    $uri = '{0}/deviceManagement/deviceHealthScripts/{1}/deviceRunStates?$expand=managedDevice($select=id,deviceName,userPrincipalName,operatingSystem,osVersion,lastSyncDateTime)' -f $script:GraphBase, $Id
    $raw = Get-GraphAll -Uri $uri

    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($r in $raw) {
        $md = $r.managedDevice
        $rows.Add([pscustomobject][ordered]@{
            DeviceName          = $md.deviceName
            User                = $md.userPrincipalName
            OS                  = $md.operatingSystem
            OSVersion           = $md.osVersion
            DetectionState      = $r.detectionState
            RemediationState    = $r.remediationState
            LastStateUpdate     = (Format-Date $r.lastStateUpdateDateTime)
            LastSync            = (Format-Date $md.lastSyncDateTime)
            PreDetectionOutput  = $r.preRemediationDetectionScriptOutput
            PostDetectionOutput = $r.postRemediationDetectionScriptOutput
            PreDetectionError   = $r.preRemediationDetectionScriptError
            RemediationError    = $r.remediationScriptError
            PostDetectionError  = $r.postRemediationDetectionScriptError
            ManagedDeviceId     = $md.id
            RunStateId          = $r.id
        })
    }

    $script:State.RunStates[$Id] = $rows
    return ,$rows
}
#endregion

#region Grid helpers
function ConvertTo-DataTable {
    # DataTable lets the grid sort and filter (RowFilter) without extra code
    param($Rows)
    $dt   = New-Object System.Data.DataTable
    $list = @($Rows | Where-Object { $null -ne $_ })
    if ($list.Count -eq 0) { return ,$dt }

    foreach ($p in $list[0].PSObject.Properties) {
        $type = [string]
        if ($p.Value -is [int] -or $p.Value -is [long]) { $type = [long] }
        [void]$dt.Columns.Add($p.Name, $type)
    }

    foreach ($row in $list) {
        $dr = $dt.NewRow()
        foreach ($col in $dt.Columns) {
            $v = $row.($col.ColumnName)
            if ($null -eq $v)                  { $dr[$col.ColumnName] = [DBNull]::Value }
            elseif ($col.DataType -eq [long])  { $dr[$col.ColumnName] = [long]$v }
            elseif ($v -is [array])            { $dr[$col.ColumnName] = ($v -join ', ') }
            else                               { $dr[$col.ColumnName] = [string]$v }
        }
        $dt.Rows.Add($dr)
    }
    return ,$dt   # comma stops PowerShell enumerating the table rows
}

function Resize-Grid {
    param($Grid)
    if (-not $Grid.Visible -or $Grid.Columns.Count -eq 0) { return }
    $mode = if ($Grid.Rows.Count -le 2000) { 'AllCells' } else { 'ColumnHeader' }
    $Grid.AutoResizeColumns([System.Windows.Forms.DataGridViewAutoSizeColumnsMode]$mode)
    foreach ($c in $Grid.Columns) { if ($c.Width -gt 350) { $c.Width = 350 } }
    $Grid.Tag = 'sized'
}

function Set-GridData {
    param($Grid, $Rows)
    $script:State.Loading = $true
    try {
        $Grid.DataSource = $null
        $Grid.DataSource = ConvertTo-DataTable -Rows $Rows
        $Grid.Tag = $null
        Resize-Grid $Grid
    }
    finally {
        $script:State.Loading = $false
    }
}

function Set-ViewFilter {
    param($Grid, [string[]]$Columns, [string]$Search, [string]$Extra)
    $dt = $Grid.DataSource
    if (-not ($dt -is [System.Data.DataTable]) -or $dt.Columns.Count -eq 0) { return }

    $parts = @()
    if ($Search) {
        $clauses = $Columns | Where-Object { $dt.Columns.Contains($_) } | ForEach-Object { "[$_] LIKE '*$Search*'" }
        if ($clauses) { $parts += '(' + ($clauses -join ' OR ') + ')' }
    }
    if ($Extra) { $parts += "($Extra)" }
    $dt.DefaultView.RowFilter = ($parts -join ' AND ')
}

function Update-Filters {
    $script:State.Loading = $true
    try {
        $search = ConvertTo-LikeSafe $txtSearch.Text.Trim()

        Set-ViewFilter -Grid $gridPackages -Columns @('Name', 'Description', 'Publisher') -Search $search
        Set-ViewFilter -Grid $gridDash     -Columns @('Name', 'Publisher') -Search $search

        $stateClause = $script:ResultFilters[[string]$cmbState.SelectedItem]
        Set-ViewFilter -Grid $gridResults `
            -Columns @('DeviceName', 'User', 'DetectionState', 'RemediationState', 'PreDetectionOutput', 'PostDetectionOutput', 'RemediationError') `
            -Search $search -Extra $stateClause

        $dt = $gridResults.DataSource
        if ($dt -is [System.Data.DataTable] -and $dt.Columns.Count -gt 0) {
            $lblResultCount.Text = '{0} of {1} devices shown' -f $dt.DefaultView.Count, $dt.Rows.Count
        }
    }
    finally {
        $script:State.Loading = $false
    }
}
#endregion

#region UI builders
function New-Grid {
    $g = New-Object System.Windows.Forms.DataGridView
    $g.Dock                        = 'Fill'
    $g.ReadOnly                    = $true
    $g.AllowUserToAddRows          = $false
    $g.AllowUserToDeleteRows       = $false
    $g.AllowUserToResizeRows       = $false
    $g.SelectionMode               = 'FullRowSelect'
    $g.MultiSelect                 = $false
    $g.RowHeadersVisible           = $false
    $g.AutoSizeColumnsMode         = 'None'
    $g.ColumnHeadersHeightSizeMode = 'AutoSize'
    $g.BackgroundColor             = [System.Drawing.SystemColors]::Window
    $g.BorderStyle                 = 'None'
    $g.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)
    $script:AllGrids.Add($g)
    return $g
}

function New-OutputBox {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Multiline  = $true
    $t.ReadOnly   = $true
    $t.ScrollBars = 'Both'
    $t.WordWrap   = $false
    $t.Dock       = 'Fill'
    $t.Font       = New-Object System.Drawing.Font('Consolas', 10)
    $t.BackColor  = [System.Drawing.SystemColors]::Window
    return $t
}

function New-Button {
    param([string]$Text, [int]$Width = 120)
    $b = New-Object System.Windows.Forms.Button
    $b.Text   = $Text
    $b.Width  = $Width
    $b.Height = 28
    return $b
}

function New-Label {
    param([string]$Text, [int]$TopMargin = 8)
    $l = New-Object System.Windows.Forms.Label
    $l.Text     = $Text
    $l.AutoSize = $true
    $l.Margin   = New-Object System.Windows.Forms.Padding(3, $TopMargin, 6, 3)
    return $l
}

function New-HeaderLabel {
    $l = New-Label -Text 'Selected: (none)' -TopMargin 6
    $l.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $script:HeaderLabels.Add($l)
    return $l
}

function New-ScriptTab {
    param([string]$Title, [string]$Kind)
    $page = New-Object System.Windows.Forms.TabPage $Title

    $top = New-Object System.Windows.Forms.FlowLayoutPanel
    $top.Dock   = 'Top'
    $top.Height = 66

    $header = New-HeaderLabel
    $top.Controls.Add($header)
    $top.SetFlowBreak($header, $true)

    $btnCopy = New-Button 'Copy' 80
    $btnSave = New-Button 'Save as .ps1' 110
    $info    = New-Label -Text ''
    $box     = New-OutputBox

    # Tag carries the controls into the event handler. Local variables are gone by the time a click fires.
    $btnCopy.Tag = $box
    $btnSave.Tag = @{ Box = $box; Kind = $Kind }

    $btnCopy.Add_Click({
        if ($this.Tag.Text) {
            [System.Windows.Forms.Clipboard]::SetText($this.Tag.Text)
            Set-Status 'Script copied to clipboard.'
        }
    })
    $btnSave.Add_Click({
        $t = $this.Tag
        Invoke-UiAction { Save-ScriptToFile -Box $t.Box -Kind $t.Kind }
    })

    $top.Controls.AddRange([System.Windows.Forms.Control[]]@($btnCopy, $btnSave, $info))
    $page.Controls.Add($box)
    $page.Controls.Add($top)
    $box.BringToFront()

    return @{ Page = $page; Box = $box; Info = $info }
}

function Set-ScriptTab {
    param($Tab, [string]$Content, $Parameters, $Package)
    $text = ConvertFrom-ScriptContent $Content
    if (-not $text) {
        $text = "# No script content returned for this package.`r`n# Microsoft-published packages and detection-only packages can show this."
    }
    $Tab.Box.Text = $text -replace "`r?`n", "`r`n"

    $params = @($Parameters | Where-Object { $_ })
    $paramText = 'none'
    if ($params.Count) {
        $paramText = ($params | ForEach-Object {
            if ($_.isRequired) { '{0} (required)' -f $_.name } else { $_.name }
        }) -join ', '
    }
    $arch = if ($Package.runAs32Bit) { '32-bit' } else { '64-bit' }
    $Tab.Info.Text = 'Run as: {0}  |  {1}  |  Signature check: {2}  |  Lines: {3}  |  Parameters: {4}' -f `
        $Package.runAsAccount, $arch, $Package.enforceSignatureCheck, $Tab.Box.Lines.Count, $paramText
}

function Save-ScriptToFile {
    param($Box, [string]$Kind)
    if (-not $Box.Text -or -not $script:State.SelectedId) { throw 'No script loaded. Select a package first.' }
    $dlg = New-Object System.Windows.Forms.SaveFileDialog
    $dlg.Filter   = 'PowerShell script (*.ps1)|*.ps1'
    $dlg.FileName = '{0}_{1}.ps1' -f (Get-SafeName (Get-PackageName $script:State.SelectedId)), $Kind
    if ($dlg.ShowDialog() -eq 'OK') {
        Set-Content -Path $dlg.FileName -Value $Box.Text -Encoding UTF8
        Set-Status ('Saved {0}' -f $dlg.FileName)
    }
}
#endregion

#region Main form
$script:Form = New-Object System.Windows.Forms.Form
$Form.Text          = 'Intune Remediations Explorer'
$Form.Size          = New-Object System.Drawing.Size(1400, 850)
$Form.StartPosition = 'CenterScreen'
$Form.Font          = New-Object System.Drawing.Font('Segoe UI', 9)

# Top bar: Connect, Refresh, Search
$topBar = New-Object System.Windows.Forms.FlowLayoutPanel
$topBar.Dock    = 'Top'
$topBar.Height  = 42
$topBar.Padding = New-Object System.Windows.Forms.Padding(6, 6, 6, 0)

$btnConnect     = New-Button 'Connect Graph' 120
$btnRefresh     = New-Button 'Refresh' 100
$lblSearch      = New-Label 'Search:'
$txtSearch      = New-Object System.Windows.Forms.TextBox
$txtSearch.Width  = 320
$txtSearch.Margin = New-Object System.Windows.Forms.Padding(3, 5, 3, 3)
$btnClearSearch = New-Button 'Clear' 70
$topBar.Controls.AddRange([System.Windows.Forms.Control[]]@($btnConnect, $btnRefresh, $lblSearch, $txtSearch, $btnClearSearch))

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = 'Fill'

# Dashboard tab
$tabDash = New-Object System.Windows.Forms.TabPage 'Dashboard'
$dashTop = New-Object System.Windows.Forms.Panel
$dashTop.Dock   = 'Top'
$dashTop.Height = 56
$lblTotals = New-Object System.Windows.Forms.Label
$lblTotals.AutoSize = $true
$lblTotals.Location = New-Object System.Drawing.Point(8, 8)
$lblTotals.Font     = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
$lblTotals.Text     = 'Not loaded. Connect, then click Refresh.'
$lblDashHint = New-Object System.Windows.Forms.Label
$lblDashHint.AutoSize  = $true
$lblDashHint.Location  = New-Object System.Drawing.Point(8, 32)
$lblDashHint.ForeColor = [System.Drawing.Color]::DimGray
$lblDashHint.Text      = 'Double-click a row to open that package.'
$dashTop.Controls.AddRange([System.Windows.Forms.Control[]]@($lblTotals, $lblDashHint))
$gridDash = New-Grid
$tabDash.Controls.Add($gridDash)
$tabDash.Controls.Add($dashTop)
$gridDash.BringToFront()

# Packages tab
$tabPackages = New-Object System.Windows.Forms.TabPage 'Packages'
$pkgTop = New-Object System.Windows.Forms.FlowLayoutPanel
$pkgTop.Dock   = 'Top'
$pkgTop.Height = 32
$pkgTop.Controls.Add((New-HeaderLabel))
$splitPackages = New-Object System.Windows.Forms.SplitContainer
$splitPackages.Dock        = 'Fill'
$splitPackages.Orientation = 'Horizontal'
$gridPackages     = New-Grid
$txtPackageDetail = New-OutputBox
$splitPackages.Panel1.Controls.Add($gridPackages)
$splitPackages.Panel2.Controls.Add($txtPackageDetail)
$tabPackages.Controls.Add($splitPackages)
$tabPackages.Controls.Add($pkgTop)
$splitPackages.BringToFront()

# Assignments tab
$tabAssign = New-Object System.Windows.Forms.TabPage 'Assignments'
$assignTop = New-Object System.Windows.Forms.FlowLayoutPanel
$assignTop.Dock   = 'Top'
$assignTop.Height = 32
$assignTop.Controls.Add((New-HeaderLabel))
$gridAssign = New-Grid
$tabAssign.Controls.Add($gridAssign)
$tabAssign.Controls.Add($assignTop)
$gridAssign.BringToFront()

# Script tabs
$script:DetTab = New-ScriptTab -Title 'Detection Script' -Kind 'Detect'
$script:RemTab = New-ScriptTab -Title 'Remediation Script' -Kind 'Remediate'

# Device Results tab
$tabResults = New-Object System.Windows.Forms.TabPage 'Device Results'
$resTop = New-Object System.Windows.Forms.FlowLayoutPanel
$resTop.Dock   = 'Top'
$resTop.Height = 66
$resHeader = New-HeaderLabel
$resTop.Controls.Add($resHeader)
$resTop.SetFlowBreak($resHeader, $true)
$btnLoadResults   = New-Button 'Load device results' 150
$btnReloadResults = New-Button 'Reload from Graph' 140
$lblShow  = New-Label 'Show:'
$cmbState = New-Object System.Windows.Forms.ComboBox
$cmbState.DropDownStyle = 'DropDownList'
$cmbState.Width  = 170
$cmbState.Margin = New-Object System.Windows.Forms.Padding(3, 5, 3, 3)
[void]$cmbState.Items.AddRange([object[]]@($script:ResultFilters.Keys))
$cmbState.SelectedIndex = 0
$lblResultCount = New-Label ''
$resTop.Controls.AddRange([System.Windows.Forms.Control[]]@($btnLoadResults, $btnReloadResults, $lblShow, $cmbState, $lblResultCount))
$splitResults = New-Object System.Windows.Forms.SplitContainer
$splitResults.Dock        = 'Fill'
$splitResults.Orientation = 'Horizontal'
$gridResults     = New-Grid
$txtResultDetail = New-OutputBox
$splitResults.Panel1.Controls.Add($gridResults)
$splitResults.Panel2.Controls.Add($txtResultDetail)
$tabResults.Controls.Add($splitResults)
$tabResults.Controls.Add($resTop)
$splitResults.BringToFront()

# Export tab
$tabExport = New-Object System.Windows.Forms.TabPage 'Export'
$expTop = New-Object System.Windows.Forms.FlowLayoutPanel
$expTop.Dock          = 'Top'
$expTop.Height        = 330
$expTop.FlowDirection = 'TopDown'
$expTop.WrapContents  = $false
$expTop.Padding       = New-Object System.Windows.Forms.Padding(8)

$folderRow = New-Object System.Windows.Forms.FlowLayoutPanel
$folderRow.AutoSize = $true
$txtExportFolder = New-Object System.Windows.Forms.TextBox
$txtExportFolder.Width  = 520
$txtExportFolder.Margin = New-Object System.Windows.Forms.Padding(3, 5, 3, 3)
$txtExportFolder.Text   = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'IntuneRemediationReports'
$btnBrowse = New-Button 'Browse...' 90
$folderRow.Controls.AddRange([System.Windows.Forms.Control[]]@((New-Label 'Export folder:'), $txtExportFolder, $btnBrowse))

$btnExpDash     = New-Button 'Dashboard summary (CSV)' 340
$btnExpPackages = New-Button 'Package list (CSV)' 340
$btnExpAssign   = New-Button 'All assignments, all packages (CSV)' 340
$btnExpResSel   = New-Button 'Device results: selected package (CSV)' 340
$btnExpResAll   = New-Button 'Device results: all packages (CSV)' 340
$btnExpScripts  = New-Button 'All scripts (.ps1 files)' 340
$btnExpJson     = New-Button 'Full report: selected package (JSON)' 340
$btnOpenFolder  = New-Button 'Open export folder' 340
$expTop.Controls.AddRange([System.Windows.Forms.Control[]]@(
    $folderRow, $btnExpDash, $btnExpPackages, $btnExpAssign, $btnExpResSel,
    $btnExpResAll, $btnExpScripts, $btnExpJson, $btnOpenFolder))
$txtExportLog = New-OutputBox
$tabExport.Controls.Add($txtExportLog)
$tabExport.Controls.Add($expTop)
$txtExportLog.BringToFront()

$tabs.TabPages.AddRange([System.Windows.Forms.TabPage[]]@(
    $tabDash, $tabPackages, $tabAssign, $script:DetTab.Page, $script:RemTab.Page, $tabResults, $tabExport))

# Status bar
$statusStrip = New-Object System.Windows.Forms.StatusStrip
$script:StatusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:StatusLabel.Spring    = $true
$script:StatusLabel.TextAlign = 'MiddleLeft'
$script:ConnLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:ConnLabel.Text = 'Not connected'
[void]$statusStrip.Items.Add($script:StatusLabel)
[void]$statusStrip.Items.Add($script:ConnLabel)

# Dock order: Fill control is brought to front so it takes the space left by Top and Bottom
$Form.Controls.Add($tabs)
$Form.Controls.Add($topBar)
$Form.Controls.Add($statusStrip)
$tabs.BringToFront()
#endregion

#region Actions
function Clear-Selection {
    $script:State.SelectedId = $null
    foreach ($h in $script:HeaderLabels) { $h.Text = 'Selected: (none)' }
    $txtPackageDetail.Clear()
    $script:DetTab.Box.Clear(); $script:DetTab.Info.Text = ''
    $script:RemTab.Box.Clear(); $script:RemTab.Info.Text = ''
    Set-GridData -Grid $gridAssign  -Rows $null
    Set-GridData -Grid $gridResults -Rows $null
    $txtResultDetail.Clear()
    $lblResultCount.Text = ''
}

function Update-AllData {
    if (-not (Get-MgContext)) { throw 'Not connected. Click Connect Graph first.' }

    # Reset caches so Refresh always shows current data
    foreach ($k in 'Details', 'Summaries', 'Assignments', 'RunStates', 'Filters') { $script:State[$k] = @{} }
    Clear-Selection

    Set-Status 'Loading assignment filters...'
    try {
        foreach ($f in (Get-GraphAll -Uri ('{0}/deviceManagement/assignmentFilters' -f $script:GraphBase))) {
            $script:State.Filters[[string]$f.id] = $f.displayName
        }
    }
    catch { }  # filters are optional, IDs are shown if names cannot be read

    Set-Status 'Loading remediation packages...'
    $pkgs = Get-GraphAll -Uri ('{0}/deviceManagement/deviceHealthScripts' -f $script:GraphBase)
    $script:State.Packages = $pkgs

    $dashList = New-Object System.Collections.Generic.List[object]
    $pkgList  = New-Object System.Collections.Generic.List[object]
    $i = 0

    foreach ($p in $pkgs) {
        $i++
        Set-Status ('Loading run summary {0} of {1}: {2}' -f $i, $pkgs.Count, $p.displayName)
        $s = $null
        try { $s = Invoke-GraphGet -Uri ('{0}/deviceManagement/deviceHealthScripts/{1}/runSummary' -f $script:GraphBase, $p.id) } catch { }
        $script:State.Summaries[$p.id] = $s

        $dashList.Add([pscustomobject][ordered]@{
            Name                 = $p.displayName
            Publisher            = $p.publisher
            NoIssue              = (ConvertTo-Long $s.noIssueDetectedDeviceCount)
            IssueDetected        = (ConvertTo-Long $s.issueDetectedDeviceCount)
            Remediated           = (ConvertTo-Long $s.issueRemediatedDeviceCount)
            Recurred             = (ConvertTo-Long $s.issueReoccurredDeviceCount)
            RemediatedCumulative = (ConvertTo-Long $s.issueRemediatedCumulativeDeviceCount)
            DetectionErrors      = (ConvertTo-Long $s.detectionScriptErrorDeviceCount)
            RemediationErrors    = (ConvertTo-Long $s.remediationScriptErrorDeviceCount)
            RemediationSkipped   = (ConvertTo-Long $s.remediationSkippedDeviceCount)
            Pending              = (ConvertTo-Long $s.detectionScriptPendingDeviceCount)
            NotApplicable        = (ConvertTo-Long $s.detectionScriptNotApplicableDeviceCount)
            LastRun              = (Format-Date $s.lastScriptRunDateTime)
            Id                   = $p.id
        })

        $pkgList.Add([pscustomobject][ordered]@{
            Name           = $p.displayName
            Description    = $p.description
            Publisher      = $p.publisher
            Version        = $p.version
            Type           = $p.deviceHealthScriptType
            RunAs          = $p.runAsAccount
            RunAs32Bit     = $p.runAs32Bit
            SignatureCheck = $p.enforceSignatureCheck
            Global         = $p.isGlobalScript
            ScopeTags      = (@($p.roleScopeTagIds) -join ', ')
            Created        = (Format-Date $p.createdDateTime)
            Modified       = (Format-Date $p.lastModifiedDateTime)
            Id             = $p.id
        })
    }

    $script:State.DashboardRows = @($dashList | Sort-Object Name)
    $script:State.PackageRows   = @($pkgList  | Sort-Object Name)

    Set-GridData -Grid $gridDash     -Rows $script:State.DashboardRows
    Set-GridData -Grid $gridPackages -Rows $script:State.PackageRows

    $d = $script:State.DashboardRows
    $lblTotals.Text = 'Packages: {0}   |   No issue: {1}   |   Issue detected: {2}   |   Remediated: {3}   |   Recurred: {4}   |   Detection errors: {5}   |   Remediation errors: {6}' -f `
        $d.Count, (Get-Sum $d 'NoIssue'), (Get-Sum $d 'IssueDetected'), (Get-Sum $d 'Remediated'),
        (Get-Sum $d 'Recurred'), (Get-Sum $d 'DetectionErrors'), (Get-Sum $d 'RemediationErrors')

    Update-Filters

    if ($gridPackages.Rows.Count -gt 0) {
        Select-Package -Id ([string]$gridPackages.Rows[0].Cells['Id'].Value)
    }
    Set-Status ('Loaded {0} remediation packages.' -f $pkgs.Count)
}

function Select-Package {
    param([string]$Id)
    if (-not $Id) { return }
    $script:State.SelectedId = $Id

    Set-Status 'Loading package details...'
    $d = Get-PackageDetail -Id $Id
    foreach ($h in $script:HeaderLabels) { $h.Text = 'Selected: {0}' -f $d.displayName }

    # Package properties and run summary as JSON
    $view = $d | Select-Object * -ExcludeProperty detectionScriptContent, remediationScriptContent
    $summary = $script:State.Summaries[$Id]
    $summaryText = if ($summary) { $summary | ConvertTo-Json -Depth 5 } else { 'Not available' }
    $txtPackageDetail.Text = ("PACKAGE`r`n" + ($view | ConvertTo-Json -Depth 10) + "`r`n`r`nRUN SUMMARY`r`n" + $summaryText) -replace "`r?`n", "`r`n"

    # Scripts
    Set-ScriptTab -Tab $script:DetTab -Content $d.detectionScriptContent   -Parameters $d.detectionScriptParameters   -Package $d
    Set-ScriptTab -Tab $script:RemTab -Content $d.remediationScriptContent -Parameters $d.remediationScriptParameters -Package $d

    # Assignments
    Set-Status 'Loading assignments...'
    Set-GridData -Grid $gridAssign -Rows (Get-PackageAssignments -Id $Id)

    # Device results only load on request because they can be large
    $txtResultDetail.Clear()
    if ($script:State.RunStates.ContainsKey($Id)) {
        Set-GridData -Grid $gridResults -Rows $script:State.RunStates[$Id]
        Update-Filters
    }
    else {
        Set-GridData -Grid $gridResults -Rows $null
        $lblResultCount.Text = 'Not loaded. Click Load device results.'
    }
    Set-Status ('Selected: {0}' -f $d.displayName)
}

function Show-DeviceResults {
    param([switch]$Force)
    $id = $script:State.SelectedId
    if (-not $id) { throw 'Select a package on the Packages tab first.' }
    Set-Status 'Loading device results...'
    $rows = Get-PackageRunStates -Id $id -Force:$Force
    Set-GridData -Grid $gridResults -Rows $rows
    Update-Filters
    Show-ResultDetail
    Set-Status ('Loaded {0} device results.' -f $rows.Count)
}

function Show-ResultDetail {
    $row = $gridResults.CurrentRow
    if ($null -eq $row -or $null -eq $row.DataBoundItem) { $txtResultDetail.Clear(); return }
    $drv = $row.DataBoundItem
    $sb  = New-Object System.Text.StringBuilder
    foreach ($col in $drv.Row.Table.Columns) {
        $value = [string]$drv[$col.ColumnName]
        if ($value.Length -gt 80 -or $value -match "`n") {
            [void]$sb.AppendLine('')
            [void]$sb.AppendLine(('==== {0} ====' -f $col.ColumnName))
            [void]$sb.AppendLine($value)
        }
        else {
            [void]$sb.AppendLine(('{0,-22}: {1}' -f $col.ColumnName, $value))
        }
    }
    $txtResultDetail.Text = $sb.ToString() -replace "`r?`n", "`r`n"
}
#endregion

#region Export functions
function Assert-Loaded {
    if ($null -eq $script:State.Packages) { throw 'No data loaded. Connect and click Refresh first.' }
}

function Get-ExportPath {
    param([string]$BaseName, [string]$Extension = 'csv')
    $folder = $txtExportFolder.Text.Trim()
    if (-not $folder) { throw 'Set an export folder first.' }
    if (-not (Test-Path $folder)) { New-Item -Path $folder -ItemType Directory -Force | Out-Null }
    return Join-Path $folder ('{0}_{1:yyyyMMdd-HHmmss}.{2}' -f $BaseName, (Get-Date), $Extension)
}

function Write-ExportLog {
    param([string]$Message)
    $txtExportLog.AppendText(('[{0:HH:mm:ss}] {1}' -f (Get-Date), $Message) + "`r`n")
    Set-Status $Message
}

function Export-AllAssignments {
    Assert-Loaded
    $all = New-Object System.Collections.Generic.List[object]
    $i = 0
    foreach ($p in $script:State.Packages) {
        $i++
        Set-Status ('Reading assignments {0} of {1}' -f $i, $script:State.Packages.Count)
        foreach ($a in (Get-PackageAssignments -Id $p.id)) {
            $all.Add(($a | Select-Object @{ n = 'Package'; e = { $p.displayName } }, @{ n = 'PackageId'; e = { $p.id } }, *))
        }
    }
    $path = Get-ExportPath 'Remediation_Assignments'
    $all | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
    Write-ExportLog ('Exported {0} assignments to {1}' -f $all.Count, $path)
}

function Export-AllDeviceResults {
    Assert-Loaded
    $answer = [System.Windows.Forms.MessageBox]::Show(
        'This reads device results for every package and can take a while in large tenants. Continue?',
        'Export all device results', 'YesNo', 'Question')
    if ($answer -ne 'Yes') { return }

    $all = New-Object System.Collections.Generic.List[object]
    $i = 0
    foreach ($p in $script:State.Packages) {
        $i++
        Set-Status ('Reading device results {0} of {1}: {2}' -f $i, $script:State.Packages.Count, $p.displayName)
        foreach ($r in (Get-PackageRunStates -Id $p.id)) {
            $all.Add(($r | Select-Object @{ n = 'Package'; e = { $p.displayName } }, @{ n = 'PackageId'; e = { $p.id } }, *))
        }
    }
    $path = Get-ExportPath 'Remediation_DeviceResults_All'
    $all | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
    Write-ExportLog ('Exported {0} device results to {1}' -f $all.Count, $path)
}

function Export-AllScripts {
    Assert-Loaded
    $folder = $txtExportFolder.Text.Trim()
    $root   = Join-Path $folder ('Scripts_{0:yyyyMMdd-HHmmss}' -f (Get-Date))
    $count  = 0
    $i      = 0
    foreach ($p in $script:State.Packages) {
        $i++
        Set-Status ('Saving scripts {0} of {1}: {2}' -f $i, $script:State.Packages.Count, $p.displayName)
        $d   = Get-PackageDetail -Id $p.id
        $dir = Join-Path $root ('{0}_{1}' -f (Get-SafeName $p.displayName), ([string]$p.id).Substring(0, 8))
        New-Item -Path $dir -ItemType Directory -Force | Out-Null

        $det = ConvertFrom-ScriptContent $d.detectionScriptContent
        $rem = ConvertFrom-ScriptContent $d.remediationScriptContent
        if ($det) { Set-Content -Path (Join-Path $dir 'Detect.ps1')    -Value $det -Encoding UTF8; $count++ }
        if ($rem) { Set-Content -Path (Join-Path $dir 'Remediate.ps1') -Value $rem -Encoding UTF8; $count++ }
    }
    Write-ExportLog ('Saved {0} script files under {1}' -f $count, $root)
}

function Export-PackageJson {
    Assert-Loaded
    $id = $script:State.SelectedId
    if (-not $id) { throw 'Select a package on the Packages tab first.' }

    $d       = Get-PackageDetail -Id $id
    $assign  = Get-PackageAssignments -Id $id
    Set-Status 'Reading device results for report...'
    $results = Get-PackageRunStates -Id $id

    $report = [ordered]@{
        GeneratedAt       = (Get-Date).ToString('s')
        TenantId          = (Get-MgContext).TenantId
        Package           = ($d | Select-Object * -ExcludeProperty detectionScriptContent, remediationScriptContent)
        RunSummary        = $script:State.Summaries[$id]
        Assignments       = $assign.ToArray()
        DetectionScript   = (ConvertFrom-ScriptContent $d.detectionScriptContent)
        RemediationScript = (ConvertFrom-ScriptContent $d.remediationScriptContent)
        DeviceResults     = $results.ToArray()
    }
    $path = Get-ExportPath ('Remediation_{0}' -f (Get-SafeName $d.displayName)) 'json'
    $report | ConvertTo-Json -Depth 10 | Set-Content -Path $path -Encoding UTF8
    Write-ExportLog ('Exported full report to {0}' -f $path)
}
#endregion

#region Events
$btnConnect.Add_Click({
    Invoke-UiAction {
        Set-Status 'Connecting to Microsoft Graph. Complete sign-in in the browser or popup...'
        Connect-MgGraph -Scopes $script:Scopes -NoWelcome -ErrorAction Stop
        $ctx = Get-MgContext
        $script:ConnLabel.Text = 'Connected: {0}' -f $ctx.Account
        Set-Status 'Connected. Click Refresh to load remediations.'
    }
})

$btnRefresh.Add_Click({ Invoke-UiAction { Update-AllData } })

$txtSearch.Add_TextChanged({ try { Update-Filters } catch { Set-Status $_.Exception.Message } })
$btnClearSearch.Add_Click({ $txtSearch.Clear() })
$cmbState.Add_SelectedIndexChanged({ try { Update-Filters } catch { Set-Status $_.Exception.Message } })

$gridPackages.Add_SelectionChanged({
    if ($script:State.Loading) { return }
    $row = $gridPackages.CurrentRow
    if ($null -eq $row) { return }
    $id = [string]$row.Cells['Id'].Value
    if ($id -and $id -ne $script:State.SelectedId) {
        Invoke-UiAction { Select-Package -Id $id }
    }
})

$gridDash.Add_CellDoubleClick({
    param($s, $e)
    if ($e.RowIndex -lt 0) { return }
    $id = [string]$gridDash.Rows[$e.RowIndex].Cells['Id'].Value
    $tabs.SelectedTab = $tabPackages
    $found = $false
    foreach ($r in $gridPackages.Rows) {
        if ([string]$r.Cells['Id'].Value -eq $id) {
            $gridPackages.CurrentCell = $r.Cells[0]   # triggers SelectionChanged
            $found = $true
            break
        }
    }
    if (-not $found) { Invoke-UiAction { Select-Package -Id $id } }
})

$gridResults.Add_SelectionChanged({
    if ($script:State.Loading) { return }
    Show-ResultDetail
})

$btnLoadResults.Add_Click({   Invoke-UiAction { Show-DeviceResults } })
$btnReloadResults.Add_Click({ Invoke-UiAction { Show-DeviceResults -Force } })

$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.SelectedPath = $txtExportFolder.Text
    if ($dlg.ShowDialog() -eq 'OK') { $txtExportFolder.Text = $dlg.SelectedPath }
})

$btnExpDash.Add_Click({
    Invoke-UiAction {
        Assert-Loaded
        $path = Get-ExportPath 'Remediation_Dashboard'
        $script:State.DashboardRows | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        Write-ExportLog ('Exported dashboard to {0}' -f $path)
    }
})

$btnExpPackages.Add_Click({
    Invoke-UiAction {
        Assert-Loaded
        $path = Get-ExportPath 'Remediation_Packages'
        $script:State.PackageRows | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        Write-ExportLog ('Exported package list to {0}' -f $path)
    }
})

$btnExpAssign.Add_Click({ Invoke-UiAction { Export-AllAssignments } })

$btnExpResSel.Add_Click({
    Invoke-UiAction {
        Assert-Loaded
        $id = $script:State.SelectedId
        if (-not $id) { throw 'Select a package on the Packages tab first.' }
        $rows = Get-PackageRunStates -Id $id
        $path = Get-ExportPath ('Remediation_DeviceResults_{0}' -f (Get-SafeName (Get-PackageName $id)))
        $rows | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
        Write-ExportLog ('Exported {0} device results to {1}' -f $rows.Count, $path)
    }
})

$btnExpResAll.Add_Click({  Invoke-UiAction { Export-AllDeviceResults } })
$btnExpScripts.Add_Click({ Invoke-UiAction { Export-AllScripts } })
$btnExpJson.Add_Click({    Invoke-UiAction { Export-PackageJson } })

$btnOpenFolder.Add_Click({
    Invoke-UiAction {
        $folder = $txtExportFolder.Text.Trim()
        if (-not (Test-Path $folder)) { New-Item -Path $folder -ItemType Directory -Force | Out-Null }
        Invoke-Item $folder
    }
})

# Grids on hidden tabs cannot measure their cells, so size them when their tab is shown
$tabs.Add_SelectedIndexChanged({
    foreach ($g in $script:AllGrids) {
        if ($g.Visible -and $g.Tag -ne 'sized') { Resize-Grid $g }
    }
})

$Form.Add_Shown({
    try { $splitPackages.SplitterDistance = 380 } catch { }
    try { $splitResults.SplitterDistance  = 360 } catch { }
    $ctx = Get-MgContext
    if ($ctx) {
        $script:ConnLabel.Text = 'Connected: {0}' -f $ctx.Account
        Set-Status 'Existing Graph session found. Click Refresh.'
    }
    else {
        Set-Status 'Click Connect Graph to sign in.'
    }
})
#endregion

[void]$Form.ShowDialog()
$Form.Dispose()
