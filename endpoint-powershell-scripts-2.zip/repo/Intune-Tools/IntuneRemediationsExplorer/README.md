# IntuneRemediationsExplorer.ps1

Read-only WinForms tool for browsing and reporting on Intune Remediations (device health scripts). Nothing is changed in the tenant.

## Tabs
| Tab | Shows |
|---|---|
| Dashboard | Run summary counts per package plus tenant totals. Double-click opens the package |
| Packages | Package list, with full properties and run summary as JSON below |
| Assignments | Include/exclude, group names, filters, schedule, whether remediation runs |
| Detection / Remediation Script | Decoded script, run context, 32/64-bit, signature check, parameters. Copy or save as .ps1 |
| Device Results | Per-device states with a Show filter. Click a row for full output and errors |
| Export | Dashboard, packages, assignments and device results to CSV; all scripts to .ps1; one package to JSON |

Search filters the Dashboard, Packages and Device Results grids live.

## Requirements
- Windows PowerShell 5.1 or PowerShell 7 on Windows, STA mode
- `Microsoft.Graph.Authentication`
- Delegated scopes: `DeviceManagementConfiguration.Read.All`, `DeviceManagementManagedDevices.Read.All`, `Group.Read.All`
- Graph beta (deviceHealthScripts is beta only)

## Usage
```powershell
Unblock-File .\IntuneRemediationsExplorer.ps1
powershell.exe -STA -File .\IntuneRemediationsExplorer.ps1
```
Click **Connect Graph**, then **Refresh**.

## Notes
- Graph calls run on the UI thread, so the window is slow while a large tenant loads.
- Microsoft-published packages often return no script content. The tool says so.
- Device results are cached until **Reload from Graph** or **Refresh**.
- Exports contain tenant data (device names, users, script output). Keep them inside your environment.
