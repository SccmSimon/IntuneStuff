<#
.SYNOPSIS
    Reports which update ring groups each device belongs to in Entra ID, and flags
    devices that are in more than one.

.DESCRIPTION
    Reads a CSV of device names (column "Asset Name"), looks up each device in Entra ID
    through Microsoft Graph, and gets its group membership. Membership is checked both
    directly and through nested groups, because nested membership is the usual reason a
    device ends up in two rings without anyone noticing.

    Only groups whose name matches one of the -RingPatterns are reported. Output is one
    row per device, written to CSV.

.PARAMETER InputCsv
    CSV with an "Asset Name" column. FQDNs (PC123.corp.example.com) are shortened to the
    device name automatically.

.PARAMETER OutputCsv
    Where to write the results.

.PARAMETER RingPatterns
    Wildcard patterns for ring group names. Matching is case-insensitive.

.EXAMPLE
    .\Get-DeviceUpdateRingGroups.ps1 -InputCsv .\assets.csv

.EXAMPLE
    .\Get-DeviceUpdateRingGroups.ps1 -InputCsv .\assets.csv -RingPatterns '*UpdateRing*','*_Ring*','*Early_Adopters*'

.NOTES
    Author:     Simon Diaz
    Version:    1.0.0
    Changes:    1.0.0 - Initial version.
    Requires:   Microsoft.Graph.Authentication, Microsoft.Graph.Identity.DirectoryManagement
                Install-Module Microsoft.Graph -Scope CurrentUser
    Permissions: Device.Read.All, GroupMember.Read.All (delegated, read only)
    Runs on:    Windows PowerShell 5.1 or PowerShell 7
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$InputCsv,

    [string]$OutputCsv = ".\DeviceUpdateRingGroups_$(Get-Date -Format 'yyyyMMdd_HHmm').csv",

    [string[]]$RingPatterns = @('*UpdateRing*', '*_Ring*')
)

#region Connect
$scopes = @('Device.Read.All', 'GroupMember.Read.All')
$ctx = Get-MgContext
if (-not $ctx -or ($scopes | Where-Object { $_ -notin $ctx.Scopes })) {
    Connect-MgGraph -Scopes $scopes -NoWelcome
}
#endregion

#region Helpers
function Test-IsRingGroup {
    param([string]$Name)
    foreach ($p in $RingPatterns) {
        if ($Name -like $p) { return $true }   # -like is case-insensitive by default
    }
    return $false
}

function Get-GroupNames {
    # Returns the display names of groups from a memberOf / transitiveMemberOf result.
    # Graph returns mixed object types here (groups, directory roles, admin units), so
    # filter to groups only.
    param($Objects)
    $Objects |
        Where-Object { $_.AdditionalProperties['@odata.type'] -eq '#microsoft.graph.group' } |
        ForEach-Object { $_.AdditionalProperties['displayName'] }
}
#endregion

#region Load input
$names = Import-Csv -Path $InputCsv |
    ForEach-Object { ($_.'Asset Name' -split '\.')[0].Trim().ToUpper() } |
    Where-Object { $_ } |
    Sort-Object -Unique

Write-Host "Loaded $($names.Count) unique device names from $InputCsv"
#endregion

#region Main loop
$results = New-Object System.Collections.Generic.List[object]
$i = 0

foreach ($name in $names) {
    $i++
    Write-Progress -Activity 'Checking update ring groups' -Status "$name ($i of $($names.Count))" `
        -PercentComplete (($i / $names.Count) * 100)

    try {
        $safeName = $name -replace "'", "''"
        $devices  = @(Get-MgDevice -Filter "displayName eq '$safeName'" -All `
                        -Property Id, DeviceId, DisplayName, TrustType, AccountEnabled, ApproximateLastSignInDateTime)
    }
    catch {
        $results.Add([PSCustomObject]@{
            AssetName = $name; Status = "Error: $($_.Exception.Message)"
        })
        continue
    }

    if ($devices.Count -eq 0) {
        $results.Add([PSCustomObject]@{
            AssetName       = $name
            Status          = 'Not found in Entra'
            EntraObjects    = 0
            RingGroupCount  = 0
            MultipleRings   = ''
            RingGroups      = ''
            DirectRings     = ''
            NestedRings     = ''
            TrustType       = ''
            AccountEnabled  = ''
            LastSignIn      = ''
            EntraDeviceIds  = ''
        })
        continue
    }

    # A name can map to more than one Entra object (stale records after a rebuild or
    # rejoin). Collect groups across all of them, since any of them could be receiving policy.
    $allRings    = New-Object System.Collections.Generic.List[string]
    $directRings = New-Object System.Collections.Generic.List[string]

    foreach ($d in $devices) {
        try {
            $direct     = Get-GroupNames (Get-MgDeviceMemberOf -DeviceId $d.Id -All)
            $transitive = Get-GroupNames (Get-MgDeviceTransitiveMemberOf -DeviceId $d.Id -All)
        }
        catch {
            Write-Warning "$name ($($d.Id)): $($_.Exception.Message)"
            continue
        }
        $transitive | Where-Object { Test-IsRingGroup $_ } | ForEach-Object { $allRings.Add($_) }
        $direct     | Where-Object { Test-IsRingGroup $_ } | ForEach-Object { $directRings.Add($_) }
    }

    $rings  = @($allRings    | Sort-Object -Unique)
    $dRings = @($directRings | Sort-Object -Unique)
    $nRings = @($rings | Where-Object { $_ -notin $dRings })   # reached only through a nested group

    # Report the most recently active object for the device details
    $primary = $devices | Sort-Object ApproximateLastSignInDateTime -Descending | Select-Object -First 1

    $status = 'OK'
    if ($devices.Count -gt 1) { $status = 'Duplicate Entra objects' }

    $results.Add([PSCustomObject]@{
        AssetName       = $name
        Status          = $status
        EntraObjects    = $devices.Count
        RingGroupCount  = $rings.Count
        MultipleRings   = $(if ($rings.Count -gt 1) { 'Yes' } else { 'No' })
        RingGroups      = ($rings  -join '; ')
        DirectRings     = ($dRings -join '; ')
        NestedRings     = ($nRings -join '; ')
        TrustType       = $primary.TrustType
        AccountEnabled  = $primary.AccountEnabled
        LastSignIn      = $primary.ApproximateLastSignInDateTime
        EntraDeviceIds  = (($devices | ForEach-Object { $_.DeviceId }) -join '; ')
    })
}
Write-Progress -Activity 'Checking update ring groups' -Completed
#endregion

#region Output
$results | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8

$multi    = @($results | Where-Object { $_.MultipleRings -eq 'Yes' })
$none     = @($results | Where-Object { $_.Status -notlike 'Not found*' -and $_.RingGroupCount -eq 0 })
$missing  = @($results | Where-Object { $_.Status -like 'Not found*' })
$dupes    = @($results | Where-Object { $_.Status -eq 'Duplicate Entra objects' })

Write-Host ''
Write-Host "Devices checked:              $($results.Count)"
Write-Host "In more than one ring group:  $($multi.Count)" -ForegroundColor $(if ($multi.Count) { 'Yellow' } else { 'Green' })
Write-Host "In no ring group:             $($none.Count)"
Write-Host "Not found in Entra:           $($missing.Count)"
Write-Host "Duplicate Entra objects:      $($dupes.Count)"
Write-Host "Results written to:           $OutputCsv"
#endregion
