# Test-IntuneDevices.ps1

Checks a list of device names against Intune and exports one CSV row per match, showing whether each device is enrolled and when it last checked in.

## How it works
- Reads names from a `.txt` (one per line) or a `.csv` (`-ColumnName`, default `DeviceName`). Blank lines and duplicates are removed.
- Downloads managed devices once, then matches locally with a case-insensitive hashtable. Much faster than one Graph call per name.
- `-NamePrefix` filters server-side with `startswith(deviceName,...)`, one call per prefix.
- Every Intune record for a name gets its own row. `RecordCount` greater than 1 points to stale duplicate records.

## Output columns
`InputName, InIntune, RecordCount, IntuneDeviceName, OperatingSystem, OSVersion, PrimaryUser, ComplianceState, LastIntuneContact, DaysSinceContact, Enrolled, SerialNumber, ManagementAgent, IntuneDeviceId, EntraDeviceId`

`LastIntuneContact` is `lastSyncDateTime`. `DaysSinceContact` is worked out against UTC so it is not an hour out during BST.

## Usage
```powershell
.\Test-IntuneDevices.ps1 -InputPath .\devices.txt
.\Test-IntuneDevices.ps1 -InputPath .\devices.csv -ColumnName ComputerName -NamePrefix 'LT','DT'
```

## Permissions
- Graph scope: `DeviceManagementManagedDevices.Read.All`
- An Intune role as well (for example Intune Read Only Operator, or Intune Administrator). Without it Graph accepts the token but Intune returns **401** from `proxy.*.manage.microsoft.com`. That is a role problem, not a script problem.

## Notes
- With `-NamePrefix` set, any input name outside those prefixes always shows `InIntune = False`, because it was never downloaded.
- Matches on device name only. To match on serial number, build the lookup on `$device.SerialNumber` instead.
