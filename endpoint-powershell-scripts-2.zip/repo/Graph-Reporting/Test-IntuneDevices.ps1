<#
.SYNOPSIS
    Checks a list of device names against Intune and exports the results to CSV.

.DESCRIPTION
    Reads device names from a .txt file (one name per line) or a .csv file
    (with a column holding the names). Pulls Intune managed devices once,
    then matches each input name locally. Much faster than one Graph call per
    device on large lists.

    If -NamePrefix is set, Graph filters server-side so only devices whose
    names start with those prefixes are downloaded.

.PARAMETER InputPath
    Path to a .txt or .csv file containing device names.

.PARAMETER OutputPath
    Path for the results CSV. Defaults to a timestamped file in the current folder.

.PARAMETER ColumnName
    Column holding the device names when InputPath is a CSV. Default: DeviceName.

.PARAMETER NamePrefix
    Optional. One or more device name prefixes. Only devices starting with
    these are downloaded. Leave empty to download all managed devices.

.EXAMPLE
    .\Test-IntuneDevices.ps1 -InputPath .\devices.txt

.EXAMPLE
    .\Test-IntuneDevices.ps1 -InputPath .\devices.csv -ColumnName ComputerName -OutputPath C:\Temp\IntuneCheck.csv

.EXAMPLE
    .\Test-IntuneDevices.ps1 -InputPath .\devices.txt -NamePrefix 'LT','DT'

.NOTES
    Author : Simon Diaz
    Scope  : DeviceManagementManagedDevices.Read.All (plus an Intune role, see README)
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateScript({ Test-Path $_ -PathType Leaf })]
    [string]$InputPath,

    [string]$OutputPath = ".\IntuneDeviceCheck_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv",

    [string]$ColumnName = 'DeviceName',

    [string[]]$NamePrefix = @()
)

#region Module and connection
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.DeviceManagement)) {
    Write-Host "Installing Microsoft.Graph.DeviceManagement module for current user..." -ForegroundColor Yellow
    Install-Module Microsoft.Graph.DeviceManagement -Scope CurrentUser -Force
}
Import-Module Microsoft.Graph.DeviceManagement

# Only connect if there is no existing session with the scope we need
$context = Get-MgContext
if (-not $context -or $context.Scopes -notcontains 'DeviceManagementManagedDevices.Read.All') {
    Connect-MgGraph -Scopes 'DeviceManagementManagedDevices.Read.All' -NoWelcome
}
#endregion

#region Read input list
$extension = [System.IO.Path]::GetExtension($InputPath).ToLower()

if ($extension -eq '.csv') {
    $csv = Import-Csv -Path $InputPath
    if ($csv.Count -gt 0 -and $ColumnName -notin $csv[0].PSObject.Properties.Name) {
        throw "Column '$ColumnName' not found in $InputPath. Use -ColumnName to set the right one."
    }
    $deviceNames = $csv.$ColumnName
}
else {
    $deviceNames = Get-Content -Path $InputPath
}

# Trim whitespace, drop blank lines and duplicates
$deviceNames = $deviceNames |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ } |
    Sort-Object -Unique

Write-Host "Loaded $($deviceNames.Count) unique device names from $InputPath" -ForegroundColor Cyan
#endregion

#region Pull Intune devices once
$properties = @(
    'id', 'deviceName', 'operatingSystem', 'osVersion', 'userPrincipalName',
    'lastSyncDateTime', 'complianceState', 'serialNumber', 'managementAgent',
    'azureADDeviceId', 'enrolledDateTime'
)

if ($NamePrefix.Count -gt 0) {
    # One filtered call per prefix. Graph does the filtering server-side, so only
    # matching devices are downloaded. Combining startswith() with "or" is not
    # reliably supported on the managedDevices endpoint.
    $intuneDevices = foreach ($prefix in $NamePrefix) {
        Write-Host "Retrieving Intune devices starting with '$prefix'..." -ForegroundColor Cyan
        Get-MgDeviceManagementManagedDevice -All -Property $properties `
            -Filter "startswith(deviceName,'$prefix')"
    }
}
else {
    Write-Host "Retrieving all Intune managed devices..." -ForegroundColor Cyan
    $intuneDevices = Get-MgDeviceManagementManagedDevice -All -Property $properties
}
$intuneDevices = @($intuneDevices)
Write-Host "Retrieved $($intuneDevices.Count) Intune devices" -ForegroundColor Cyan

# Build a lookup table keyed on device name.
# PowerShell hashtables are case-insensitive by default, so "PC01" matches "pc01".
# Each value is a list, because Intune can hold more than one record with the same name.
$lookup = @{}
foreach ($device in $intuneDevices) {
    if (-not $lookup.ContainsKey($device.DeviceName)) {
        $lookup[$device.DeviceName] = [System.Collections.Generic.List[object]]::new()
    }
    $lookup[$device.DeviceName].Add($device)
}
#endregion

#region Match and build results
$nowUtc = (Get-Date).ToUniversalTime()

$results = foreach ($name in $deviceNames) {
    if ($lookup.ContainsKey($name)) {
        foreach ($match in $lookup[$name]) {
            # Graph returns lastSyncDateTime in UTC, so compare against UTC now
            $daysSince = $null
            if ($match.LastSyncDateTime) {
                $daysSince = [int]($nowUtc - $match.LastSyncDateTime).TotalDays
            }

            [PSCustomObject]@{
                InputName         = $name
                InIntune          = $true
                RecordCount       = $lookup[$name].Count
                IntuneDeviceName  = $match.DeviceName
                OperatingSystem   = $match.OperatingSystem
                OSVersion         = $match.OsVersion
                PrimaryUser       = $match.UserPrincipalName
                ComplianceState   = $match.ComplianceState
                LastIntuneContact = $match.LastSyncDateTime
                DaysSinceContact  = $daysSince
                Enrolled          = $match.EnrolledDateTime
                SerialNumber      = $match.SerialNumber
                ManagementAgent   = $match.ManagementAgent
                IntuneDeviceId    = $match.Id
                EntraDeviceId     = $match.AzureAdDeviceId
            }
        }
    }
    else {
        # Same columns as the found block, so Export-Csv keeps every header
        [PSCustomObject]@{
            InputName         = $name
            InIntune          = $false
            RecordCount       = 0
            IntuneDeviceName  = $null
            OperatingSystem   = $null
            OSVersion         = $null
            PrimaryUser       = $null
            ComplianceState   = $null
            LastIntuneContact = $null
            DaysSinceContact  = $null
            Enrolled          = $null
            SerialNumber      = $null
            ManagementAgent   = $null
            IntuneDeviceId    = $null
            EntraDeviceId     = $null
        }
    }
}
#endregion

#region Export and summary
$results | Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8

$found      = @($results | Where-Object InIntune | Select-Object -ExpandProperty InputName -Unique).Count
$notFound   = @($results | Where-Object { -not $_.InIntune }).Count
$duplicates = @($results | Where-Object { $_.RecordCount -gt 1 } | Select-Object -ExpandProperty InputName -Unique).Count

Write-Host ""
Write-Host "Found in Intune:       $found"      -ForegroundColor Green
Write-Host "Not found in Intune:   $notFound"   -ForegroundColor Red
Write-Host "Names with duplicates: $duplicates" -ForegroundColor Yellow
Write-Host "Results saved to:      $((Resolve-Path $OutputPath).Path)"
#endregion
