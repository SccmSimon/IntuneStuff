# Get-DeviceUpdateRingGroups.ps1

Finds which Windows Update ring groups each device is in (Entra ID, via Microsoft Graph) and flags devices in more than one ring, including through nested groups.

## Input
A CSV with an `Asset Name` column. FQDNs are trimmed to the host name. See `sample-assets.csv`.

## Output CSV columns
| Column | Meaning |
|---|---|
| Status | OK, Not found in Entra, Duplicate Entra objects, or the error |
| EntraObjects | Number of Entra device objects with that name |
| RingGroupCount / MultipleRings | How many ring groups, and whether more than one |
| RingGroups | All matching groups (direct and nested) |
| DirectRings / NestedRings | Split so you know whether to fix the device or a parent group |
| TrustType, AccountEnabled, LastSignIn | From the most recently active object |
| EntraDeviceIds | All device IDs for that name |

## Usage
```powershell
Install-Module Microsoft.Graph -Scope CurrentUser
.\Get-DeviceUpdateRingGroups.ps1 -InputCsv .\assets.csv -RingPatterns '*UpdateRing*','*_Ring*'
```

## Permissions
Delegated, read only: `Device.Read.All`, `GroupMember.Read.All`.

## Notes
- Stale duplicate device objects are all checked, because a stale record can still hold a ring membership.
- Change `-RingPatterns` to match your ring naming convention.
- Two or three Graph calls per device. About 1,000 devices takes a few minutes.
