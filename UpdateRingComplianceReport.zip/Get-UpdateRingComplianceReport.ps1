<#
.SYNOPSIS
    Builds an Excel report showing whether Windows devices installed each monthly cumulative update inside
    their Intune update ring's window (after the deferral ends, before the deadline plus grace period).

.DESCRIPTION
    Works in any Intune tenant. Nothing in the script is specific to one organisation.

    It reads, through Microsoft Graph (read only):
      - Every "Update rings for Windows 10 and later" policy, its settings and its include and exclude groups.
      - Windows managed devices (name, primary user, model, OS build, last check-in, co-management workload).
      - The detection output of the Intune Remediations package that runs Detect-WUInstallHistory.ps1.
        That script runs on each device and reports when each monthly update was downloaded, installed,
        how many attempts failed and the last error code.
      - Windows Update error descriptions and mitigations from Microsoft Learn (cached for 30 days).

    For each device, ring and month it works out:
      Release date   = Patch Tuesday (second Tuesday) of the update month.
      Deferral ends  = release date + quality update deferral (days).
      Deadline       = deferral end + quality update deadline + grace period (days).
      Compliance     = Green: installed between deferral end and deadline (inclusive, by date).
                       Red:   installed early or late, failed and not installed past the deadline, Windows Update
                              managed by ConfigMgr, device in more than one ring, or broken WMI.
                       Grey:  not due yet, no deadline on the ring, or no data from the device yet.

    Output workbook sheets:
      Summary          One row per ring for the latest month, plus totals and notes.
      <ring name>      Ring settings, then one row per device per month, colour coded.
      No update ring   Live devices that no ring targets.
      Multiple rings   Devices targeted by more than one ring.
      Errors           Error codes reported by devices, with Microsoft's text and mitigation.
      Column guide     What each ring sheet column means, and the matching WUfB reports field.

.PARAMETER RemediationName
    Text to match against the Remediations package display name. Every package whose name contains this text
    is read, and the newest result per device is used. Default: WUInstallHistory

.PARAMETER DeviceListPath
    Optional. A .csv or .txt list of device names to limit the report to. For CSV, the column used is the first
    one found of: DeviceName, Device name, Device, Asset Name, ComputerName, Name, else the first column.
    Leave out to report on every Windows device in Intune.

.PARAMETER MonthsToCheck
    How many monthly updates to check, newest first. Default 3. The newest is used for the percentages.

.PARAMETER LiveDays
    Only devices that checked in to Intune within this many days are counted. Default 30.

.PARAMETER RingNameFilter
    Optional wildcard to limit which update rings are reported, for example 'MMS_*'. Devices are still checked
    against every ring for the "more than one ring" test.

.PARAMETER OutputPath
    Path of the .xlsx to create. Default: UpdateRingCompliance_<yyyyMMdd_HHmm>.xlsx in the current folder.

.PARAMETER TenantId
    Optional. Tenant ID or domain to sign in to. Required for app-only sign-in.

.PARAMETER ClientId
    Optional. App registration (client) ID. With -CertificateThumbprint, signs in app-only for unattended runs.
    Without a certificate, uses the app for delegated sign-in.

.PARAMETER CertificateThumbprint
    Optional. Certificate thumbprint for app-only sign-in (certificate in CurrentUser\My or LocalMachine\My).

.PARAMETER Scopes
    Delegated Graph permissions requested at sign-in. Change only if your tenant needs different scopes.

.PARAMETER SkipErrorLookup
    Do not download error text from Microsoft Learn. Error codes are still shown, without descriptions.

.PARAMETER ErrorCachePath
    Where the Microsoft Learn error text is cached. Default: %LOCALAPPDATA%\UpdateRingCompliance\WUErrorCatalog.json

.EXAMPLE
    .\Get-UpdateRingComplianceReport.ps1
    Signs in interactively and reports on every Windows device.

.EXAMPLE
    .\Get-UpdateRingComplianceReport.ps1 -DeviceListPath .\CyberEssentialsDevices.csv -MonthsToCheck 3 -OutputPath C:\Reports\CE-Rings.xlsx

.EXAMPLE
    .\Get-UpdateRingComplianceReport.ps1 -TenantId contoso.onmicrosoft.com -ClientId <appId> -CertificateThumbprint <thumbprint>
    Unattended run, for a scheduled task.

.NOTES
    Version : 2.0
    Author  : Simon Diaz
    Requires: Windows PowerShell 5.1 or PowerShell 7.
              Modules Microsoft.Graph.Authentication and ImportExcel (Install-Module <name> -Scope CurrentUser).
              Delegated permissions (or the same as application permissions for app-only):
                DeviceManagementConfiguration.Read.All, DeviceManagementManagedDevices.Read.All,
                Group.Read.All, Device.Read.All
    Device  : Detect-WUInstallHistory.ps1 deployed as an Intune Remediations detection script (no remediation
              script), running as SYSTEM, 64-bit, daily.
    Limits  : Assignment filters on rings are listed but not evaluated. Rings assigned to user groups are
              matched to devices by the device's primary user.

    2.0     : Tenant agnostic rewrite. All names, paths and tenant details are parameters. Reports on all Windows
              devices when no device list is given. Fixed the Column guide sheet (previously wrote zeros).
              Microsoft Learn error text cached locally. Graph paging and throttling retries.
    1.5     : Previous version, built for a single tenant.
#>

[CmdletBinding()]
param(
    [string]   $RemediationName = 'WUInstallHistory',
    [string]   $DeviceListPath,
    [ValidateRange(1, 6)]
    [int]      $MonthsToCheck = 3,
    [ValidateRange(1, 365)]
    [int]      $LiveDays = 30,
    [string]   $RingNameFilter = '*',
    [string]   $OutputPath,
    [string]   $TenantId,
    [string]   $ClientId,
    [string]   $CertificateThumbprint,
    [string[]] $Scopes = @(
        'DeviceManagementConfiguration.Read.All',
        'DeviceManagementManagedDevices.Read.All',
        'Group.Read.All',
        'Device.Read.All'
    ),
    [switch]   $SkipErrorLookup,
    [string]   $ErrorCachePath
)

#region Settings
$ScriptName          = 'Get-UpdateRingComplianceReport.ps1'
$ScriptVersion       = '2.0'
$LatestDeviceScript  = '1.4'     # current Detect-WUInstallHistory.ps1 version
$MinErrorCodeVersion = '1.2'     # device script versions below this cannot report error codes
$GraphBase           = 'https://graph.microsoft.com/beta'
$ErrorRefUrl         = 'https://learn.microsoft.com/windows/deployment/update/windows-update-error-reference'
$CommonErrorsUrl     = 'https://learn.microsoft.com/troubleshoot/windows-client/installing-updates-features-roles/common-windows-update-errors'
$SchemaUrl           = 'https://learn.microsoft.com/windows/deployment/update/wufb-reports-schema-ucclientupdatestatus'
$ErrorCacheDays      = 30

$ColGreenRgb = 198, 239, 206   # same fills as the Excel "Good", "Bad" and neutral grey styles
$ColRedRgb   = 255, 199, 206
$ColGreyRgb  = 237, 237, 237

$RingColumns = @(
    'Device', 'Primary user', 'Model', 'OS build (device)', 'Updates managed by', 'Last check-in',
    'Update month', 'KB', 'Release date', 'Deferral ends', 'Deadline (incl. grace)', 'Offered (download started)',
    'Installed', 'Days after release', 'Failed attempts', 'Error code', 'Error (MS Learn)',
    'What it means (MS Learn)', 'Mitigation (MS Learn)', 'MS Learn link', 'Compliance', 'Reason',
    'Device data date', 'Last WU scan', 'Device script', 'Entra device ID'
)
$RingColumnWidths = @(18, 30, 34, 18, 12, 13, 9, 26, 12, 12, 13, 18, 17, 10, 9, 12, 32, 45, 45, 40, 11, 70, 17, 17, 9, 38)
#endregion

#region Helpers
function Write-Step {
    param([string]$Message)
    Write-Host ("[{0:HH:mm:ss}] {1}" -f (Get-Date), $Message)
}

function Format-Day {
    param($Date)
    if ($Date) { ([datetime]$Date).ToString('yyyy-MM-dd') } else { '' }
}

function Format-Stamp {
    param($Date)
    if ($Date) { ([datetime]$Date).ToString('yyyy-MM-dd HH:mm') } else { '' }
}

function Get-ShortName {
    # Upper case short name: "wl123.contoso.com" -> "WL123"
    param([string]$Name)
    if (-not $Name) { return '' }
    ($Name.Trim() -split '\.')[0].ToUpperInvariant()
}

function Compare-Version {
    # True when $Version is lower than $Minimum. Unknown versions count as lower.
    param([string]$Version, [string]$Minimum)
    $v = $null; $m = $null
    if (-not [version]::TryParse($Version, [ref]$v)) { return $true }
    [void][version]::TryParse($Minimum, [ref]$m)
    return ($v -lt $m)
}

function Get-PatchTuesday {
    param([int]$Year, [int]$Month)
    $d = New-Object DateTime ($Year, $Month, 1)
    while ($d.DayOfWeek -ne [DayOfWeek]::Tuesday) { $d = $d.AddDays(1) }
    $d.AddDays(7)
}

function Get-SafeSheetName {
    # Excel sheet names: max 31 characters, no []:*?/\ and unique in the workbook.
    param([string]$Name, [System.Collections.Generic.HashSet[string]]$Used)
    $base = ($Name -replace '[\[\]:\*\?/\\]', '-').Trim()
    if (-not $base) { $base = 'Ring' }
    if ($base.Length -gt 31) { $base = $base.Substring(0, 31) }
    $candidate = $base; $i = 2
    while (-not $Used.Add($candidate.ToLowerInvariant())) {
        $suffix = " ($i)"
        $candidate = $base.Substring(0, [Math]::Min($base.Length, 31 - $suffix.Length)) + $suffix
        $i++
    }
    $candidate
}

function Get-SafeTableName {
    param([string]$Name, [System.Collections.Generic.HashSet[string]]$Used)
    $base = 'T' + ($Name -replace '[^A-Za-z0-9]', '')
    if ($base.Length -gt 200) { $base = $base.Substring(0, 200) }
    $candidate = $base; $i = 2
    while (-not $Used.Add($candidate.ToLowerInvariant())) { $candidate = "$base$i"; $i++ }
    $candidate
}

function ConvertFrom-HtmlText {
    param([string]$Html)
    if (-not $Html) { return '' }
    $t = [regex]::Replace($Html, '<br\s*/?>', ' ')
    $t = [regex]::Replace($t, '<[^>]+>', '')
    $t = [System.Net.WebUtility]::HtmlDecode($t)
    ([regex]::Replace($t, '\s+', ' ')).Trim()
}
#endregion

#region Graph
function Connect-ReportGraph {
    $ctx = Get-MgContext -ErrorAction SilentlyContinue
    if ($ctx -and -not $CertificateThumbprint) {
        $missing = @($Scopes | Where-Object { $ctx.Scopes -notcontains $_ })
        if ($ctx.AuthType -eq 'AppOnly' -or $missing.Count -eq 0) {
            Write-Step "Using existing Graph connection ($($ctx.Account))."
            return
        }
    }
    $p = @{ NoWelcome = $true; ErrorAction = 'Stop' }
    if ($TenantId) { $p.TenantId = $TenantId }
    if ($ClientId) { $p.ClientId = $ClientId }
    if ($CertificateThumbprint) {
        if (-not ($TenantId -and $ClientId)) { throw 'App-only sign-in needs -TenantId, -ClientId and -CertificateThumbprint.' }
        $p.CertificateThumbprint = $CertificateThumbprint
    }
    else {
        $p.Scopes = $Scopes
    }
    Write-Step 'Connecting to Microsoft Graph.'
    Connect-MgGraph @p | Out-Null
}

function Invoke-Graph {
    # GET with retries for throttling (429) and transient errors (500, 502, 503, 504).
    param([string]$Uri, [hashtable]$Headers)
    $attempt = 0
    while ($true) {
        $attempt++
        try {
            $p = @{ Method = 'GET'; Uri = $Uri; OutputType = 'PSObject'; ErrorAction = 'Stop' }
            if ($Headers) { $p.Headers = $Headers }
            return Invoke-MgGraphRequest @p
        }
        catch {
            $status = 0
            try { $status = [int]$_.Exception.Response.StatusCode } catch { }
            if ($status -eq 0 -and $_.Exception.Message -match '\b(429|500|502|503|504)\b') { $status = [int]$Matches[1] }
            if ($attempt -ge 6 -or $status -notin 429, 500, 502, 503, 504) { throw }
            $wait = [Math]::Min(60, [Math]::Pow(2, $attempt))
            try {
                $ra = $_.Exception.Response.Headers.RetryAfter.Delta
                if ($ra) { $wait = [Math]::Ceiling($ra.TotalSeconds) }
            } catch { }
            Write-Verbose "Graph returned $status, retrying in $wait s: $Uri"
            Start-Sleep -Seconds $wait
        }
    }
}

function Invoke-GraphAll {
    # Follows @odata.nextLink and returns every item.
    param([string]$Uri, [hashtable]$Headers)
    $items = New-Object System.Collections.Generic.List[object]
    $next = $Uri
    while ($next) {
        $resp = Invoke-Graph -Uri $next -Headers $Headers
        if ($resp.PSObject.Properties.Name -contains 'value') {
            foreach ($v in @($resp.value)) { if ($null -ne $v) { $items.Add($v) } }
        }
        $next = $null
        if ($resp.PSObject.Properties.Name -contains '@odata.nextLink') { $next = $resp.'@odata.nextLink' }
    }
    , $items
}

$script:GroupCache = @{}
function Get-GroupInfo {
    # Display name, Entra device IDs and user IDs of a group (nested members included). Cached.
    param([string]$GroupId)
    if ($script:GroupCache.ContainsKey($GroupId)) { return $script:GroupCache[$GroupId] }
    $info = [pscustomobject]@{
        Name    = $GroupId
        Devices = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
        Users   = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
        Found   = $true
    }
    $h = @{ ConsistencyLevel = 'eventual' }
    try {
        $g = Invoke-Graph -Uri "$GraphBase/groups/$GroupId`?`$select=id,displayName"
        $info.Name = $g.displayName
        foreach ($d in (Invoke-GraphAll -Uri "$GraphBase/groups/$GroupId/transitiveMembers/microsoft.graph.device?`$select=id,deviceId&`$top=999&`$count=true" -Headers $h)) {
            if ($d.deviceId) { [void]$info.Devices.Add([string]$d.deviceId) }
        }
        foreach ($u in (Invoke-GraphAll -Uri "$GraphBase/groups/$GroupId/transitiveMembers/microsoft.graph.user?`$select=id&`$top=999&`$count=true" -Headers $h)) {
            if ($u.id) { [void]$info.Users.Add([string]$u.id) }
        }
    }
    catch {
        $info.Name  = "$GroupId (not found)"
        $info.Found = $false
        Write-Warning "Could not read group $GroupId : $($_.Exception.Message)"
    }
    $script:GroupCache[$GroupId] = $info
    $info
}
#endregion

#region Microsoft Learn error text
function Get-WUErrorCatalog {
    # Returns a hashtable: '0x8024xxxx' -> object with Message, Description, Mitigation, Link.
    $catalog = @{}
    if ($SkipErrorLookup) { return $catalog }

    $cache = $ErrorCachePath
    if (-not $cache) {
        $root = $env:LOCALAPPDATA
        if (-not $root) { $root = [IO.Path]::GetTempPath() }
        $cache = Join-Path $root 'UpdateRingCompliance\WUErrorCatalog.json'
    }
    if ((Test-Path $cache) -and ((Get-Item $cache).LastWriteTime -gt (Get-Date).AddDays(-$ErrorCacheDays))) {
        try {
            foreach ($e in (Get-Content $cache -Raw | ConvertFrom-Json)) { $catalog[$e.Code] = $e }
            Write-Step "Loaded $($catalog.Count) error descriptions from cache."
            return $catalog
        } catch { $catalog = @{} }
    }

    Write-Step 'Downloading Windows Update error descriptions from Microsoft Learn.'
    $wr = @{ UseBasicParsing = $true; TimeoutSec = 60; ErrorAction = 'Stop' }

    # Page 1: full error reference. Tables of Error code | Message | Description.
    try {
        $html = (Invoke-WebRequest -Uri $ErrorRefUrl @wr).Content
        foreach ($row in [regex]::Matches($html, '(?s)<tr[^>]*>(.*?)</tr>')) {
            $cells = @([regex]::Matches($row.Groups[1].Value, '(?s)<t[dh][^>]*>(.*?)</t[dh]>') | ForEach-Object { ConvertFrom-HtmlText $_.Groups[1].Value })
            if ($cells.Count -ge 3 -and $cells[0] -match '^0x([0-9A-Fa-f]{8})$') {
                $code = '0x' + $Matches[1].ToUpperInvariant()
                $catalog[$code] = [pscustomobject]@{ Code = $code; Message = $cells[1]; Description = $cells[2]; Mitigation = ''; Link = $ErrorRefUrl }
            }
        }
    }
    catch { Write-Warning "Could not read $ErrorRefUrl : $($_.Exception.Message)" }

    # Page 2: common errors. One heading per code (or several codes), then Message | Description | Mitigation.
    try {
        $html = (Invoke-WebRequest -Uri $CommonErrorsUrl @wr).Content
        foreach ($section in ($html -split '(?i)<h2')) {
            $end = $section.IndexOf('</h2>')
            if ($end -lt 0) { continue }
            $heading = ConvertFrom-HtmlText ('<h2' + $section.Substring(0, $end))
            $codes = @([regex]::Matches($heading, '0x([0-9A-Fa-f]{8})') | ForEach-Object { '0x' + $_.Groups[1].Value.ToUpperInvariant() })
            if ($codes.Count -eq 0) { continue }
            # First table row with data cells (<td>) after the heading
            $cells = @()
            foreach ($tr in [regex]::Matches($section, '(?s)<tr[^>]*>(.*?)</tr>')) {
                $cells = @([regex]::Matches($tr.Groups[1].Value, '(?s)<td[^>]*>(.*?)</td>') | ForEach-Object { ConvertFrom-HtmlText $_.Groups[1].Value })
                if ($cells.Count -ge 3) { break }
            }
            if ($cells.Count -lt 3) { continue }
            foreach ($code in $codes) {
                $catalog[$code] = [pscustomobject]@{ Code = $code; Message = $cells[0]; Description = $cells[1]; Mitigation = $cells[2]; Link = $CommonErrorsUrl }
            }
        }
    }
    catch { Write-Warning "Could not read $CommonErrorsUrl : $($_.Exception.Message)" }

    if ($catalog.Count -gt 0) {
        try {
            $dir = Split-Path $cache -Parent
            if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
            @($catalog.Values) | ConvertTo-Json -Depth 3 | Set-Content -Path $cache -Encoding UTF8
        } catch { Write-Verbose "Could not write error cache: $($_.Exception.Message)" }
    }
    Write-Step "Found $($catalog.Count) error descriptions."
    $catalog
}

function Get-ErrorText {
    param([string]$Code)
    if (-not $Code) { return $null }
    if ($script:ErrorCatalog.ContainsKey($Code)) {
        $e = $script:ErrorCatalog[$Code]
        $mit = $e.Mitigation
        if (-not $mit) { $mit = 'No mitigation listed on MS Learn for this code. See the link.' }
        return [pscustomobject]@{ Message = $e.Message; Description = $e.Description; Mitigation = $mit; Link = $e.Link }
    }
    [pscustomobject]@{
        Message     = 'Not listed'
        Description = 'This code is not in the Windows Update error reference. It may be a Windows servicing (CBS) or system error.'
        Mitigation  = 'Search MS Learn for the code.'
        Link        = $ErrorRefUrl
    }
}
#endregion

#region Device output parsing
function ConvertFrom-UtcToken {
    # "2026-10-21T12:04Z" (UTC) -> local DateTime
    param([string]$Text)
    if (-not $Text) { return $null }
    $d = [datetime]::MinValue
    $styles = [Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal
    if ([datetime]::TryParseExact($Text.Trim(), "yyyy-MM-dd'T'HH:mm'Z'", [Globalization.CultureInfo]::InvariantCulture, $styles, [ref]$d)) {
        return $d.ToLocalTime()
    }
    $null
}

function ConvertFrom-WUHistOutput {
    # Parses the one-line output of Detect-WUInstallHistory.ps1. Returns $null if the text is not from it.
    param([string]$Text)
    if (-not $Text -or $Text -notmatch 'WUHIST v([0-9.]+)') { return $null }
    $r = [pscustomobject]@{
        Version = $Matches[1]
        OS      = ''
        Scan    = $null
        Boot    = $null
        Wmi     = ''
        Error   = ''
        Months  = @{}
    }
    foreach ($part in ($Text -split '\s*\|\s*')) {
        $part = $part.Trim()
        if ($part -match '^OS=(.*)$')        { $r.OS = $Matches[1].Trim(); continue }
        if ($part -match '^Scan=(.*)$')      { $r.Scan = ConvertFrom-UtcToken $Matches[1]; continue }
        if ($part -match '^Boot=(.*)$')      { $r.Boot = ConvertFrom-UtcToken $Matches[1]; continue }
        if ($part -match '^WMI=(.*)$')       { $r.Wmi = $Matches[1].Trim(); continue }
        if ($part -match '^ERROR=(.*)$')     { $r.Error = $Matches[1].Trim(); continue }
        if ($part -match '^(\d{4}-\d{2})=([^,]+)(.*)$') {
            $month = $Matches[1]; $kb = $Matches[2].Trim(); $rest = $Matches[3]
            $m = [pscustomobject]@{ KB = $kb; Installed = $null; Download = $null; Failed = 0; FirstFail = $null; Error = ''; Pending = $false }
            foreach ($kv in ($rest -split ',')) {
                if ($kv -notmatch '^\s*(FD|I|D|F|E|P):(.*)$') { continue }
                $key = $Matches[1]; $val = $Matches[2].Trim()
                switch ($key) {
                    'I'  { $m.Installed = ConvertFrom-UtcToken $val }
                    'D'  { $m.Download  = ConvertFrom-UtcToken $val }
                    'F'  { $n = 0; if ([int]::TryParse($val, [ref]$n)) { $m.Failed = $n } }
                    'FD' { $m.FirstFail = ConvertFrom-UtcToken $val }
                    'E'  { if ($val -match '^0x[0-9A-Fa-f]{8}$') { $m.Error = '0x' + $val.Substring(2).ToUpperInvariant() } }
                    'P'  { $m.Pending = ($val -eq '1') }
                }
            }
            $r.Months[$month] = $m
        }
    }
    $r
}
#endregion

#region Compliance
function Get-MonthResult {
    # Works out the compliance colour and reason for one device, one ring and one month.
    param($Device, $Ring, $MonthInfo)

    $deferralEnd = $MonthInfo.Release.AddDays($Ring.QualityDeferral)
    $deadline = $null
    if ($null -ne $Ring.QualityDeadline) { $deadline = $deferralEnd.AddDays($Ring.QualityDeadline + $Ring.Grace) }

    $res = [ordered]@{
        DeferralEnd = $deferralEnd; Deadline = $deadline; KB = ''; Installed = $null; Download = $null
        DaysAfter = $null; Failed = $null; ErrorCode = ''; Colour = 'Grey'; Reason = ''; IsInstalled = $false; InWindow = $false
    }

    $data = $Device.Data
    if (-not $data) {
        if ($Device.RawOutput) { $res.Reason = 'Device output not recognised (not from Detect-WUInstallHistory.ps1)' }
        else { $res.Reason = 'No data from the device (remediation not run yet)' }
        return [pscustomobject]$res
    }

    $prefix = New-Object System.Collections.Generic.List[string]
    $forceRed = $false
    if ($Device.Rings.Count -gt 1) {
        $prefix.Add("In more than one update ring ($(($Device.Rings | ForEach-Object { $_.Name }) -join '; '))")
        $forceRed = $true
    }
    if ($Device.ManagedBy -eq 'ConfigMgr') {
        $prefix.Add('Windows Update is managed by ConfigMgr (co-management workload), so the ring does not apply')
        $forceRed = $true
    }
    if ($data.Error) { $prefix.Add("Device script error: $($data.Error)") }

    $m = $null
    if ($data.Months.ContainsKey($MonthInfo.Key)) { $m = $data.Months[$MonthInfo.Key] }
    if ($m) {
        $res.KB = $m.KB; $res.Download = $m.Download; $res.Failed = $m.Failed; $res.ErrorCode = $m.Error
    }
    $today = (Get-Date).Date
    $main = ''; $colour = 'Grey'

    if ($m -and $m.Installed) {
        $res.Installed   = $m.Installed
        $res.IsInstalled = $true
        $res.DaysAfter   = [Math]::Round(($m.Installed - $MonthInfo.Release).TotalDays, 1)
        $tries = ''
        if ($m.Failed -gt 0) { $tries = " ($($m.Failed) failed attempt(s) first)" }
        $day = $m.Installed.Date
        if ($day -lt $deferralEnd.Date) {
            $colour = 'Red'; $main = "Installed $(($deferralEnd.Date - $day).Days) day(s) before the deferral ended$tries"
        }
        elseif ($null -eq $deadline) {
            $colour = 'Green'; $res.InWindow = $true; $main = "Installed after the deferral ended (no deadline set on the ring)$tries"
        }
        elseif ($day -le $deadline.Date) {
            $colour = 'Green'; $res.InWindow = $true; $main = "Installed within the ring window$tries"
        }
        else {
            $colour = 'Red'; $main = "Installed $(($day - $deadline.Date).Days) day(s) after the deadline$tries"
        }
    }
    else {
        # A later monthly cumulative also contains this month's fixes.
        $cover = $null
        foreach ($k in $data.Months.Keys) {
            if ($k -le $MonthInfo.Key) { continue }
            $lm = $data.Months[$k]
            if ($lm.Installed -and (-not $cover -or $lm.Installed -lt $cover.Installed)) {
                $cover = [pscustomobject]@{ Month = $k; KB = $lm.KB; Installed = $lm.Installed }
            }
        }
        $notes = New-Object System.Collections.Generic.List[string]
        if ($data.Wmi) { $notes.Add("WMI repository broken on the device, which also stops Windows Update ($($data.Wmi))") }

        if ($cover) {
            if (-not $res.KB) { $res.KB = "(none, covered by $($cover.KB))" }
            $when = Format-Day $cover.Installed
            if ($null -eq $deadline -or $cover.Installed.Date -le $deadline.Date) {
                $colour = 'Green'; $res.InWindow = $true
                $notes.Add("Not installed. Covered by $($cover.KB) ($($cover.Month)) on $when, within this month's window")
            }
            else {
                $colour = 'Red'
                $notes.Add("Not installed. Covered later by $($cover.KB) ($($cover.Month)) on $when, after this month's deadline")
            }
        }
        else {
            if ($m -and $m.Failed -gt 0) {
                $t = "Failed $($m.Failed) time(s)"
                if ($m.FirstFail) { $t += ", first $(Format-Day $m.FirstFail)" }
                if ($m.Error) {
                    $et = Get-ErrorText $m.Error
                    $t += ", last error $($m.Error)"
                    if ($et -and $et.Message -and $et.Message -ne 'Not listed') { $t += " ($($et.Message))" }
                }
                $notes.Add($t)
            }
            if ($m -and $m.Pending) { $notes.Add('Started but not finished (usually waiting for a restart)') }
            if ($null -eq $deadline) {
                $colour = 'Grey'; $notes.Add('Not installed, no deadline set on the ring')
            }
            elseif ($today -gt $deadline.Date) {
                $colour = 'Red'; $notes.Add("Not installed, deadline $(Format-Day $deadline) has passed")
            }
            else {
                $colour = 'Grey'; $notes.Add("Not due yet, deadline $(Format-Day $deadline)")
            }
        }
        $main = $notes -join '. '
    }

    if ($forceRed) { $colour = 'Red'; $res.InWindow = $false }
    $all = @($prefix) + @($main) | Where-Object { $_ }
    $res.Colour = $colour
    $res.Reason = $all -join '. '
    [pscustomobject]$res
}
#endregion

#region Excel helpers
function Set-Cell {
    param($Ws, [int]$Row, [int]$Col, $Value, [switch]$Bold, [double]$Size = 0)
    $c = $Ws.Cells[$Row, $Col]
    $c.Value = $Value
    if ($Bold) { $c.Style.Font.Bold = $true }
    if ($Size -gt 0) { $c.Style.Font.Size = $Size }
}

function Add-ColourRules {
    param($Ws, [string]$Range, [string]$FirstCell)
    Add-ConditionalFormatting -Worksheet $Ws -Address $Range -RuleType Expression -ConditionValue ('{0}="Green"' -f $FirstCell) -BackgroundColor $ColGreen
    Add-ConditionalFormatting -Worksheet $Ws -Address $Range -RuleType Expression -ConditionValue ('{0}="Red"' -f $FirstCell) -BackgroundColor $ColRed
    Add-ConditionalFormatting -Worksheet $Ws -Address $Range -RuleType Expression -ConditionValue ('{0}="Grey"' -f $FirstCell) -BackgroundColor $ColGrey
}

function Get-ColumnLetter {
    param([int]$Index)
    $s = ''
    while ($Index -gt 0) { $m = ($Index - 1) % 26; $s = [char](65 + $m) + $s; $Index = [int](($Index - $m - 1) / 26) }
    $s
}
#endregion

# ===================================================================================================
# Main
# ===================================================================================================
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

foreach ($mod in 'Microsoft.Graph.Authentication', 'ImportExcel') {
    if (-not (Get-Module -ListAvailable -Name $mod)) {
        throw "Module $mod is not installed. Run: Install-Module $mod -Scope CurrentUser"
    }
    Import-Module $mod -ErrorAction Stop
}
Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
$ColGreen = [System.Drawing.Color]::FromArgb($ColGreenRgb[0], $ColGreenRgb[1], $ColGreenRgb[2])
$ColRed   = [System.Drawing.Color]::FromArgb($ColRedRgb[0], $ColRedRgb[1], $ColRedRgb[2])
$ColGrey  = [System.Drawing.Color]::FromArgb($ColGreyRgb[0], $ColGreyRgb[1], $ColGreyRgb[2])

if (-not $OutputPath) { $OutputPath = Join-Path (Get-Location) ("UpdateRingCompliance_{0:yyyyMMdd_HHmm}.xlsx" -f (Get-Date)) }
$OutputPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputPath)
if (Test-Path $OutputPath) { Remove-Item $OutputPath -Force }

Connect-ReportGraph
$started = Get-Date

# ---- Months to check: the newest released Patch Tuesday first ----
$months = New-Object System.Collections.Generic.List[object]
$cursor = (Get-Date).Date
$pt = Get-PatchTuesday $cursor.Year $cursor.Month
if ($pt -gt $cursor) { $cursor = $cursor.AddMonths(-1) }
for ($i = 0; $i -lt $MonthsToCheck; $i++) {
    $d = $cursor.AddMonths(-$i)
    $months.Add([pscustomobject]@{ Key = $d.ToString('yyyy-MM'); Release = (Get-PatchTuesday $d.Year $d.Month) })
}
$latest = $months[0]
Write-Step ("Checking {0}." -f (($months | ForEach-Object { "$($_.Key) (released $(Format-Day $_.Release))" }) -join ', '))

# ---- Optional device list ----
$listed = $null
if ($DeviceListPath) {
    if (-not (Test-Path $DeviceListPath)) { throw "Device list not found: $DeviceListPath" }
    $listed = New-Object System.Collections.Generic.List[string]
    if ($DeviceListPath -match '\.csv$') {
        $csv = @(Import-Csv -Path $DeviceListPath)
        if ($csv.Count -gt 0) {
            $cols = @($csv[0].PSObject.Properties.Name)
            $col = $null
            foreach ($want in 'DeviceName', 'Device name', 'Device', 'Asset Name', 'ComputerName', 'Name') {
                $col = $cols | Where-Object { $_ -eq $want } | Select-Object -First 1
                if ($col) { break }
            }
            if (-not $col) { $col = $cols[0] }
            foreach ($row in $csv) { $n = Get-ShortName ([string]$row.$col); if ($n -and -not $listed.Contains($n)) { $listed.Add($n) } }
        }
    }
    else {
        foreach ($line in (Get-Content -Path $DeviceListPath)) { $n = Get-ShortName $line; if ($n -and -not $listed.Contains($n)) { $listed.Add($n) } }
    }
    Write-Step "Device list: $($listed.Count) devices from $(Split-Path $DeviceListPath -Leaf)."
}

# ---- Intune Windows devices ----
Write-Step 'Reading Windows devices from Intune.'
$select = 'id,deviceName,azureADDeviceId,userPrincipalName,userId,model,osVersion,lastSyncDateTime,managementAgent,configurationManagerClientEnabledFeatures'
$allDevices = Invoke-GraphAll -Uri ("$GraphBase/deviceManagement/managedDevices?`$filter=operatingSystem eq 'Windows'&`$select=$select")
Write-Step "Found $($allDevices.Count) Windows devices."

# Newest record per short name (duplicates happen after re-enrolment).
$byName = @{}
foreach ($d in $allDevices) {
    $n = Get-ShortName $d.deviceName
    if (-not $n) { continue }
    $sync = $null
    if ($d.lastSyncDateTime) { $sync = ([datetime]$d.lastSyncDateTime).ToLocalTime() }
    $managedBy = 'Intune'
    if ([string]$d.managementAgent -match 'configurationManager') {
        $wufb = $false
        if ($d.configurationManagerClientEnabledFeatures) { $wufb = [bool]$d.configurationManagerClientEnabledFeatures.windowsUpdateForBusiness }
        if (-not $wufb) { $managedBy = 'ConfigMgr' }
    }
    $rec = [pscustomobject]@{
        Name = $n; DeviceName = $d.deviceName; Id = $d.id; EntraId = [string]$d.azureADDeviceId
        User = $d.userPrincipalName; UserId = [string]$d.userId; Model = $d.model; OSVersion = $d.osVersion
        LastSync = $sync; ManagedBy = $managedBy
        Rings = New-Object System.Collections.Generic.List[object]
        Data = $null; RawOutput = ''; DataDate = $null
    }
    if (-not $byName.ContainsKey($n) -or ($sync -and (-not $byName[$n].LastSync -or $sync -gt $byName[$n].LastSync))) { $byName[$n] = $rec }
}

$notFound = New-Object System.Collections.Generic.List[string]
if ($listed) {
    $scope = New-Object System.Collections.Generic.List[object]
    foreach ($n in $listed) { if ($byName.ContainsKey($n)) { $scope.Add($byName[$n]) } else { $notFound.Add($n) } }
}
else {
    $scope = New-Object System.Collections.Generic.List[object]
    foreach ($v in $byName.Values) { $scope.Add($v) }
}
$liveSince = (Get-Date).AddDays(-$LiveDays)
$live = @($scope | Where-Object { $_.LastSync -and $_.LastSync -ge $liveSince } | Sort-Object Name)
Write-Step "Live devices (checked in within $LiveDays days): $($live.Count) of $($scope.Count)."

# ---- Update rings ----
Write-Step 'Reading update rings.'
try {
    $ringsRaw = Invoke-GraphAll -Uri ("$GraphBase/deviceManagement/deviceConfigurations?`$filter=isof('microsoft.graph.windowsUpdateForBusinessConfiguration')")
}
catch {
    Write-Verbose 'isof filter not accepted, reading all configuration profiles instead.'
    $allProfiles = Invoke-GraphAll -Uri "$GraphBase/deviceManagement/deviceConfigurations"
    $ringsRaw = @($allProfiles | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.windowsUpdateForBusinessConfiguration' })
}

$filterNames = @{}
try {
    foreach ($f in (Invoke-GraphAll -Uri "$GraphBase/deviceManagement/assignmentFilters?`$select=id,displayName")) { $filterNames[[string]$f.id] = $f.displayName }
} catch { Write-Verbose 'Could not read assignment filters.' }

$rings = New-Object System.Collections.Generic.List[object]
foreach ($r in ($ringsRaw | Sort-Object displayName)) {
    $assign = Invoke-GraphAll -Uri "$GraphBase/deviceManagement/deviceConfigurations/$($r.id)/assignments"
    $incl = New-Object System.Collections.Generic.List[object]
    $excl = New-Object System.Collections.Generic.List[object]
    $inclNames = New-Object System.Collections.Generic.List[string]
    $exclNames = New-Object System.Collections.Generic.List[string]
    $allDev = $false; $allUsers = $false
    foreach ($a in $assign) {
        $t = $a.target
        $filterText = ''
        if ($t.deviceAndAppManagementAssignmentFilterId -and $t.deviceAndAppManagementAssignmentFilterId -ne '00000000-0000-0000-0000-000000000000') {
            $fn = $filterNames[[string]$t.deviceAndAppManagementAssignmentFilterId]
            if (-not $fn) { $fn = $t.deviceAndAppManagementAssignmentFilterId }
            $filterText = " (filter: $fn, $($t.deviceAndAppManagementAssignmentFilterType), not evaluated)"
        }
        switch ($t.'@odata.type') {
            '#microsoft.graph.groupAssignmentTarget'          { $g = Get-GroupInfo $t.groupId; $incl.Add($g); $inclNames.Add($g.Name + $filterText) }
            '#microsoft.graph.exclusionGroupAssignmentTarget' { $g = Get-GroupInfo $t.groupId; $excl.Add($g); $exclNames.Add($g.Name) }
            '#microsoft.graph.allDevicesAssignmentTarget'     { $allDev = $true; $inclNames.Add('All devices' + $filterText) }
            '#microsoft.graph.allLicensedUsersAssignmentTarget' { $allUsers = $true; $inclNames.Add('All users' + $filterText) }
        }
    }

    $sched = ''
    $is = $r.installationSchedule
    if ($is) {
        if ($is.'@odata.type' -match 'ActiveHours') {
            $s = ([string]$is.activeHoursStart -replace '^(\d{2}:\d{2}).*$', '$1')
            $e = ([string]$is.activeHoursEnd -replace '^(\d{2}:\d{2}).*$', '$1')
            $sched = "Active hours $s to $e"
        }
        elseif ($is.'@odata.type' -match 'Scheduled') {
            $sched = "Scheduled install $($is.scheduledInstallDay) at $(([string]$is.scheduledInstallTime -replace '^(\d{2}:\d{2}).*$', '$1'))"
        }
    }

    $grace = 0
    if ($null -ne $r.deadlineGracePeriodInDays) { $grace = [int]$r.deadlineGracePeriodInDays }
    $qDeadline = $null
    if ($null -ne $r.deadlineForQualityUpdatesInDays) { $qDeadline = [int]$r.deadlineForQualityUpdatesInDays }
    $fDeadline = 'Not set'
    if ($null -ne $r.deadlineForFeatureUpdatesInDays) { $fDeadline = [int]$r.deadlineForFeatureUpdatesInDays }
    $qDefer = 0
    if ($null -ne $r.qualityUpdatesDeferralPeriodInDays) { $qDefer = [int]$r.qualityUpdatesDeferralPeriodInDays }
    $fDefer = 0
    if ($null -ne $r.featureUpdatesDeferralPeriodInDays) { $fDefer = [int]$r.featureUpdatesDeferralPeriodInDays }
    $modified = $null
    if ($r.lastModifiedDateTime) { $modified = ([datetime]$r.lastModifiedDateTime).ToLocalTime() }

    $rings.Add([pscustomobject]@{
        Id = $r.id; Name = $r.displayName; Description = [string]$r.description
        QualityDeferral = $qDefer; QualityDeadline = $qDeadline; Grace = $grace
        FeatureDeferral = $fDefer; FeatureDeadline = $fDeadline
        AutoReboot = $(if ($r.postponeRebootUntilAfterDeadline -eq $true) { 'No' } else { 'Yes' })
        UpdateMode = [string]$r.automaticUpdateMode; Schedule = $sched
        QualityPaused = $(if ($r.qualityUpdatesPaused -eq $true) { 'Yes' } else { 'No' })
        FeaturePaused = $(if ($r.featureUpdatesPaused -eq $true) { 'Yes' } else { 'No' })
        Channel = [string]$r.businessReadyUpdatesOnly
        MicrosoftUpdate = $(if ($r.microsoftUpdateServiceAllowed -eq $false) { 'No' } else { 'Yes' })
        DriversExcluded = $(if ($r.driversExcluded -eq $true) { 'Yes' } else { 'No' })
        Included = $incl; Excluded = $excl; AllDevices = $allDev; AllUsers = $allUsers
        IncludedNames = ($inclNames -join '; '); ExcludedNames = ($exclNames -join '; ')
        Modified = $modified
        Devices = New-Object System.Collections.Generic.List[object]
        Report = ($r.displayName -like $RingNameFilter)
    })
}
Write-Step "Found $($rings.Count) update rings."

# ---- Ring membership per device (include minus exclude) ----
foreach ($dev in $live) {
    foreach ($ring in $rings) {
        $in = $ring.AllDevices -or ($ring.AllUsers -and $dev.UserId)
        if (-not $in) {
            foreach ($g in $ring.Included) {
                if (($dev.EntraId -and $g.Devices.Contains($dev.EntraId)) -or ($dev.UserId -and $g.Users.Contains($dev.UserId))) { $in = $true; break }
            }
        }
        if ($in) {
            foreach ($g in $ring.Excluded) {
                if (($dev.EntraId -and $g.Devices.Contains($dev.EntraId)) -or ($dev.UserId -and $g.Users.Contains($dev.UserId))) { $in = $false; break }
            }
        }
        if ($in) { $dev.Rings.Add($ring); $ring.Devices.Add($dev) }
    }
}

# ---- Device data from the remediation ----
Write-Step "Reading Remediations packages matching '$RemediationName'."
$allPackages = Invoke-GraphAll -Uri "$GraphBase/deviceManagement/deviceHealthScripts?`$select=id,displayName"
$packages = @($allPackages | Where-Object { $_.displayName -like "*$RemediationName*" })
if ($packages.Count -eq 0) {
    Write-Warning "No Remediations package found with '$RemediationName' in its name. All devices will show as no data."
}
$byId = @{}
foreach ($d in $live) { $byId[$d.Id] = $d }
foreach ($p in $packages) {
    Write-Step "Reading device results for '$($p.displayName)'."
    $states = Invoke-GraphAll -Uri ("$GraphBase/deviceManagement/deviceHealthScripts/$($p.id)/deviceRunStates?`$expand=managedDevice(`$select=id)")
    foreach ($s in $states) {
        $mid = $null
        if ($s.managedDevice) { $mid = [string]$s.managedDevice.id }
        if (-not $mid -or -not $byId.ContainsKey($mid)) { continue }
        $dev = $byId[$mid]
        $when = $null
        if ($s.lastStateUpdateDateTime) { $when = ([datetime]$s.lastStateUpdateDateTime).ToLocalTime() }
        $out = [string]$s.preRemediationDetectionScriptOutput
        if (-not $out) { continue }
        if ($dev.DataDate -and $when -and $when -le $dev.DataDate) { continue }
        $dev.RawOutput = $out
        $dev.Data = ConvertFrom-WUHistOutput $out
        $dev.DataDate = $when
    }
}
$withData = @($live | Where-Object { $_.Data }).Count
Write-Step "Device data found for $withData of $($live.Count) live devices."

$script:ErrorCatalog = Get-WUErrorCatalog

# ---- Rows per ring ----
function New-DeviceRow {
    param($Dev, $Ring, $MonthInfo, $Res)
    $os = $Dev.OSVersion
    if ($Dev.Data -and $Dev.Data.OS -and $Dev.Data.OS -match '^\d+\.\d+$') { $os = "10.0.$($Dev.Data.OS)" }
    $et = $null
    if ($Res.ErrorCode) { $et = Get-ErrorText $Res.ErrorCode }
    $ver = ''
    if ($Dev.Data) { $ver = "v$($Dev.Data.Version)" }
    $failed = ''
    if ($null -ne $Res.Failed) { $failed = [int]$Res.Failed }
    $days = ''
    if ($null -ne $Res.DaysAfter) { $days = [double]$Res.DaysAfter }
    $scan = $null
    if ($Dev.Data) { $scan = $Dev.Data.Scan }

    [pscustomobject][ordered]@{
        'Device'                     = $Dev.DeviceName
        'Primary user'               = $Dev.User
        'Model'                      = $Dev.Model
        'OS build (device)'          = $os
        'Updates managed by'         = $Dev.ManagedBy
        'Last check-in'              = Format-Day $Dev.LastSync
        'Update month'               = $MonthInfo.Key
        'KB'                         = $Res.KB
        'Release date'               = Format-Day $MonthInfo.Release
        'Deferral ends'              = Format-Day $Res.DeferralEnd
        'Deadline (incl. grace)'     = $(if ($Res.Deadline) { Format-Day $Res.Deadline } else { 'Not set' })
        'Offered (download started)' = Format-Stamp $Res.Download
        'Installed'                  = Format-Stamp $Res.Installed
        'Days after release'         = $days
        'Failed attempts'            = $failed
        'Error code'                 = $Res.ErrorCode
        'Error (MS Learn)'           = $(if ($et) { $et.Message } else { '' })
        'What it means (MS Learn)'   = $(if ($et) { $et.Description } else { '' })
        'Mitigation (MS Learn)'      = $(if ($et) { $et.Mitigation } else { '' })
        'MS Learn link'              = $(if ($et) { $et.Link } else { '' })
        'Compliance'                 = $Res.Colour
        'Reason'                     = $Res.Reason
        'Device data date'           = Format-Stamp $Dev.DataDate
        'Last WU scan'               = Format-Stamp $scan
        'Device script'              = $ver
        'Entra device ID'            = $Dev.EntraId
    }
}

$summaryRows = New-Object System.Collections.Generic.List[object]
$ringRows = @{}
$latestInstalled = New-Object 'System.Collections.Generic.HashSet[string]'
$errorDevices = @{}   # code -> set of device names

foreach ($ring in $rings) {
    $rows = New-Object System.Collections.Generic.List[object]
    $c = [ordered]@{ Devices = 0; Data = 0; Installed = 0; InWindow = 0; LateEarly = 0; NotInstalled = 0; NoData = 0; Multi = 0 }
    foreach ($dev in ($ring.Devices | Sort-Object Name)) {
        $c.Devices++
        if ($dev.Rings.Count -gt 1) { $c.Multi++ }
        foreach ($mi in $months) {
            $res = Get-MonthResult -Device $dev -Ring $ring -MonthInfo $mi
            $rows.Add((New-DeviceRow -Dev $dev -Ring $ring -MonthInfo $mi -Res $res))
            if ($res.ErrorCode) {
                if (-not $errorDevices.ContainsKey($res.ErrorCode)) { $errorDevices[$res.ErrorCode] = New-Object 'System.Collections.Generic.HashSet[string]' }
                [void]$errorDevices[$res.ErrorCode].Add($dev.DeviceName)
            }
            if ($mi.Key -eq $latest.Key) {
                if (-not $dev.Data) { $c.NoData++ }
                else {
                    $c.Data++
                    if ($res.IsInstalled) {
                        $c.Installed++
                        [void]$latestInstalled.Add($dev.Name)
                        if ($res.InWindow -and $res.Colour -eq 'Green') { $c.InWindow++ } else { $c.LateEarly++ }
                    }
                    else { $c.NotInstalled++ }
                }
            }
        }
    }
    $ringRows[$ring.Id] = [pscustomobject]@{ Rows = $rows; Counts = [pscustomobject]$c }
    $pctI = ''; $pctW = ''
    if ($c.Data -gt 0) { $pctI = [Math]::Round(100 * $c.Installed / $c.Data, 1); $pctW = [Math]::Round(100 * $c.InWindow / $c.Data, 1) }
    $summaryRows.Add([pscustomobject][ordered]@{
        'Update ring'             = $ring.Name
        'Devices'                 = $c.Devices
        'Quality deferral (d)'    = $ring.QualityDeferral
        'Deadline (d)'            = $(if ($null -ne $ring.QualityDeadline) { $ring.QualityDeadline } else { 'Not set' })
        'Grace (d)'               = $ring.Grace
        'Paused'                  = $ring.QualityPaused
        'With device data'        = $c.Data
        "Installed $($latest.Key)" = $c.Installed
        'Installed in window'     = $c.InWindow
        'Installed late / early'  = $c.LateEarly
        'Not installed'           = $c.NotInstalled
        'No device data'          = $c.NoData
        'Installed %'             = $pctI
        'In window %'             = $pctW
        'In more than one ring'   = $c.Multi
        Report                    = $ring.Report
    })
}

$noRing = @($live | Where-Object { $_.Rings.Count -eq 0 })
$multi  = @($live | Where-Object { $_.Rings.Count -gt 1 })
$nrData = @($noRing | Where-Object { $_.Data }).Count
$nrInst = @($noRing | Where-Object { $_.Data -and $_.Data.Months.ContainsKey($latest.Key) -and $_.Data.Months[$latest.Key].Installed }).Count
foreach ($d in $noRing) { if ($d.Data -and $d.Data.Months.ContainsKey($latest.Key) -and $d.Data.Months[$latest.Key].Installed) { [void]$latestInstalled.Add($d.Name) } }
$summaryRows.Add([pscustomobject][ordered]@{
    'Update ring' = 'No update ring'; 'Devices' = $noRing.Count; 'Quality deferral (d)' = ''; 'Deadline (d)' = ''; 'Grace (d)' = ''
    'Paused' = ''; 'With device data' = $nrData; "Installed $($latest.Key)" = $nrInst; 'Installed in window' = ''
    'Installed late / early' = ''; 'Not installed' = ($nrData - $nrInst); 'No device data' = ($noRing.Count - $nrData)
    'Installed %' = ''; 'In window %' = ''; 'In more than one ring' = ''; Report = $true
})

# ===================================================================================================
# Workbook
# ===================================================================================================
Write-Step "Writing $OutputPath"
$usedSheets = New-Object 'System.Collections.Generic.HashSet[string]'
$usedTables = New-Object 'System.Collections.Generic.HashSet[string]'
$pkg = Open-ExcelPackage -Path $OutputPath -Create
$noConvert = @{ NoNumberConversion = '*' }

# ---- Summary ----
$sumName = Get-SafeSheetName 'Summary' $usedSheets
$ws = $pkg.Workbook.Worksheets.Add($sumName)
$liveText = if ($listed) { "$($listed.Count) devices from $(Split-Path $DeviceListPath -Leaf)" } else { "$($scope.Count) Windows devices in Intune" }
$allData = @($live | Where-Object { $_.Data }).Count
$allPct = if ($allData -gt 0) { [Math]::Round(100 * $latestInstalled.Count / $allData, 0) } else { 0 }
$oldScript = @($live | Where-Object { $_.Data -and (Compare-Version $_.Data.Version $MinErrorCodeVersion) }).Count
$tenantText = ''
try { $tenantText = " Tenant $((Get-MgContext).TenantId)." } catch { }

Set-Cell $ws 1 1 'Update ring compliance report' -Bold -Size 16
Set-Cell $ws 2 1 ("Generated {0:yyyy-MM-dd HH:mm} by {1} v{2}.{3} Live devices (checked in within {4} days, {5}): {6}." -f $started, $ScriptName, $ScriptVersion, $tenantText, $LiveDays, $liveText, $live.Count)
Set-Cell $ws 3 1 ("Updates checked: {0}. Device data from remediation: {1}." -f (($months | ForEach-Object { "$($_.Key) (released $(Format-Day $_.Release))" }) -join ', '), $(if ($packages.Count) { ($packages | ForEach-Object { $_.displayName }) -join ', ' } else { "none found matching '$RemediationName'" }))
Set-Cell $ws 4 1 ("Percentages use the latest monthly cumulative update only ({0}, released {1}), one result per device. Installed % = devices that installed it / devices with device data. In window % = installed between the end of the ring deferral and the deadline / devices with device data. Earlier months are on the ring sheets for history." -f $latest.Key, (Format-Day $latest.Release))
Set-Cell $ws 5 1 "Devices in more than one update ring: $($multi.Count)"
Set-Cell $ws 6 1 ("All devices, {0}: {1} of {2} devices with data installed it ({3}%). {4} device(s) have no data from the device yet." -f $latest.Key, $latestInstalled.Count, $allData, $allPct, ($live.Count - $allData))
Set-Cell $ws 7 1 'Row colours on ring sheets: green = installed between the end of the ring deferral and the deadline (incl. grace). Red = early, late, failed, not installed by the deadline, ConfigMgr-managed, or in more than one ring. Grey = not due yet, no deadline on the ring, or no device data.'
if ($oldScript -gt 0) {
    Set-Cell $ws 8 1 ("{0} device(s) are on Detect-WUInstallHistory.ps1 older than {1}, so they cannot report error codes. Upload the latest version ({2}) to the remediation (see the Device script column)." -f $oldScript, $MinErrorCodeVersion, $LatestDeviceScript)
}
else {
    Set-Cell $ws 8 1 "All devices with data are on Detect-WUInstallHistory.ps1 $MinErrorCodeVersion or later."
}

$sumData = @($summaryRows | Where-Object { $_.Report } | Select-Object * -ExcludeProperty Report)
$pkg = @($sumData) | Export-Excel -ExcelPackage $pkg -WorksheetName $sumName -StartRow 9 -TableName (Get-SafeTableName 'Summary' $usedTables) -TableStyle Medium2 -PassThru @noConvert
$ws = $pkg.Workbook.Worksheets[$sumName]
$r = 9 + $sumData.Count + 3
if ($notFound.Count -gt 0) {
    Set-Cell $ws $r 1 "Listed devices not found in Intune ($($notFound.Count)):" -Bold
    Set-Cell $ws ($r + 1) 1 'Device' -Bold
    $i = $r + 2
    foreach ($n in ($notFound | Sort-Object)) { Set-Cell $ws $i 1 $n; $i++ }
    $r = $i + 1
}
$notLive = $scope.Count - $live.Count
if ($notLive -gt 0) { Set-Cell $ws $r 1 "$notLive device(s) not counted because they have not checked in for more than $LiveDays days." }
$widths = @(45, 9, 12, 10, 9, 8, 12, 14, 12, 14, 12, 12, 11, 11, 12)
for ($i = 0; $i -lt $widths.Count; $i++) { $ws.Column($i + 1).Width = $widths[$i] }

# ---- One sheet per ring ----
foreach ($ring in ($rings | Where-Object { $_.Report })) {
    $sheet = Get-SafeSheetName $ring.Name $usedSheets
    $ws = $pkg.Workbook.Worksheets.Add($sheet)
    Set-Cell $ws 1 1 "Update ring: $($ring.Name)" -Bold -Size 14
    Set-Cell $ws 3 1 'Setting' -Bold
    Set-Cell $ws 3 2 'Value' -Bold
    $settings = @(
        @('Update ring', $ring.Name),
        @('Description', $ring.Description),
        @('Quality update deferral (days)', $ring.QualityDeferral),
        @('Quality update deadline (days)', $(if ($null -ne $ring.QualityDeadline) { $ring.QualityDeadline } else { 'Not set' })),
        @('Grace period (days)', $ring.Grace),
        @('Feature update deferral (days)', $ring.FeatureDeferral),
        @('Feature update deadline (days)', $ring.FeatureDeadline),
        @('Auto reboot before deadline', $ring.AutoReboot),
        @('Automatic update behaviour', $ring.UpdateMode),
        @('Install schedule / active hours', $ring.Schedule),
        @('Quality updates paused', $ring.QualityPaused),
        @('Feature updates paused', $ring.FeaturePaused),
        @('Servicing channel / pre-release', $ring.Channel),
        @('Microsoft product updates', $ring.MicrosoftUpdate),
        @('Windows drivers excluded', $ring.DriversExcluded),
        @('Assigned groups', $ring.IncludedNames),
        @('Excluded groups', $ring.ExcludedNames),
        @('Last modified', (Format-Stamp $ring.Modified))
    )
    $row = 4
    foreach ($s in $settings) { Set-Cell $ws $row 1 $s[0] -Bold; Set-Cell $ws $row 2 $s[1]; $row++ }

    $data = $ringRows[$ring.Id]
    $cnt = $data.Counts
    if ($data.Rows.Count -eq 0) {
        Set-Cell $ws 24 1 'No devices.'
        $ws.Column(1).Width = 34; $ws.Column(2).Width = 80
        continue
    }
    $pi = if ($cnt.Data) { [Math]::Round(100 * $cnt.Installed / $cnt.Data, 1) } else { 0 }
    $pw = if ($cnt.Data) { [Math]::Round(100 * $cnt.InWindow / $cnt.Data, 1) } else { 0 }
    Set-Cell $ws 23 1 ("Latest cumulative update {0}: devices {1}, with device data {2}, installed {3} ({4}%), installed within the ring window {5} ({6}%), not installed {7}, no data {8}. Earlier months are shown for history only." -f $latest.Key, $cnt.Devices, $cnt.Data, $cnt.Installed, $pi, $cnt.InWindow, $pw, $cnt.NotInstalled, $cnt.NoData) -Bold

    $pkg = @($data.Rows) | Export-Excel -ExcelPackage $pkg -WorksheetName $sheet -StartRow 24 -TableName (Get-SafeTableName $ring.Name $usedTables) -TableStyle Light1 -PassThru @noConvert
    $ws = $pkg.Workbook.Worksheets[$sheet]
    $last = 24 + $data.Rows.Count
    $lastCol = Get-ColumnLetter $RingColumns.Count
    Add-ColourRules -Ws $ws -Range "A25:$lastCol$last" -FirstCell '$U25'
    for ($i = 0; $i -lt $RingColumnWidths.Count; $i++) { $ws.Column($i + 1).Width = $RingColumnWidths[$i] }
    $ws.Column(1).Width = [Math]::Max($RingColumnWidths[0], 34)   # setting names
    $ws.View.FreezePanes(25, 2)
}

# ---- No update ring ----
$sheet = Get-SafeSheetName 'No update ring' $usedSheets
$ws = $pkg.Workbook.Worksheets.Add($sheet)
Set-Cell $ws 1 1 'Devices in no update ring' -Bold -Size 14
Set-Cell $ws 3 1 'Setting' -Bold; Set-Cell $ws 3 2 'Value' -Bold
Set-Cell $ws 4 1 'Note' -Bold
Set-Cell $ws 4 2 'Live devices that are not in any update ring. Without a ring, Windows Update uses its defaults or other policy (Group Policy, ConfigMgr).'
if ($noRing.Count -eq 0) {
    Set-Cell $ws 7 1 'No devices.'
}
else {
    $nr = foreach ($d in $noRing) {
        $m = $null
        if ($d.Data -and $d.Data.Months.ContainsKey($latest.Key)) { $m = $d.Data.Months[$latest.Key] }
        [pscustomobject][ordered]@{
            'Device' = $d.DeviceName; 'Primary user' = $d.User; 'Model' = $d.Model; 'OS build (device)' = $d.OSVersion
            'Updates managed by' = $d.ManagedBy; 'Last check-in' = Format-Day $d.LastSync
            "KB $($latest.Key)" = $(if ($m) { $m.KB } else { '' })
            "Installed $($latest.Key)" = $(if ($m) { Format-Stamp $m.Installed } else { '' })
            'Device script' = $(if ($d.Data) { "v$($d.Data.Version)" } else { '' })
            'Entra device ID' = $d.EntraId
        }
    }
    $pkg = @($nr) | Export-Excel -ExcelPackage $pkg -WorksheetName $sheet -StartRow 7 -TableName (Get-SafeTableName 'NoUpdateRing' $usedTables) -TableStyle Light1 -PassThru @noConvert
    $ws = $pkg.Workbook.Worksheets[$sheet]
}
$w = @(18, 100, 34, 18, 12, 13, 14, 17, 9, 38)
for ($i = 0; $i -lt $w.Count; $i++) { $ws.Column($i + 1).Width = $w[$i] }

# ---- Multiple rings ----
$sheet = Get-SafeSheetName 'Multiple rings' $usedSheets
$ws = $pkg.Workbook.Worksheets.Add($sheet)
Set-Cell $ws 1 1 'Devices in more than one update ring' -Bold -Size 14
Set-Cell $ws 3 1 'Setting' -Bold; Set-Cell $ws 3 2 'Value' -Bold
Set-Cell $ws 4 1 'Note' -Bold
Set-Cell $ws 4 2 'Devices targeted by more than one update ring after include and exclude groups are applied. Windows applies conflicting settings unpredictably.'
Set-Cell $ws 5 1 'Fix' -Bold
Set-Cell $ws 5 2 "Add the device's ring group to the exclude groups of the other rings, or remove it from the extra include group."
if ($multi.Count -eq 0) {
    Set-Cell $ws 8 1 'No devices.'
}
else {
    $mr = foreach ($d in $multi) {
        [pscustomobject][ordered]@{
            'Device' = $d.DeviceName; 'Primary user' = $d.User
            'Update rings' = ($d.Rings | ForEach-Object { $_.Name }) -join '; '
            'Ring count' = $d.Rings.Count; 'Last check-in' = Format-Day $d.LastSync; 'Entra device ID' = $d.EntraId
        }
    }
    $pkg = @($mr) | Export-Excel -ExcelPackage $pkg -WorksheetName $sheet -StartRow 8 -TableName (Get-SafeTableName 'MultipleRings' $usedTables) -TableStyle Light1 -PassThru @noConvert
    $ws = $pkg.Workbook.Worksheets[$sheet]
}
$w = @(18, 100, 80, 10, 13, 38)
for ($i = 0; $i -lt $w.Count; $i++) { $ws.Column($i + 1).Width = $w[$i] }

# ---- Errors ----
$sheet = Get-SafeSheetName 'Errors' $usedSheets
$ws = $pkg.Workbook.Worksheets.Add($sheet)
Set-Cell $ws 1 1 "Windows Update error codes reported by devices (last failed attempt per month), with Microsoft's text from MS Learn" -Bold -Size 14
if ($errorDevices.Count -eq 0) {
    Set-Cell $ws 3 1 'No error codes reported.'
}
else {
    $er = foreach ($code in ($errorDevices.Keys | Sort-Object { $errorDevices[$_].Count } -Descending)) {
        $et = Get-ErrorText $code
        [pscustomobject][ordered]@{
            'Error code' = $code; 'Devices' = $errorDevices[$code].Count
            'Device list' = (@($errorDevices[$code]) | Sort-Object) -join ', '
            'Error (MS Learn)' = $et.Message; 'What it means (MS Learn)' = $et.Description
            'Mitigation (MS Learn)' = $et.Mitigation; 'MS Learn link' = $et.Link
        }
    }
    $pkg = @($er) | Export-Excel -ExcelPackage $pkg -WorksheetName $sheet -StartRow 3 -TableName (Get-SafeTableName 'Errors' $usedTables) -TableStyle Medium2 -PassThru @noConvert
    $ws = $pkg.Workbook.Worksheets[$sheet]
}
$w = @(14, 9, 60, 36, 60, 60, 45)
for ($i = 0; $i -lt $w.Count; $i++) { $ws.Column($i + 1).Width = $w[$i] }
for ($i = 4; $i -le $ws.Dimension.End.Row; $i++) { foreach ($c in 3, 5, 6) { $ws.Cells[$i, $c].Style.WrapText = $true } }

# ---- Column guide ----
$sheet = Get-SafeSheetName 'Column guide' $usedSheets
$ws = $pkg.Workbook.Worksheets.Add($sheet)
Set-Cell $ws 1 1 'Column guide' -Bold -Size 14
Set-Cell $ws 2 1 "Field names from the Windows Update for Business reports schema: $SchemaUrl"
$guide = @(
    @('Device', 'DeviceName', 'Device name in Intune.'),
    @('Primary user', '', 'Primary user of the device in Intune.'),
    @('Model', '', 'Hardware model from Intune.'),
    @('OS build (device)', '', 'Current OS build with revision, as reported by the device. Falls back to the Intune OS version when the device has not reported.'),
    @('Updates managed by', '', 'Intune, or ConfigMgr when the device is co-managed and the Windows Update policies workload is still with ConfigMgr. Rings do not apply to ConfigMgr-managed devices.'),
    @('Last check-in', '', 'Last time the device synced with Intune.'),
    @('Update month', '', 'Month of the monthly cumulative update (Patch Tuesday release).'),
    @('KB', 'TargetKBNumber', 'KB the device installed or tried to install for that month. "(none, covered by KB...)" means a later cumulative was installed instead.'),
    @('Release date', 'UpdateReleaseTime', 'Patch Tuesday (second Tuesday) of the update month.'),
    @('Deferral ends', '', 'Release date plus the ring quality update deferral. Installing before this date is early.'),
    @('Deadline (incl. grace)', '', 'Deferral end plus the ring quality update deadline plus grace period. Installing after this date is late.'),
    @('Offered (download started)', 'OfferReceivedTime (nearest equivalent)', 'When Windows Update started downloading the update (WindowsUpdateClient event 44). Empty when the device event log no longer holds it.'),
    @('Installed', 'UpdateInstalledTime', 'First successful install from the device Windows Update history (local time).'),
    @('Days after release', '', 'Days between the release date and the install.'),
    @('Failed attempts', '', 'Failed or aborted install attempts recorded in the device Windows Update history for that month.'),
    @('Error code', '', 'HRESULT of the most recent failed attempt that month (device script 1.2 or later).'),
    @('Error (MS Learn)', '', 'Error name from the Windows Update error reference on MS Learn.'),
    @('What it means (MS Learn)', '', 'Description from MS Learn.'),
    @('Mitigation (MS Learn)', '', 'Mitigation from the MS Learn common Windows Update errors page, where listed.'),
    @('MS Learn link', '', 'Page the error text came from.'),
    @('Compliance', '', 'Green, Red or Grey. See the colour key on the Summary sheet.'),
    @('Reason', '', 'Why the row has that colour.'),
    @('Device data date', '', 'When the device last reported its data through the remediation.'),
    @('Last WU scan', '', 'Last successful Windows Update scan on the device (local time).'),
    @('Device script', '', 'Version of Detect-WUInstallHistory.ps1 that produced the data.'),
    @('Entra device ID', 'AzureADDeviceId', 'Microsoft Entra device ID.')
)
$gr = foreach ($g in $guide) { [pscustomobject][ordered]@{ 'Column' = $g[0]; 'WUfB reports field (UCClientUpdateStatus)' = $g[1]; 'Meaning' = $g[2] } }
$pkg = @($gr) | Export-Excel -ExcelPackage $pkg -WorksheetName $sheet -StartRow 3 -TableName (Get-SafeTableName 'ColumnGuide' $usedTables) -TableStyle Medium2 -PassThru @noConvert
$ws = $pkg.Workbook.Worksheets[$sheet]
$ws.Column(1).Width = 28; $ws.Column(2).Width = 40; $ws.Column(3).Width = 110

$pkg.Workbook.Worksheets[$sumName].Select()
Close-ExcelPackage $pkg

Write-Step ("Done in {0:N0} s. {1}" -f ((Get-Date) - $started).TotalSeconds, $OutputPath)
[pscustomobject]@{
    Report             = $OutputPath
    LiveDevices        = $live.Count
    WithDeviceData     = $allData
    InstalledLatest    = $latestInstalled.Count
    LatestMonth        = $latest.Key
    InMultipleRings    = $multi.Count
    InNoRing           = $noRing.Count
    NotFoundInIntune   = $notFound.Count
}
